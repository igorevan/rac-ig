# Indicativo de prescrição não estruturada ou medicamento não identificado - Guia de Implementação do Registro de Atendimento Clínico (RAC) da RNDS v1.0.0

## ValueSet: Indicativo de prescrição não estruturada ou medicamento não identificado 

 **References** 

* [Prescrição de Medicamento](StructureDefinition-BRPrescricaoMedicamento.md)

### Definição lógica (CLD)

 

### Expansão

-------

 [Descrição do(s) quadro(s) acima](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "BRPrescricaoNaoEstruturada",
  "meta" : {
    "lastUpdated" : "2020-03-11T19:14:51.806+00:00"
  },
  "language" : "en",
  "url" : "http://www.saude.gov.br/fhir/r4/ValueSet/BRPrescricaoNaoEstruturada",
  "version" : "1.0.0",
  "name" : "BRPrescricaoNaoEstruturada",
  "title" : "Indicativo de prescrição não estruturada ou medicamento não identificado",
  "status" : "active",
  "experimental" : false,
  "date" : "2020-06-27T19:15:12.2909517+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Indicativo de prescrição não estruturada ou medicamento não identificado.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "immutable" : false,
  "compose" : {
    "include" : [{
      "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRDadoAusenteOuDesconhecido",
      "concept" : [{
        "code" : "no-medication-info",
        "display" : "No information about medications"
      },
      {
        "code" : "no-known-medications",
        "display" : "No known medications"
      }]
    }]
  }
}

```
