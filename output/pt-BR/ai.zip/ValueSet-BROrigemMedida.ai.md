# Origem de Medição - Guia de Implementação do Registro de Atendimento Clínico (RAC) da RNDS v1.0.0

## ValueSet: Origem de Medição 

 **References** 

* [Origem da Medição](StructureDefinition-BROrigemMedida.md)

### Definição lógica (CLD)

 

### Expansão

-------

 [Descrição do(s) quadro(s) acima](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "BROrigemMedida",
  "language" : "en",
  "url" : "http://www.saude.gov.br/fhir/r4/ValueSet/BROrigemMedida",
  "version" : "1.0.0",
  "name" : "BROrigemMedida",
  "title" : "Origem de Medição",
  "status" : "active",
  "experimental" : false,
  "date" : "2022-05-23T08:50:09.8385573+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "ValueSet utilizado para definir o tipo de medição corporal adotada.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "immutable" : false,
  "copyright" : "This material contains content from LOINC (http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the license at http://loinc.org/license. LOINC® is a registered United States trademark of Regenstrief Institute, Inc",
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "3138-5",
        "display" : "Body height Stated",
        "designation" : [{
          "language" : "pt-BR",
          "value" : "Relatado"
        }]
      },
      {
        "code" : "3137-7",
        "display" : "Body height Measured",
        "designation" : [{
          "language" : "pt-BR",
          "value" : "Medido"
        }]
      }]
    }]
  }
}

```
