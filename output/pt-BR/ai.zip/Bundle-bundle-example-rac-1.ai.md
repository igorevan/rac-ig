# Bundle de Exemplo do Registro de Atendimento Clínico (RAC) - Paciente Identificado - Guia de Implementação do Registro de Atendimento Clínico (RAC) da RNDS v1.0.0-release

## Exemplo Bundle: Bundle de Exemplo do Registro de Atendimento Clínico (RAC) - Paciente Identificado



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundle-example-rac-1",
  "meta" : {
    "lastUpdated" : "2022-05-09T18:11:18.946402Z"
  },
  "identifier" : {
    "system" : "http://www.saude.gov.br/fhir/r4/NamingSystem/BRRNDS-3061",
    "value" : "94641731210"
  },
  "type" : "document",
  "timestamp" : "2022-05-09T18:11:19.005486Z",
  "entry" : [{
    "fullUrl" : "urn:uuid:5df38718-3047-4e95-8a90-413ec48e741a",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "5df38718-3047-4e95-8a90-413ec48e741a",
      "meta" : {
        "lastUpdated" : "2022-05-09T17:28:34.132629Z",
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRRegistroAtendimentoClinico"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_5df38718-3047-4e95-8a90-413ec48e741a\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Composition 5df38718-3047-4e95-8a90-413ec48e741a</b></p><a name=\"5df38718-3047-4e95-8a90-413ec48e741a\"> </a><a name=\"hc5df38718-3047-4e95-8a90-413ec48e741a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Última atualização: 2022-05-09 17:28:34+0000</p><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRRegistroAtendimentoClinico.html\">Registro de Atendimento Clínico</a></p></div><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoDocumento RAC}\">Registro de Atendimento Clínico</span></p><p><b>category</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRModalidadeAssistencial 04}\">Atenção Hospitalar</span></p><p><b>date</b>: 2022-05-09 15:36:40-0300</p><p><b>author</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0</code>/3191384</p><p><b>title</b>: Registro de Atendimento Clínico</p></div>"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoDocumento",
          "code" : "RAC"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRModalidadeAssistencial",
          "code" : "04"
        }]
      }],
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "819217217061851"
        }
      },
      "date" : "2022-05-09T15:36:40.157-03:00",
      "author" : [{
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0",
          "value" : "3191384"
        }
      }],
      "title" : "Registro de Atendimento Clínico",
      "section" : [{
        "entry" : [{
          "reference" : "urn:uuid:d12070e4-3461-4fa0-95a6-76fd435cb403"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:2af3c6c9-87ed-4f01-afec-ee8dc7df9951"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:1031de4c-be76-48d3-85de-75274dba036c"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:bd2466a4-18af-4c3b-899c-b6cccc51acff"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:84e657cc-159f-4271-b0a1-38a76e28c624"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:5302c1a3-2190-44aa-a9a2-382d27fe9230"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:8264b367-cce0-4a76-b8d4-f9dcea39ee3d"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:0509d090-3594-4f07-b32c-2a97da6a6fed"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:059208f1-0083-4f81-a472-87b32140b31d"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:98b0e992-9c95-464a-a661-6c42a4bd310c"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:efcce484-7226-435f-8c7c-b1d703079444"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:d78c1159-1473-4bef-9096-5ba98384e950"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:32e99ca6-4e7d-4d56-8f25-612dd1c51a71"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:19011496-44a1-4048-8e1b-558b82b1caf1"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:34fe98d3-e5fc-491e-a125-c90ab2abb83a"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:48e799d2-1087-4461-af34-8ecdd5bce316"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:d2176159-0427-42da-a727-636bbb042d97"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:22f0baea-50d7-429b-8767-3b07c9a8120e"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:d12070e4-3461-4fa0-95a6-76fd435cb403",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "d12070e4-3461-4fa0-95a6-76fd435cb403",
      "meta" : {
        "lastUpdated" : "2022-05-09T17:31:16.551205Z",
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRContatoAssistencial-1.0"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_d12070e4-3461-4fa0-95a6-76fd435cb403\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Encounter d12070e4-3461-4fa0-95a6-76fd435cb403</b></p><a name=\"d12070e4-3461-4fa0-95a6-76fd435cb403\"> </a><a name=\"hcd12070e4-3461-4fa0-95a6-76fd435cb403\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Última atualização: 2022-05-09 17:31:16+0000</p><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRContatoAssistencial-1.0.html\">Contato Assistencial</a></p></div><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"CodeSystem-BRModalidadeAssistencial.html#BRModalidadeAssistencial-04\">Modalidade Assistencial: 04</a> (Atenção Hospitalar)</p><p><b>priority</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRCaraterAtendimento 01}\">Eletivo</span></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/819217217061851</p><blockquote><p><b>participant</b></p><p><b>Ocupação</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRCBO 223505}\">ENFERMEIRO</span></p><p><b>Identificador Nacional de Equipe</b>: 2</p><p><b>type</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRResponsabilidadeParticipante solicitante}\">Profissional que solicitou o Contato Assistencial</span></p><p><b>individual</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRLotacaoProfissional-1.0</code>/815113499149874-3191384</p></blockquote><p><b>period</b>: 2022-04-09 15:36:40-0300 --&gt; 2022-05-09 15:46:48-0300</p><p><b>reasonReference</b>: <a href=\"Bundle-bundle-example-rac-2.html#urn-uuid-c9f83c17-3081-4233-b1e4-f629c58d6813\">Observation Annotation comment [Interpretation] Narrative</a></p><blockquote><p><b>diagnosis</b></p><p><b>condition</b>: <a href=\"Bundle-bundle-example-rac-2.html#urn-uuid-2af3c6c9-87ed-4f01-afec-ee8dc7df9951\">Condition Varizes esofagianas sem sangramento</a></p><p><b>use</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRPapelProblemaDiagnostico NAD}\">Diagnóstico não presente na admissão</span></p><p><b>rank</b>: 1</p></blockquote><blockquote><p><b>diagnosis</b></p><p><b>condition</b>: <a href=\"Bundle-bundle-example-rac-2.html#urn-uuid-1031de4c-be76-48d3-85de-75274dba036c\">Procedure CONSULTA DE PROFISSIONAIS DE NIVEL SUPERIOR NA ATENÇÃO ESPECIALIZADA (EXCETO MÉDICO)</a></p></blockquote><h3>Hospitalizations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>AdmitSource</b></td><td><b>DischargeDisposition</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRProcedencia 99}\">Informação ausente no modelo de origem</span></td><td><span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRMotivoDesfecho 06}\">Óbito</span></td></tr></table><h3>Locations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Location</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundle-example-rac-2.html#urn-uuid-6f2180c5-32aa-49cf-8b66-b2581465513c\">Estabelecimento de saúde</a></td></tr></table><p><b>serviceProvider</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0</code>/162338254590005</p></div>"
      },
      "status" : "finished",
      "class" : {
        "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRModalidadeAssistencial",
        "code" : "04"
      },
      "priority" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCaraterAtendimento",
          "code" : "01"
        }]
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "819217217061851"
        }
      },
      "participant" : [{
        "extension" : [{
          "url" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BROcupacao-1.0",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCBO",
              "code" : "223505"
            }]
          }
        },
        {
          "url" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIdentificacaoEquipe-1.0",
          "valueInteger" : 2
        }],
        "type" : [{
          "coding" : [{
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRResponsabilidadeParticipante",
            "code" : "solicitante"
          }]
        }],
        "individual" : {
          "identifier" : {
            "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRLotacaoProfissional-1.0",
            "value" : "815113499149874-3191384"
          }
        }
      }],
      "period" : {
        "start" : "2022-04-09T15:36:40.157-03:00",
        "end" : "2022-05-09T15:46:48.534-03:00"
      },
      "reasonReference" : [{
        "reference" : "urn:uuid:c9f83c17-3081-4233-b1e4-f629c58d6813"
      }],
      "diagnosis" : [{
        "condition" : {
          "reference" : "urn:uuid:2af3c6c9-87ed-4f01-afec-ee8dc7df9951"
        },
        "use" : {
          "coding" : [{
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRPapelProblemaDiagnostico",
            "code" : "NAD"
          }]
        },
        "rank" : 1
      },
      {
        "condition" : {
          "extension" : [{
            "url" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRFinanciamento-1.0",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRFinanciamento",
                "code" : "01"
              }]
            }
          }],
          "reference" : "urn:uuid:1031de4c-be76-48d3-85de-75274dba036c"
        }
      }],
      "hospitalization" : {
        "extension" : [{
          "url" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BROutrasInformacoes",
          "valueAnnotation" : {
            "time" : "2022-05-09",
            "text" : "Paciente se queixando da presença de sangue na saliva."
          }
        }],
        "admitSource" : {
          "coding" : [{
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRProcedencia",
            "code" : "99"
          }]
        },
        "dischargeDisposition" : {
          "coding" : [{
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRMotivoDesfecho",
            "code" : "06"
          }]
        }
      },
      "location" : [{
        "location" : {
          "reference" : "urn:uuid:6f2180c5-32aa-49cf-8b66-b2581465513c"
        }
      }],
      "serviceProvider" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0",
          "value" : "162338254590005"
        }
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:2af3c6c9-87ed-4f01-afec-ee8dc7df9951",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "2af3c6c9-87ed-4f01-afec-ee8dc7df9951",
      "meta" : {
        "lastUpdated" : "2022-05-09T17:37:55.000322Z",
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRProblemaDiagnostico"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_2af3c6c9-87ed-4f01-afec-ee8dc7df9951\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Condition 2af3c6c9-87ed-4f01-afec-ee8dc7df9951</b></p><a name=\"2af3c6c9-87ed-4f01-afec-ee8dc7df9951\"> </a><a name=\"hc2af3c6c9-87ed-4f01-afec-ee8dc7df9951\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Última atualização: 2022-05-09 17:37:55+0000</p><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRProblemaDiagnostico.html\">Problema / Diagnóstico</a></p></div><p><b>clinicalStatus</b>: <span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>category</b>: <span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/condition-category encounter-diagnosis}\">Encounter Diagnosis</span></p><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRCID10 I859}\">Varizes esofagianas sem sangramento</span></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/819217217061851</p><p><b>note</b>: </p><blockquote><div><p>Varizes esofagianas sem sangramento.</p>\n</div></blockquote></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
          "code" : "encounter-diagnosis"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCID10",
          "code" : "I859"
        }]
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "819217217061851"
        }
      },
      "note" : [{
        "text" : "Varizes esofagianas sem sangramento."
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:1031de4c-be76-48d3-85de-75274dba036c",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "1031de4c-be76-48d3-85de-75274dba036c",
      "meta" : {
        "lastUpdated" : "2022-05-09T17:39:08.701859Z",
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRProcedimentoRealizado-1.0"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_1031de4c-be76-48d3-85de-75274dba036c\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Procedure 1031de4c-be76-48d3-85de-75274dba036c</b></p><a name=\"1031de4c-be76-48d3-85de-75274dba036c\"> </a><a name=\"hc1031de4c-be76-48d3-85de-75274dba036c\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Última atualização: 2022-05-09 17:39:08+0000</p><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRProcedimentoRealizado-1.0.html\">Procedimento Realizado</a></p></div><p><b>Quantidade</b>: 23</p><p><b>identifier</b>: Código de Autorização/462921313170263</p><p><b>status</b>: Completed</p><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRTabelaSUS 0301010048}\">CONSULTA DE PROFISSIONAIS DE NIVEL SUPERIOR NA ATENÇÃO ESPECIALIZADA (EXCETO MÉDICO)</span></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/819217217061851</p><p><b>performed</b>: 2022-05-09 15:36:40-0300</p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Function</b></td><td><b>Actor</b></td><td><b>OnBehalfOf</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRCBO 223605}\">FISIOTERAPEUTA GERAL</span></td><td>Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRLotacaoProfissional-1.0</code>/815113499149874-3191384</td><td>Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0</code>/162338254590005</td></tr></table></div>"
      },
      "extension" : [{
        "url" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRQuantidade-1.0",
        "valuePositiveInt" : 23
      }],
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoIdentificador",
            "code" : "AUTH"
          }]
        },
        "value" : "462921313170263"
      }],
      "status" : "completed",
      "code" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTabelaSUS",
          "code" : "0301010048"
        }]
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "819217217061851"
        }
      },
      "performedDateTime" : "2022-05-09T15:36:40.157-03:00",
      "performer" : [{
        "extension" : [{
          "url" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIdentificacaoEquipe-1.0",
          "valueInteger" : 2
        }],
        "function" : {
          "coding" : [{
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCBO",
            "code" : "223605"
          }]
        },
        "actor" : {
          "identifier" : {
            "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRLotacaoProfissional-1.0",
            "value" : "815113499149874-3191384"
          }
        },
        "onBehalfOf" : {
          "identifier" : {
            "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0",
            "value" : "162338254590005"
          }
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:c9f83c17-3081-4233-b1e4-f629c58d6813",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "c9f83c17-3081-4233-b1e4-f629c58d6813",
      "meta" : {
        "lastUpdated" : "2022-05-09T17:37:55.000322Z",
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRObservacaoDescritiva-1.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_c9f83c17-3081-4233-b1e4-f629c58d6813\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Observation c9f83c17-3081-4233-b1e4-f629c58d6813</b></p><a name=\"c9f83c17-3081-4233-b1e4-f629c58d6813\"> </a><a name=\"hcc9f83c17-3081-4233-b1e4-f629c58d6813\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Última atualização: 2022-05-09 17:37:55+0000</p><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRObservacaoDescritiva-1.0.html\">Observação Descritiva</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Códigos:{http://loinc.org 48767-8}\">Annotation comment [Interpretation] Narrative</span></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/819217217061851</p><p><b>issued</b>: 2022-05-09 17:39:08+0000</p><p><b>value</b>: Varizes esofagianas sem sangramento.</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "48767-8"
        }]
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "819217217061851"
        }
      },
      "issued" : "2022-05-09T17:39:08.701859Z",
      "valueString" : "Varizes esofagianas sem sangramento."
    }
  },
  {
    "fullUrl" : "urn:uuid:6f2180c5-32aa-49cf-8b66-b2581465513c",
    "resource" : {
      "resourceType" : "Location",
      "id" : "6f2180c5-32aa-49cf-8b66-b2581465513c",
      "meta" : {
        "lastUpdated" : "2022-05-09T17:37:55.000322Z",
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRLocalAtendimento-1.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Location_6f2180c5-32aa-49cf-8b66-b2581465513c\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Location 6f2180c5-32aa-49cf-8b66-b2581465513c</b></p><a name=\"6f2180c5-32aa-49cf-8b66-b2581465513c\"> </a><a name=\"hc6f2180c5-32aa-49cf-8b66-b2581465513c\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Última atualização: 2022-05-09 17:37:55+0000</p><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRLocalAtendimento-1.0.html\">Local de Atendimento</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Estabelecimento de saúde</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"The status of the location\">Status:</td><td>Active</td><td style=\"background-color: #f3f5da\" title=\"Whether this describes a specific location, or a class of locations\">Mode:</td><td>Kind</td></tr></table></div>"
      },
      "status" : "active",
      "name" : "Estabelecimento de saúde",
      "mode" : "kind"
    }
  },
  {
    "fullUrl" : "urn:uuid:bd2466a4-18af-4c3b-899c-b6cccc51acff",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "bd2466a4-18af-4c3b-899c-b6cccc51acff",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRMedidaObservada"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_bd2466a4-18af-4c3b-899c-b6cccc51acff\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Observation bd2466a4-18af-4c3b-899c-b6cccc51acff</b></p><a name=\"bd2466a4-18af-4c3b-899c-b6cccc51acff\"> </a><a name=\"hcbd2466a4-18af-4c3b-899c-b6cccc51acff\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRMedidaObservada.html\">Medida Observada</a></p></div><p><b>Origem da Medição</b>: <span title=\"Códigos:{http://loinc.org 3137-7}\">Bdy height Measured</span></p><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Códigos:{http://loinc.org 8302-2}\">Bdy height</span></p><p><b>value</b>: 1.83 m<span style=\"background: LightGoldenRodYellow\"> (Detalhes: UCUM códigom = 'm')</span></p><p><b>method</b>: <span title=\"Códigos:{http://loinc.org LA11870-5}\">Standing</span></p></div>"
      },
      "extension" : [{
        "url" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BROrigemMedida",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "3137-7"
          }]
        }
      }],
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "8302-2"
        }]
      },
      "valueQuantity" : {
        "value" : 1.83,
        "system" : "http://unitsofmeasure.org",
        "code" : "m"
      },
      "method" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA11870-5"
        }]
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:84e657cc-159f-4271-b0a1-38a76e28c624",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "84e657cc-159f-4271-b0a1-38a76e28c624",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRMedidaObservada"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_84e657cc-159f-4271-b0a1-38a76e28c624\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Observation 84e657cc-159f-4271-b0a1-38a76e28c624</b></p><a name=\"84e657cc-159f-4271-b0a1-38a76e28c624\"> </a><a name=\"hc84e657cc-159f-4271-b0a1-38a76e28c624\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRMedidaObservada.html\">Medida Observada</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Códigos:{http://loinc.org 8280-0}\">Circumf.at umbilicus by Tape Measure</span></p><p><b>value</b>: 135.5 cm<span style=\"background: LightGoldenRodYellow\"> (Detalhes: UCUM códigocm = 'cm')</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "8280-0"
        }]
      },
      "valueQuantity" : {
        "value" : 135.5,
        "system" : "http://unitsofmeasure.org",
        "code" : "cm"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:5302c1a3-2190-44aa-a9a2-382d27fe9230",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "5302c1a3-2190-44aa-a9a2-382d27fe9230",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRMedidaObservada"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_5302c1a3-2190-44aa-a9a2-382d27fe9230\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Observation 5302c1a3-2190-44aa-a9a2-382d27fe9230</b></p><a name=\"5302c1a3-2190-44aa-a9a2-382d27fe9230\"> </a><a name=\"hc5302c1a3-2190-44aa-a9a2-382d27fe9230\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRMedidaObservada.html\">Medida Observada</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Códigos:{http://loinc.org 8665-2}\">Date last menstrual period</span></p><p><b>value</b>: 2022-05-23</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "8665-2"
        }]
      },
      "valueDateTime" : "2022-05-23"
    }
  },
  {
    "fullUrl" : "urn:uuid:8264b367-cce0-4a76-b8d4-f9dcea39ee3d",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "8264b367-cce0-4a76-b8d4-f9dcea39ee3d",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRMedidaObservada"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_8264b367-cce0-4a76-b8d4-f9dcea39ee3d\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Observation 8264b367-cce0-4a76-b8d4-f9dcea39ee3d</b></p><a name=\"8264b367-cce0-4a76-b8d4-f9dcea39ee3d\"> </a><a name=\"hc8264b367-cce0-4a76-b8d4-f9dcea39ee3d\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRMedidaObservada.html\">Medida Observada</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Códigos:{http://loinc.org 56832-9}\">Acused substance</span></p><p><b>effective</b>: Código </p><p><b>value</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoSubstanciaUso alcool}\">Bebidas Alcóolicas</span></p><p><b>note</b>: </p><blockquote><div><p>Uso ocasional de cannabis.</p>\n</div></blockquote></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "56832-9"
        }]
      },
      "effectiveTiming" : {
        "code" : {
          "coding" : [{
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRFrequenciaUsoSubstancia",
            "code" : "uma-ou-duas"
          }]
        }
      },
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoSubstanciaUso",
          "code" : "alcool"
        }]
      },
      "note" : [{
        "text" : "Uso ocasional de cannabis."
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:0509d090-3594-4f07-b32c-2a97da6a6fed",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "0509d090-3594-4f07-b32c-2a97da6a6fed",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRMedidaObservada"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_0509d090-3594-4f07-b32c-2a97da6a6fed\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Observation 0509d090-3594-4f07-b32c-2a97da6a6fed</b></p><a name=\"0509d090-3594-4f07-b32c-2a97da6a6fed\"> </a><a name=\"hc0509d090-3594-4f07-b32c-2a97da6a6fed\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRMedidaObservada.html\">Medida Observada</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Códigos:{http://loinc.org 11885-1}\">GA Est from LMP</span></p><p><b>value</b>: 3.5 wk<span style=\"background: LightGoldenRodYellow\"> (Detalhes: UCUM códigowk = 'wk')</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11885-1"
        }]
      },
      "valueQuantity" : {
        "value" : 3.5,
        "system" : "http://unitsofmeasure.org",
        "code" : "wk"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:059208f1-0083-4f81-a472-87b32140b31d",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "059208f1-0083-4f81-a472-87b32140b31d",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRMedidaObservada"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_059208f1-0083-4f81-a472-87b32140b31d\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Observation 059208f1-0083-4f81-a472-87b32140b31d</b></p><a name=\"059208f1-0083-4f81-a472-87b32140b31d\"> </a><a name=\"hc059208f1-0083-4f81-a472-87b32140b31d\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRMedidaObservada.html\">Medida Observada</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Códigos:{http://loinc.org 9843-4}\">Head Circumf OCF</span></p><p><b>value</b>: 45.5 cm<span style=\"background: LightGoldenRodYellow\"> (Detalhes: UCUM códigocm = 'cm')</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "9843-4"
        }]
      },
      "valueQuantity" : {
        "value" : 45.5,
        "system" : "http://unitsofmeasure.org",
        "code" : "cm"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:98b0e992-9c95-464a-a661-6c42a4bd310c",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "98b0e992-9c95-464a-a661-6c42a4bd310c",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRMedidaObservada"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_98b0e992-9c95-464a-a661-6c42a4bd310c\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Observation 98b0e992-9c95-464a-a661-6c42a4bd310c</b></p><a name=\"98b0e992-9c95-464a-a661-6c42a4bd310c\"> </a><a name=\"hc98b0e992-9c95-464a-a661-6c42a4bd310c\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRMedidaObservada.html\">Medida Observada</a></p></div><p><b>Origem da Medição</b>: <span title=\"Códigos:{http://loinc.org 3138-5}\">Bdy height Stated</span></p><p><b>Roupas Usadas na Medição</b>: <span title=\"Códigos:{http://loinc.org LA11873-9}\">Street clothes &amp; shoes</span></p><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Códigos:{http://loinc.org 29463-7}\">Weight</span></p><p><b>value</b>: 88.15 kg<span style=\"background: LightGoldenRodYellow\"> (Detalhes: UCUM códigokg = 'kg')</span></p><p><b>method</b>: <span title=\"Códigos:{http://loinc.org LA11870-5}\">Standing</span></p></div>"
      },
      "extension" : [{
        "url" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BROrigemMedida",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "3138-5"
          }]
        }
      },
      {
        "url" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRRoupasUsadasMedicao",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA11873-9"
          }]
        }
      }],
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "29463-7"
        }]
      },
      "valueQuantity" : {
        "value" : 88.15,
        "system" : "http://unitsofmeasure.org",
        "code" : "kg"
      },
      "method" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA11870-5"
        }]
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:efcce484-7226-435f-8c7c-b1d703079444",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "efcce484-7226-435f-8c7c-b1d703079444",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRMedidaObservada"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_efcce484-7226-435f-8c7c-b1d703079444\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Observation efcce484-7226-435f-8c7c-b1d703079444</b></p><a name=\"efcce484-7226-435f-8c7c-b1d703079444\"> </a><a name=\"hcefcce484-7226-435f-8c7c-b1d703079444\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRMedidaObservada.html\">Medida Observada</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Códigos:{http://loinc.org 8480-6}\">BP sys</span></p><p><b>value</b>: 0.15 mm[Hg]<span style=\"background: LightGoldenRodYellow\"> (Detalhes: UCUM códigomm[Hg] = 'mm[Hg]')</span></p><p><b>bodySite</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRLocalAfericao 6}\">Pulso esquerdo</span></p><p><b>method</b>: <span title=\"Códigos:{http://loinc.org LA11868-9}\">Sitting</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "8480-6"
        }]
      },
      "valueQuantity" : {
        "value" : 0.15,
        "system" : "http://unitsofmeasure.org",
        "code" : "mm[Hg]"
      },
      "bodySite" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRLocalAfericao",
          "code" : "6"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA11868-9"
        }]
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:d78c1159-1473-4bef-9096-5ba98384e950",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "d78c1159-1473-4bef-9096-5ba98384e950",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRMedidaObservada"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_d78c1159-1473-4bef-9096-5ba98384e950\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Observation d78c1159-1473-4bef-9096-5ba98384e950</b></p><a name=\"d78c1159-1473-4bef-9096-5ba98384e950\"> </a><a name=\"hcd78c1159-1473-4bef-9096-5ba98384e950\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRMedidaObservada.html\">Medida Observada</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Códigos:{http://loinc.org 11612-9}\">Acortions</span></p><p><b>value</b>: 1</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11612-9"
        }]
      },
      "valueQuantity" : {
        "value" : 1
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:32e99ca6-4e7d-4d56-8f25-612dd1c51a71",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "32e99ca6-4e7d-4d56-8f25-612dd1c51a71",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRMedidaObservada"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_32e99ca6-4e7d-4d56-8f25-612dd1c51a71\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Observation 32e99ca6-4e7d-4d56-8f25-612dd1c51a71</b></p><a name=\"32e99ca6-4e7d-4d56-8f25-612dd1c51a71\"> </a><a name=\"hc32e99ca6-4e7d-4d56-8f25-612dd1c51a71\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRMedidaObservada.html\">Medida Observada</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Códigos:{http://loinc.org 11996-6}\">Pregnancies</span></p><p><b>value</b>: 2</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11996-6"
        }]
      },
      "valueQuantity" : {
        "value" : 2
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:19011496-44a1-4048-8e1b-558b82b1caf1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "19011496-44a1-4048-8e1b-558b82b1caf1",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRMedidaObservada"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_19011496-44a1-4048-8e1b-558b82b1caf1\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Observation 19011496-44a1-4048-8e1b-558b82b1caf1</b></p><a name=\"19011496-44a1-4048-8e1b-558b82b1caf1\"> </a><a name=\"hc19011496-44a1-4048-8e1b-558b82b1caf1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRMedidaObservada.html\">Medida Observada</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Códigos:{http://loinc.org 11996-6}\">Pregnancies</span></p><p><b>value</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoAleitamentoMaterno predominante}\">Predominante</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11996-6"
        }]
      },
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoAleitamentoMaterno",
          "code" : "predominante"
        }]
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:34fe98d3-e5fc-491e-a125-c90ab2abb83a",
    "resource" : {
      "resourceType" : "AllergyIntolerance",
      "id" : "34fe98d3-e5fc-491e-a125-c90ab2abb83a",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRAlergiaReacaoAdversa-1.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AllergyIntolerance_34fe98d3-e5fc-491e-a125-c90ab2abb83a\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: AllergyIntolerance 34fe98d3-e5fc-491e-a125-c90ab2abb83a</b></p><a name=\"34fe98d3-e5fc-491e-a125-c90ab2abb83a\"> </a><a name=\"hc34fe98d3-e5fc-491e-a125-c90ab2abb83a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRAlergiaReacaoAdversa-1.0.html\">Alergia ou Reação Adversa</a></p></div><p><b>clinicalStatus</b>: <span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/allergyintolerance-verification confirmed}\">Confirmed</span></p><p><b>category</b>: Food</p><p><b>criticality</b>: Low Risk</p><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRImunobiologico 2}\">SAT</span></p><p><b>patient</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/819217217061851</p><p><b>onset</b>: 2022-06-01</p><p><b>note</b>: </p><blockquote><div><p>Soro antitetânico</p>\n</div></blockquote><h3>Reactions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manifestation</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRMedDRA 10037087}\">Prurido</span></td></tr></table></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical",
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-verification",
          "code" : "confirmed"
        }]
      },
      "category" : ["food"],
      "criticality" : "low",
      "code" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRImunobiologico",
          "code" : "2"
        }],
        "text" : "SAT"
      },
      "patient" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "819217217061851"
        }
      },
      "onsetDateTime" : "2022-06-01",
      "note" : [{
        "text" : "Soro antitetânico"
      }],
      "reaction" : [{
        "manifestation" : [{
          "coding" : [{
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRMedDRA",
            "code" : "10037087"
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:48e799d2-1087-4461-af34-8ecdd5bce316",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "48e799d2-1087-4461-af34-8ecdd5bce316",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRRegistroPrescricaoMedicamento"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_48e799d2-1087-4461-af34-8ecdd5bce316\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Composition 48e799d2-1087-4461-af34-8ecdd5bce316</b></p><a name=\"48e799d2-1087-4461-af34-8ecdd5bce316\"> </a><a name=\"hc48e799d2-1087-4461-af34-8ecdd5bce316\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRRegistroPrescricaoMedicamento.html\">Registro de Prescrição de Medicamento</a></p></div><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoDocumento RPM}\">Registro de Prescrição de Medicamento</span></p><p><b>date</b>: 2022-03-04 14:59:51-0300</p><p><b>author</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0</code>/3191384</p><p><b>title</b>: Registro de Prescrição de Medicamento</p></div>"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoDocumento",
          "code" : "RPM"
        }]
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "819217217061851"
        }
      },
      "date" : "2022-03-04T14:59:51-03:00",
      "author" : [{
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0",
          "value" : "3191384"
        }
      }],
      "title" : "Registro de Prescrição de Medicamento",
      "section" : [{
        "entry" : [{
          "reference" : "urn:uuid:6d607d4c-18f4-4647-be8c-d3b40e1659bb"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:6d607d4c-18f4-4647-be8c-d3b40e1659bb",
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "6d607d4c-18f4-4647-be8c-d3b40e1659bb",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRPrescricaoMedicamento"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_6d607d4c-18f4-4647-be8c-d3b40e1659bb\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: MedicationRequest 6d607d4c-18f4-4647-be8c-d3b40e1659bb</b></p><a name=\"6d607d4c-18f4-4647-be8c-d3b40e1659bb\"> </a><a name=\"hc6d607d4c-18f4-4647-be8c-d3b40e1659bb\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRPrescricaoMedicamento.html\">Prescrição de Medicamento</a></p></div><p><b>status</b>: Completed</p><p><b>intent</b>: Order</p><p><b>medication</b>: <a href=\"Bundle-bundle-example-rac-2.html#urn-uuid-8bea4fe3-0769-4318-b5a8-7d3a8c6f04bd\">Medication Terminologia segundo CATMAT</a></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/819217217061851</p><p><b>authoredOn</b>: 2022-03-04</p><p><b>requester</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0</code>/3191384</p><p><b>recorder</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRProfissional-1.0</code>/162338254590005</p><p><b>note</b>: Por Dr. Getúlio @2022-03-04</p><blockquote><div><p>Medicamento necessário para tratamento da febre devido à gripe.</p>\n</div></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>patientInstruction</b>: Tomar uma vez ao dia via oral.</p><p><b>timing</b>: Contagem 1  times, 12</p><p><b>asNeeded</b>: true</p><p><b>route</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRViaAdministracao 10907}\">Oral</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida 13}\">Cápsula</span></td><td>10</td></tr></table><p><b>maxDosePerAdministration</b>: 10</p></blockquote><h3>DispenseRequests</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ValidityPeriod</b></td><td><b>Quantity</b></td></tr><tr><td style=\"display: none\">*</td><td>2022-02-24 --&gt; 2022-03-03</td><td>10</td></tr></table></div>"
      },
      "status" : "completed",
      "intent" : "order",
      "medicationReference" : {
        "reference" : "urn:uuid:8bea4fe3-0769-4318-b5a8-7d3a8c6f04bd"
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "819217217061851"
        }
      },
      "authoredOn" : "2022-03-04",
      "requester" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0",
          "value" : "3191384"
        }
      },
      "recorder" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRProfissional-1.0",
          "value" : "162338254590005"
        }
      },
      "note" : [{
        "authorString" : "Dr. Getúlio",
        "time" : "2022-03-04",
        "text" : "Medicamento necessário para tratamento da febre devido à gripe."
      }],
      "dosageInstruction" : [{
        "patientInstruction" : "Tomar uma vez ao dia via oral.",
        "timing" : {
          "repeat" : {
            "extension" : [{
              "url" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRTurno",
              "valueCode" : "3"
            },
            {
              "extension" : [{
                "url" : "periodUnit",
                "valueCode" : "min"
              },
              {
                "url" : "period",
                "valuePositiveInt" : 1
              }],
              "url" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIntervaloDoses"
            }],
            "count" : 1,
            "countMax" : 10,
            "frequency" : 12
          }
        },
        "asNeededBoolean" : true,
        "route" : {
          "coding" : [{
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRViaAdministracao",
            "code" : "10907"
          }]
        },
        "doseAndRate" : [{
          "type" : {
            "coding" : [{
              "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida",
              "code" : "13"
            }]
          },
          "doseQuantity" : {
            "value" : 10
          }
        }],
        "maxDosePerAdministration" : {
          "value" : 10
        }
      }],
      "dispenseRequest" : {
        "validityPeriod" : {
          "start" : "2022-02-24",
          "end" : "2022-03-03"
        },
        "quantity" : {
          "value" : 10
        }
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:8bea4fe3-0769-4318-b5a8-7d3a8c6f04bd",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "8bea4fe3-0769-4318-b5a8-7d3a8c6f04bd",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRMedicamento"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_8bea4fe3-0769-4318-b5a8-7d3a8c6f04bd\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Medication 8bea4fe3-0769-4318-b5a8-7d3a8c6f04bd</b></p><a name=\"8bea4fe3-0769-4318-b5a8-7d3a8c6f04bd\"> </a><a name=\"hc8bea4fe3-0769-4318-b5a8-7d3a8c6f04bd\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRMedicamento.html\">Medicamento</a></p></div><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmCATMAT BR0352317}\">Terminologia segundo CATMAT</span></p><p><b>form</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida 2}\">Ampola</span></p></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmCATMAT",
          "code" : "BR0352317"
        }],
        "text" : "Terminologia segundo CATMAT"
      },
      "form" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida",
          "code" : "2"
        }]
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:d2176159-0427-42da-a727-636bbb042d97",
    "resource" : {
      "resourceType" : "CarePlan",
      "id" : "d2176159-0427-42da-a727-636bbb042d97",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRPlanoCuidados-1.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"CarePlan_d2176159-0427-42da-a727-636bbb042d97\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: CarePlan d2176159-0427-42da-a727-636bbb042d97</b></p><a name=\"d2176159-0427-42da-a727-636bbb042d97\"> </a><a name=\"hcd2176159-0427-42da-a727-636bbb042d97\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRPlanoCuidados-1.0.html\">Plano de Cuidados</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Plan</p><p><b>description</b>: Repouso pós-medicação intramuscular</p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/819217217061851</p></div>"
      },
      "status" : "active",
      "intent" : "plan",
      "description" : "Repouso pós-medicação intramuscular",
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "819217217061851"
        }
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:22f0baea-50d7-429b-8767-3b07c9a8120e",
    "resource" : {
      "resourceType" : "CarePlan",
      "id" : "22f0baea-50d7-429b-8767-3b07c9a8120e",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRAtestado"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"CarePlan_22f0baea-50d7-429b-8767-3b07c9a8120e\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: CarePlan 22f0baea-50d7-429b-8767-3b07c9a8120e</b></p><a name=\"22f0baea-50d7-429b-8767-3b07c9a8120e\"> </a><a name=\"hc22f0baea-50d7-429b-8767-3b07c9a8120e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRAtestado.html\">Atestado Digital</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Plan</p><p><b>category</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoDocumento ATM}\">Atestado Médico/Odontológico</span></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/819217217061851</p><p><b>addresses</b>: <a href=\"Bundle-bundle-example-rac-2.html#urn-uuid-6f057e45-34ab-43d6-8fd5-53c1d3aa73b2\">Condition Varizes esofagianas sem sangramento</a></p><blockquote><p><b>activity</b></p><h3>Details</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Status</b></td><td><b>Scheduled[x]</b></td><td><b>Description</b></td></tr><tr><td style=\"display: none\">*</td><td>Unknown</td><td>Eventos: 2022-07-25 18:11:19+0000 , Contagem 1  times, Uma vez</td><td>Nada digno de nota.</td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "intent" : "plan",
      "category" : [{
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoDocumento",
          "code" : "ATM"
        }]
      }],
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "819217217061851"
        }
      },
      "addresses" : [{
        "reference" : "urn:uuid:6f057e45-34ab-43d6-8fd5-53c1d3aa73b2"
      }],
      "activity" : [{
        "detail" : {
          "status" : "unknown",
          "scheduledTiming" : {
            "event" : ["2022-07-25T18:11:19.005486Z"],
            "repeat" : {
              "count" : 1
            }
          },
          "description" : "Nada digno de nota."
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:6f057e45-34ab-43d6-8fd5-53c1d3aa73b2",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "6f057e45-34ab-43d6-8fd5-53c1d3aa73b2",
      "meta" : {
        "lastUpdated" : "2022-05-09T17:37:55.000322Z",
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRCID10Avaliado-1.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_6f057e45-34ab-43d6-8fd5-53c1d3aa73b2\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Condition 6f057e45-34ab-43d6-8fd5-53c1d3aa73b2</b></p><a name=\"6f057e45-34ab-43d6-8fd5-53c1d3aa73b2\"> </a><a name=\"hc6f057e45-34ab-43d6-8fd5-53c1d3aa73b2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Última atualização: 2022-05-09 17:37:55+0000</p><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRCID10Avaliado-1.0.html\">CID10 Avaliado</a></p></div><p><b>clinicalStatus</b>: <span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>category</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRCategoriaDiagnostico 01}\">Principal</span></p><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRCID10 I859}\">Varizes esofagianas sem sangramento</span></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/819217217061851</p><p><b>onset</b>: 2023-06-16</p><p><b>note</b>: </p><blockquote><div><p>Varizes esofagianas sem sangramento.</p>\n</div></blockquote></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCategoriaDiagnostico",
          "code" : "01"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCID10",
          "code" : "I859"
        }]
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "819217217061851"
        }
      },
      "onsetDateTime" : "2023-06-16",
      "note" : [{
        "text" : "Varizes esofagianas sem sangramento."
      }]
    }
  }]
}

```
