# Modalidade Assistencial (CodeSystem) - Guia de Implementação do Registro de Atendimento Clínico (RAC) da RNDS v1.0.0

## CodeSystem: Modalidade Assistencial (CodeSystem) 

Este sistema de códigos é referenciado na definição dos seguintes conjuntos de valores:

* [Modalidade Assistencial](ValueSet-BRModalidadeAssistencial-1.0.md)

-------

 [Descrição do(s) quadro(s) acima](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRModalidadeAssistencial",
  "meta" : {
    "lastUpdated" : "2020-03-11T18:15:59.439+00:00"
  },
  "language" : "pt-BR",
  "url" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRModalidadeAssistencial",
  "version" : "1.0.0",
  "name" : "BRModalidadeAssistencial",
  "title" : "Modalidade Assistencial",
  "status" : "active",
  "experimental" : false,
  "date" : "2020-03-11T18:16:19.9468275+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Classifica os contatos assistenciais de acordo com as especificidades do modo, local e duração do atendimento",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "01",
    "display" : "Atenção Básica"
  },
  {
    "code" : "02",
    "display" : "Atenção Domiciliar"
  },
  {
    "code" : "03",
    "display" : "Atenção Intermediária"
  },
  {
    "code" : "04",
    "display" : "Atenção Hospitalar"
  },
  {
    "code" : "05",
    "display" : "Atenção Psicossocial"
  },
  {
    "code" : "06",
    "display" : "Atenção à Urgência/Emergência"
  },
  {
    "code" : "07",
    "display" : "Ambulatorial Especializada"
  },
  {
    "code" : "08",
    "display" : "Assistência Farmacêutica"
  },
  {
    "code" : "09",
    "display" : "Assistência Ambulatorial"
  }]
}

```
