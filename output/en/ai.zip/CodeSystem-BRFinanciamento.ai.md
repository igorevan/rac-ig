# Financiamento (CodeSystem) - Guia de Implementação do Registro de Atendimento Clínico (RAC) da RNDS v1.0.0-release

## CodeSystem: Financiamento (CodeSystem) 

 
Terminologia que descreve o agente, instituição ou entidade responsável por custear as ações e serviços de saúde. 

This Code system is referenced in the definition of the following value sets:

* [BRFinanciamento](ValueSet-BRFinanciamento-1.0.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRFinanciamento",
  "meta" : {
    "lastUpdated" : "2020-03-11T18:12:26.041+00:00"
  },
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/fhir/r4/rac/1.0.0/ImplementationGuide/br.gov.saude.rac.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/fhir/r4/rac/1.0.0/ImplementationGuide/br.gov.saude.rac.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRFinanciamento",
  "version" : "1.0.0-release",
  "name" : "BRFinanciamento",
  "title" : "Financiamento",
  "status" : "active",
  "experimental" : false,
  "date" : "2020-03-11T18:12:46.5570008+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Terminologia que descreve o agente, instituição ou entidade responsável por custear as ações e serviços de saúde.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "01",
    "display" : "Federal SUS"
  },
  {
    "code" : "02",
    "display" : "Plano de Saúde Público"
  },
  {
    "code" : "03",
    "display" : "Plano de Saúde Privado"
  },
  {
    "code" : "04",
    "display" : "Particular"
  },
  {
    "code" : "05",
    "display" : "Gratuidade"
  },
  {
    "code" : "06",
    "display" : "Estadual SUS"
  },
  {
    "code" : "07",
    "display" : "Municipal SUS"
  },
  {
    "code" : "08",
    "display" : "Programas e Projetos Federais"
  }]
}

```
