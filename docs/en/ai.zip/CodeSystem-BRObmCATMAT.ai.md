# Terminologia de Produto Medicinal Virtual (VMP) no Catálogo de Materiais (CATMAT) - Guia de Implementação do Registro de Atendimento Clínico (RAC) da RNDS v1.0.0-release

## CodeSystem: Terminologia de Produto Medicinal Virtual (VMP) no Catálogo de Materiais (CATMAT) 

 
Apresenta o Produto Medicinal Virtual (VMP) e seu código no Catálogo de Materiais (CATMAT) 

This Code system is referenced in the definition of the following value sets:

* [Terminologia dos medicamentos](ValueSet-BRTerminologiaMedicamento.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRObmCATMAT",
  "meta" : {
    "lastUpdated" : "2022-04-06T12:48:11.6743763+03:00"
  },
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/rac/ImplementationGuide/br.gov.saude.rac.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/rac/ImplementationGuide/br.gov.saude.rac.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmCATMAT",
  "version" : "1.0.0-release",
  "name" : "BRObmCATMAT",
  "title" : "Terminologia de Produto Medicinal Virtual (VMP) no Catálogo de Materiais (CATMAT)",
  "status" : "active",
  "experimental" : false,
  "date" : "2022-04-06T12:48:11.6743763+03:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Apresenta o Produto Medicinal Virtual (VMP) e seu código no Catálogo de Materiais (CATMAT)",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "BR0356705",
    "display" : "Mercaptamina 50 mg comprimido"
  },
  {
    "code" : "BR0260160-2E",
    "display" : "Imunoglobulina humana anti-hepatite B 500 unidades internacionais/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266532-1",
    "display" : "Fenoterol 200 microgramas/dose solução aerossol"
  },
  {
    "code" : "BR0266532-2",
    "display" : "Fenoterol 200 microgramas/dose solução aerossol"
  },
  {
    "code" : "BR0266587",
    "display" : "Fenitoína Sódica 25 mg/mL suspensão oral"
  },
  {
    "code" : "BR0266597",
    "display" : "Formoterol 12 microgramas cápsula para inalação"
  },
  {
    "code" : "BR0266599",
    "display" : "Formoterol 12 microgramas/dose pó para inalação"
  },
  {
    "code" : "BR0266599E",
    "display" : "Formoterol 12 microgramas/dose pó para inalação"
  },
  {
    "code" : "BR0266627",
    "display" : "Alfaepoetina 1.000 unidades internacionais/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266627E",
    "display" : "Alfaepoetina 1.000 unidades internacionais/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266629",
    "display" : "Alfaepoetina 4.000 unidades internacionais/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266629E",
    "display" : "Alfaepoetina 4.000 unidades internacionais/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266630",
    "display" : "Alfaepoetina 10.000 unidades internacionais/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266665",
    "display" : "Arteméter 80 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0266699",
    "display" : "Budesonida 50 microgramas/dose suspensão aerossol"
  },
  {
    "code" : "BR0266700",
    "display" : "Budesonida 200 microgramas/dose suspensão aerossol"
  },
  {
    "code" : "BR0266701",
    "display" : "Budesonida 50 microgramas/dose suspensão spray"
  },
  {
    "code" : "BR0266703-1",
    "display" : "Budesonida 100 microgramas/pó para inalação"
  },
  {
    "code" : "BR0266703-2",
    "display" : "Budesonida 100 microgramas/pó para inalação"
  },
  {
    "code" : "BR0266703-3",
    "display" : "Budesonida 100 microgramas/pó para inalação"
  },
  {
    "code" : "BR0266706U0066",
    "display" : "Budesonida 32 microgramas/dose suspensão spray"
  },
  {
    "code" : "BR0266706-1",
    "display" : "Budesonida 32 microgramas/dose solução nasal"
  },
  {
    "code" : "BR0266707",
    "display" : "Budesonida 64 microgramas/dose suspensão spray"
  },
  {
    "code" : "BR0266707-1",
    "display" : "Budesonida 64 microgramas/dose solução nasal"
  },
  {
    "code" : "BR0266713",
    "display" : "Pancrelipase 20.000 unidades internacionais cápsula"
  },
  {
    "code" : "BR0266713E",
    "display" : "Pancrelipase 20.000 unidades internacionais cápsula"
  },
  {
    "code" : "BR0266714",
    "display" : "Pancrelipase 4.500 unidades internacionais cápsula"
  },
  {
    "code" : "BR0266714E",
    "display" : "Pancrelipase 4.500 unidades internacionais cápsula"
  },
  {
    "code" : "BR02667158",
    "display" : "Pancrelipase 12.000 unidades internacionais cápsula"
  },
  {
    "code" : "BR0266715E",
    "display" : "Pancrelipase 12.000 unidades internacionais cápsula"
  },
  {
    "code" : "BR0266716E",
    "display" : "Pancrelipase 18.000 unidades internacionais cápsula"
  },
  {
    "code" : "BR0266736",
    "display" : "Desferroxamina 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266736E",
    "display" : "Desferroxamina 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266750",
    "display" : "Rivastigmina 2 mg/mL solução oral"
  },
  {
    "code" : "BR0266750E",
    "display" : "Rivastigmina 2 mg/mL solução oral"
  },
  {
    "code" : "BR0266752",
    "display" : "Imiglucerase 200 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266752E",
    "display" : "Imiglucerase 200 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266762-1",
    "display" : "Alfainterferona 2a 3.000.000 unidades internacionais/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0266765",
    "display" : "Alfainterferona 2b 5.000.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266765E",
    "display" : "Alfainterferona 2b 5.000.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266766",
    "display" : "Alfainterferona 2b 10.000.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266766E",
    "display" : "Alfainterferona 2b 10.000.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266767",
    "display" : "Alfainterferona 2b 3.000.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266767E",
    "display" : "Alfainterferona 2b 3.000.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266788-1",
    "display" : "Nistatina 25.000 unidades internacionais/g creme vaginal"
  },
  {
    "code" : "BR0266788-2",
    "display" : "Nistatina 25.000 unidades internacionais/g creme vaginal"
  },
  {
    "code" : "BR0266809",
    "display" : "Salmeterol 50 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "BR0266809E",
    "display" : "Salmeterol 50 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "BR0266820",
    "display" : "Imunoglobulina Humana 5 g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266822E",
    "display" : "Imunoglobulina humana 2,5 g/25 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266823E",
    "display" : "Imunoglobulina humana 1 g/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266827",
    "display" : "Imunoglobulina anti-Rho (D) 1.500 unidades internacionais/2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266863-1",
    "display" : "Benzoilmetronidazol 40 mg/mL suspensão oral"
  },
  {
    "code" : "BR0266863-2",
    "display" : "Benzoilmetronidazol 40 mg/mL suspensão oral"
  },
  {
    "code" : "BR0266863-3",
    "display" : "Benzoilmetronidazol 40 mg/mL suspensão oral"
  },
  {
    "code" : "BR0266962",
    "display" : "Somatropina 4 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266962E",
    "display" : "Somatropina 4 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266963",
    "display" : "Somatropina 12 mg/1,5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266963E",
    "display" : "Somatropina 12 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267077",
    "display" : "Bezafibrato 200 mg comprimido"
  },
  {
    "code" : "BR0267077E",
    "display" : "Bezafibrato 200 mg comprimido"
  },
  {
    "code" : "BR0267079",
    "display" : "Alfaepoetina 3.000 unidades internacionais/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267081",
    "display" : "Fenofibrato 200 mg cápsula"
  },
  {
    "code" : "BR0267081E",
    "display" : "Fenofibrato 200 mg cápsula"
  },
  {
    "code" : "BR0267082",
    "display" : "Fluvastatina 80 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0267083",
    "display" : "Fluvastatina 20 mg cápsula"
  },
  {
    "code" : "BR0267083E",
    "display" : "Fluvastatina 20 mg cápsula"
  },
  {
    "code" : "BR0267084",
    "display" : "Fluvastatina 40 mg cápsula"
  },
  {
    "code" : "BR0267084E",
    "display" : "Fluvastatina 40 mg cápsula"
  },
  {
    "code" : "BR0267087",
    "display" : "Genfibrozila 900 mg comprimido"
  },
  {
    "code" : "BR0267087E",
    "display" : "Genfibrozila 900 mg comprimido"
  },
  {
    "code" : "BR0267088",
    "display" : "Genfibrozila 600 mg comprimido"
  },
  {
    "code" : "BR0267088E",
    "display" : "Genfibrozila 600 mg comprimido"
  },
  {
    "code" : "BR0267089",
    "display" : "Genfibrozila 300 mg cápsula"
  },
  {
    "code" : "BR0267092E",
    "display" : "Lovastatina 40 mg comprimido"
  },
  {
    "code" : "BR0267107",
    "display" : "Fenitoína Sódica 250 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0267139",
    "display" : "Ampicilina 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0267140",
    "display" : "Azitromicina 500 mg comprimido"
  },
  {
    "code" : "BR0267151",
    "display" : "Cetoconazol 200 mg comprimido"
  },
  {
    "code" : "BR0267159",
    "display" : "Cloreto de Potássio 600 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0267160",
    "display" : "Cloreto de Potássio 15% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0267161",
    "display" : "Cloreto de Potássio 10% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0267162",
    "display" : "Cloreto de Potássio 19,1% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0267164-1",
    "display" : "Cloreto de Potássio 60 mg/mL solução oral"
  },
  {
    "code" : "BR0267164-2",
    "display" : "Cloreto de Potássio 60 mg/mL solução oral"
  },
  {
    "code" : "BR0267187",
    "display" : "Dexametasona 1 mg/mL (0,1%) solução oftálmica"
  },
  {
    "code" : "BR0267194",
    "display" : "Diazepam 10 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0267195",
    "display" : "Diazepam 5 mg comprimido"
  },
  {
    "code" : "BR0267197",
    "display" : "Diazepam 10 mg comprimido"
  },
  {
    "code" : "BR0267203",
    "display" : "Dipirona 500 mg comprimido"
  },
  {
    "code" : "BR0267205-1",
    "display" : "Dipirona 500 mg/mL solução oral"
  },
  {
    "code" : "BR0267205-2",
    "display" : "Dipirona 500 mg/mL solução oral"
  },
  {
    "code" : "BR0267205-3",
    "display" : "Dipirona 500 mg/mL solução oral"
  },
  {
    "code" : "BR0267206",
    "display" : "Dipirona 50 mg/mL solução oral"
  },
  {
    "code" : "BR0267208",
    "display" : "Estriol 1 mg/g creme vaginal"
  },
  {
    "code" : "BR0267210",
    "display" : "Estriol 2 mg comprimido"
  },
  {
    "code" : "BR0267256",
    "display" : "Fenoterol 5 mg/mL solução"
  },
  {
    "code" : "BR0267271",
    "display" : "Hidróxido de Alumínio 300 mg comprimido"
  },
  {
    "code" : "BR0267271E",
    "display" : "Hidróxido de Alumínio 300 mg comprimido"
  },
  {
    "code" : "BR0267281-1",
    "display" : "Escopolamina 10 mg/mL solução oral"
  },
  {
    "code" : "BR0267281-2",
    "display" : "Escopolamina 10 mg/mL solução oral"
  },
  {
    "code" : "BR0267282",
    "display" : "Escopolamina 20 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0267283",
    "display" : "Escopolamina 10 mg comprimido"
  },
  {
    "code" : "BR0267292",
    "display" : "Imipramina 25 mg comprimido"
  },
  {
    "code" : "BR0267293",
    "display" : "Imipramina 10 mg comprimido"
  },
  {
    "code" : "BR0267294",
    "display" : "Imipramina 75 mg cápsula"
  },
  {
    "code" : "BR0267309",
    "display" : "Medroxiprogesterona 5 mg comprimido"
  },
  {
    "code" : "BR0267310-1",
    "display" : "Metoclopramida 5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0267310-2",
    "display" : "Metoclopramida 10 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0267311",
    "display" : "Metoclopramida 4 mg/mL solução oral"
  },
  {
    "code" : "BR0267312",
    "display" : "Metoclopramida 10 mg comprimido"
  },
  {
    "code" : "BR0267328",
    "display" : "Fosfato de Sódio Monobásico 160 mg/mL + Fosfato de Sódio Dibásico 60 mg/mL solução retal"
  },
  {
    "code" : "BR0267328-1",
    "display" : "Fosfato de Sódio Monobásico 160 mg/mL + Fosfato de Sódio Dibásico 60 mg/mL solução retal"
  },
  {
    "code" : "BR0267355",
    "display" : "Isoconazol 10 mg/g creme"
  },
  {
    "code" : "BR0267376",
    "display" : "Midazolam 7,5 mg comprimido"
  },
  {
    "code" : "BR0267378-1",
    "display" : "Nistatina 100.000 unidades internacionais/mL suspensão oral"
  },
  {
    "code" : "BR0267378-2",
    "display" : "Nistatina 100.000 unidades internacionais/mL suspensão oral"
  },
  {
    "code" : "BR0267378-3",
    "display" : "Nistatina 100.000 unidades internacionais/mL suspensão oral"
  },
  {
    "code" : "BR0267378-4",
    "display" : "Nistatina 100.000 unidades internacionais/mL suspensão oral"
  },
  {
    "code" : "BR0267378-5",
    "display" : "Nistatina 100.000 unidades internacionais/mL suspensão oral"
  },
  {
    "code" : "BR0267393",
    "display" : "Tetraciclina 500 mg comprimido"
  },
  {
    "code" : "BR0267395",
    "display" : "Ibuprofeno 400 mg comprimido"
  },
  {
    "code" : "BR0267415",
    "display" : "Teofilina 100 mg comprimido"
  },
  {
    "code" : "BR0267416",
    "display" : "Teofilina 200mg"
  },
  {
    "code" : "BR0267418 -1",
    "display" : "Tiabendazol 50 mg/g pomada"
  },
  {
    "code" : "BR0267418 -2",
    "display" : "Tiabendazol 50 mg/g pomada"
  },
  {
    "code" : "BR0267418 -3",
    "display" : "Tiabendazol 50 mg/g pomada"
  },
  {
    "code" : "BR0267419",
    "display" : "Tiabendazol 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0267419-1",
    "display" : "Tiabendazol 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0267424",
    "display" : "Verapamil 5 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0267425",
    "display" : "Verapamil 80 mg comprimido"
  },
  {
    "code" : "BR0267470",
    "display" : "Alfapeginterferona 2a 180 microgramas/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267470E",
    "display" : "Alfapeginterferona 2a 180 microgramas/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267471",
    "display" : "Alfapeginterferona 2b 177,6 microgramas pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267471E",
    "display" : "Alfapeginterferona 2b 177,6 microgramas pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267472",
    "display" : "Alfapeginterferona 2b 118,4 microgramas pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267472E",
    "display" : "Alfapeginterferona 2b 118,4 microgramas pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267473",
    "display" : "Alfapeginterferona 2b 148 microgramas pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267473E",
    "display" : "Alfapeginterferona 2b 148 microgramas pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267501",
    "display" : "Ácido Acetilsalicílico 500 mg comprimido"
  },
  {
    "code" : "BR0267502",
    "display" : "Ácido Acetilsalicílico 100 mg comprimido"
  },
  {
    "code" : "BR0267503",
    "display" : "Ácido Fólico 5 mg comprimido"
  },
  {
    "code" : "BR0267504-1",
    "display" : "Ácido Valproico 250 mg cápsula"
  },
  {
    "code" : "BR0267504-2",
    "display" : "Ácido Valproico 250 mg comprimido"
  },
  {
    "code" : "BR0267505",
    "display" : "Valproato de sódio 500 mg comprimido"
  },
  {
    "code" : "BR0267506",
    "display" : "Albendazol 400 mg comprimido mastigável"
  },
  {
    "code" : "BR0267507-1",
    "display" : "Albendazol 40 mg/mL suspensão oral"
  },
  {
    "code" : "BR0267507-2",
    "display" : "Albendazol 40 mg/mL suspensão oral"
  },
  {
    "code" : "BR0267508",
    "display" : "Alopurinol 100 mg comprimido"
  },
  {
    "code" : "BR0267509",
    "display" : "Alopurinol 300 mg comprimido"
  },
  {
    "code" : "BR0267510",
    "display" : "Amiodarona 200 mg comprimido"
  },
  {
    "code" : "BR0267511",
    "display" : "Aminofilina 100 mg comprimido"
  },
  {
    "code" : "BR0267512",
    "display" : "Amitriptilina 25 mg comprimido"
  },
  {
    "code" : "BR0267515-1",
    "display" : "Ampicilina 500 mg cápsula"
  },
  {
    "code" : "BR0267515-2",
    "display" : "Ampicilina 500 mg comprimido"
  },
  {
    "code" : "BR0267516",
    "display" : "Atenolol 25 mg comprimido"
  },
  {
    "code" : "BR0267517",
    "display" : "Atenolol 50 mg comprimido"
  },
  {
    "code" : "BR0267518",
    "display" : "Atenolol 100 mg comprimido"
  },
  {
    "code" : "BR0267522",
    "display" : "Clomipramina 25 mg comprimido"
  },
  {
    "code" : "BR0267523",
    "display" : "Clomipramina 10 mg comprimido"
  },
  {
    "code" : "BR0267526",
    "display" : "Cloxazolam 1 mg comprimido"
  },
  {
    "code" : "BR0267527",
    "display" : "Cloxazolam 2 mg comprimido"
  },
  {
    "code" : "BR0267531",
    "display" : "Indapamida 2,5 mg comprimido"
  },
  {
    "code" : "BR0267531-1",
    "display" : "Perindopril Erbumina 4 mg + Indapamida 1,25 mg comprimido"
  },
  {
    "code" : "BR0267540",
    "display" : "Glicose 25% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0267541",
    "display" : "Glicose 50% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0267544-2",
    "display" : "Glicose 10% solução para injeção 250 mL; bolsa"
  },
  {
    "code" : "BR0267544-3",
    "display" : "Glicose 10% solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "BR0267544-4",
    "display" : "Glicose 10% solução para injeção 1 L; bolsa"
  },
  {
    "code" : "BR0267564",
    "display" : "Carvedilol 12,5 mg comprimido"
  },
  {
    "code" : "BR0267565",
    "display" : "Carvedilol 6,25 mg comprimido"
  },
  {
    "code" : "BR0267566",
    "display" : "Carvedilol 3,125 mg comprimido"
  },
  {
    "code" : "BR0267567",
    "display" : "Carvedilol 25 mg comprimido"
  },
  {
    "code" : "BR0267568",
    "display" : "Diltiazem 60 mg comprimido"
  },
  {
    "code" : "BR0267569",
    "display" : "Diltiazem 30 mg comprimido"
  },
  {
    "code" : "BR0267570",
    "display" : "Diltiazem 180 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0267571",
    "display" : "Diltiazem 90 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0267571-1",
    "display" : "Diltiazem 90 mg comprimido"
  },
  {
    "code" : "BR0267572",
    "display" : "Diltiazem 120 mg comprimido"
  },
  {
    "code" : "BR0267572-1",
    "display" : "Diltiazem 120 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0267573",
    "display" : "Verapamil 120 mg comprimido"
  },
  {
    "code" : "BR0267574",
    "display" : "Cloreto de Sódio 20% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0267582-1",
    "display" : "Beclometasona 50 microgramas/dose suspensão spray"
  },
  {
    "code" : "BR0267582-3",
    "display" : "Beclometasona 50 microgramas/dose suspensão spray"
  },
  {
    "code" : "BR0267585",
    "display" : "Beclometasona 400 micrograma cápsula para inalação"
  },
  {
    "code" : "BR0267586",
    "display" : "Beclometasona 200 microgramas cápsula para inalação"
  },
  {
    "code" : "BR0267586E",
    "display" : "Beclometasona 200 microgramas cápsula para inalação"
  },
  {
    "code" : "BR0267587",
    "display" : "Beclometasona 200 microgramas/dose solução aerossol; inalador"
  },
  {
    "code" : "BR0267587E",
    "display" : "Beclometasona 200 microgramas cápsula para inalação"
  },
  {
    "code" : "BR0267589",
    "display" : "Beclometasona 400 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "BR0267589E",
    "display" : "Beclometasona 400 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "BR0267590E",
    "display" : "Beclometasona 250 microgramas/dose solução aerossol; inalador"
  },
  {
    "code" : "BR0267614",
    "display" : "Captopril 12,5 mg comprimido"
  },
  {
    "code" : "BR0267615",
    "display" : "Captopril 50 mg comprimido"
  },
  {
    "code" : "BR0267617",
    "display" : "Carbamazepina 400 mg comprimido"
  },
  {
    "code" : "BR0267618",
    "display" : "Carbamazepina 200 mg comprimido"
  },
  {
    "code" : "BR0267621",
    "display" : "Carbonato de Lítio 300 mg comprimido"
  },
  {
    "code" : "BR0267625-1",
    "display" : "Cefalexina 500 mg cápsula"
  },
  {
    "code" : "BR0267625-2",
    "display" : "Cefalexina 500 mg comprimido"
  },
  {
    "code" : "BR0267627",
    "display" : "Cimetidina 200 mg comprimido"
  },
  {
    "code" : "BR0267628",
    "display" : "Cinarizina 25 mg comprimido"
  },
  {
    "code" : "BR0267629",
    "display" : "Cinarizina 75 mg comprimido"
  },
  {
    "code" : "BR0267631",
    "display" : "Ciprofloxacino 250 mg comprimido"
  },
  {
    "code" : "BR0267632",
    "display" : "Ciprofloxacino 500 mg comprimido"
  },
  {
    "code" : "BR0267635",
    "display" : "Clorpromazina 25 mg comprimido"
  },
  {
    "code" : "BR0267638",
    "display" : "Clorpromazina 100 mg comprimido"
  },
  {
    "code" : "BR0267641",
    "display" : "Clorpropamida 250 mg comprimido"
  },
  {
    "code" : "BR0267642",
    "display" : "Colchicina 0,5 mg comprimido"
  },
  {
    "code" : "BR0267643",
    "display" : "Dexametasona 1 mg/g (0,1%) creme"
  },
  {
    "code" : "BR0267643-1",
    "display" : "Dexametasona 10 mg/g (1%) creme"
  },
  {
    "code" : "BR0267643-2",
    "display" : "Dexametasona 1 mg/g (0,1%) creme"
  },
  {
    "code" : "BR0267644",
    "display" : "Dexametasona 0,5 mg comprimido"
  },
  {
    "code" : "BR0267645",
    "display" : "Dexclorfeniramina 2 mg comprimido"
  },
  {
    "code" : "BR0267646-1",
    "display" : "Dexclorfeniramina 0,4 mg/mL solução oral"
  },
  {
    "code" : "BR0267646-2",
    "display" : "Dexclorfeniramina 0,4 mg/mL solução oral"
  },
  {
    "code" : "BR0267646-3",
    "display" : "Dexclorfeniramina 0,4 mg/mL solução oral"
  },
  {
    "code" : "BR0267647",
    "display" : "Digoxina 0,25 mg comprimido"
  },
  {
    "code" : "BR0267648",
    "display" : "Digoxina 0,05 mg/mL elixir"
  },
  {
    "code" : "BR0267649",
    "display" : "Digoxina 0,5 mg/mL solução oral"
  },
  {
    "code" : "BR0267650",
    "display" : "Enalapril 5 mg comprimido"
  },
  {
    "code" : "BR0267652",
    "display" : "Enalapril 20 mg comprimido"
  },
  {
    "code" : "BR0267653",
    "display" : "Espironolactona 25 mg comprimido"
  },
  {
    "code" : "BR0267654",
    "display" : "Espironolactona 100 mg comprimido"
  },
  {
    "code" : "BR0267657",
    "display" : "Fenitoína 100 mg comprimido"
  },
  {
    "code" : "BR0267660",
    "display" : "Fenobarbital 100 mg comprimido"
  },
  {
    "code" : "BR0267661",
    "display" : "Fluconazol 100 mg cápsula"
  },
  {
    "code" : "BR0267662",
    "display" : "Fluconazol 150 mg cápsula"
  },
  {
    "code" : "BR0267663",
    "display" : "Furosemida 40 mg comprimido"
  },
  {
    "code" : "BR0267666",
    "display" : "Furosemida 20 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0267668",
    "display" : "Gentamicina 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0267669",
    "display" : "Haloperidol 5 mg comprimido"
  },
  {
    "code" : "BR0267670",
    "display" : "Haloperidol 1 mg comprimido"
  },
  {
    "code" : "BR0267675",
    "display" : "Hidroclorotiazida 50 mg comprimido"
  },
  {
    "code" : "BR0267676",
    "display" : "Ibuprofeno 600 mg comprimido"
  },
  {
    "code" : "BR0267677",
    "display" : "Ibuprofeno 300 mg comprimido"
  },
  {
    "code" : "BR0267688",
    "display" : "Metildopa 500 mg comprimido"
  },
  {
    "code" : "BR0267689",
    "display" : "Metildopa 250 mg comprimido"
  },
  {
    "code" : "BR0267692",
    "display" : "Mebendazol 100 mg comprimido"
  },
  {
    "code" : "BR0267694",
    "display" : "Mebendazol 20 mg/mL suspensão oral"
  },
  {
    "code" : "BR0267711",
    "display" : "Omeprazol 10 mg cápsula gastrorresistente"
  },
  {
    "code" : "BR0267712",
    "display" : "Omeprazol 20 mg cápsula gastrorresistente"
  },
  {
    "code" : "BR0267713",
    "display" : "Omeprazol 40 mg comprimido gastrorresistente"
  },
  {
    "code" : "BR0267717",
    "display" : "Metronidazol 250 mg comprimido"
  },
  {
    "code" : "BR0267728-1",
    "display" : "Nifedipino 10 mg comprimido de liberação retardada"
  },
  {
    "code" : "BR0267728-2",
    "display" : "Nifedipino 10 mg cápsula"
  },
  {
    "code" : "BR0267729",
    "display" : "Nifedipino 20 mg comprimido"
  },
  {
    "code" : "BR0267730",
    "display" : "Nifedipino 10 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0267731",
    "display" : "Nifedipino 20 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0267731-1",
    "display" : "Nifedipino 20 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0267732",
    "display" : "Vitelinato de Prata 100 mg/mL (10%) solução oftálmica"
  },
  {
    "code" : "BR0267734",
    "display" : "Ranitidina 15 mg/mL xarope"
  },
  {
    "code" : "BR0267735",
    "display" : "Ranitidina 50 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0267736",
    "display" : "Ranitidina 150 mg comprimido"
  },
  {
    "code" : "BR0267737",
    "display" : "Ranitidina 300 mg comprimido"
  },
  {
    "code" : "BR0267741",
    "display" : "Prednisona 5 mg comprimido"
  },
  {
    "code" : "BR0267743",
    "display" : "Prednisona 20 mg comprimido"
  },
  {
    "code" : "BR0267744",
    "display" : "Sinvastatina 80 mg comprimido"
  },
  {
    "code" : "BR0267765",
    "display" : "Sulfadiazina 500 mg comprimido"
  },
  {
    "code" : "BR0267768",
    "display" : "Cloridrato de Prometazina 25 mg comprimido"
  },
  {
    "code" : "BR0267769",
    "display" : "Prometazina 50 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0267770",
    "display" : "Propranolol 80 mg comprimido"
  },
  {
    "code" : "BR0267771",
    "display" : "Propranolol 10 mg comprimido"
  },
  {
    "code" : "BR0267773-1",
    "display" : "Permetrina 10 mg/mL loção"
  },
  {
    "code" : "BR0267773-2",
    "display" : "Permetrina 10 mg/mL loção"
  },
  {
    "code" : "BR0267774",
    "display" : "Piridoxina 40 mg comprimido"
  },
  {
    "code" : "BR0267776-1",
    "display" : "Paracetamol 100 mg/mL solução oral"
  },
  {
    "code" : "BR0267776-2",
    "display" : "Paracetamol 100 mg/mL suspensão oral"
  },
  {
    "code" : "BR0267777-1",
    "display" : "Paracetamol 200 mg/mL solução oral"
  },
  {
    "code" : "BR0267777-2",
    "display" : "Paracetamol 200 mg/mL solução oral"
  },
  {
    "code" : "BR0267777-3",
    "display" : "Paracetamol 200 mg/mL solução oral"
  },
  {
    "code" : "BR0267778",
    "display" : "Paracetamol 500 mg comprimido"
  },
  {
    "code" : "BR0267779",
    "display" : "Paracetamol 750 mg comprimido"
  },
  {
    "code" : "BR0267892",
    "display" : "Pantoprazol 40 mg comprimido"
  },
  {
    "code" : "BR0267894",
    "display" : "Rivastigmina 3 mg cápsula"
  },
  {
    "code" : "BR0267894E",
    "display" : "Rivastigmina 3 mg cápsula"
  },
  {
    "code" : "BR0267895",
    "display" : "Rivastigmina 6 mg cápsula"
  },
  {
    "code" : "BR0267895E",
    "display" : "Rivastigmina 6 mg cápsula"
  },
  {
    "code" : "BR0267896",
    "display" : "Rivastigmina 1,5 mg cápsula"
  },
  {
    "code" : "BR0267896E",
    "display" : "Rivastigmina 1,5 mg cápsula"
  },
  {
    "code" : "BR0267897",
    "display" : "Rivastigmina 4,5 mg cápsula"
  },
  {
    "code" : "BR0267897E",
    "display" : "Rivastigmina 4,5 mg cápsula"
  },
  {
    "code" : "BR0267907",
    "display" : "Beclometasona 400 microgramas/mL suspensão para inalação 2 mL; flaconete"
  },
  {
    "code" : "BR0267936",
    "display" : "Betaistina 16 mg comprimido"
  },
  {
    "code" : "BR0268000",
    "display" : "Dipirona 300 mg supositório"
  },
  {
    "code" : "BR0268005",
    "display" : "Travoprosta 0,04 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0268005-2",
    "display" : "Travoprosta 0,04 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0268005E",
    "display" : "Travoprosta 0,04 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0268037",
    "display" : "Lovastatina 10 mg comprimido"
  },
  {
    "code" : "BR0268037E",
    "display" : "Lovastatina 10 mg comprimido"
  },
  {
    "code" : "BR0268038",
    "display" : "Lovastatina 20 mg comprimido"
  },
  {
    "code" : "BR0268038E",
    "display" : "Lovastatina 20 mg comprimido"
  },
  {
    "code" : "BR0268069",
    "display" : "Clorpromazina 25 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268072",
    "display" : "Selegilina 5 mg comprimido"
  },
  {
    "code" : "BR0268072E",
    "display" : "Selegilina 5 mg comprimido"
  },
  {
    "code" : "BR0268073E",
    "display" : "Selegilina 10 mg comprimido"
  },
  {
    "code" : "BR0268074",
    "display" : "Desmopressina 0,1 mg/mL solução spray"
  },
  {
    "code" : "BR0268074E",
    "display" : "Desmopressina 0,1 mg/mL solução nasal"
  },
  {
    "code" : "BR0268075",
    "display" : "Sulfato de Magnésio 50% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0268076",
    "display" : "Sulfato de Magnésio 10% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0268077",
    "display" : "Ciproterona 50 mg comprimido"
  },
  {
    "code" : "BR0268077E",
    "display" : "Ciproterona 50 mg comprimido"
  },
  {
    "code" : "BR0268079",
    "display" : "Amantadina 100 mg comprimido"
  },
  {
    "code" : "BR0268079E",
    "display" : "Amantadina 100 mg comprimido"
  },
  {
    "code" : "BR0268080",
    "display" : "Atorvastatina 10 mg comprimido"
  },
  {
    "code" : "BR0268080E",
    "display" : "Atorvastatina 10 mg comprimido"
  },
  {
    "code" : "BR0268081",
    "display" : "Atorvastatina 20 mg comprimido"
  },
  {
    "code" : "BR0268081E",
    "display" : "Atorvastatina 20 mg comprimido"
  },
  {
    "code" : "BR0268082",
    "display" : "Atorvastatina 40 mg comprimido"
  },
  {
    "code" : "BR0268082E",
    "display" : "Atorvastatina 40 mg comprimido"
  },
  {
    "code" : "BR0268083",
    "display" : "Azatioprina 50 mg comprimido"
  },
  {
    "code" : "BR0268083E",
    "display" : "Azatioprina 50 mg comprimido"
  },
  {
    "code" : "BR0268084",
    "display" : "Cabergolina 0,5 mg comprimido"
  },
  {
    "code" : "BR0268084E",
    "display" : "Cabergolina 0,5 mg comprimido"
  },
  {
    "code" : "BR0268092",
    "display" : "Metadona 5 mg comprimido"
  },
  {
    "code" : "BR0268092E",
    "display" : "Metadona 5 mg comprimido"
  },
  {
    "code" : "BR0268093",
    "display" : "Metadona 10 mg comprimido"
  },
  {
    "code" : "BR0268093E",
    "display" : "Metadona 10 mg comprimido"
  },
  {
    "code" : "BR0268094",
    "display" : "Metadona 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268094E",
    "display" : "Metadona 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268097",
    "display" : "Tacrolimo 5 mg cápsula"
  },
  {
    "code" : "BR0268097E",
    "display" : "Tacrolimo 5 mg cápsula"
  },
  {
    "code" : "BR0268098",
    "display" : "Tacrolimo 1 mg cápsula"
  },
  {
    "code" : "BR0268098E",
    "display" : "Tacrolimo 1 mg cápsula"
  },
  {
    "code" : "BR0268103",
    "display" : "Codeína 60 mg comprimido"
  },
  {
    "code" : "BR0268103E",
    "display" : "Codeína 60 mg comprimido"
  },
  {
    "code" : "BR0268106",
    "display" : "Gabapentina 400 mg cápsula"
  },
  {
    "code" : "BR0268106E",
    "display" : "Gabapentina 400 mg cápsula"
  },
  {
    "code" : "BR0268107",
    "display" : "Gabapentina 300 mg cápsula"
  },
  {
    "code" : "BR0268107E",
    "display" : "Gabapentina 300 mg cápsula"
  },
  {
    "code" : "BR0268108E",
    "display" : "Gosserrelina 10,8 mg implante de liberação prolongada; seringa preenchida"
  },
  {
    "code" : "BR0268109E",
    "display" : "Gosserrelina 3,6 mg implante; seringa preenchida"
  },
  {
    "code" : "BR0268110",
    "display" : "Hidroxiureia 500 mg cápsula"
  },
  {
    "code" : "BR0268110E",
    "display" : "Hidroxiureia 500 mg cápsula"
  },
  {
    "code" : "BR0268111",
    "display" : "Hidralazina 25 mg comprimido"
  },
  {
    "code" : "BR0268112",
    "display" : "Hidralazina 50 mg comprimido"
  },
  {
    "code" : "BR0268113",
    "display" : "Leflunomida 100 mg comprimido"
  },
  {
    "code" : "BR0268114",
    "display" : "Leflunomida 20 mg comprimido"
  },
  {
    "code" : "BR0268114E",
    "display" : "Leflunomida 20 mg comprimido"
  },
  {
    "code" : "BR0268115",
    "display" : "Hidralazina 20 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268118",
    "display" : "Filgrastim 300 microgramas/1 mL (30 milhões de unidades internacionais/1 mL) solução para injeção; ampola"
  },
  {
    "code" : "BR0268118E",
    "display" : "Filgrastim 300 microgramas/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0268119",
    "display" : "Hidroxicloroquina 400 mg comprimido"
  },
  {
    "code" : "BR0268119E",
    "display" : "Hidroxicloroquina 400 mg comprimido"
  },
  {
    "code" : "BR0268123",
    "display" : "Levotiroxina Sódica 50 microgramas comprimido"
  },
  {
    "code" : "BR0268124",
    "display" : "Levotiroxina Sódica 25 microgramas comprimido"
  },
  {
    "code" : "BR0268125",
    "display" : "Levotiroxina Sódica 100 microgramas comprimido"
  },
  {
    "code" : "BR0268126",
    "display" : "Levotiroxina Sódica 150 microgramas comprimido"
  },
  {
    "code" : "BR0268128",
    "display" : "Levomepromazina 25 mg comprimido"
  },
  {
    "code" : "BR0268129",
    "display" : "Levomepromazina 100 mg comprimido"
  },
  {
    "code" : "BR0268130-1",
    "display" : "Cloridrato de Levomepromazina 40 mg/mL solução oral"
  },
  {
    "code" : "BR0268130-2",
    "display" : "Maleato de Levomepromazina 40 mg/mL solução oral"
  },
  {
    "code" : "BR0268132",
    "display" : "Levomepromazina 25mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268143",
    "display" : "Micofenolato de Mofetila 500 mg comprimido"
  },
  {
    "code" : "BR0268143E",
    "display" : "Micofenolato de Mofetila 500 mg comprimido"
  },
  {
    "code" : "BR0268147E",
    "display" : "Pravastatina 10 mg comprimido"
  },
  {
    "code" : "BR0268148",
    "display" : "Pravastatina 20 mg comprimido"
  },
  {
    "code" : "BR0268148E",
    "display" : "Pravastatina 20 mg comprimido"
  },
  {
    "code" : "BR0268149",
    "display" : "Risperidona 2 mg comprimido"
  },
  {
    "code" : "BR0268149E",
    "display" : "Risperidona 2 mg comprimido"
  },
  {
    "code" : "BR0268150-1",
    "display" : "Prednisolona 3 mg/mL solução oral"
  },
  {
    "code" : "BR0268150-2",
    "display" : "Prednisolona 3 mg/mL solução oral"
  },
  {
    "code" : "BR0268150-3",
    "display" : "Prednisolona 3 mg/mL solução oral"
  },
  {
    "code" : "BR0268151-1",
    "display" : "Prednisolona 1 mg/mL solução oral"
  },
  {
    "code" : "BR0268151-2",
    "display" : "Prednisolona 1 mg/mL solução oral"
  },
  {
    "code" : "BR0268151-3",
    "display" : "Prednisolona 1 mg/mL solução oral"
  },
  {
    "code" : "BR0268152",
    "display" : "Sirolimo 1 mg/mL solução oral"
  },
  {
    "code" : "BR0268152E",
    "display" : "Sirolimo 1 mg/mL solução oral"
  },
  {
    "code" : "BR0268153",
    "display" : "Sulfassalazina 500 mg comprimido"
  },
  {
    "code" : "BR0268153E",
    "display" : "Sulfassalazina 500 mg comprimido"
  },
  {
    "code" : "BR0268155",
    "display" : "Tiabendazol 500 mg comprimido"
  },
  {
    "code" : "BR0268158",
    "display" : "Pirimetamina 25 mg comprimido"
  },
  {
    "code" : "BR0268159",
    "display" : "Pentoxifilina 400 mg comprimido"
  },
  {
    "code" : "BR0268160",
    "display" : "Omeprazol 40 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268162-1",
    "display" : "Miconazol 20 mg/g creme vaginal"
  },
  {
    "code" : "BR0268162-2",
    "display" : "Miconazol 20 mg/g creme vaginal"
  },
  {
    "code" : "BR0268162-3",
    "display" : "Miconazol 20 mg/g creme vaginal"
  },
  {
    "code" : "BR0268163",
    "display" : "Minociclina 100 mg comprimido"
  },
  {
    "code" : "BR0268177",
    "display" : "Flutamida 250 mg comprimido"
  },
  {
    "code" : "BR0268181",
    "display" : "Etofibrato 500 mg cápsula"
  },
  {
    "code" : "BR0268181E",
    "display" : "Etofibrato 500 mg cápsula"
  },
  {
    "code" : "BR0268185",
    "display" : "Glicerol 95% supositório"
  },
  {
    "code" : "BR0268186",
    "display" : "Glicerol 95% supositório"
  },
  {
    "code" : "BR0268202",
    "display" : "Acarbose 50 mg comprimido"
  },
  {
    "code" : "BR0268207",
    "display" : "Ampicilina 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268214",
    "display" : "Atropina 0,25 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268222-1",
    "display" : "Bicarbonato de Sódio 84 mg/mL (8,4%) solução para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "BR0268222-2",
    "display" : "Bicarbonato de Sódio 8,4% solução para injeção 250 mL; frasco-ampola"
  },
  {
    "code" : "BR0268222-3",
    "display" : "Bicarbonato de Sódio 84 mg/mL (8,4%) solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "BR0268228",
    "display" : "Cefalotina 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268236-1",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 100 mL; frasco-ampola"
  },
  {
    "code" : "BR0268236-2",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 125 mL; frasco-ampola"
  },
  {
    "code" : "BR0268236-3",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 250 mL; frasco-ampola"
  },
  {
    "code" : "BR0268236-4",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "BR0268236-5",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 1 L; frasco-ampola"
  },
  {
    "code" : "BR0268237-4",
    "display" : "Cloreto de Sódio 9 mg/mL (0,9%) suspensão para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "BR0268241",
    "display" : "Deltametrina 0,2 mg/mL loção"
  },
  {
    "code" : "BR0268242",
    "display" : "Deltametrina 0,2 mg/mL xampu"
  },
  {
    "code" : "BR0268243-1",
    "display" : "Dexametasona 0,1 mg/mL elixir"
  },
  {
    "code" : "BR0268243-2",
    "display" : "Dexametasona 0,1 mg/mL elixir"
  },
  {
    "code" : "BR0268252",
    "display" : "Dipirona 1 g/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268253",
    "display" : "Dipiridamol 75 mg comprimido"
  },
  {
    "code" : "BR0268255",
    "display" : "Epinefrina 1 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268256-1",
    "display" : "Gentamicina 40 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268256-2",
    "display" : "Gentamicina 60 mg/1,5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268256-3",
    "display" : "Gentamicina 80 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268262",
    "display" : "Metilergometrina 0,2 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268263",
    "display" : "Metilergometrina 0,125 mg comprimido"
  },
  {
    "code" : "BR0268265-1",
    "display" : "Iodeto de Potássio 20 mg/mL xarope"
  },
  {
    "code" : "BR0268265-2",
    "display" : "Iodeto de Potássio 20 mg/mL xarope"
  },
  {
    "code" : "BR0268267",
    "display" : "Miconazol 20 mg/mL (2%) solução"
  },
  {
    "code" : "BR0268268",
    "display" : "Miconazol 20 mg/g pó"
  },
  {
    "code" : "BR0268269",
    "display" : "Miconazol 20 mg/g gel"
  },
  {
    "code" : "BR0268270",
    "display" : "Monossulfiram 250 mg/mL solução"
  },
  {
    "code" : "BR0268273-1",
    "display" : "Nitrofurantoína 100 mg cápsula"
  },
  {
    "code" : "BR0268273-2",
    "display" : "Nitrofurantoína 100 mg comprimido"
  },
  {
    "code" : "BR0268274-1",
    "display" : "Nitrofural 2 mg/g pomada"
  },
  {
    "code" : "BR0268274-2",
    "display" : "Nitrofural 2 mg/g pomada"
  },
  {
    "code" : "BR0268277",
    "display" : "Ocitocina 5 unidades internacionais/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268285",
    "display" : "Nitrazepam 5 mg comprimido"
  },
  {
    "code" : "BR0268286-1",
    "display" : "Miconazol 20 mg/g creme"
  },
  {
    "code" : "BR0268286-2",
    "display" : "Miconazol 20 mg/g creme"
  },
  {
    "code" : "BR0268286-3",
    "display" : "Miconazol 20 mg/g creme"
  },
  {
    "code" : "BR0268286-4",
    "display" : "Miconazol 20 mg/g creme"
  },
  {
    "code" : "BR0268292",
    "display" : "Folinato de Cálcio 15 mg comprimido"
  },
  {
    "code" : "BR0268295",
    "display" : "Ácido Nalidíxico 500 mg comprimido"
  },
  {
    "code" : "BR0268296",
    "display" : "Ácido Nalidíxico 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0268296-1",
    "display" : "Ácido Nalidíxico 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0268297",
    "display" : "Ofloxacino 400 mg comprimido"
  },
  {
    "code" : "BR0268298",
    "display" : "Praziquantel 500 mg comprimido"
  },
  {
    "code" : "BR0268299",
    "display" : "Secnidazol 1 g comprimido"
  },
  {
    "code" : "BR0268300",
    "display" : "Secnidazol 500 mg comprimido"
  },
  {
    "code" : "BR0268301-1",
    "display" : "Secnidazol 30 mg/mL suspensão oral"
  },
  {
    "code" : "BR0268301-2",
    "display" : "Secnidazol 30 mg/mL suspensão oral"
  },
  {
    "code" : "BR0268302",
    "display" : "Salbutamol 2 mg comprimido"
  },
  {
    "code" : "BR0268303",
    "display" : "Salbutamol 5 mg/mL solução para inalação 5 mL; frasco"
  },
  {
    "code" : "BR0268315",
    "display" : "Abacavir 300 mg comprimido"
  },
  {
    "code" : "BR0268317",
    "display" : "Abacavir 20 mg/mL solução oral"
  },
  {
    "code" : "BR0268320",
    "display" : "Amprenavir 150 mg cápsula"
  },
  {
    "code" : "BR0268322",
    "display" : "Amprenavir 15 mg/mL solução oral"
  },
  {
    "code" : "BR0268331U0075",
    "display" : "Brometo de Ipratrópio 0,25 mg/mL solução para inalação 15 mL; frasco"
  },
  {
    "code" : "BR0268331U0086",
    "display" : "Brometo de Ipratrópio 0,25 mg/mL solução para inalação 20 mL; frasco"
  },
  {
    "code" : "BR0268332U0084",
    "display" : "Brometo de Ipratrópio 0,02 mg/dose pó para inalação"
  },
  {
    "code" : "BR0268337",
    "display" : "Efavirenz 200 mg cápsula"
  },
  {
    "code" : "BR0268340",
    "display" : "Estavudina 40 mg cápsula"
  },
  {
    "code" : "BR0268341",
    "display" : "Estavudina 30 mg cápsula"
  },
  {
    "code" : "BR0268344",
    "display" : "Indinavir 400 mg cápsula"
  },
  {
    "code" : "BR0268345",
    "display" : "Lamivudina 150 mg comprimido"
  },
  {
    "code" : "BR0268345E",
    "display" : "Lamivudina 150 mg comprimido"
  },
  {
    "code" : "BR0268349",
    "display" : "Nelfinavir 250 mg comprimido"
  },
  {
    "code" : "BR0268350",
    "display" : "Nelfinavir 50 mg/g pó para solução oral"
  },
  {
    "code" : "BR0268352-1",
    "display" : "Brimonidina 2 mg/mL (0,2%) solução oftálmica"
  },
  {
    "code" : "BR0268352-2",
    "display" : "Brimonidina 2 mg/mL (0,2%) solução oftálmica"
  },
  {
    "code" : "BR0268352E",
    "display" : "Brimonidina 2 mg/mL (0,2%) solução oftálmica"
  },
  {
    "code" : "BR0268353",
    "display" : "Nevirapina 200 mg comprimido"
  },
  {
    "code" : "BR0268356",
    "display" : "Ritonavir 80 mg/mL solução oral"
  },
  {
    "code" : "BR0268359",
    "display" : "Zidovudina 100 mg cápsula"
  },
  {
    "code" : "BR0268360",
    "display" : "Zidovudina 10 mg/mL xarope"
  },
  {
    "code" : "BR0268361",
    "display" : "Zidovudina 200 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268370",
    "display" : "Aciclovir 200 mg comprimido"
  },
  {
    "code" : "BR0268372",
    "display" : "Aciclovir 400 mg comprimido"
  },
  {
    "code" : "BR0268373",
    "display" : "Aciclovir 30 mg/g pomada oftálmica"
  },
  {
    "code" : "BR0268374",
    "display" : "Aciclovir 250 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268375-1",
    "display" : "Aciclovir 50 mg/g (5%) creme"
  },
  {
    "code" : "BR0268375-2",
    "display" : "Aciclovir 50 mg/g (5%) creme"
  },
  {
    "code" : "BR0268376",
    "display" : "Albumina Humana 20% solução para injeção 50 mL; frasco-ampola"
  },
  {
    "code" : "BR0268377",
    "display" : "Albumina Humana 20% solução para injeção 50 mL; frasco-ampola"
  },
  {
    "code" : "BR0268378",
    "display" : "Alfentanila 2,72 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268380",
    "display" : "Alprostadil 20 microgramas pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268381-1",
    "display" : "Amicacina 250 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268381-2",
    "display" : "Amicacina 500 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268382-2",
    "display" : "Amicacina 250 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268383",
    "display" : "Amicacina 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268390",
    "display" : "Glicose 20 g + Cloreto de Sódio 3,5 g + Citrato de Sódio 2,5 g + Cloreto de Potássio 1,5 g pó para solução oral"
  },
  {
    "code" : "BR0268393",
    "display" : "Ampicilina 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268394",
    "display" : "Anfotericina B Lipossomal 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268395",
    "display" : "Anfotericina B 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268396",
    "display" : "Besilato de Atracúrio 50 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268396-1",
    "display" : "Besilato de Atracúrio 25 mg/2,5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268397",
    "display" : "Aztreonam 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268403",
    "display" : "Capecitabina 500 mg comprimido"
  },
  {
    "code" : "BR0268404",
    "display" : "Capecitabina 150 mg comprimido"
  },
  {
    "code" : "BR0268405",
    "display" : "Cefazolina 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268410",
    "display" : "Cefotaxima 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268411",
    "display" : "Cefotaxima 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268412",
    "display" : "Ceftazidima 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268414",
    "display" : "Ceftriaxona 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268415",
    "display" : "Ceftriaxona 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268416",
    "display" : "Ceftriaxona 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268417",
    "display" : "Ceftriaxona 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268422",
    "display" : "Cetoprofeno 50 mg cápsula"
  },
  {
    "code" : "BR0268423",
    "display" : "Cetoprofeno 25 mg/g gel"
  },
  {
    "code" : "BR0268424",
    "display" : "Cetoprofeno 20 mg/mL solução oral"
  },
  {
    "code" : "BR0268427",
    "display" : "Ciclofosfamida 50 mg comprimido"
  },
  {
    "code" : "BR0268427E",
    "display" : "Ciclofosfamida 50 mg comprimido"
  },
  {
    "code" : "BR0268432",
    "display" : "Ciprofloxacino 3 mg/g pomada oftálmica"
  },
  {
    "code" : "BR0268436",
    "display" : "Clindamicina 300 mg cápsula"
  },
  {
    "code" : "BR0268439-1",
    "display" : "Claritromicina 500 mg comprimido"
  },
  {
    "code" : "BR0268439-2",
    "display" : "Claritromicina 500 mg cápsula"
  },
  {
    "code" : "BR0268440",
    "display" : "Claritromicina 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268442",
    "display" : "Cloreto de Suxametônio 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268443",
    "display" : "Codeína 60 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268443E",
    "display" : "Codeína 60 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268446",
    "display" : "Dobutamina 250 mg/20 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268451",
    "display" : "Doxorrubicina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268454",
    "display" : "Enoxaparina Sódica 60 mg/0,6 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0268455",
    "display" : "Enoxaparina Sódica 80 mg/0,8 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0268456",
    "display" : "Enoxaparina Sódica 100 mg/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0268458",
    "display" : "Ganciclovir 250 mg cápsula"
  },
  {
    "code" : "BR0268462",
    "display" : "Halotano líquido para inalação 100 mL"
  },
  {
    "code" : "BR0268462-1",
    "display" : "Halotano líquido para inalação 250 mL"
  },
  {
    "code" : "BR0268463",
    "display" : "Heparina Sódica 5.000 unidades internacionais/0,25 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268469",
    "display" : "Isoflurano líquido para inalação 100 mL"
  },
  {
    "code" : "BR0268469-2",
    "display" : "Isoflurano líquido para inalação 240 mL"
  },
  {
    "code" : "BR0268471",
    "display" : "Levobupivacaína 100 mg/20 mL (0,5%) solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268472",
    "display" : "Levobupivacaína Isobárica 20 mg/4 mL (0,5%) solução para injeção; ampola"
  },
  {
    "code" : "BR0268477",
    "display" : "Fluoruracila 250 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268478",
    "display" : "Fluoruracila 500 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268481-1",
    "display" : "Maleato de Midazolam 15 mg/3 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268481-2",
    "display" : "Maleato de Midazolam 50 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268481-3",
    "display" : "Cloridrato de Midazolam 50 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268481-4",
    "display" : "Midazolam 15 mg/3 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268482",
    "display" : "Midazolam 5 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268487",
    "display" : "Meropeném 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268488",
    "display" : "Meropeném 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268492",
    "display" : "Lincomicina 300 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268492-1",
    "display" : "Lincomicina 600 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268493",
    "display" : "Doxazosina 2 mg comprimido"
  },
  {
    "code" : "BR0268494",
    "display" : "Doxazosina 1 mg comprimido"
  },
  {
    "code" : "BR0268495",
    "display" : "Doxazosina 4 mg comprimido"
  },
  {
    "code" : "BR0268498",
    "display" : "Metronidazol 500 mg/100 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268499",
    "display" : "Metronidazol 400 mg comprimido"
  },
  {
    "code" : "BR0268501",
    "display" : "Nalbufina 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268504",
    "display" : "Ondansetrona 4 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268504-1",
    "display" : "Ondansetrona 8 mg/4 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268505",
    "display" : "Ondansetrona 8 mg comprimido"
  },
  {
    "code" : "BR0268506",
    "display" : "Ondansetrona 4 mg comprimido"
  },
  {
    "code" : "BR0268510",
    "display" : "Flumazenil 0,5 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268513",
    "display" : "Oxacilina 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268520",
    "display" : "Rituximabe 500 mg/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268520-1",
    "display" : "Rituximabe 100 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268520E",
    "display" : "Rituximabe 500 mg/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268521",
    "display" : "Brometo de Rocurônio 50 mg/5 mL solução par ainjeção; ampola"
  },
  {
    "code" : "BR0268523",
    "display" : "Salbutamol 0,5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268528",
    "display" : "Teicoplanina 400 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268529",
    "display" : "Teicoplanina 200mg"
  },
  {
    "code" : "BR0268531",
    "display" : "Tenoxicam 20 mg comprimido"
  },
  {
    "code" : "BR0268532",
    "display" : "Tenoxicam 20 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268533",
    "display" : "Tenoxicam 40 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268534-1",
    "display" : "Tramadol 50 mg cápsula"
  },
  {
    "code" : "BR0268534-2",
    "display" : "Tramadol 50 mg comprimido"
  },
  {
    "code" : "BR0268540",
    "display" : "Vancomicina 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268541",
    "display" : "Vancomicina 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268542",
    "display" : "Vimblastina 10 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268553",
    "display" : "Sufentanila 50 microgramas/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268572",
    "display" : "Desmopressina 0,2 mg comprimido"
  },
  {
    "code" : "BR0268575",
    "display" : "Desmopressina 4 microgramas/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268580E",
    "display" : "Pamidronato Dissódico 30 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268581",
    "display" : "Pamidronato Dissódico 60 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268581E",
    "display" : "Pamidronato Dissódico 60 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268609",
    "display" : "Levosimendana 12,5 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268691",
    "display" : "Concentrado de Complexo Protrombínico 510 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268808",
    "display" : "Efavirenz 30 mg/mL solução oral"
  },
  {
    "code" : "BR0268812",
    "display" : "Efavirenz 600 mg comprimido"
  },
  {
    "code" : "BR0268816",
    "display" : "Nevirapina 10 mg/mL suspensão oral"
  },
  {
    "code" : "BR0268816-1",
    "display" : "Nevirapina 10 mg/mL suspensão oral"
  },
  {
    "code" : "BR0268819",
    "display" : "Atazanavir 150 mg cápsula"
  },
  {
    "code" : "BR0268820",
    "display" : "Atazanavir 200 mg cápsula"
  },
  {
    "code" : "BR0268825",
    "display" : "Tenofovir 300 mg comprimido"
  },
  {
    "code" : "BR0268825E",
    "display" : "Tenofovir 300 mg comprimido"
  },
  {
    "code" : "BR0268829",
    "display" : "Terizidona 250 mg cápsula"
  },
  {
    "code" : "BR0268830",
    "display" : "Ritonavir 100 mg comprimido"
  },
  {
    "code" : "BR0268831",
    "display" : "Saquinavir 200 mg cápsula"
  },
  {
    "code" : "BR0268837",
    "display" : "Saccharomyces boulardii 100 mg cápsula"
  },
  {
    "code" : "BR0268848",
    "display" : "Pantoprazol 20 mg comprimido"
  },
  {
    "code" : "BR0268851",
    "display" : "Norfloxacino 400 mg comprimido"
  },
  {
    "code" : "BR0268859",
    "display" : "Levotiroxina Sódica 75 microgramas comprimido"
  },
  {
    "code" : "BR0268860",
    "display" : "Levotiroxina Sódica 125 microgramas comprimido"
  },
  {
    "code" : "BR0268861",
    "display" : "Itraconazol 100 mg cápsula"
  },
  {
    "code" : "BR0268862",
    "display" : "Fosinopril 10 mg comprimido"
  },
  {
    "code" : "BR0268864",
    "display" : "Ticlopidina 250 mg comprimido"
  },
  {
    "code" : "BR0268866",
    "display" : "Celecoxibe 200 mg cápsula"
  },
  {
    "code" : "BR0268869",
    "display" : "Rizatriptana 10 mg comprimido"
  },
  {
    "code" : "BR0268896",
    "display" : "Anlodipino 10 mg comprimido"
  },
  {
    "code" : "BR0268951",
    "display" : "Azitromicina 1 g comprimido"
  },
  {
    "code" : "BR0268952",
    "display" : "Azitromicina 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268953",
    "display" : "Benznidazol 100 mg comprimido"
  },
  {
    "code" : "BR0268954",
    "display" : "Praziquantel 600 mg comprimido"
  },
  {
    "code" : "BR0268955",
    "display" : "Clindamicina 150 mg cápsula"
  },
  {
    "code" : "BR0268956",
    "display" : "Levonorgestrel 0,75 mg comprimido"
  },
  {
    "code" : "BR0268957",
    "display" : "Levonorgestrel 30 micrograma comprimido"
  },
  {
    "code" : "BR0268958-1",
    "display" : "Colagenase 0,6 unidades/g pomada"
  },
  {
    "code" : "BR0268958-2",
    "display" : "Colagenase 0,6 unidades/g pomada"
  },
  {
    "code" : "BR0268959-1",
    "display" : "Colagenase 1,2 unidades/g pomada"
  },
  {
    "code" : "BR0268959-2",
    "display" : "Colagenase 1,2 unidades/g pomada"
  },
  {
    "code" : "BR0268960",
    "display" : "Dopamina 50 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268970-1",
    "display" : "Nitroglicerina 25 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268970-2",
    "display" : "Nitroglicerina 50 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268971",
    "display" : "Polimixina B 500.000 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268972",
    "display" : "Remifentanila 5 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268973",
    "display" : "Remifentanila 2 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268994",
    "display" : "Bupropiona 150 mg comprimido"
  },
  {
    "code" : "BR0268994-1",
    "display" : "Bupropiona 150 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0269388",
    "display" : "Dexametasona 4 mg comprimido"
  },
  {
    "code" : "BR0269389",
    "display" : "Prometazina 20 mg/g creme"
  },
  {
    "code" : "BR0269390",
    "display" : "Furosemida 10 mg/mL solução oral"
  },
  {
    "code" : "BR0269391",
    "display" : "Fenitoína 20 mg/mL suspensão oral"
  },
  {
    "code" : "BR0269460",
    "display" : "Ácido Ursodesoxicólico 150 mg comprimido"
  },
  {
    "code" : "BR0269462U0042",
    "display" : "Ácido Alendrônico 70 mg comprimido"
  },
  {
    "code" : "BR0269468",
    "display" : "Ropivacaína 200 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0269470",
    "display" : "Ropivacaína 1,50 g/20 mL (7,5%) solução para injeção; frasco"
  },
  {
    "code" : "BR0269567",
    "display" : "Brometo de Pancurônio 4 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0269571-1",
    "display" : "Proximetacaína 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0269571-2",
    "display" : "Proximetacaína 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0269572",
    "display" : "Bupivacaína Isobárica 5% solução para injeção 4 mL; frasco-ampola"
  },
  {
    "code" : "BR0269573",
    "display" : "Bupivacaína 50 mg/20 mL (0,25%) solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0269574",
    "display" : "Bupivacaína 100 mg/20 mL (0,5%) solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0269574-1",
    "display" : "Bupivacaína Isobárica 20 mg/4 mL (0,5%) solução para injeção; ampola"
  },
  {
    "code" : "BR0269575",
    "display" : "Bupivacaína 150 mg/20 mL (0,75%) solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0269591",
    "display" : "Simeticona 125 mg cápsula"
  },
  {
    "code" : "BR0269592",
    "display" : "Simeticona 40 mg comprimido"
  },
  {
    "code" : "BR0269595",
    "display" : "Picossulfato de Sódio 7,5 mg/mL solução oral"
  },
  {
    "code" : "BR0269603",
    "display" : "Bisacodil 5 mg comprimido gastrorresistente"
  },
  {
    "code" : "BR0269622-1",
    "display" : "Glicerol 120 mg/mL solução retal"
  },
  {
    "code" : "BR0269622-2",
    "display" : "Glicerol 120 mg/mL solução retal"
  },
  {
    "code" : "BR0269622-3",
    "display" : "Glicerol 120 mg/mL solução retal"
  },
  {
    "code" : "BR0269622-4",
    "display" : "Glicerol 120 mg/mL solução retal"
  },
  {
    "code" : "BR0269628",
    "display" : "Albendazol 200 mg comprimido"
  },
  {
    "code" : "BR0269633",
    "display" : "Piperazina 100 mg/mL solução oral"
  },
  {
    "code" : "BR0269634",
    "display" : "Praziquantel 150 mg comprimido"
  },
  {
    "code" : "BR0269759",
    "display" : "Gentamicina 160 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0269760",
    "display" : "Gentamicina 140 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0269760-1",
    "display" : "Gentamicina 280 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0269761",
    "display" : "Gentamicina 20 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0269810",
    "display" : "Aminofilina 200 mg comprimido"
  },
  {
    "code" : "BR0269817",
    "display" : "Terbutalina 0,3 mg/mL xarope"
  },
  {
    "code" : "BR0269818",
    "display" : "Terbutalina 0,5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0269821",
    "display" : "Bromexina 1,6 mg/mL xarope"
  },
  {
    "code" : "BR0269822",
    "display" : "Bromexina 0,8 mg/mL xarope"
  },
  {
    "code" : "BR0269823",
    "display" : "Bromexina 2 mg/mL solução"
  },
  {
    "code" : "BR0269833",
    "display" : "Prilocaína 54 mg/1,8 mL + Felipressina 0,054 unidades internacionais/1,8 mL solução para injeção; carpule"
  },
  {
    "code" : "BR0269835-1",
    "display" : "Lidocaína 25 mg/g + Prilocaína 25 mg/g creme"
  },
  {
    "code" : "BR0269835-2",
    "display" : "Lidocaína 25 mg/g + Prilocaína 25 mg/g creme"
  },
  {
    "code" : "BR0269842-1",
    "display" : "Lidocaína 50 mg/5 mL (1%) solução para injeção; ampola"
  },
  {
    "code" : "BR0269842-2",
    "display" : "Lidocaína 200 mg/20 mL (1%) solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0269842-3",
    "display" : "Lidocaína 500 mg/50 mL solução para injeção; frasco"
  },
  {
    "code" : "BR0269843-1",
    "display" : "Lidocaína 100 mg/5 mL (2%) solução para injeção; ampola"
  },
  {
    "code" : "BR0269843-2",
    "display" : "Lidocaína 400 mg/20 mL (2%) solução para injeção; ampola"
  },
  {
    "code" : "BR0269843-3",
    "display" : "Lidocaína 36 mg/1,8 mL solução para injeção; frasco"
  },
  {
    "code" : "BR0269845-1",
    "display" : "Lidocaína 100 mg/mL solução"
  },
  {
    "code" : "BR0269845-2",
    "display" : "Lidocaína 100 mg/mL solução"
  },
  {
    "code" : "BR0269846-1",
    "display" : "Lidocaína 20 mg/g (2%) gel"
  },
  {
    "code" : "BR0269846-2",
    "display" : "Lidocaína 20 mg/g (2%) gel"
  },
  {
    "code" : "BR0269848",
    "display" : "Lidocaína 100 mg/2 mL (5%) + Glicose 150 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0269851",
    "display" : "Lidocaína 20 mg/mL (2%) + Epinefrina 0,01 mg/mL (1:100.000) solução para injeção 1,8 mL; carpule"
  },
  {
    "code" : "BR0269872",
    "display" : "Hidrocortisona 5 mg/g (0,5%) + Lidocaína 20 mg/g (2%) + Subgalato de Bismuto 20 mg/g (2%) + Óxido de Zinco 100 mg/g (10%) pomada"
  },
  {
    "code" : "BR0269881-2",
    "display" : "Clorexidina 0,2% solução"
  },
  {
    "code" : "BR0269954-1",
    "display" : "Bromoprida 10 mg cápsula"
  },
  {
    "code" : "BR0269954-2",
    "display" : "Bromoprida 10 mg comprimido"
  },
  {
    "code" : "BR0269956",
    "display" : "Bromoprida 4 mg/mL solução oral"
  },
  {
    "code" : "BR0269958-1",
    "display" : "Bromoprida 10 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0269960",
    "display" : "Cefoxitina 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0269962",
    "display" : "Domperidona 10 mg comprimido"
  },
  {
    "code" : "BR0269963",
    "display" : "Domperidona 1 mg/mL suspensão oral"
  },
  {
    "code" : "BR0269963-1",
    "display" : "Domperidona 1 mg/mL suspensão oral"
  },
  {
    "code" : "BR0269964",
    "display" : "Lansoprazol 15 mg cápsula"
  },
  {
    "code" : "BR0269965",
    "display" : "Lansoprazol 30 mg cápsula"
  },
  {
    "code" : "BR0269977",
    "display" : "Omeprazol 20 mg cápsula gastrorresistente e Claritromicina 500 mg comprimido e Amoxicilina 500 mg cápsula"
  },
  {
    "code" : "BR0269986-1",
    "display" : "Claritromicina 250 mg cápsula"
  },
  {
    "code" : "BR0269986-2",
    "display" : "Claritromicina 250 mg comprimido"
  },
  {
    "code" : "BR0269987",
    "display" : "Claritromicina 25 mg/mL suspensão oral"
  },
  {
    "code" : "BR0269987-1",
    "display" : "Claritromicina 25 mg/mL suspensão oral"
  },
  {
    "code" : "BR0269987-2",
    "display" : "Claritromicina 25 mg/mL suspensão oral"
  },
  {
    "code" : "BR0269988-1",
    "display" : "Claritromicina 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0269988-2",
    "display" : "Claritromicina 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0269990",
    "display" : "Estearato de Eritromicina 25 mg/mL suspensão oral"
  },
  {
    "code" : "BR0269991",
    "display" : "Estearato de Eritromicina 250 mg comprimido"
  },
  {
    "code" : "BR0269992-1",
    "display" : "Estearato de Eritromicina 500 mg cápsula"
  },
  {
    "code" : "BR0269992-2",
    "display" : "Estearato de Eritromicina 500 mg comprimido"
  },
  {
    "code" : "BR0269994-1",
    "display" : "Estearato de Eritromicina 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0269994-2",
    "display" : "Estearato de Eritromicina 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0269994-3",
    "display" : "Estearato de Eritromicina 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0269994-4",
    "display" : "Estearato de Eritromicina 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0269995",
    "display" : "Estolato de Eritromicina 250 mg comprimido"
  },
  {
    "code" : "BR0269996",
    "display" : "Estolato de Eritromicina 500 mg comprimido"
  },
  {
    "code" : "BR0269997-2",
    "display" : "Estolato de Eritromicina 25 mg/mL suspensão oral"
  },
  {
    "code" : "BR0269998",
    "display" : "Estolato de Eritromicina 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0269998-1",
    "display" : "Estolato de Eritromicina 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0269998-2",
    "display" : "Estolato de Eritromicina 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0270007",
    "display" : "Nimodipino 30 mg comprimido"
  },
  {
    "code" : "BR0270019",
    "display" : "Gliconato de Cálcio 10% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0270020",
    "display" : "Cloreto de Benzalcônio 0,1 mg/mL + Cloreto de Sódio 9 mg/mL solução nasal"
  },
  {
    "code" : "BR0270020-1",
    "display" : "Cloreto de Benzalcônio 0,1 mg/mL + Cloreto de Sódio 9 mg/mL solução nasal"
  },
  {
    "code" : "BR0270042",
    "display" : "Hipromelose 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0270045",
    "display" : "Hipromelose 3 mg/mL + Dextrana 1 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0270092",
    "display" : "Glicose 5% solução para injeção 100 mL; bolsa"
  },
  {
    "code" : "BR0270092-1",
    "display" : "Glicose 5% solução para injeção 250 mL; bolsa"
  },
  {
    "code" : "BR0270092-2",
    "display" : "Glicose 5% solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "BR0270092-3",
    "display" : "Glicose 5% solução para injeção 1 L; bolsa"
  },
  {
    "code" : "BR0270093",
    "display" : "Cloreto de Sódio 0,9% + Glicose 5% solução para injeção 1 L; frasco-ampola"
  },
  {
    "code" : "BR0270093-1",
    "display" : "Cloreto de Sódio 0,9% + Glicose 5% solução para injeção 250 mL; frasco-ampola"
  },
  {
    "code" : "BR0270095",
    "display" : "Bupivacaína 20 mg/4 mL + Glicose 320 mg/4 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270096",
    "display" : "Bupivacaína 100 mg/20 mL (0,5%) + Epinefrina 100 microgramas/20 mL (1:200.000) solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270114-1",
    "display" : "Cetamina 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0270114-2",
    "display" : "Cetamina 500 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270115",
    "display" : "Remifentanila 1 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270116",
    "display" : "Etomidato 20 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0270118",
    "display" : "Clonazepam 0,5 mg comprimido"
  },
  {
    "code" : "BR0270119",
    "display" : "Clonazepam 2 mg comprimido"
  },
  {
    "code" : "BR0270120",
    "display" : "Clonazepam 2,5 mg/mL solução oral"
  },
  {
    "code" : "BR0270126",
    "display" : "Levodopa 200 mg + Benserazida 50 mg comprimido"
  },
  {
    "code" : "BR0270126-1",
    "display" : "Levodopa 200 mg + Benserazida 50 mg comprimido de liberação modificada"
  },
  {
    "code" : "BR0270127",
    "display" : "Levodopa 100 mg + Benserazida 25 mg comprimido"
  },
  {
    "code" : "BR0270127-2",
    "display" : "Levodopa 100 mg + Benserazida 25 mg cápsula"
  },
  {
    "code" : "BR0270128",
    "display" : "Levodopa 100 mg + Benserazida 25 mg comprimido para suspensão"
  },
  {
    "code" : "BR0270129",
    "display" : "Levodopa 200 mg + Carbidopa 50 mg comprimido"
  },
  {
    "code" : "BR0270130",
    "display" : "Levodopa 250 mg + Carbidopa 25 mg comprimido"
  },
  {
    "code" : "BR0270138",
    "display" : "Biperideno 5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0270140",
    "display" : "Biperideno 2 mg comprimido"
  },
  {
    "code" : "BR0270141",
    "display" : "Biperideno 4 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0270143",
    "display" : "Bromocriptina 2,5 mg comprimido"
  },
  {
    "code" : "BR0270143E",
    "display" : "Bromocriptina 2,5 mg comprimido"
  },
  {
    "code" : "BR0270220",
    "display" : "Succinato Sódico de Hidrocortisona 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270224",
    "display" : "Prednisolona 10 mg/mL (1%) solução oftálmica"
  },
  {
    "code" : "BR0270228",
    "display" : "Polimixina B 10.000 unidades internacionais/mL + Neomicina 5 mg/mL + Hidrocortisona 10 mg/mL suspensão otológica"
  },
  {
    "code" : "BR0270229",
    "display" : "Polimixina B 11.000 unidades internacionais/mL + Neomicina 3,85 mg/mL + Fluocinolona 0,275 mg/mL + Lidocaína 20 mg/mL solução otológica"
  },
  {
    "code" : "BR0270231",
    "display" : "Dexametasona 1 mg/g + Neomicina 5 mg/g + Polimixina B 6.000 unidades internacionais/g pomada oftálmica"
  },
  {
    "code" : "BR0270366",
    "display" : "Epirrubicina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270371",
    "display" : "Etoposídeo 50 mg cápsula"
  },
  {
    "code" : "BR0270372",
    "display" : "Etoposídeo 100 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270376",
    "display" : "Vincristina 1 mg pó para solução para injeção; ampola"
  },
  {
    "code" : "BR0270398",
    "display" : "Mitomicina 5 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270409",
    "display" : "Carboplatina 450 mg/45 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270415",
    "display" : "Oxaliplatina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270416",
    "display" : "Oxaliplatina 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270423",
    "display" : "Mercaptopurina 50 mg comprimido"
  },
  {
    "code" : "BR0270430",
    "display" : "Gencitabina 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270436",
    "display" : "Metotrexato 2,5 mg comprimido"
  },
  {
    "code" : "BR0270436E",
    "display" : "Metotrexato 2,5 mg comprimido"
  },
  {
    "code" : "BR0270438",
    "display" : "Dacarbazina 200 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270440",
    "display" : "Melfalana 2 mg comprimido"
  },
  {
    "code" : "BR0270443",
    "display" : "Ifosfamida 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270444",
    "display" : "Ifosfamida 2 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270445",
    "display" : "Clorambucila 2 mg comprimido"
  },
  {
    "code" : "BR0270456",
    "display" : "Dexametasona 0,05 mg/mL + Cloranfenicol 5 mg/mL + Tetrizolina 0,25 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0270457",
    "display" : "Dexametasona 1 mg/mL + Neomicina 3,5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0270458",
    "display" : "Nafazolina 0,75 mg/mL + Dexametasona 0,5 mg/mL + Neomicina 5 mg/mL solução spray"
  },
  {
    "code" : "BR0270494",
    "display" : "Cloranfenicol 10 mg/g + Colagenase 0,6 unidades internacionais/g creme vaginal"
  },
  {
    "code" : "BR0270495-1",
    "display" : "Cloranfenicol 10 mg/g + Colagenase 0,6 unidades internacionais/g pomada"
  },
  {
    "code" : "BR0270495-2",
    "display" : "Cloranfenicol 10 mg/g + Colagenase 0,6 unidades internacionais/g pomada"
  },
  {
    "code" : "BR0270548",
    "display" : "Ácido Acetilsalicílico 325 mg comprimido"
  },
  {
    "code" : "BR0270555",
    "display" : "Ampicilina 2 g + Sulbactam 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270556",
    "display" : "Ampicilina 1 g + Sulbactam 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270557",
    "display" : "Acetilcisteína 200 mg granulado"
  },
  {
    "code" : "BR0270558-1",
    "display" : "Acetilcisteína 20 mg/mL xarope"
  },
  {
    "code" : "BR0270558-2",
    "display" : "Acetilcisteína 20 mg/mL xarope"
  },
  {
    "code" : "BR0270558-3",
    "display" : "Acetilcisteína 20 mg/mL xarope"
  },
  {
    "code" : "BR0270587",
    "display" : "Dipropionato de Betametasona 0,5 mg/g creme"
  },
  {
    "code" : "BR0270588",
    "display" : "Dipropionato de Betametasona 0,5 mg/g (0,05%) pomada"
  },
  {
    "code" : "BR0270590",
    "display" : "Dipropionato de Betametasona 5 mg/1 mL + Fosfato Dissódico de Betametasona 2 mg/1 mL suspensão para injeção; ampola"
  },
  {
    "code" : "BR0270591",
    "display" : "Dipropionato de Betametasona 0,5 mg/g + Gentamicina 1 mg/g creme"
  },
  {
    "code" : "BR0270593",
    "display" : "Cetoconazol 20 mg/g + Dipropionato de Betametasona 0,5 mg/g + Neomicina 2,5 mg/g creme"
  },
  {
    "code" : "BR0270596",
    "display" : "Dipropionato de Betametasona 0,5 mg/g + Gentamicina 1 mg/g pomada"
  },
  {
    "code" : "BR0270597",
    "display" : "Fosfato Dissódico de Betametasona 3 mg/1 mL + Acetato de Betametasona 3 mg/1 mL suspensão para injeção; ampola"
  },
  {
    "code" : "BR0270602",
    "display" : "Valerato de Betametasona 0,5 mg/g + Gentamicina 1 mg/g + Tolnaftato 10 mg/g + Clioquinol 10 mg/g creme"
  },
  {
    "code" : "BR0270602-1",
    "display" : "Valerato de Betametasona 0,5 mg/g + Gentamicina 1 mg/g + Tolnaftato 10 mg/g + Clioquinol 10 mg/g creme"
  },
  {
    "code" : "BR0270605",
    "display" : "Mebendazol 20 mg/mL + Tiabendazol 33,2 mg/mL suspensão oral"
  },
  {
    "code" : "BR0270606",
    "display" : "Mebendazol 100 mg + Tiabendazol 166 mg comprimido"
  },
  {
    "code" : "BR0270606-1",
    "display" : "Mebendazol 200 mg + Tiabendazol 332 mg comprimido"
  },
  {
    "code" : "BR0270612",
    "display" : "Benzilpenicilina Benzatina 1.200.000 unidades internacionais pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270613",
    "display" : "Benzilpenicilina Benzatina 600.000 unidades internacionais pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270614",
    "display" : "Benzilpenicilina Procaína 300.000 unidades internacionais + Benzilpenicilina Potássica 100.000 unidades internacionais pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270615",
    "display" : "Benzilpenicilina Potássica 1.000.000 unidades internacionais/2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270616",
    "display" : "Benzilpenicilina Potássica 5.000.000 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270620",
    "display" : "Escopolamina 10 mg + Dipirona 250 mg comprimido"
  },
  {
    "code" : "BR0270621",
    "display" : "Escopolamina 20 mg/5 mL + Dipirona 2,5 g/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0270622",
    "display" : "Escopolamina 6,67 mg/mL + Dipirona 333,4 mg/mL solução oral"
  },
  {
    "code" : "BR0270622-1",
    "display" : "Escopolamina 6,67 mg/mL + Dipirona 333,4 mg/mL solução oral"
  },
  {
    "code" : "BR0270633",
    "display" : "Dipirona 300 mg + Isometepteno 30 mg + Cafeína 30 mg comprimido"
  },
  {
    "code" : "BR0270711",
    "display" : "Lansoprazol 30 mg cápsula gastrorresistente e Claritromicina 500 mg comprimido e Amoxicilina 500 mg cápsula"
  },
  {
    "code" : "BR0270713",
    "display" : "Tenecteplase 40 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270768",
    "display" : "Levotiroxina Sódica 175 microgramas comprimido"
  },
  {
    "code" : "BR0270769",
    "display" : "Isoconazol 600 mg óvulo"
  },
  {
    "code" : "BR0270773-2",
    "display" : "Isoconazol 10 mg/g creme vaginal"
  },
  {
    "code" : "BR0270779",
    "display" : "Nifedipino 20 mg + Atenolol 50 mg comprimido"
  },
  {
    "code" : "BR0270782",
    "display" : "Etoricoxibe 60 mg comprimido"
  },
  {
    "code" : "BR0270785",
    "display" : "Fenoterol 100 microgramas/dose solução aerossol; inalador"
  },
  {
    "code" : "BR0270785E",
    "display" : "Fenoterol 100 microgramas/dose solução aerossol; inalador"
  },
  {
    "code" : "BR0270786",
    "display" : "Losartana 25 mg comprimido"
  },
  {
    "code" : "BR0270788",
    "display" : "Losartana 50 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0270791",
    "display" : "Atenolol 100 mg + Clortalidona 25 mg comprimido"
  },
  {
    "code" : "BR0270792",
    "display" : "Atenolol 50 mg + Clortalidona 12,5 mg comprimido"
  },
  {
    "code" : "BR0270793",
    "display" : "Atenolol 25 mg + Clortalidona 12,5 mg comprimido"
  },
  {
    "code" : "BR0270796",
    "display" : "Fexofenadina 60 mg + Pseudoefedrina 120 mg comprimido de liberação modificada"
  },
  {
    "code" : "BR0270798",
    "display" : "Fexofenadina 120 mg comprimido"
  },
  {
    "code" : "BR0270799",
    "display" : "Fexofenadina 180 mg comprimido"
  },
  {
    "code" : "BR0270813-1",
    "display" : "Cianocobalamina 5 mg + Tiamina 100 mg + Piridoxina 100 mg comprimido"
  },
  {
    "code" : "BR0270813-2",
    "display" : "Cianocobalamina 5 mg/2 mL + Tiamina 100 mg/2 mL + Piridoxina 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0270833",
    "display" : "Estradiol 2 mg comprimido"
  },
  {
    "code" : "BR0270835",
    "display" : "Estradiol 50 microgramas/24 horas adesivo transdérmico"
  },
  {
    "code" : "BR0270836",
    "display" : "Estradiol 25 microgramas/24 horas adesivo transdérmico"
  },
  {
    "code" : "BR0270839",
    "display" : "Estradiol 0,75 mg/g gel"
  },
  {
    "code" : "BR0270848",
    "display" : "Estradiol 2 mg + Enantato de Noretisterona 1 mg comprimido"
  },
  {
    "code" : "BR0270877",
    "display" : "Anlodipino 2,5 mg + Enalapril 10 mg cápsula"
  },
  {
    "code" : "BR0270878",
    "display" : "Anlodipino 5 mg + Enalapril 10 mg cápsula"
  },
  {
    "code" : "BR0270879",
    "display" : "Anlodipino 5 mg + Enalapril 20 mg comprimido"
  },
  {
    "code" : "BR0270889",
    "display" : "Escina 10 mg/g + Polissulfato de Escina Sódica 10 mg/g + Salicilato de Dietilamina 50 mg/g gel"
  },
  {
    "code" : "BR0270889-1",
    "display" : "Escina 10 mg/g + Polissulfato de Escina Sódica 10 mg/g + Salicilato de Dietilamina 50 mg/g gel"
  },
  {
    "code" : "BR0270893",
    "display" : "Carbonato de Cálcio 1,25 g (Cálcio 500 mg) + Colecalciferol 200 unidades internacionais comprimido"
  },
  {
    "code" : "BR0270895-1",
    "display" : "Carbonato de Cálcio 1,25 g (Cálcio 500 mg) comprimido"
  },
  {
    "code" : "BR0270895-2",
    "display" : "Carbonato de Cálcio 1,25 g (Cálcio 500 mg) comprimido mastigável"
  },
  {
    "code" : "BR0270906",
    "display" : "Paracetamol 500 mg + Codeína 7,5 mg comprimido"
  },
  {
    "code" : "BR0270907",
    "display" : "Paracetamol 500 mg + Codeína 30 mg comprimido"
  },
  {
    "code" : "BR0270911",
    "display" : "Paracetamol 350 mg + Carisoprodol 150 mg + Cafeína 50 mg comprimido"
  },
  {
    "code" : "BR0270916",
    "display" : "Paracetamol 500 mg + Carisoprodol 150 mg + Fenilbutazona 75 mg comprimido"
  },
  {
    "code" : "BR0270917",
    "display" : "Paracetamol 300 mg + Diclofenaco Sódico 50 mg + Carisoprodol 125 mg + Cafeína 30 mg comprimido"
  },
  {
    "code" : "BR0270965",
    "display" : "Ácido Acetilsalicílico 100 mg + Carbonato de Magnésio 30 mg + Glicinato de Alumínio 15 mg comprimido"
  },
  {
    "code" : "BR0270971",
    "display" : "Escopolamina 10 mg + Paracetamol 500 mg comprimido"
  },
  {
    "code" : "BR0270974",
    "display" : "Clorzoxazona 200 mg + Paracetamol 300 mg comprimido"
  },
  {
    "code" : "BR0270986",
    "display" : "Paracetamol 400 mg + Clorfeniramina 4 mg + Fenilefrina 4 mg comprimido"
  },
  {
    "code" : "BR0270990",
    "display" : "Colestiramina 4 g pó para suspensão oral"
  },
  {
    "code" : "BR0270992",
    "display" : "Diclofenaco Potássico 50 mg comprimido"
  },
  {
    "code" : "BR0270999-1",
    "display" : "Diclofenaco Potássico 75 mg/3 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271000",
    "display" : "Diclofenaco Sódico 50 mg comprimido"
  },
  {
    "code" : "BR0271003",
    "display" : "Diclofenaco Sódico 75 mg/3 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271004",
    "display" : "Diclofenaco Sódico 225 mg/3 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271006",
    "display" : "Diclofenaco Sódico 1 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271028-1",
    "display" : "Diclofenaco Potássico 15 mg/mL suspensão oral"
  },
  {
    "code" : "BR0271028-2",
    "display" : "Diclofenaco Potássico 15 mg/mL suspensão oral"
  },
  {
    "code" : "BR0271036-1",
    "display" : "Doxiciclina 100 mg comprimido"
  },
  {
    "code" : "BR0271050",
    "display" : "Atropina 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271051",
    "display" : "Atropina 10 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271064",
    "display" : "Hidróxido de Alumínio 40 mg/mL + Hidróxido de Magnésio 30 mg/mL + Simeticona 5 mg/mL suspensão oral"
  },
  {
    "code" : "BR0271064-1",
    "display" : "Hidróxido de Alumínio 40 mg/mL + Hidróxido de Magnésio 30 mg/mL + Simeticona 5 mg/mL suspensão oral"
  },
  {
    "code" : "BR0271077",
    "display" : "Pidolato de Magnésio 150 mg/mL solução oral"
  },
  {
    "code" : "BR0271089-1",
    "display" : "Amoxicilina 500 mg cápsula"
  },
  {
    "code" : "BR0271089-2",
    "display" : "Amoxicilina 500 mg comprimido"
  },
  {
    "code" : "BR0271099",
    "display" : "Amoxicilina 500 mg + Ácido Clavulânico 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271101",
    "display" : "Calcitriol 0,25 microgramas cápsula"
  },
  {
    "code" : "BR0271101E",
    "display" : "Calcitriol 0,25 microgramas cápsula"
  },
  {
    "code" : "BR0271102",
    "display" : "Carbonato de Lítio 450 mg comprimido"
  },
  {
    "code" : "BR0271103-1",
    "display" : "Cetoconazol 20 mg/g xampu"
  },
  {
    "code" : "BR0271103-2",
    "display" : "Cetoconazol 20 mg/g xampu"
  },
  {
    "code" : "BR0271104",
    "display" : "Ciclosporina 25 mg cápsula"
  },
  {
    "code" : "BR0271104E",
    "display" : "Ciclosporina 25 mg cápsula"
  },
  {
    "code" : "BR0271105",
    "display" : "Ciclosporina 10 mg cápsula"
  },
  {
    "code" : "BR0271105E",
    "display" : "Ciclosporina 10 mg cápsula"
  },
  {
    "code" : "BR0271106",
    "display" : "Ciclosporina 50 mg cápsula"
  },
  {
    "code" : "BR0271106E",
    "display" : "Ciclosporina 50 mg cápsula"
  },
  {
    "code" : "BR0271107",
    "display" : "Ciclosporina 100 mg cápsula"
  },
  {
    "code" : "BR0271107E",
    "display" : "Ciclosporina 100 mg cápsula"
  },
  {
    "code" : "BR0271109",
    "display" : "Levonorgestrel 0,25 mg + Etinilestradiol 0,05 mg comprimido"
  },
  {
    "code" : "BR0271110",
    "display" : "Ciproterona 2 mg + Etinilestradiol 0,035 mg comprimido"
  },
  {
    "code" : "BR0271111-1",
    "display" : "Amoxicilina 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0271111-2",
    "display" : "Amoxicilina 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0271111-3",
    "display" : "Amoxicilina 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0271111-4",
    "display" : "Amoxicilina 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0271116",
    "display" : "Fluconazol 200 mg/100 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271118",
    "display" : "Flufenazina 25 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271120-1",
    "display" : "Tetraciclina 25 mg/g + Anfotericina B 12,5 mg/g creme vaginal"
  },
  {
    "code" : "BR0271120-2",
    "display" : "Tetraciclina 25 mg/g + Anfotericina B 12,5 mg/g creme vaginal"
  },
  {
    "code" : "BR0271123-1",
    "display" : "Tetraciclina 5 mg/g pomada oftálmica"
  },
  {
    "code" : "BR0271124-1",
    "display" : "Cetotifeno 0,2 mg/mL xarope"
  },
  {
    "code" : "BR0271124-2",
    "display" : "Cetotifeno 0,2 mg/mL xarope"
  },
  {
    "code" : "BR0271124-3",
    "display" : "Cetotifeno 0,2 mg/mL xarope"
  },
  {
    "code" : "BR0271125",
    "display" : "Cetotifeno 1 mg/mL solução oral"
  },
  {
    "code" : "BR0271126",
    "display" : "Cetotifeno 1 mg comprimido"
  },
  {
    "code" : "BR0271129",
    "display" : "Bisoprolol 5 mg + Hidroclorotiazida 6,25 mg comprimido"
  },
  {
    "code" : "BR0271134-1",
    "display" : "Ibuprofeno 20 mg/mL suspensão oral"
  },
  {
    "code" : "BR0271134-2",
    "display" : "Ibuprofeno 20 mg/mL suspensão oral"
  },
  {
    "code" : "BR0271138",
    "display" : "Rifampicina 300 mg + Isoniazida 200 mg cápsula"
  },
  {
    "code" : "BR0271139",
    "display" : "Rifampicina 150 mg + Isoniazida 100 mg cápsula"
  },
  {
    "code" : "BR0271140",
    "display" : "Rifamicina SV Sódica 10 mg/mL solução spray"
  },
  {
    "code" : "BR0271162",
    "display" : "Hidroclorotiazida 50 mg + Amilorida 5 mg comprimido"
  },
  {
    "code" : "BR0271165",
    "display" : "Hidroclorotiazida 25 mg + Amilorida 2,5 mg comprimido"
  },
  {
    "code" : "BR0271166",
    "display" : "Furosemida 40 mg + Amilorida 10 mg comprimido"
  },
  {
    "code" : "BR0271167",
    "display" : "Lisinopril 5 mg comprimido"
  },
  {
    "code" : "BR0271168",
    "display" : "Lisinopril 10 mg comprimido"
  },
  {
    "code" : "BR0271169",
    "display" : "Lisinopril 20 mg comprimido"
  },
  {
    "code" : "BR0271170",
    "display" : "Lisinopril 20 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0271171",
    "display" : "Enalapril 20 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0271172",
    "display" : "Enalapril 10 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "BR0271197",
    "display" : "Pindolol 10 mg + Clopamida 5 mg comprimido"
  },
  {
    "code" : "BR0271217",
    "display" : "Amoxicilina 500 mg + Ácido Clavulânico 125 mg comprimido"
  },
  {
    "code" : "BR0271218",
    "display" : "Amoxicilina 25 mg/mL + Ácido Clavulânico 6,25 mg/mL suspensão oral"
  },
  {
    "code" : "BR0271352",
    "display" : "Cloridrato de Pilocarpina 10 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271353",
    "display" : "Cloridrato de Pilocarpina 20 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271353-1",
    "display" : "Cloridrato de Pilocarpina 20 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271353E",
    "display" : "Cloridrato de Pilocarpina 20 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271354",
    "display" : "Cloridrato de Pilocarpina 40 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271355",
    "display" : "Metronidazol 100 mg/g + Nistatina 20.000 unidades internacionais/g creme vaginal"
  },
  {
    "code" : "BR0271356",
    "display" : "Alprazolam 1 mg comprimido"
  },
  {
    "code" : "BR0271357",
    "display" : "Alprazolam 0,5 mg comprimido"
  },
  {
    "code" : "BR0271357-1",
    "display" : "Alprazolam 0,5 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0271358",
    "display" : "Alprazolam 0,25 mg comprimido"
  },
  {
    "code" : "BR0271359",
    "display" : "Carbonato de Cálcio + Lactogliconato de Cálcio 500 mg comprimido"
  },
  {
    "code" : "BR0271360",
    "display" : "Carbonato de Cálcio + Lactogliconato de Cálcio 1.000 mg comprimido"
  },
  {
    "code" : "BR0271373E",
    "display" : "Formoterol 12 microgramas cápsula para inalação"
  },
  {
    "code" : "BR0271391",
    "display" : "Morfina 30 mg comprimido"
  },
  {
    "code" : "BR0271391E",
    "display" : "Morfina 30 mg comprimido"
  },
  {
    "code" : "BR0271392",
    "display" : "Morfina 10 mg comprimido"
  },
  {
    "code" : "BR0271392E",
    "display" : "Morfina 10 mg comprimido"
  },
  {
    "code" : "BR0271394",
    "display" : "Sulfato de Morfina 10 mg/mL solução oral"
  },
  {
    "code" : "BR0271394E",
    "display" : "Sulfato de Morfina 10 mg/mL solução oral"
  },
  {
    "code" : "BR0271434",
    "display" : "Estrogênios Conjugados 0,625 mg comprimido"
  },
  {
    "code" : "BR0271435",
    "display" : "Estrogênios Conjugados 0,625 mg/g creme vaginal"
  },
  {
    "code" : "BR0271444",
    "display" : "Medroxiprogesterona 2,5 mg comprimido"
  },
  {
    "code" : "BR0271445",
    "display" : "Medroxiprogesterona 10 mg comprimido"
  },
  {
    "code" : "BR0271556",
    "display" : "Midazolam 2 mg/mL solução oral"
  },
  {
    "code" : "BR0271570",
    "display" : "Tobramicina 3 mg/g + Dexametasona 1 mg/g pomada oftálmica"
  },
  {
    "code" : "BR02715701",
    "display" : "Dexametasona 1 mg/g pomada oftálmica"
  },
  {
    "code" : "BR0271578",
    "display" : "Tobramicina 75 mg/1,5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271581",
    "display" : "Tobramicina 3 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271582",
    "display" : "Tobramicina 3 mg/g pomada oftálmica"
  },
  {
    "code" : "BR0271599",
    "display" : "Succinato Sódico de Metilprednisolona 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271600",
    "display" : "Succinato Sódico de Metilprednisolona 125 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271604",
    "display" : "Aceponato de Metilprednisolona 1 mg/g creme"
  },
  {
    "code" : "BR0271606",
    "display" : "Nortriptilina 25 mg cápsula"
  },
  {
    "code" : "BR0271607",
    "display" : "Nortriptilina 75 mg cápsula"
  },
  {
    "code" : "BR0271608",
    "display" : "Nortriptilina 2 mg/mL solução oral"
  },
  {
    "code" : "BR0271609-1",
    "display" : "Nortriptilina 10 mg cápsula"
  },
  {
    "code" : "BR0271609-2",
    "display" : "Nortriptilina 10 mg comprimido"
  },
  {
    "code" : "BR0271610",
    "display" : "Nortriptilina 50 mg cápsula"
  },
  {
    "code" : "BR0271610-1",
    "display" : "Nortriptilina 50 mg comprimido"
  },
  {
    "code" : "BR0271620",
    "display" : "Olanzapina 5 mg comprimido"
  },
  {
    "code" : "BR0271620E",
    "display" : "Olanzapina 5 mg comprimido"
  },
  {
    "code" : "BR0271621",
    "display" : "Olanzapina 10 mg comprimido"
  },
  {
    "code" : "BR0271621E",
    "display" : "Olanzapina 10 mg comprimido"
  },
  {
    "code" : "BR0271644",
    "display" : "Oximetolona 50 mg comprimido"
  },
  {
    "code" : "BR0271645",
    "display" : "Oximetazolina 0,5 mg/mL solução nasal"
  },
  {
    "code" : "BR0271647",
    "display" : "Oximetazolina 0,25 mg/mL solução nasal"
  },
  {
    "code" : "BR0271652",
    "display" : "Hidroxocobalamina 15 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271653-1",
    "display" : "Hidroxocobalamina 1 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271653-2",
    "display" : "Hidroxocobalamina 2 mg/2 mL solução par a injeção; ampola"
  },
  {
    "code" : "BR0271654",
    "display" : "Megestrol 160 mg comprimido"
  },
  {
    "code" : "BR0271656",
    "display" : "Caspofungina 70 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271657",
    "display" : "Caspofungina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271659-1",
    "display" : "Ambroxol 6 mg/mL xarope"
  },
  {
    "code" : "BR0271659-2",
    "display" : "Ambroxol 6 mg/mL xarope"
  },
  {
    "code" : "BR0271660-1",
    "display" : "Ambroxol 3 mg/mL xarope"
  },
  {
    "code" : "BR0271660-2",
    "display" : "Ambroxol 3 mg/mL xarope"
  },
  {
    "code" : "BR0271661-1",
    "display" : "Ambroxol 7,5 mg/mL solução"
  },
  {
    "code" : "BR0271661-2",
    "display" : "Ambroxol 7,5 mg/mL solução"
  },
  {
    "code" : "BR0271666",
    "display" : "Aceclofenaco 100 mg comprimido"
  },
  {
    "code" : "BR0271670",
    "display" : "Ácido Mefenâmico 500 mg comprimido"
  },
  {
    "code" : "BR0271685",
    "display" : "Ácido Ascórbico 1 g comprimido efervescente"
  },
  {
    "code" : "BR0271686",
    "display" : "Ácido Ascórbico 2 g comprimido efervescente"
  },
  {
    "code" : "BR0271687",
    "display" : "Ácido Ascórbico 500 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271689-1",
    "display" : "Ácido Ascórbico 200 mg/mL solução oral"
  },
  {
    "code" : "BR0271689-2",
    "display" : "Ácido Ascórbico 200 mg/mL solução oral"
  },
  {
    "code" : "BR0271691",
    "display" : "Ácido Ascórbico 500 mg comprimido"
  },
  {
    "code" : "BR0271709",
    "display" : "Amiodarona 100 mg comprimido"
  },
  {
    "code" : "BR0271710",
    "display" : "Amiodarona 150 mg/3 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271724",
    "display" : "Piperacilina 2 g + Tazobactam 250 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271725",
    "display" : "Piperacilina 4 g + Tazobactam 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271727",
    "display" : "Pravastatina 40 mg comprimido"
  },
  {
    "code" : "BR0271727E",
    "display" : "Pravastatina 40 mg comprimido"
  },
  {
    "code" : "BR0271746",
    "display" : "Baclofeno 10 mg comprimido"
  },
  {
    "code" : "BR0271747",
    "display" : "Benciclano 100 mg comprimido"
  },
  {
    "code" : "BR0271748",
    "display" : "Benciclano 200 mg comprimido"
  },
  {
    "code" : "BR0271758",
    "display" : "Betanecol 10 mg cápsula"
  },
  {
    "code" : "BR0271761",
    "display" : "Bicalutamida 50 mg comprimido"
  },
  {
    "code" : "BR0271764",
    "display" : "Brometo de Piridostigmina 60 mg comprimido"
  },
  {
    "code" : "BR0271764E",
    "display" : "Brometo de Piridostigmina 60 mg comprimido"
  },
  {
    "code" : "BR0271773",
    "display" : "Bromazepam 3 mg comprimido"
  },
  {
    "code" : "BR0271774",
    "display" : "Bromazepam 6 mg comprimido"
  },
  {
    "code" : "BR0271790-1",
    "display" : "Fenilefrina 100 mg/mL (10%) solução oftálmica"
  },
  {
    "code" : "BR0271790-2",
    "display" : "Fenilefrina 100 mg/mL (10%) solução oftálmica"
  },
  {
    "code" : "BR0271790-3",
    "display" : "Fenilefrina 100 mg/mL (10%) solução oftálmica"
  },
  {
    "code" : "BR0271848-1",
    "display" : "Bimatoprosta 0,3 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271848-2",
    "display" : "Bimatoprosta 0,3 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271848E",
    "display" : "Bimatoprosta 0,3 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271866-1",
    "display" : "Brinzolamida 10 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271866-2",
    "display" : "Brinzolamida 10 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271866E",
    "display" : "Brinzolamida 10 mg/mL suspensão oftálmica"
  },
  {
    "code" : "BR0271876",
    "display" : "Ringer solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "BR0271913",
    "display" : "Retinol 50.000 unidades internacionais comprimido"
  },
  {
    "code" : "BR0271946",
    "display" : "Fentanila 25 microgramas/hora adesivo transdérmico"
  },
  {
    "code" : "BR0271948",
    "display" : "Fentanila 100 microgramas/hora adesivo transdérmico"
  },
  {
    "code" : "BR0271949",
    "display" : "Fentanila 50 microgramas/hora adesivo transdérmico"
  },
  {
    "code" : "BR0271950-1",
    "display" : "Fentanila 0,1 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271950-2",
    "display" : "Fentanila 0,25 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271950-3",
    "display" : "Fentanila 0,5 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271953-1",
    "display" : "Droperidol 2,5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271980",
    "display" : "Cefadroxila 50 mg/mL solução oral"
  },
  {
    "code" : "BR0271982",
    "display" : "Cefadroxila 500 mg cápsula"
  },
  {
    "code" : "BR0271986",
    "display" : "Cefuroxima 25 mg/mL suspensão oral"
  },
  {
    "code" : "BR0271987",
    "display" : "Cefuroxima 750 mg pó para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271988",
    "display" : "Cefuroxima 250 mg comprimido"
  },
  {
    "code" : "BR0271989",
    "display" : "Cefuroxima 500 mg comprimido"
  },
  {
    "code" : "BR0271990",
    "display" : "Cefuroxima 125 mg comprimido"
  },
  {
    "code" : "BR0271992",
    "display" : "Celecoxibe 100 mg cápsula"
  },
  {
    "code" : "BR0272005",
    "display" : "Citicolina 500 mg comprimido"
  },
  {
    "code" : "BR0272022",
    "display" : "Tamoxifeno 10 mg comprimido"
  },
  {
    "code" : "BR0272023",
    "display" : "Tamoxifeno 20 mg comprimido"
  },
  {
    "code" : "BR0272027",
    "display" : "Bamifilina 600 mg comprimido"
  },
  {
    "code" : "BR0272028",
    "display" : "Bamifilina 300 mg comprimido"
  },
  {
    "code" : "BR0272041",
    "display" : "Clomipramina 75 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0272042",
    "display" : "Clonidina 0,2 mg comprimido"
  },
  {
    "code" : "BR0272043",
    "display" : "Clonidina 0,1 mg comprimido"
  },
  {
    "code" : "BR0272044",
    "display" : "Clonidina 0,15 mg comprimido"
  },
  {
    "code" : "BR0272045",
    "display" : "Clopidogrel 75 mg comprimido"
  },
  {
    "code" : "BR0272045E",
    "display" : "Clopidogrel 75 mg comprimido"
  },
  {
    "code" : "BR0272049",
    "display" : "Clordiazepóxido 25 mg comprimido"
  },
  {
    "code" : "BR0272050",
    "display" : "Clordiazepóxido 10 mg comprimido"
  },
  {
    "code" : "BR0272082",
    "display" : "Cloridrato de Sevelâmer 400 mg comprimido"
  },
  {
    "code" : "BR0272083",
    "display" : "Cloridrato de Sevelâmer 800 mg comprimido"
  },
  {
    "code" : "BR0272083E",
    "display" : "Cloridrato de Sevelâmer 800 mg comprimido"
  },
  {
    "code" : "BR0272088-1",
    "display" : "Sulfadiazina de Prata 10 mg/g (1%) + Nitrato de Cério 4 mg/g (0,4%) creme"
  },
  {
    "code" : "BR0272088-2",
    "display" : "Sulfadiazina de Prata 10 mg/g (1%) + Nitrato de Cério 4 mg/g (0,4%) creme"
  },
  {
    "code" : "BR0272088-3",
    "display" : "Sulfadiazina de Prata 10 mg/g (1%) + Nitrato de Cério 4 mg/g (0,4%) creme"
  },
  {
    "code" : "BR0272088-4",
    "display" : "Sulfadiazina de Prata 10 mg/g (1%) + Nitrato de Cério 4 mg/g (0,4%) creme"
  },
  {
    "code" : "BR0272089",
    "display" : "Sulfadiazina de Prata 10 mg/g creme"
  },
  {
    "code" : "BR0272089-1",
    "display" : "Sulfadiazina de Prata 10 mg/g creme"
  },
  {
    "code" : "BR0272089-2",
    "display" : "Sulfadiazina de Prata 1% pasta"
  },
  {
    "code" : "BR0272089-3",
    "display" : "Sulfadiazina de Prata 1% pasta"
  },
  {
    "code" : "BR0272089-4",
    "display" : "Sulfadiazina de Prata 1% pasta"
  },
  {
    "code" : "BR0272089-5",
    "display" : "Sulfadiazina de Prata 1% pasta"
  },
  {
    "code" : "BR0272089-6",
    "display" : "Sulfadiazina de Prata 10 mg/g creme"
  },
  {
    "code" : "BR0272089-7",
    "display" : "Sulfadiazina de Prata 10 mg/g creme"
  },
  {
    "code" : "BR0272089-8",
    "display" : "Sulfadiazina de Prata 10 mg/g creme vaginal"
  },
  {
    "code" : "BR0272094",
    "display" : "Lamivudina 150 mg + Zidovudina 300 mg comprimido"
  },
  {
    "code" : "BR0272131",
    "display" : "Sulfato de Quinina 500 mg comprimido"
  },
  {
    "code" : "BR0272134",
    "display" : "Ciclopentolato 10 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0272166",
    "display" : "Ciclobenzaprina 5 mg comprimido"
  },
  {
    "code" : "BR0272174",
    "display" : "Benzidamina 30 mg/mL solução oral"
  },
  {
    "code" : "BR0272178",
    "display" : "Clobutinol 4 mg/mL xarope"
  },
  {
    "code" : "BR0272194",
    "display" : "Esmolol 100 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272198",
    "display" : "Etilefrina 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272201",
    "display" : "Etilefrina 7,5 mg/mL solução oral"
  },
  {
    "code" : "BR0272217",
    "display" : "Difenidramina 50 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272220",
    "display" : "Femproporex 25 mg comprimido"
  },
  {
    "code" : "BR0272229",
    "display" : "Lercanidipino 10 mg comprimido"
  },
  {
    "code" : "BR0272234",
    "display" : "Levobunolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0272320",
    "display" : "Metilfenidato 10 mg comprimido"
  },
  {
    "code" : "BR0272326",
    "display" : "Naloxona 0,4 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272327",
    "display" : "Oxibutinina 5 mg comprimido"
  },
  {
    "code" : "BR0272328",
    "display" : "Oxibutinina 1 mg/mL xarope"
  },
  {
    "code" : "BR0272329",
    "display" : "Petidina 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272330",
    "display" : "Piperidolato 100 mg + Hesperidina 50 mg + Ácido Ascórbico 50 mg comprimido"
  },
  {
    "code" : "BR0272331",
    "display" : "Dimenidrinato 100 mg comprimido"
  },
  {
    "code" : "BR0272333",
    "display" : "Dimenidrinato 50 mg + Piridoxina 10 mg comprimido"
  },
  {
    "code" : "BR0272334-1",
    "display" : "Dimenidrinato 50 mg/1 mL + Piridoxina 50 mg/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272334-2",
    "display" : "Dimenidrinato 500 mg/10 mL + Piridoxina 500 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272335",
    "display" : "Dimenidrinato 25 mg/mL + Piridoxina 5 mg/mL solução oral"
  },
  {
    "code" : "BR0272336",
    "display" : "Dimenidrinato 30 mg/10 mL + Piridoxina 50 mg/10 mL + Glicose 1 g/10 mL + Frutose 1 g/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272337",
    "display" : "Piridoxina 100 mg comprimido"
  },
  {
    "code" : "BR0272338",
    "display" : "Piridoxina 300 mg comprimido"
  },
  {
    "code" : "BR0272340",
    "display" : "Tiamina 100 mg cápsula"
  },
  {
    "code" : "BR0272341",
    "display" : "Tiamina 300 mg comprimido"
  },
  {
    "code" : "BR0272343",
    "display" : "Tiamina 100 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272362",
    "display" : "Protamina 50 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272363",
    "display" : "Sertralina 100 mg comprimido"
  },
  {
    "code" : "BR0272364",
    "display" : "Sertralina 25 mg comprimido"
  },
  {
    "code" : "BR0272364-1",
    "display" : "Sertralina 75 mg comprimido"
  },
  {
    "code" : "BR0272365",
    "display" : "Sertralina 50 mg comprimido"
  },
  {
    "code" : "BR0272366",
    "display" : "Tioridazina 50 mg comprimido"
  },
  {
    "code" : "BR0272367",
    "display" : "Tioridazina 100 mg comprimido"
  },
  {
    "code" : "BR0272369",
    "display" : "Valaciclovir 500 mg comprimido"
  },
  {
    "code" : "BR0272379",
    "display" : "Venlafaxina 75 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0272380",
    "display" : "Venlafaxina 150 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0272381",
    "display" : "Venlafaxina 37,5 mg comprimido"
  },
  {
    "code" : "BR0272382",
    "display" : "Venlafaxina 75 mg comprimido"
  },
  {
    "code" : "BR0272383",
    "display" : "Venlafaxina 50 mg comprimido"
  },
  {
    "code" : "BR0272400",
    "display" : "Nafazolina 0,5 mg/mL solução nasal"
  },
  {
    "code" : "BR0272400-1",
    "display" : "Nafazolina 0,5 mg/mL solução nasal"
  },
  {
    "code" : "BR0272402",
    "display" : "Nafazolina 0,5 mg/mL + Cloreto de Benzalcônio 0,1 mg/mL solução nasal"
  },
  {
    "code" : "BR0272406",
    "display" : "Nafazolina 0,25 mg/mL + Feniramina 3 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0272410",
    "display" : "Fluocinolona 0,25 mg/mL + Nafazolina 0,5 mg/mL + Zinco 4 mg/mL + Neomicina 7 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0272411",
    "display" : "Nafazolina 0,5 mg/mL + Zinco 1 mg/mL + Berberina 0,025 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0272412",
    "display" : "Propafenona 300 mg comprimido"
  },
  {
    "code" : "BR0272417",
    "display" : "Cloroquina 250 mg comprimido"
  },
  {
    "code" : "BR0272420",
    "display" : "Clortalidona 50 mg comprimido"
  },
  {
    "code" : "BR0272423",
    "display" : "Clotrimazol 10 mg/g (1%) creme"
  },
  {
    "code" : "BR0272423-1",
    "display" : "Clotrimazol 10 mg/g (1%) creme"
  },
  {
    "code" : "BR0272423-2",
    "display" : "Clotrimazol 10 mg/g (1%) creme"
  },
  {
    "code" : "BR0272423-3",
    "display" : "Clotrimazol 10 mg/g (1%) creme"
  },
  {
    "code" : "BR0272429",
    "display" : "Clozapina 25 mg comprimido"
  },
  {
    "code" : "BR0272429E",
    "display" : "Clozapina 25 mg comprimido"
  },
  {
    "code" : "BR0272431",
    "display" : "Clozapina 100 mg comprimido"
  },
  {
    "code" : "BR0272431E",
    "display" : "Clozapina 100 mg comprimido"
  },
  {
    "code" : "BR0272434",
    "display" : "Anlodipino 5 mg comprimido"
  },
  {
    "code" : "BR0272435",
    "display" : "Anlodipino 2,5 mg comprimido"
  },
  {
    "code" : "BR0272445",
    "display" : "Ciclofenila 200 mg comprimido"
  },
  {
    "code" : "BR0272454-1",
    "display" : "Carbamazepina 20 mg/mL suspensão oral"
  },
  {
    "code" : "BR0272454-2",
    "display" : "Carbamazepina 20 mg/mL suspensão oral"
  },
  {
    "code" : "BR0272457",
    "display" : "Carbamazepina 400 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0272458",
    "display" : "Carbamazepina 200 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0272469",
    "display" : "Dalteparina Sódica 5.000 unidades internacionais /0,2 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0272470",
    "display" : "Dalteparina Sódica 2.500 unidades internacionais /0,2 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0272471E",
    "display" : "Danazol 50 mg cápsula"
  },
  {
    "code" : "BR0272472E",
    "display" : "Danazol 200 mg cápsula"
  },
  {
    "code" : "BR0272473",
    "display" : "Danazol 100 mg comprimido"
  },
  {
    "code" : "BR0272473E",
    "display" : "Danazol 100 mg cápsula"
  },
  {
    "code" : "BR0272475",
    "display" : "Dantroleno 20 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272476",
    "display" : "Dapsona 100 mg comprimido"
  },
  {
    "code" : "BR0272477",
    "display" : "Cetirizina 10 mg comprimido"
  },
  {
    "code" : "BR0272478",
    "display" : "Flunarizina 10 mg comprimido"
  },
  {
    "code" : "BR0272482",
    "display" : "Zuclopentixol 10 mg comprimido"
  },
  {
    "code" : "BR0272487",
    "display" : "Didanosina 25 mg comprimido"
  },
  {
    "code" : "BR0272488",
    "display" : "Didanosina 100 mg comprimido"
  },
  {
    "code" : "BR0272489",
    "display" : "Citrato de Dietilcarbamazina 50 mg comprimido"
  },
  {
    "code" : "BR0272490",
    "display" : "Dietilestilbestrol 1 mg comprimido"
  },
  {
    "code" : "BR0272525",
    "display" : "Dipiridamol 10 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272565",
    "display" : "Retinol 150.000 unidades internacionais/mL solução oral"
  },
  {
    "code" : "BR0272567",
    "display" : "Retinol 5.500 unidades internacionais/mL + Colecalciferol 2.200 unidades internacionais/mL solução oral"
  },
  {
    "code" : "BR0272568",
    "display" : "Retinol 50.000 unidades internacionais/mL + Colecalciferol 10.000 unidades internacionais/mL solução oral"
  },
  {
    "code" : "BR0272568-2",
    "display" : "Retinol 50.000 unidades internacionais/mL + Colecalciferol 10.000 unidades internacionais/mL solução oral"
  },
  {
    "code" : "BR0272572",
    "display" : "Buspirona 5 mg comprimido"
  },
  {
    "code" : "BR0272573",
    "display" : "Buspirona 10 mg comprimido"
  },
  {
    "code" : "BR0272579",
    "display" : "Dorzolamida 20 mg/mL + Timolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0272580",
    "display" : "Dorzolamida 20 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0272580E",
    "display" : "Dorzolamida 20 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0272581",
    "display" : "Timolol 5 mg/mL (0,5%) solução oftálmica"
  },
  {
    "code" : "BR0272585",
    "display" : "Decanoato de Zuclopentixol 200 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272587",
    "display" : "Dissulfiram 250 mg comprimido"
  },
  {
    "code" : "BR0272588",
    "display" : "Divalproato de sódio 250 mg comprimido gastrorresistente"
  },
  {
    "code" : "BR0272589",
    "display" : "Divalproato de sódio 500 mg comprimido gastrorresistente"
  },
  {
    "code" : "BR0272602",
    "display" : "Dropropizina 3 mg/mL xarope"
  },
  {
    "code" : "BR0272602-3",
    "display" : "Dropropizina 3 mg/mL xarope"
  },
  {
    "code" : "BR0272603",
    "display" : "Dropropizina 1,5 mg/mL xarope"
  },
  {
    "code" : "BR0272603-1",
    "display" : "Dropropizina 1,5 mg/mL xarope"
  },
  {
    "code" : "BR0272636",
    "display" : "Enflurano líquido para inalação 100 mL"
  },
  {
    "code" : "BR0272644",
    "display" : "Enoxaparina Sódica 20 mg/0,2 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0272645",
    "display" : "Enoxaparina Sódica 40 mg/0,4 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0272653",
    "display" : "Entacapona 200 mg comprimido"
  },
  {
    "code" : "BR0272653E",
    "display" : "Entacapona 200 mg comprimido"
  },
  {
    "code" : "BR0272689",
    "display" : "Nandrolona 25 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272690",
    "display" : "Nandrolona 50 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272737",
    "display" : "Antimoniato de Meglumina 300 mg/mL solução para injeção 5 mL; ampola"
  },
  {
    "code" : "BR0272780",
    "display" : "Cloroquina 150 mg comprimido"
  },
  {
    "code" : "BR0272780E",
    "display" : "Cloroquina 150 mg comprimido"
  },
  {
    "code" : "BR0272782",
    "display" : "Codeína 30 mg comprimido"
  },
  {
    "code" : "BR0272782E",
    "display" : "Codeína 30 mg comprimido"
  },
  {
    "code" : "BR0272784",
    "display" : "Codeína 3 mg/mL solução oral"
  },
  {
    "code" : "BR0272784E",
    "display" : "Codeína 3 mg/mL solução oral"
  },
  {
    "code" : "BR0272785",
    "display" : "Donepezila 5 mg comprimido"
  },
  {
    "code" : "BR0272785E",
    "display" : "Donepezila 5 mg comprimido"
  },
  {
    "code" : "BR0272786",
    "display" : "Donepezila 10 mg comprimido"
  },
  {
    "code" : "BR0272786E",
    "display" : "Donepezila 10 mg comprimido"
  },
  {
    "code" : "BR0272787",
    "display" : "Alfadornase 1 mg/mL solução para inalação 2,5 mL; ampola"
  },
  {
    "code" : "BR0272787E",
    "display" : "Alfadornase 1 mg/mL solução para inalação 2,5 mL; ampola"
  },
  {
    "code" : "BR0272790",
    "display" : "Etionamida 250 mg comprimido"
  },
  {
    "code" : "BR0272791",
    "display" : "Etossuximida 250 mg comprimido"
  },
  {
    "code" : "BR0272792",
    "display" : "Etossuximida 50 mg/mL solução oral"
  },
  {
    "code" : "BR0272792E",
    "display" : "Etossuximida 50 mg/mL xarope"
  },
  {
    "code" : "BR0272793",
    "display" : "Fludrocortisona 0,1 mg comprimido"
  },
  {
    "code" : "BR0272793E",
    "display" : "Fludrocortisona 0,1 mg comprimido"
  },
  {
    "code" : "BR0272796",
    "display" : "Heparina Sódica 25.000 unidades internacionais/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272807",
    "display" : "Isotretinoína 10 mg cápsula"
  },
  {
    "code" : "BR0272807E",
    "display" : "Isotretinoína 10 mg cápsula"
  },
  {
    "code" : "BR0272808",
    "display" : "Isotretinoína 20 mg cápsula"
  },
  {
    "code" : "BR0272808E",
    "display" : "Isotretinoína 20 mg cápsula"
  },
  {
    "code" : "BR0272809",
    "display" : "Lamotrigina 100 mg comprimido"
  },
  {
    "code" : "BR0272809E",
    "display" : "Lamotrigina 100 mg comprimido"
  },
  {
    "code" : "BR0272815",
    "display" : "Penicilamina 250 mg cápsula"
  },
  {
    "code" : "BR0272815E",
    "display" : "Penicilamina 250 mg cápsula"
  },
  {
    "code" : "BR0272817",
    "display" : "Midazolam 15 mg comprimido"
  },
  {
    "code" : "BR0272822",
    "display" : "Pirazinamida 500 mg comprimido"
  },
  {
    "code" : "BR0272824",
    "display" : "Pramipexol 0,125 mg comprimido"
  },
  {
    "code" : "BR0272824E",
    "display" : "Pramipexol 0,125 mg comprimido"
  },
  {
    "code" : "BR0272825",
    "display" : "Pramipexol 0,25 mg comprimido"
  },
  {
    "code" : "BR0272825E",
    "display" : "Pramipexol 0,25 mg comprimido"
  },
  {
    "code" : "BR0272826",
    "display" : "Pramipexol 1 mg comprimido"
  },
  {
    "code" : "BR0272826E",
    "display" : "Pramipexol 1 mg comprimido"
  },
  {
    "code" : "BR0272827",
    "display" : "Primaquina 5 mg comprimido"
  },
  {
    "code" : "BR0272828",
    "display" : "Primaquina 15 mg comprimido"
  },
  {
    "code" : "BR0272831",
    "display" : "Quetiapina 25 mg comprimido"
  },
  {
    "code" : "BR0272831E",
    "display" : "Quetiapina 25 mg comprimido"
  },
  {
    "code" : "BR0272832",
    "display" : "Quetiapina 100 mg comprimido"
  },
  {
    "code" : "BR0272832E",
    "display" : "Quetiapina 100 mg comprimido"
  },
  {
    "code" : "BR0272833",
    "display" : "Quetiapina 200 mg comprimido"
  },
  {
    "code" : "BR0272833E",
    "display" : "Quetiapina 200 mg comprimido"
  },
  {
    "code" : "BR0272834",
    "display" : "Raloxifeno 60 mg comprimido"
  },
  {
    "code" : "BR0272834E",
    "display" : "Raloxifeno 60 mg comprimido"
  },
  {
    "code" : "BR0272835",
    "display" : "Ribavirina 250 mg cápsula"
  },
  {
    "code" : "BR0272835E",
    "display" : "Ribavirina 250 mg cápsula"
  },
  {
    "code" : "BR0272837",
    "display" : "Rifampicina 300 mg cápsula"
  },
  {
    "code" : "BR0272838",
    "display" : "Riluzol 50 mg comprimido"
  },
  {
    "code" : "BR0272838E",
    "display" : "Riluzol 50 mg comprimido"
  },
  {
    "code" : "BR0272839",
    "display" : "Risperidona 1 mg comprimido"
  },
  {
    "code" : "BR0272839E",
    "display" : "Risperidona 1 mg comprimido"
  },
  {
    "code" : "BR0272843",
    "display" : "Sinvastatina 5 mg comprimido"
  },
  {
    "code" : "BR0272846",
    "display" : "Talidomida 100 mg comprimido"
  },
  {
    "code" : "BR0272847E",
    "display" : "Tolcapona 100 mg comprimido"
  },
  {
    "code" : "BR0272848",
    "display" : "Tolcapona 200 mg comprimido"
  },
  {
    "code" : "BR0272849",
    "display" : "Topiramato 25 mg comprimido"
  },
  {
    "code" : "BR0272849E",
    "display" : "Topiramato 25 mg comprimido"
  },
  {
    "code" : "BR0272850",
    "display" : "Topiramato 50 mg comprimido"
  },
  {
    "code" : "BR0272850E",
    "display" : "Topiramato 50 mg comprimido"
  },
  {
    "code" : "BR0272851",
    "display" : "Topiramato 100 mg comprimido"
  },
  {
    "code" : "BR0272851E",
    "display" : "Topiramato 100 mg comprimido"
  },
  {
    "code" : "BR0272852",
    "display" : "Triexifenidil 5 mg comprimido"
  },
  {
    "code" : "BR0272852E",
    "display" : "Triexifenidil 5 mg comprimido"
  },
  {
    "code" : "BR0272853",
    "display" : "Vigabatrina 500 mg comprimido"
  },
  {
    "code" : "BR0272853E",
    "display" : "Vigabatrina 500 mg comprimido"
  },
  {
    "code" : "BR0272896",
    "display" : "Dexclorfeniramina 0,4 mg/mL + Betametasona 0,05 mg/mL xarope"
  },
  {
    "code" : "BR0272901",
    "display" : "Clobazam 10 mg comprimido"
  },
  {
    "code" : "BR0272901E",
    "display" : "Clobazam 10 mg comprimido"
  },
  {
    "code" : "BR0272902",
    "display" : "Clobazam 20 mg comprimido"
  },
  {
    "code" : "BR0272902E",
    "display" : "Clobazam 20 mg comprimido"
  },
  {
    "code" : "BR0272903",
    "display" : "Citalopram 20 mg comprimido"
  },
  {
    "code" : "BR0272931",
    "display" : "Flunitrazepam 1 mg comprimido"
  },
  {
    "code" : "BR0272944",
    "display" : "Fluoresceína 1% solução oftálmica"
  },
  {
    "code" : "BR0272945",
    "display" : "Fluoresceína 2% solução oftálmica"
  },
  {
    "code" : "BR0272948",
    "display" : "Fluoresceína 10% solução para injeção 5 mL; frasco-ampola"
  },
  {
    "code" : "BR0272971",
    "display" : "Fenoximetilpenicilina Potássica 500.000 unidades internacionais comprimido"
  },
  {
    "code" : "BR0272972",
    "display" : "Fenoximetilpenicilina Potássica 80.000 unidades internacionais/mL solução oral"
  },
  {
    "code" : "BR0272974",
    "display" : "Fenoximetilpenicilina Potássica 1.200.000 unidades internacionais solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272979",
    "display" : "Fenazopiridina 100 mg comprimido"
  },
  {
    "code" : "BR0272980",
    "display" : "Fenazopiridina 200 mg comprimido"
  },
  {
    "code" : "BR0272996",
    "display" : "Famotidina 40 mg comprimido"
  },
  {
    "code" : "BR0273009-1",
    "display" : "Fluoxetina 20 mg cápsula"
  },
  {
    "code" : "BR0273009-2",
    "display" : "Fluoxetina 20 mg comprimido"
  },
  {
    "code" : "BR0273011",
    "display" : "Flurazepam 30 mg comprimido"
  },
  {
    "code" : "BR0273112",
    "display" : "Griseofulvina 500 mg comprimido"
  },
  {
    "code" : "BR0273115",
    "display" : "Gliclazida 80 mg comprimido"
  },
  {
    "code" : "BR0273116",
    "display" : "Gliclazida 30 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0273119",
    "display" : "Glimepirida 2 mg comprimido"
  },
  {
    "code" : "BR0273120",
    "display" : "Glimepirida 1 mg comprimido"
  },
  {
    "code" : "BR0273121",
    "display" : "Glimepirida 4 mg comprimido"
  },
  {
    "code" : "BR0273132",
    "display" : "Cloridrato de Difenidramina 10 mg/mL + Calamina 80 mg/mL + Cânfora 1 mg/mL loção"
  },
  {
    "code" : "BR0273137",
    "display" : "Diclofenaco Sódico 75 mg comprimido"
  },
  {
    "code" : "BR0273140",
    "display" : "Verapamil 240 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0273148",
    "display" : "Deflazacorte 6 mg comprimido"
  },
  {
    "code" : "BR0273149",
    "display" : "Deflazacorte 7,5 mg comprimido"
  },
  {
    "code" : "BR0273150",
    "display" : "Deflazacorte 30 mg comprimido"
  },
  {
    "code" : "BR0273166",
    "display" : "Neomicina 3,5 mg/g pomada"
  },
  {
    "code" : "BR0273167-1",
    "display" : "Neomicina 5 mg/g + Bacitracina 250 unidades internacionais/g pomada"
  },
  {
    "code" : "BR0273167-2",
    "display" : "Neomicina 5 mg/g + Bacitracina 250 unidades internacionais/g pomada"
  },
  {
    "code" : "BR0273167-3",
    "display" : "Neomicina 5 mg/g + Bacitracina 250 unidades internacionais/g pomada"
  },
  {
    "code" : "BR0273167-4",
    "display" : "Neomicina 5 mg/g + Bacitracina 250 unidades internacionais/g pomada"
  },
  {
    "code" : "BR0273192",
    "display" : "Temozolomida 250 mg cápsula"
  },
  {
    "code" : "BR0273193",
    "display" : "Temozolomida 5 mg cápsula"
  },
  {
    "code" : "BR0273194",
    "display" : "Temozolomida 20 mg cápsula"
  },
  {
    "code" : "BR0273195",
    "display" : "Temozolomida 100 mg cápsula"
  },
  {
    "code" : "BR0273221",
    "display" : "Memantina 10 mg comprimido"
  },
  {
    "code" : "BR0273255",
    "display" : "Oxcarbazepina 60 mg/mL suspensão oral"
  },
  {
    "code" : "BR0273256",
    "display" : "Oxcarbazepina 600 mg comprimido"
  },
  {
    "code" : "BR0273257",
    "display" : "Oxcarbazepina 300 mg comprimido"
  },
  {
    "code" : "BR0273258",
    "display" : "Pamidronato Dissódico 90 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0273258E",
    "display" : "Pamidronato Dissódico 90 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0273264",
    "display" : "Loperamida 2 mg comprimido"
  },
  {
    "code" : "BR0273266",
    "display" : "Naltrexona 50 mg comprimido"
  },
  {
    "code" : "BR0273310",
    "display" : "Hidroxizina 25 mg comprimido"
  },
  {
    "code" : "BR0273311",
    "display" : "Hidroxizina 10 mg comprimido"
  },
  {
    "code" : "BR0273314",
    "display" : "Cianocobalamina 5 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273317",
    "display" : "Imatinibe 100 mg comprimido"
  },
  {
    "code" : "BR0273319",
    "display" : "Indometacina 25 mg cápsula"
  },
  {
    "code" : "BR0273320",
    "display" : "Indometacina 50 mg cápsula"
  },
  {
    "code" : "BR0273328",
    "display" : "Ivermectina 6 mg comprimido"
  },
  {
    "code" : "BR0273387",
    "display" : "Irbesartana 150 mg comprimido"
  },
  {
    "code" : "BR0273388",
    "display" : "Irbesartana 300 mg comprimido"
  },
  {
    "code" : "BR0273389",
    "display" : "Irbesartana 150 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0273390",
    "display" : "Irbesartana 300 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0273395",
    "display" : "Dinitrato de Isossorbida 5 mg comprimido sublingual"
  },
  {
    "code" : "BR0273396",
    "display" : "Dinitrato de Isossorbida 10 mg comprimido"
  },
  {
    "code" : "BR0273400",
    "display" : "Mononitrato de Isossorbida 20 mg comprimido"
  },
  {
    "code" : "BR0273401",
    "display" : "Mononitrato de Isossorbida 40 mg comprimido"
  },
  {
    "code" : "BR0273402",
    "display" : "Mononitrato de Isossorbida 5 mg comprimido sublingual"
  },
  {
    "code" : "BR0273403",
    "display" : "Mononitrato de Isossorbida 50 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0273404",
    "display" : "Mononitrato de Isossorbida 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273407",
    "display" : "Letrozol 2,5 mg cápsula"
  },
  {
    "code" : "BR0273412",
    "display" : "Linezolida 600 mg comprimido"
  },
  {
    "code" : "BR0273413",
    "display" : "Linezolida 600 mg/300 mL solução para injeção; frasco"
  },
  {
    "code" : "BR0273434",
    "display" : "Sorbitol 2,7% + Manitol 0,54% solução para irrigação 1 L; frasco-ampola"
  },
  {
    "code" : "BR0273450",
    "display" : "Moxifloxacino 400 mg comprimido"
  },
  {
    "code" : "BR0273455",
    "display" : "Mupirocina 20 mg/g creme"
  },
  {
    "code" : "BR0273457",
    "display" : "Neostigmina 0,5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273466",
    "display" : "Loratadina 10 mg comprimido"
  },
  {
    "code" : "BR0273467",
    "display" : "Loratadina 1 mg/mL xarope"
  },
  {
    "code" : "BR0273467-1",
    "display" : "Loratadina 1 mg/mL xarope"
  },
  {
    "code" : "BR0273467-2",
    "display" : "Loratadina 1 mg/mL xarope"
  },
  {
    "code" : "BR0273469",
    "display" : "Loratadina 10 mg + Pseudoefedrina 240 mg comprimido"
  },
  {
    "code" : "BR0273470",
    "display" : "Loratadina 5 mg + Pseudoefedrina 120 mg comprimido"
  },
  {
    "code" : "BR0273471",
    "display" : "Loratadina 1 mg/mL + Pseudoefedrina 12 mg/mL xarope"
  },
  {
    "code" : "BR0273472",
    "display" : "Lorazepam 1 mg comprimido"
  },
  {
    "code" : "BR0273473",
    "display" : "Lorazepam 2 mg comprimido"
  },
  {
    "code" : "BR0273474",
    "display" : "Milrinona 10 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273479",
    "display" : "Minoxidil 10 mg comprimido"
  },
  {
    "code" : "BR0273483",
    "display" : "Mitotano 500 mg comprimido"
  },
  {
    "code" : "BR0273484",
    "display" : "Mometasona 1 mg/g (0,1%) creme"
  },
  {
    "code" : "BR0273553",
    "display" : "Meloxicam 7,5 mg comprimido"
  },
  {
    "code" : "BR0273554",
    "display" : "Meloxicam 15 mg comprimido"
  },
  {
    "code" : "BR0273555",
    "display" : "Meloxicam 15 mg/1,5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273557",
    "display" : "Ocitocina 5 unidades internacionais/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273579",
    "display" : "Cloridrato de Difenidramina 1,5 mg/mL + Paracetamol 12 mg/mL + Pseudoefedrina 1,5 mg/mL + Dropropizina 1,5 mg/mL xarope"
  },
  {
    "code" : "BR0273589",
    "display" : "Propiltiouracila 100 mg comprimido"
  },
  {
    "code" : "BR0273596",
    "display" : "Tioridazina 200 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0273597",
    "display" : "Tioridazina 25 mg comprimido"
  },
  {
    "code" : "BR0273598",
    "display" : "Tioridazina 10 mg comprimido"
  },
  {
    "code" : "BR0273599",
    "display" : "Terbinafina 250 mg comprimido"
  },
  {
    "code" : "BR0273618",
    "display" : "Teclozana 10 mg/mL suspensão oral"
  },
  {
    "code" : "BR0273619",
    "display" : "Teclozana 500 mg comprimido"
  },
  {
    "code" : "BR0273621",
    "display" : "Sulfato Ferroso 60 mg comprimido"
  },
  {
    "code" : "BR0273626",
    "display" : "Fenobarbital 50 mg comprimido"
  },
  {
    "code" : "BR0273642",
    "display" : "Hidróxido de Alumínio 200 mg + Hidróxido de Magnésio 200 mg comprimido mastigável"
  },
  {
    "code" : "BR0273664",
    "display" : "Mesna 400 mg/4 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273668",
    "display" : "Mesilato de Pralidoxima 200 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0273675",
    "display" : "Metaraminol 10 mg/ 1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273675-1",
    "display" : "Metaraminol 10 mg/ 1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273675-2",
    "display" : "Metaraminol 100 mg/ 10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273690",
    "display" : "Metilcelulose 2% solução oftálmica"
  },
  {
    "code" : "BR0273694",
    "display" : "Metilcelulose 30 mg/1,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0273700",
    "display" : "Tiamazol 5 mg comprimido"
  },
  {
    "code" : "BR0273702E",
    "display" : "Naproxeno 250 mg comprimido"
  },
  {
    "code" : "BR0273703E",
    "display" : "Naproxeno 500 mg comprimido"
  },
  {
    "code" : "BR0273704",
    "display" : "Naproxeno Sódico 275 mg comprimido"
  },
  {
    "code" : "BR0273706",
    "display" : "Naratriptana 2,5 mg comprimido"
  },
  {
    "code" : "BR0273710",
    "display" : "Nimesulida 100 mg comprimido"
  },
  {
    "code" : "BR0273711",
    "display" : "Nimesulida 50 mg/mL solução oral"
  },
  {
    "code" : "BR0273712",
    "display" : "Nimesulida 10 mg/mL suspensão oral"
  },
  {
    "code" : "BR0273719",
    "display" : "Nitroprusseto de Sódio 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0273810",
    "display" : "Olanzapina 2,5 mg comprimido"
  },
  {
    "code" : "BR0273818",
    "display" : "Diosmina 450 mg + Hesperidina 50 mg comprimido"
  },
  {
    "code" : "BR0273820",
    "display" : "Sildenafila 25 mg comprimido"
  },
  {
    "code" : "BR0273820E",
    "display" : "Sildenafila 25 mg comprimido"
  },
  {
    "code" : "BR0273821",
    "display" : "Sildenafila 50 mg comprimido"
  },
  {
    "code" : "BR0273821E",
    "display" : "Sildenafila 50 mg comprimido"
  },
  {
    "code" : "BR0273824",
    "display" : "Ácido Fólico 2 mg comprimido"
  },
  {
    "code" : "BR0273830",
    "display" : "Citidina 2,5 mg + Uridina 1,5 mg + Hidroxocobalamina 1 mg cápsula"
  },
  {
    "code" : "BR0273836-1",
    "display" : "Insulina Glargina 100 unidades/mL solução para injeção 3 mL; carpule"
  },
  {
    "code" : "BR0273836-2",
    "display" : "Insulina Glargina 100 unidades/mL solução para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "BR0273838",
    "display" : "Sibutramina 10 mg comprimido"
  },
  {
    "code" : "BR0273839",
    "display" : "Sibutramina 15 mg comprimido"
  },
  {
    "code" : "BR0273892-1",
    "display" : "Budesonida 0,5 mg/mL suspensão para inalação 5 mL; frasco"
  },
  {
    "code" : "BR0273893",
    "display" : "Budesonida 0,25 mg/mL suspensão para inalação 2 mL; frasco"
  },
  {
    "code" : "BR0273931",
    "display" : "Orlistate 120 mg cápsula"
  },
  {
    "code" : "BR0273940",
    "display" : "Paroxetina 20 mg comprimido"
  },
  {
    "code" : "BR0273941",
    "display" : "Paroxetina 30 mg comprimido"
  },
  {
    "code" : "BR0273944",
    "display" : "Perindopril Erbumina 4 mg comprimido"
  },
  {
    "code" : "BR0273952",
    "display" : "Progesterona 200 mg cápsula"
  },
  {
    "code" : "BR0273953",
    "display" : "Progesterona 100 mg cápsula"
  },
  {
    "code" : "BR0274036-1",
    "display" : "Piroxicam 20 mg comprimido"
  },
  {
    "code" : "BR0274036-2",
    "display" : "Piroxicam 20 mg cápsula"
  },
  {
    "code" : "BR0274041",
    "display" : "Piroxicam 5 mg/g gel"
  },
  {
    "code" : "BR0274049-1",
    "display" : "Propionato de Fluticasona 50 microgramas/dose suspensão spray"
  },
  {
    "code" : "BR0274049-2",
    "display" : "Propionato de Fluticasona 50 microgramas/dose suspensão spray"
  },
  {
    "code" : "BR0274105",
    "display" : "Penfluridol 20 mg comprimido"
  },
  {
    "code" : "BR0274115",
    "display" : "Gelatina 3,5% solução para injeção 500 mL; frasco"
  },
  {
    "code" : "BR0274149",
    "display" : "Ertapeném 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0274150",
    "display" : "Nifedipino 30 mg comprimido"
  },
  {
    "code" : "BR0274191-1",
    "display" : "Brimonidina 1,5 mg/mL (0,15%) solução oftálmica"
  },
  {
    "code" : "BR0274191-2",
    "display" : "Brimonidina 1,5 mg/mL (0,15%) solução oftálmica"
  },
  {
    "code" : "BR0274226",
    "display" : "Femprocumona 3 mg comprimido"
  },
  {
    "code" : "BR0274227",
    "display" : "Sulfato de Glicosamina 500 mg + Sulfato de Condroitina 400 mg cápsula"
  },
  {
    "code" : "BR0274393",
    "display" : "Brometo de Ipratrópio 20 microgramas/dose + Salbutamol 100 microgramas/dose suspensão aerossol"
  },
  {
    "code" : "BR0274438",
    "display" : "Valsartana 80 mg comprimido"
  },
  {
    "code" : "BR0274467-1",
    "display" : "Hialuronato de Sódio 20 mg/2 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0274467-2",
    "display" : "Hialuronato de Sódio 25 mg/2,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0274482",
    "display" : "Isoxsuprina 10 mg comprimido"
  },
  {
    "code" : "BR0274497",
    "display" : "Clortalidona 25 mg comprimido"
  },
  {
    "code" : "BR0274502",
    "display" : "Cefaclor 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0274502-1",
    "display" : "Cefaclor 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0274506",
    "display" : "Candesartana 8 mg comprimido"
  },
  {
    "code" : "BR0274527",
    "display" : "Nitrofural 2mg/mL solução"
  },
  {
    "code" : "BR0274561",
    "display" : "Tropicamida 10 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0274573",
    "display" : "Fenilefrina 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0274575",
    "display" : "Bronfeniramina 12 mg + Fenilefrina 15 mg comprimido"
  },
  {
    "code" : "BR0274576",
    "display" : "Di-hidroergocristina 6 mg cápsula"
  },
  {
    "code" : "BR0274631-1",
    "display" : "Montelucaste 4 mg comprimido mastigável"
  },
  {
    "code" : "BR0274631-2",
    "display" : "Montelucaste 4 mg granulado"
  },
  {
    "code" : "BR0274647",
    "display" : "Sotalol 160 mg comprimido"
  },
  {
    "code" : "BR0274704",
    "display" : "Imatinibe 400 mg comprimido"
  },
  {
    "code" : "BR0274806",
    "display" : "Acetilcisteína 600 mg granulado"
  },
  {
    "code" : "BR0274807",
    "display" : "Betaistina 8 mg comprimido"
  },
  {
    "code" : "BR0274808",
    "display" : "Clortalidona 12,5 mg comprimido"
  },
  {
    "code" : "BR0274811",
    "display" : "Clonixinato de Lisina 125 mg comprimido"
  },
  {
    "code" : "BR0274918-1",
    "display" : "Retinol 10.000 unidades internacionais/g + Aminoácidos 25 mg/g + Metionina 5 mg/g + Cloranfenicol 5 mg/g pomada oftálmica"
  },
  {
    "code" : "BR0274918-2",
    "display" : "Retinol 10.000 unidades internacionais/g + Aminoácidos 25 mg/g + Metionina 5 mg/g + Cloranfenicol 5 mg/g pomada oftálmica"
  },
  {
    "code" : "BR0274921",
    "display" : "Pindolol 5 mg comprimido"
  },
  {
    "code" : "BR0274922",
    "display" : "Mesilato de Codergocrina 1 mg cápsula"
  },
  {
    "code" : "BR0274936",
    "display" : "Triancinolona Acetonida 1 mg/g + Neomicina 2,5 mg/g + Gramicidina 0,25 mg/g + Nistatina 100.000 unidades internacionais/g pomada"
  },
  {
    "code" : "BR0274989",
    "display" : "Hidróxido Férrico 100 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0274995",
    "display" : "Ferripolimaltose 100 mg comprimido mastigável"
  },
  {
    "code" : "BR0274995-1",
    "display" : "Ferripolimaltose 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0274995-2",
    "display" : "Ferripolimaltose 100 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0274996-1",
    "display" : "Ferripolimaltose 10 mg/mL xarope"
  },
  {
    "code" : "BR0274996-2",
    "display" : "Ferripolimaltose 10 mg/mL xarope"
  },
  {
    "code" : "BR0275116-1",
    "display" : "Nitrendipino 10 mg comprimido"
  },
  {
    "code" : "BR0275117",
    "display" : "Nitrendipino 20 mg comprimido"
  },
  {
    "code" : "BR0275118",
    "display" : "Prednisolona 5 mg comprimido"
  },
  {
    "code" : "BR0275119",
    "display" : "Prednisolona 20 mg comprimido"
  },
  {
    "code" : "BR0275121",
    "display" : "Piracetam 1 g/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0275122",
    "display" : "Piracetam 60 mg/mL solução oral"
  },
  {
    "code" : "BR0275123",
    "display" : "Piracetam 400 mg comprimido"
  },
  {
    "code" : "BR0275124",
    "display" : "Piracetam 800 mg comprimido"
  },
  {
    "code" : "BR0275402",
    "display" : "Lidocaína 200 mg/20 mL (1%) + Epinefrina 100 microgramas/20 mL (1:200.000) solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0275422",
    "display" : "Alteplase 400 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0275423",
    "display" : "Alteplase 50 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0275428",
    "display" : "Acetato de Clostebol 5 mg/g + Neomicina 5 mg/g creme"
  },
  {
    "code" : "BR0275428-1",
    "display" : "Acetato de Clostebol 5 mg/g + Neomicina 5 mg/g creme"
  },
  {
    "code" : "BR0275436",
    "display" : "Sucralfato 1g comprimido"
  },
  {
    "code" : "BR0275440-3",
    "display" : "Triancinolona Acetonida 100 mg/5 mL solução para injeção; frasco"
  },
  {
    "code" : "BR0275475",
    "display" : "Dipirona 500 mg/1,5 mL + Prometazina 5 mg/1,5 mL + Adifenina 10 mg/1,5 mL solução oral"
  },
  {
    "code" : "BR0275475-1",
    "display" : "Dipirona 500 mg/1,5 mL + Prometazina 5 mg/1,5 mL + Adifenina 10 mg/1,5 mL solução oral"
  },
  {
    "code" : "BR0275475-2",
    "display" : "Dipirona 500 mg/1,5 mL + Prometazina 5 mg/1,5 mL + Adifenina 10 mg/1,5 mL solução oral"
  },
  {
    "code" : "BR0275475-3",
    "display" : "Dipirona 500 mg + Prometazina 5 mg + Adifenina 10 mg comprimido"
  },
  {
    "code" : "BR0275476",
    "display" : "Dipirona 750 mg/ 2 mL +  Prometazina 25 mg/ 2 mL + Adifenina 25 mg/ 2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0275478",
    "display" : "Periciazina 10 mg comprimido"
  },
  {
    "code" : "BR0275651",
    "display" : "Alfacoriogonadotropina 6.500 unidades internacionais (250 microgramas)/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0275852-1",
    "display" : "Pimecrolimo 10 mg/g creme"
  },
  {
    "code" : "BR0275852-2",
    "display" : "Pimecrolimo 10 mg/g creme"
  },
  {
    "code" : "BR0275884",
    "display" : "Colistimetato de Sódio 1.000.000 unidades internacionais pó para solução; frasco-ampola"
  },
  {
    "code" : "BR0275888",
    "display" : "Colistina 150 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0275937",
    "display" : "Racecadotrila 100 mg comprimido"
  },
  {
    "code" : "BR0275944",
    "display" : "Rilmenidina 1 mg comprimido"
  },
  {
    "code" : "BR0275963",
    "display" : "Finasterida 5 mg comprimido"
  },
  {
    "code" : "BR0275964",
    "display" : "Finasterida 1 mg comprimido"
  },
  {
    "code" : "BR0275989",
    "display" : "Saccharomyces boulardii 200 mg pó para solução oral"
  },
  {
    "code" : "BR0275989-1",
    "display" : "Saccharomyces boulardii 200 mg cápsula"
  },
  {
    "code" : "BR0276095",
    "display" : "Levotiroxina Sódica 200 microgramas comprimido"
  },
  {
    "code" : "BR0276097",
    "display" : "Bicarbonato de Sódio 10% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0276233-1",
    "display" : "Insulina Lispro 100 unidades/mL solução para injeção 3 mL; carpule"
  },
  {
    "code" : "BR0276233-2",
    "display" : "Insulina Lispro 100 unidades/mL solução para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "BR0276234-1",
    "display" : "Insulina Asparte 100 unidades/mL solução para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "BR0276234-2",
    "display" : "Insulina Asparte 100 unidades/mL solução para injeção 3 mL; carpule"
  },
  {
    "code" : "BR0276235",
    "display" : "Insulina Lispro Bifásica (25/75) 100 unidades/mL suspensão para injeção 3 mL; carpule"
  },
  {
    "code" : "BR0276258",
    "display" : "Ramipril 5 mg comprimido"
  },
  {
    "code" : "BR0276259",
    "display" : "Ramipril 10 mg comprimido"
  },
  {
    "code" : "BR0276260",
    "display" : "Ramipril 2,5 mg comprimido"
  },
  {
    "code" : "BR0276261",
    "display" : "Ramipril 5 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0276262",
    "display" : "Ramipril 5 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "BR0276263",
    "display" : "Anlodipino 2,5 mg + Ramipril 5 mg comprimido"
  },
  {
    "code" : "BR0276264",
    "display" : "Anlodipino 5 mg + Ramipril 5 mg cápsula"
  },
  {
    "code" : "BR0276270",
    "display" : "Montelucaste 5 mg comprimido mastigável"
  },
  {
    "code" : "BR0276271",
    "display" : "Montelucaste 10 mg comprimido"
  },
  {
    "code" : "BR0276283",
    "display" : "Deslanosídeo 0,4 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0276332",
    "display" : "Picossulfato de Sódio 0,334 mg/mL + Óleo Mineral 282,25 mg/mL + Ágar-Ágar 2,72 mg/mL emulsão oral"
  },
  {
    "code" : "BR0276333",
    "display" : "Amitriptilina 75 mg comprimido"
  },
  {
    "code" : "BR0276336",
    "display" : "Amitriptilina 12,5 mg + Clordiazepóxido 5 mg cápsula"
  },
  {
    "code" : "BR0276374",
    "display" : "Diltiazem 240 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0276375",
    "display" : "Diltiazem 300 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0276377",
    "display" : "Cilostazol 50 mg comprimido"
  },
  {
    "code" : "BR0276378",
    "display" : "Cilostazol 100 mg comprimido"
  },
  {
    "code" : "BR0276384",
    "display" : "Budesonida 3 mg cápsula gastrorresistente"
  },
  {
    "code" : "BR0276388",
    "display" : "Galantamina 8 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0276388E",
    "display" : "Galantamina 8 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0276393",
    "display" : "Cetorolaco 50 mg/mL (5%) solução oftálmica"
  },
  {
    "code" : "BR0276456",
    "display" : "Silimarina 70 mg + Metionina 100 mg comprimido"
  },
  {
    "code" : "BR0276656",
    "display" : "Metoprolol 25 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0276657",
    "display" : "Metoprolol 50 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0276658",
    "display" : "Metoprolol 100 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0276664",
    "display" : "Iobitridol 300 mg/1 mL solução para injeção 50 mL; frasco-ampola"
  },
  {
    "code" : "BR0276670",
    "display" : "Ioxitalamato de Meglumina 350 mg/mL solução para injeção 50 mL; frasco-ampola"
  },
  {
    "code" : "BR0276774",
    "display" : "Acetato de Sódio 20 mEq/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0276823",
    "display" : "Anfotericina B Lipossomal 100 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0276839-1",
    "display" : "Água para injeção 5 mL; ampola"
  },
  {
    "code" : "BR0276839-10",
    "display" : "Água para injeção 4 mL; ampola"
  },
  {
    "code" : "BR0276839-2",
    "display" : "Água para injeção 20 mL; ampola"
  },
  {
    "code" : "BR0276839-3",
    "display" : "Água para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "BR0276839-4",
    "display" : "Água para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0276839-5",
    "display" : "Água para injeção 250 mL; frasco-ampola"
  },
  {
    "code" : "BR0276839-6",
    "display" : "Água para injeção 1 L; bolsa"
  },
  {
    "code" : "BR0276839-7",
    "display" : "Água para injeção 2 L; frasco-ampola"
  },
  {
    "code" : "BR0276839-8",
    "display" : "Água para injeção 100 mL; frasco-ampola"
  },
  {
    "code" : "BR0276839-9",
    "display" : "Água para injeção 2 mL; ampola"
  },
  {
    "code" : "BR0276856",
    "display" : "Acetato de Noretisterona 10 mg comprimido"
  },
  {
    "code" : "BR0276862",
    "display" : "Tioconazol 65 mg/g creme vaginal"
  },
  {
    "code" : "BR0276866",
    "display" : "Tioconazol 10 mg/mL loção"
  },
  {
    "code" : "BR0276867",
    "display" : "Tioconazol 20 mg/g + Tinidazol 30 mg/g creme vaginal"
  },
  {
    "code" : "BR0276867-1",
    "display" : "Secnidazol 1 g comprimido e Tioconazol 20 mg/g + Tinidazol 30 mg/g creme vaginal"
  },
  {
    "code" : "BR0276871-1",
    "display" : "Fluoruracila 50 mg/g creme"
  },
  {
    "code" : "BR0276871-2",
    "display" : "Fluoruracila 50 mg/g creme"
  },
  {
    "code" : "BR0276871-3",
    "display" : "Fluoruracila 50 mg/g creme"
  },
  {
    "code" : "BR0276871-4",
    "display" : "Fluoruracila 50 mg/g creme"
  },
  {
    "code" : "BR0276948",
    "display" : "Trazodona 50 mg comprimido"
  },
  {
    "code" : "BR0276959",
    "display" : "Alfatirotropina 1,1 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0276961",
    "display" : "Tizanidina 2 mg comprimido"
  },
  {
    "code" : "BR0276965",
    "display" : "Telmisartana 40 mg comprimido"
  },
  {
    "code" : "BR0276966",
    "display" : "Telmisartana 80 mg comprimido"
  },
  {
    "code" : "BR0277184",
    "display" : "Valganciclovir 450 mg comprimido"
  },
  {
    "code" : "BR0277319",
    "display" : "Peróxido de Hidrogênio 3% solução"
  },
  {
    "code" : "BR0277319-1",
    "display" : "Peróxido de Hidrogênio 3% solução"
  },
  {
    "code" : "BR0277434E",
    "display" : "Betainterferona 1a 12.000.000 unidades internacionais (44 microgramas)/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0277435E",
    "display" : "Betainterferona 1a 6.000.000 unidades internacionais (22 microgramas)/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0277438E",
    "display" : "Betainterferona 1b 9.600.000 unidades internacionais (300 microgramas) pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0277513",
    "display" : "Fluoxetina 20 mg/mL solução oral"
  },
  {
    "code" : "BR0277519",
    "display" : "Ácido Ursodesoxicólico 50 mg comprimido"
  },
  {
    "code" : "BR0277525-2",
    "display" : "Didanosina 250 mg cápsula gastrorresistente"
  },
  {
    "code" : "BR0277526-1",
    "display" : "Didanosina 400 mg comprimido"
  },
  {
    "code" : "BR0277526-2",
    "display" : "Didanosina 400 mg cápsula gastrorresistente"
  },
  {
    "code" : "BR0277649",
    "display" : "Anagrelida 0,5 mg cápsula"
  },
  {
    "code" : "BR0277934-1",
    "display" : "Atropina 0,5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0277973",
    "display" : "Ergometrina 0,2 mg comprimido"
  },
  {
    "code" : "BR0278257",
    "display" : "Tinidazol 500 mg comprimido"
  },
  {
    "code" : "BR0278259",
    "display" : "Tiocolchicosídeo 4 mg comprimido"
  },
  {
    "code" : "BR0278260",
    "display" : "Tiopental 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0278261",
    "display" : "Tiopental 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0278265",
    "display" : "Hidroxiquinolina 0,04 mg/mL + Trolamina 140 mg/mL solução otológica"
  },
  {
    "code" : "BR0278268",
    "display" : "Trifluoperazina 5 mg comprimido"
  },
  {
    "code" : "BR0278268-1",
    "display" : "Trifluoperazina 2 mg comprimido"
  },
  {
    "code" : "BR0278281",
    "display" : "Adenosina 6 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0278283",
    "display" : "Acetazolamida 250 mg comprimido"
  },
  {
    "code" : "BR0278283E",
    "display" : "Acetazolamida 250 mg comprimido"
  },
  {
    "code" : "BR0278316",
    "display" : "Zolpidem 10 mg comprimido"
  },
  {
    "code" : "BR0278338",
    "display" : "Ácido Tranexâmico 250 mg comprimido"
  },
  {
    "code" : "BR0278348",
    "display" : "Anastrozol 1 mg comprimido"
  },
  {
    "code" : "BR0278356",
    "display" : "Azelastina 1 mg/mL solução spray"
  },
  {
    "code" : "BR0278357",
    "display" : "Azelastina 1 mg/mL solução aerossol"
  },
  {
    "code" : "BR0278378",
    "display" : "Tretinoína 0,25 mg/g gel"
  },
  {
    "code" : "BR0278393",
    "display" : "Tretinoína 10 mg cápsula"
  },
  {
    "code" : "BR0278429-1",
    "display" : "Bupivacaína 50 mg/20 mL (0,25%) + Epinefrina 100 microgramas/20 mL (1:200.000) solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0278482",
    "display" : "Primidona 250 mg comprimido"
  },
  {
    "code" : "BR0278482E",
    "display" : "Primidona 250 mg comprimido"
  },
  {
    "code" : "BR0278489",
    "display" : "Ácido Fólico 0,2 mg/mL solução oral"
  },
  {
    "code" : "BR0278490",
    "display" : "Ácido Fólico 0,4 mg/mL solução oral"
  },
  {
    "code" : "BR0278587-1",
    "display" : "Polissulfato de Mucopolissacarídeo 5 mg/g gel"
  },
  {
    "code" : "BR0278587-2",
    "display" : "Polissulfato de Mucopolissacarídeo 5 mg/g gel"
  },
  {
    "code" : "BR0278588",
    "display" : "Polissulfato de Mucopolissacarídeo 5 mg/g pomada"
  },
  {
    "code" : "BR0278588-1",
    "display" : "Polissulfato de Mucopolissacarídeo 5 mg/g pomada"
  },
  {
    "code" : "BR0278589-1",
    "display" : "Polissulfato de Mucopolissacarídeo 3 mg/g gel"
  },
  {
    "code" : "BR0278589-2",
    "display" : "Polissulfato de Mucopolissacarídeo 3 mg/g gel"
  },
  {
    "code" : "BR0278646",
    "display" : "Ácido Épsilon-Aminocaproico 1 g/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0278647",
    "display" : "Glibenclamida 1,25 mg + Metformina 250 mg comprimido"
  },
  {
    "code" : "BR0278648",
    "display" : "Glibenclamida 2,5 mg + Metformina 500 mg comprimido"
  },
  {
    "code" : "BR0278649",
    "display" : "Glibenclamida 5 mg + Metformina 500 mg comprimido"
  },
  {
    "code" : "BR0279118",
    "display" : "Ticarcilina 3 g + Clavulanato de Potássio 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0279269",
    "display" : "Varfarina 5 mg comprimido"
  },
  {
    "code" : "BR0279270",
    "display" : "Varfarina 2,5 mg comprimido"
  },
  {
    "code" : "BR0279271",
    "display" : "Varfarina 1 mg comprimido"
  },
  {
    "code" : "BR0279297-1",
    "display" : "Nistatina 100.000 unidades internacionais/g + Óxido de Zinco 200 mg/g creme"
  },
  {
    "code" : "BR0279297-2",
    "display" : "Nistatina 100.000 unidades internacionais/g + Óxido de Zinco 200 mg/g creme"
  },
  {
    "code" : "BR0279298",
    "display" : "Fenoterol 0,1 mg /dose + Brometo de Ipratrópio 0,04 mg/dose solução aerossol; inalador"
  },
  {
    "code" : "BR0279338-1",
    "display" : "Carbômer 2 mg/g (0,2%) gel oftálmico"
  },
  {
    "code" : "BR0279338-2",
    "display" : "Carbômer 2 mg/g (0,2%) gel oftálmico"
  },
  {
    "code" : "BR0279432",
    "display" : "Loteprednol 5 mg/mL suspensão oftálmica"
  },
  {
    "code" : "BR0279493-1",
    "display" : "Retinol 5.000 unidades internacionais/g + Colecalciferol 900 unidades internacionais/g + Óxido de Zinco 150 mg/g pomada"
  },
  {
    "code" : "BR0279493-2",
    "display" : "Retinol 5.000 unidades internacionais/g + Colecalciferol 900 unidades internacionais/g + Óxido de Zinco 150 mg/g pomada"
  },
  {
    "code" : "BR0279493-3",
    "display" : "Retinol 5.000 unidades internacionais/g + Colecalciferol 900 unidades internacionais/g + Óxido de Zinco 150 mg/g pomada"
  },
  {
    "code" : "BR0279493-4",
    "display" : "Retinol 5.000 unidades internacionais/g + Colecalciferol 900 unidades internacionais/g + Óxido de Zinco 150 mg/g pomada"
  },
  {
    "code" : "BR0279493-5",
    "display" : "Retinol 5.000 unidades internacionais/g + Colecalciferol 900 unidades internacionais/g + Óxido de Zinco 150 mg/g pomada"
  },
  {
    "code" : "BR0279493-6",
    "display" : "Retinol 5.000 unidades internacionais/g + Colecalciferol 900 unidades internacionais/g + Óxido de Zinco 150 mg/g pomada"
  },
  {
    "code" : "BR0280115",
    "display" : "Bosentana 125 mg comprimido"
  },
  {
    "code" : "BR0280115E",
    "display" : "Bosentana 125 mg comprimido"
  },
  {
    "code" : "BR0280116",
    "display" : "Bosentana 62,5 mg comprimido"
  },
  {
    "code" : "BR0280116E",
    "display" : "Bosentana 62,5 mg comprimido"
  },
  {
    "code" : "BR0280201",
    "display" : "Bortezomibe 3,5 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0280205E",
    "display" : "Adefovir 10 mg comprimido"
  },
  {
    "code" : "BR0280505",
    "display" : "Adefovir 10 mg comprimido"
  },
  {
    "code" : "BR0280627",
    "display" : "Levobupivacaína 0,25% solução para injeção 20 mL; ampola"
  },
  {
    "code" : "BR0280873",
    "display" : "Candesartana 16 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0280876",
    "display" : "Espironolactona 50 mg + Hidroclorotiazida 50 mg comprimido"
  },
  {
    "code" : "BR0280877",
    "display" : "Espironolactona 100 mg + Furosemida 20 mg comprimido"
  },
  {
    "code" : "BR0280881",
    "display" : "Propionato de Fluticasona 250 microgramas/dose + Salmeterol 25 microgramas/dose suspensão aerossol; inalador"
  },
  {
    "code" : "BR0280883",
    "display" : "Glicosamina 1,5 g + Condroitina 1,2 g pó para solução oral"
  },
  {
    "code" : "BR0280947",
    "display" : "Ofloxacino 200 mg comprimido"
  },
  {
    "code" : "BR0281135-1",
    "display" : "Amoxicilina 50 mg/mL + Ácido Clavulânico 12,5 mg/mL suspensão oral"
  },
  {
    "code" : "BR0281135-2",
    "display" : "Amoxicilina 50 mg/mL + Ácido Clavulânico 12,5 mg/mL suspensão oral"
  },
  {
    "code" : "BR0281135-3",
    "display" : "Amoxicilina 40 mg/mL + Ácido Clavulânico 5,7 mg/mL suspensão oral"
  },
  {
    "code" : "BR0281470",
    "display" : "Candesartana 8 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0282040",
    "display" : "Gefitinibe 250 mg comprimido"
  },
  {
    "code" : "BR0282149",
    "display" : "Betametasona 4 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0282151",
    "display" : "Exemestano 25 mg comprimido"
  },
  {
    "code" : "BR0282220",
    "display" : "Carbacol 0,2 mg/2 mL solução para injeção intraocular; frasco-ampola"
  },
  {
    "code" : "BR0282222-1",
    "display" : "Carbocisteína 20 mg/mL xarope"
  },
  {
    "code" : "BR0282222-2",
    "display" : "Carbocisteína 20 mg/mL xarope"
  },
  {
    "code" : "BR0282223",
    "display" : "Carbocisteína 50 mg/mL solução oral"
  },
  {
    "code" : "BR0282224-1",
    "display" : "Carbocisteína 50 mg/mL xarope"
  },
  {
    "code" : "BR0282224-2",
    "display" : "Carbocisteína 50 mg/mL xarope"
  },
  {
    "code" : "BR0282237",
    "display" : "Carnitina 200 mg/mL xarope"
  },
  {
    "code" : "BR0282298",
    "display" : "Sulpirida 20 mg/mL solução oral"
  },
  {
    "code" : "BR0282299",
    "display" : "Sulpirida 50 mg comprimido"
  },
  {
    "code" : "BR0282313",
    "display" : "Ciclobenzaprina 10 mg comprimido"
  },
  {
    "code" : "BR0282580",
    "display" : "Oleato de Etanolamina 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0282714",
    "display" : "Hidróxido de Magnésio 80 mg/mL suspensão oral"
  },
  {
    "code" : "BR0282757",
    "display" : "Propionato de Testosterona 30 mg/1 mL + Fempropionato de Testosterona 60 mg/1 mL + Isocaproato de Testosterona 60 mg/1 mL + Decanoato de Testosterona 100 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0282881",
    "display" : "Rosuvastatina 10 mg comprimido"
  },
  {
    "code" : "BR0282882",
    "display" : "Rosuvastatina 20 mg comprimido"
  },
  {
    "code" : "BR0283156",
    "display" : "Orfenadrina 35 mg + Dipirona 300 mg + Cafeína 50 mg comprimido"
  },
  {
    "code" : "BR0284101",
    "display" : "Aripiprazol 15 mg comprimido"
  },
  {
    "code" : "BR0284102",
    "display" : "Ciprofloxacino 3 mg/mL + Dexametasona 1 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0284105",
    "display" : "Risperidona 3 mg comprimido"
  },
  {
    "code" : "BR0284105E",
    "display" : "Risperidona 3 mg comprimido"
  },
  {
    "code" : "BR0284106",
    "display" : "Risperidona 1 mg/mL solução oral"
  },
  {
    "code" : "BR0284106E",
    "display" : "Risperidona 1 mg/mL solução oral"
  },
  {
    "code" : "BR0284109",
    "display" : "Benzbromarona 100 mg comprimido"
  },
  {
    "code" : "BR0284114",
    "display" : "Cetoconazol 20 mg/g + Dipropionato de Betametasona 0,5 mg/g creme"
  },
  {
    "code" : "BR0284426",
    "display" : "Telmisartana 40 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0284427",
    "display" : "Telmisartana 80 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0284428",
    "display" : "Colchicina 1 mg comprimido"
  },
  {
    "code" : "BR0284429",
    "display" : "Beclometasona 50 microgramas/dose + Salbutamol 100 microgramas/dose suspensão aerossol; inalador"
  },
  {
    "code" : "BR0284435-1",
    "display" : "Betaxolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0284435-2",
    "display" : "Betaxolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0284435-3",
    "display" : "Betaxolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0284458-1",
    "display" : "Clobetasol 0,5 mg/g creme"
  },
  {
    "code" : "BR0284458E",
    "display" : "Clobetasol 0,5 mg/g creme"
  },
  {
    "code" : "BR0284459",
    "display" : "Clobetasol 0,5 mg/g pomada"
  },
  {
    "code" : "BR0284460",
    "display" : "Clobetasol 0,5 mg/g solução"
  },
  {
    "code" : "BR0284460E",
    "display" : "Clobetasol 0,5 mg/g solução"
  },
  {
    "code" : "BR0284465",
    "display" : "Alprazolam 2 mg comprimido"
  },
  {
    "code" : "BR0284465-1",
    "display" : "Alprazolam 2 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0284838",
    "display" : "Alfafolitropina 37,5 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0284839",
    "display" : "Alfafolitropina 75 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0284840",
    "display" : "Alfafolitropina 150 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0284841",
    "display" : "Alfafolitropina 450 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0284842",
    "display" : "Alfafolitropina 1.050 unidades internacionais/2 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0285007",
    "display" : "Ácido Acetilsalicílico 100 mg + Mononitrato de Isossorbida 40 mg cápsula"
  },
  {
    "code" : "BR0285015",
    "display" : "Tramadol 37,5 mg + Paracetamol 325 mg comprimido"
  },
  {
    "code" : "BR0285055",
    "display" : "Ácido Acetilsalicílico 81 mg comprimido gastrorresistente"
  },
  {
    "code" : "BR0285063",
    "display" : "Felodipino 5 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0285064",
    "display" : "Felodipino 2,5 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0285081",
    "display" : "Cloridrato de Tansulosina 0,4mg"
  },
  {
    "code" : "BR0285686",
    "display" : "Ezetimiba 10 mg comprimido"
  },
  {
    "code" : "BR0285687",
    "display" : "Ezetimiba 10 mg + Sinvastatina 10 mg comprimido"
  },
  {
    "code" : "BR0285688",
    "display" : "Ezetimiba 10 mg + Sinvastatina 20 mg comprimido"
  },
  {
    "code" : "BR0285689",
    "display" : "Ezetimiba 10 mg + Sinvastatina 40 mg comprimido"
  },
  {
    "code" : "BR0285817",
    "display" : "Sirolimo 1 mg comprimido"
  },
  {
    "code" : "BR0285817E",
    "display" : "Sirolimo 1 mg comprimido"
  },
  {
    "code" : "BR0285818",
    "display" : "Sirolimo 2 mg comprimido"
  },
  {
    "code" : "BR0285818E",
    "display" : "Sirolimo 2 mg comprimido"
  },
  {
    "code" : "BR0285953",
    "display" : "Teofilina 300 mg cápsula"
  },
  {
    "code" : "BR0285965",
    "display" : "Levetiracetam 250 mg comprimido"
  },
  {
    "code" : "BR0285966",
    "display" : "Levetiracetam 500 mg comprimido"
  },
  {
    "code" : "BR0286246",
    "display" : "Pimozida 1 mg comprimido"
  },
  {
    "code" : "BR0286247",
    "display" : "Pimozida 4 mg comprimido"
  },
  {
    "code" : "BR0286278",
    "display" : "Aripiprazol 30 mg comprimido"
  },
  {
    "code" : "BR0286631",
    "display" : "Cloxazolam 4 mg comprimido"
  },
  {
    "code" : "BR0286632",
    "display" : "Sulpirida 200 mg comprimido"
  },
  {
    "code" : "BR0286765E",
    "display" : "Bromocriptina 5 mg cápsula de liberação retardada"
  },
  {
    "code" : "BR0286864",
    "display" : "Acetilcisteína 100 mg granulado"
  },
  {
    "code" : "BR0287252",
    "display" : "Nicotina 2 mg pastilha"
  },
  {
    "code" : "BR0287253",
    "display" : "Nicotina 4 mg pastilha"
  },
  {
    "code" : "BR0287469",
    "display" : "Nitrato de Oxiconazol 10 mg/g creme"
  },
  {
    "code" : "BR0287469-1",
    "display" : "Nitrato de Oxiconazol 10 mg/mL solução"
  },
  {
    "code" : "BR0287471",
    "display" : "Losartana 100 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "BR0287473",
    "display" : "Losartana 100 mg comprimido"
  },
  {
    "code" : "BR0287481",
    "display" : "Nicotina 2 mg goma de mascar"
  },
  {
    "code" : "BR0287529",
    "display" : "Desloratadina 5 mg comprimido"
  },
  {
    "code" : "BR0287531",
    "display" : "Desonida 0,5 mg/g creme"
  },
  {
    "code" : "BR0287533",
    "display" : "Desonida 0,5 mg/g creme"
  },
  {
    "code" : "BR0287559",
    "display" : "Estavudina 1 mg/mL solução oral"
  },
  {
    "code" : "BR0287687",
    "display" : "Efedrina 50 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0287824",
    "display" : "Tiamazol 10 mg comprimido"
  },
  {
    "code" : "BR0288001",
    "display" : "Ciclopirox 80 mg/g esmalte"
  },
  {
    "code" : "BR0288002",
    "display" : "Ciclopirox Olamina 10 mg/g creme"
  },
  {
    "code" : "BR0288275",
    "display" : "Tinidazol 30 mg/g + Miconazol 20 mg/g creme vaginal"
  },
  {
    "code" : "BR0288275-1",
    "display" : "Tinidazol 30 mg/g + Miconazol 20 mg/g creme vaginal"
  },
  {
    "code" : "BR0288300-1",
    "display" : "Moxifloxacino 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0288300-2",
    "display" : "Moxifloxacino 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0288300-3",
    "display" : "Moxifloxacino 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0288640",
    "display" : "Micofenolato de Sódio 180 mg comprimido gastrorresistente"
  },
  {
    "code" : "BR0288640E",
    "display" : "Micofenolato de Sódio 180 mg comprimido gastrorresistente"
  },
  {
    "code" : "BR0288641",
    "display" : "Micofenolato de Sódio 360 mg comprimido gastrorresistente"
  },
  {
    "code" : "BR0288641E",
    "display" : "Micofenolato de Sódio 360 mg comprimido gastrorresistente"
  },
  {
    "code" : "BR0288785",
    "display" : "Levobupivacaína 0,75% solução para injeção 20 mL; ampola"
  },
  {
    "code" : "BR0290058",
    "display" : "Adalimumabe 40 mg/0,8 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "BR0290168",
    "display" : "Cloreto de Suxametônio 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0290673",
    "display" : "Ebastina 10 mg comprimido"
  },
  {
    "code" : "BR0290674",
    "display" : "Ebastina 1 mg/mL solução oral"
  },
  {
    "code" : "BR0290675",
    "display" : "Ebastina 10 mg + Pseudoefedrina 120 mg cápsula"
  },
  {
    "code" : "BR0290891",
    "display" : "Oxamniquina 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0290992",
    "display" : "Hialuronidase 2.000 UTR pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0291019-1",
    "display" : "Hialuronidase 100 UTR/mL + Lidocaína 50 mg/mL + Neomicina 5 mg/mL solução otológica"
  },
  {
    "code" : "BR0291174",
    "display" : "Gentamicina 5 mg/g pomada oftálmica"
  },
  {
    "code" : "BR0291231",
    "display" : "Estreptomicina 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0291549",
    "display" : "Atorvastatina 80 mg comprimido"
  },
  {
    "code" : "BR0291549E",
    "display" : "Atorvastatina 80 mg comprimido"
  },
  {
    "code" : "BR0291559",
    "display" : "Piracetam 400 mg + Di-hidroergocristina 1 mg comprimido"
  },
  {
    "code" : "BR0291690",
    "display" : "Repaglinida 0,5 mg comprimido"
  },
  {
    "code" : "BR0291691",
    "display" : "Repaglinida 1 mg comprimido"
  },
  {
    "code" : "BR0291692",
    "display" : "Repaglinida 2 mg comprimido"
  },
  {
    "code" : "BR0291700",
    "display" : "Gabapentina 600 mg comprimido"
  },
  {
    "code" : "BR0291702",
    "display" : "Gabapentina 100 mg comprimido"
  },
  {
    "code" : "BR0291770",
    "display" : "Escitalopram 10 mg comprimido"
  },
  {
    "code" : "BR0291771",
    "display" : "Escitalopram 20 mg comprimido"
  },
  {
    "code" : "BR0291772",
    "display" : "Escitalopram 15 mg comprimido"
  },
  {
    "code" : "BR0291802",
    "display" : "Diacereína 50 mg cápsula"
  },
  {
    "code" : "BR0291951",
    "display" : "Nitrato de Prata 10 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0292029",
    "display" : "Tibolona 1,25 mg comprimido"
  },
  {
    "code" : "BR0292030",
    "display" : "Tibolona 2,5 mg comprimido"
  },
  {
    "code" : "BR0292043",
    "display" : "Saccharomyces cerevisiae 50 milhões/mL suspensão oral"
  },
  {
    "code" : "BR0292044",
    "display" : "Saccharomyces cerevisiae 100 milhões/mL suspensão oral"
  },
  {
    "code" : "BR0292194",
    "display" : "Haloperidol 50 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0292195-1",
    "display" : "Haloperidol 2 mg/mL solução oral"
  },
  {
    "code" : "BR0292195-2",
    "display" : "Haloperidol 2 mg/mL solução oral"
  },
  {
    "code" : "BR0292195-3",
    "display" : "Haloperidol 2 mg/mL solução oral"
  },
  {
    "code" : "BR0292195-4",
    "display" : "Haloperidol 2 mg/mL solução oral"
  },
  {
    "code" : "BR0292196",
    "display" : "Haloperidol 5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0292205",
    "display" : "Isoniazida 100 mg comprimido"
  },
  {
    "code" : "BR0292208-1",
    "display" : "Rifampicina 20 mg/mL suspensão oral"
  },
  {
    "code" : "BR0292208-2",
    "display" : "Rifampicina 20 mg/mL suspensão oral"
  },
  {
    "code" : "BR0292208-3",
    "display" : "Rifampicina 20 mg/mL suspensão oral"
  },
  {
    "code" : "BR0292227",
    "display" : "Medroxiprogesterona 50 mg/1 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292236",
    "display" : "Mesalazina 500 mg comprimido"
  },
  {
    "code" : "BR0292236E",
    "display" : "Mesalazina 500 mg comprimido"
  },
  {
    "code" : "BR0292237",
    "display" : "Mesalazina 400 mg comprimido"
  },
  {
    "code" : "BR0292237E",
    "display" : "Mesalazina 400 mg comprimido"
  },
  {
    "code" : "BR0292238",
    "display" : "Mesalazina 800 mg comprimido"
  },
  {
    "code" : "BR0292238E",
    "display" : "Mesalazina 800 mg comprimido"
  },
  {
    "code" : "BR0292239",
    "display" : "Mesalazina 250 mg supositório"
  },
  {
    "code" : "BR0292239E",
    "display" : "Mesalazina 250 mg supositório"
  },
  {
    "code" : "BR0292240",
    "display" : "Mesalazina 1 g supositório"
  },
  {
    "code" : "BR0292240E",
    "display" : "Mesalazina 1 g supositório"
  },
  {
    "code" : "BR0292242",
    "display" : "Mesalazina 30 mg/mL suspensão retal"
  },
  {
    "code" : "BR0292242E",
    "display" : "Mesalazina 30 mg/mL suspensão retal"
  },
  {
    "code" : "BR0292249-1",
    "display" : "Metotrexato 50 mg/2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292249-1E",
    "display" : "Metotrexato 500 mg/20 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0292249-2",
    "display" : "Metotrexato 500 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292249E",
    "display" : "Metotrexato 50 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0292256E",
    "display" : "Molgramostim 300 microgramas pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292262-1",
    "display" : "Morfina 100 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0292262-2",
    "display" : "Morfina 100 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0292262E",
    "display" : "Morfina 100 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0292263",
    "display" : "Morfina 30 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0292263E",
    "display" : "Morfina 30 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0292264",
    "display" : "Morfina 60 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0292264E",
    "display" : "Morfina 60 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0292278",
    "display" : "Pergolida 0,25 mg comprimido"
  },
  {
    "code" : "BR0292279",
    "display" : "Pergolida 1 mg comprimido"
  },
  {
    "code" : "BR0292331-1",
    "display" : "Salbutamol 0,4 mg/mL xarope"
  },
  {
    "code" : "BR0292331-2",
    "display" : "Salbutamol 0,4 mg/mL xarope"
  },
  {
    "code" : "BR0292344",
    "display" : "Sulfato Ferroso 40 mg comprimido"
  },
  {
    "code" : "BR0292345",
    "display" : "Sulfato Ferroso 125 mg/mL (Ferro 25 mg/mL) solução oral"
  },
  {
    "code" : "BR0292345-1",
    "display" : "Sulfato Ferroso 125 mg/mL (Ferro 25 mg/mL) solução oral"
  },
  {
    "code" : "BR0292372E",
    "display" : "Toxina Botulínica do Tipo A 100 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292373",
    "display" : "Toxina Botulínica do Tipo A 500 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292373E",
    "display" : "Toxina Botulínica do Tipo A 500 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292380",
    "display" : "Tramadol 100 mg/mL solução oral"
  },
  {
    "code" : "BR0292382",
    "display" : "Tramadol 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0292382-1",
    "display" : "Tramadol 50 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0292399-1",
    "display" : "Fitomenadiona 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0292399-2",
    "display" : "Fitomenadiona 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0292400E",
    "display" : "Alfacalcidol 0,25 microgramas cápsula"
  },
  {
    "code" : "BR0292401",
    "display" : "Alfacalcidol 1 micrograma cápsula"
  },
  {
    "code" : "BR0292401E",
    "display" : "Alfacalcidol 1 micrograma cápsula"
  },
  {
    "code" : "BR0292402",
    "display" : "Aminofilina 240 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0292409",
    "display" : "Basiliximabe 20 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292416",
    "display" : "Calcitriol 1 micrograma cápsula"
  },
  {
    "code" : "BR0292416-1",
    "display" : "Calcitriol 1 microgramas/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0292416E",
    "display" : "Calcitriol 1 microgramas/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0292418-1",
    "display" : "Ciprofloxacino 200 mg/100 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292418-2",
    "display" : "Ciprofloxacino 400 mg/200 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292419-1",
    "display" : "Clindamicina 300 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0292419-2",
    "display" : "Clindamicina 600 mg/4 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0292427",
    "display" : "Fosfato Dissódico de Dexametasona 10 mg/2,5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292468",
    "display" : "Sumatriptana 50 mg comprimido"
  },
  {
    "code" : "BR0292732",
    "display" : "Furosemida 40 mg + Cloreto de Potássio 100 mg comprimido"
  },
  {
    "code" : "BR0292764",
    "display" : "Propranolol 40 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0292765",
    "display" : "Propranolol 40 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "BR0292767",
    "display" : "Propranolol 80 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0292770",
    "display" : "Glycine max 100 mg + Persea gratissima 20 mg cápsula"
  },
  {
    "code" : "BR0292778",
    "display" : "Metoprolol 100 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0292788",
    "display" : "Benzidamina 500 mg pó"
  },
  {
    "code" : "BR0292790",
    "display" : "Valsartana 80 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0292791",
    "display" : "Valsartana 160 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0293657",
    "display" : "Dobutamina 250 mg/250 mL solução para injeção; bisnaga"
  },
  {
    "code" : "BR0293803",
    "display" : "Amoxicilina 875 mg + Sulbactam 125 mg comprimido"
  },
  {
    "code" : "BR0293839",
    "display" : "Glicose 20 g + Cloreto de Sódio 3,5 g + Citrato de Sódio 2,5 g + Cloreto de Potássio 1,5 g pó para solução oral"
  },
  {
    "code" : "BR0293879",
    "display" : "Tolterodina 1 mg comprimido"
  },
  {
    "code" : "BR0293880",
    "display" : "Tolterodina 2 mg comprimido"
  },
  {
    "code" : "BR0293891",
    "display" : "Acebrofilina 5 mg/mL xarope"
  },
  {
    "code" : "BR0293892",
    "display" : "Acebrofilina 10 mg/mL xarope"
  },
  {
    "code" : "BR0293925",
    "display" : "Clobutinol 4 mg/mL + Doxilamina 0,75 mg/mL xarope"
  },
  {
    "code" : "BR0293981",
    "display" : "Macrogol 13,12 g + Bicarbonato de Sódio 0,17 g + Cloreto de Sódio 0,35 g + Cloreto de Potássio 0,04 g pó para solução oral"
  },
  {
    "code" : "BR0294094",
    "display" : "Latanaprosta 50 microgramas/mL + Timolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0294096",
    "display" : "Ceftriaxona 250 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0294097",
    "display" : "Ceftriaxona 250 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0294202",
    "display" : "Dexrazoxano 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0294417",
    "display" : "Latanoprosta 50 microgramas/mL solução oftálmica"
  },
  {
    "code" : "BR0294417E",
    "display" : "Latanoprosta 50 microgramas/mL solução oftálmica"
  },
  {
    "code" : "BR0294520",
    "display" : "Lacidipino 2 mg comprimido"
  },
  {
    "code" : "BR0294521",
    "display" : "Lacidipino 4 mg comprimido"
  },
  {
    "code" : "BR0294536",
    "display" : "Mirtazapina 30 mg comprimido"
  },
  {
    "code" : "BR0294537",
    "display" : "Mirtazapina 45 mg comprimido"
  },
  {
    "code" : "BR0294550",
    "display" : "Ubidecarenona 20 mg/mL xarope"
  },
  {
    "code" : "BR0294648",
    "display" : "Ibuprofeno 200 mg comprimido"
  },
  {
    "code" : "BR0294729",
    "display" : "Voriconazol 50 mg comprimido"
  },
  {
    "code" : "BR0294774",
    "display" : "Alfaepoetina 40.000 unidades internacionais/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0294881E",
    "display" : "Iloprosta 10 microgramas/mL solução para inalação 1 mL; ampola"
  },
  {
    "code" : "BR0294912-1",
    "display" : "Irinotecano 40 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0294912-2",
    "display" : "Irinotecano 100 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0294927",
    "display" : "Promestrieno 10 mg/g creme vaginal"
  },
  {
    "code" : "BR0295040",
    "display" : "Lamotrigina 25 mg comprimido"
  },
  {
    "code" : "BR0295040E",
    "display" : "Lamotrigina 25 mg comprimido"
  },
  {
    "code" : "BR0295266",
    "display" : "Glicerofosfato de Sódio 4,32 g/20 mL suspensão para injeção; frasco"
  },
  {
    "code" : "BR0295302",
    "display" : "Trastuzumabe 440 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0295303",
    "display" : "Trastuzumabe 150 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0295391",
    "display" : "Meclozina 25 mg comprimido"
  },
  {
    "code" : "BR0295393",
    "display" : "Meclozina 50 mg comprimido"
  },
  {
    "code" : "BR0295605",
    "display" : "Algestona 150 mg/1 mL + Estradiol 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0295624",
    "display" : "Ácido Fusídico 20 mg/g creme"
  },
  {
    "code" : "BR0295853",
    "display" : "Levonorgestrel 1,5 mg comprimido"
  },
  {
    "code" : "BR0295856",
    "display" : "Levonorgestrel 52 mg (20 microgramas/24 horas) dispositivo intrauterino"
  },
  {
    "code" : "BR0296076",
    "display" : "Candesartana 16 mg comprimido"
  },
  {
    "code" : "BR0296302",
    "display" : "Paroxetina 25 mg comprimido de liberação modificada"
  },
  {
    "code" : "BR0296389",
    "display" : "Cetoprofeno 1 mg/mL xarope"
  },
  {
    "code" : "BR0296486",
    "display" : "Metformina 1 g comprimido"
  },
  {
    "code" : "BR0296594",
    "display" : "Norgestimato 1 mg + Etinilestradiol 90 micrograma comprimido"
  },
  {
    "code" : "BR0296647",
    "display" : "Cumarina 15 mg + Troxerrutina 90 mg comprimido"
  },
  {
    "code" : "BR0296649",
    "display" : "Levotiroxina Sódica 88 microgramas comprimido"
  },
  {
    "code" : "BR0296650",
    "display" : "Levotiroxina Sódica 112 microgramas comprimido"
  },
  {
    "code" : "BR0296657",
    "display" : "Trimebutina 200 mg cápsula"
  },
  {
    "code" : "BR0296676",
    "display" : "Valerato de Estradiol 2 mg + Ciproterona 1 mg comprimido"
  },
  {
    "code" : "BR0296715E",
    "display" : "Risedronato Sódico 5 mg comprimido"
  },
  {
    "code" : "BR0296717",
    "display" : "Risedronato Sódico 35 mg comprimido"
  },
  {
    "code" : "BR0296717E",
    "display" : "Risedronato Sódico 35 mg comprimido"
  },
  {
    "code" : "BR0296741",
    "display" : "Olmesartana Medoxomila 20 mg comprimido"
  },
  {
    "code" : "BR0296742",
    "display" : "Olmesartana Medoxomila 40 mg comprimido"
  },
  {
    "code" : "BR0296743",
    "display" : "Olmesartana Medoxomila 40 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0296744",
    "display" : "Olmesartana Medoxomila 40 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "BR0296745",
    "display" : "Olmesartana Medoxomila 20 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0296749",
    "display" : "Promestrieno 10 mg cápsula vaginal"
  },
  {
    "code" : "BR0296792-1",
    "display" : "Propionato de Fluticasona 250 microgramas/dose + Salmeterol 50 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "BR0296792-2",
    "display" : "Propionato de Fluticasona 250 microgramas/dose + Salmeterol 50 microgramas/dose suspensão aerossol"
  },
  {
    "code" : "BR0296792-3",
    "display" : "Propionato de Fluticasona 250 microgramas/dose + Salmeterol 50 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "BR0296793-1",
    "display" : "Propionato de Fluticasona 500 microgramas/dose + Salmeterol 50 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "BR0296793-2",
    "display" : "Propionato de Fluticasona 500 microgramas/dose + Salmeterol 50 microgramas/dose suspensão aerossol"
  },
  {
    "code" : "BR0296825",
    "display" : "Glicinato Férrico 150 mg (Ferro 30 mg) + Ácido Fólico 5 mg comprimido"
  },
  {
    "code" : "BR0296876",
    "display" : "Carbonato de Cálcio 1,25 g (Cálcio 500 mg) + Colecalciferol 400 unidades internacionais comprimido"
  },
  {
    "code" : "BR0296940",
    "display" : "Estradiol 1 mg + Didrogesterona 10 mg comprimido"
  },
  {
    "code" : "BR0297775",
    "display" : "Pancreatina 10.000 unidades cápsula"
  },
  {
    "code" : "BR0297775E",
    "display" : "Pancreatina 10.000 unidades cápsula"
  },
  {
    "code" : "BR0297787",
    "display" : "Cetirizina 1 mg/mL solução oral"
  },
  {
    "code" : "BR0297787-1",
    "display" : "Cetirizina 1 mg/mL solução oral"
  },
  {
    "code" : "BR0297787-2",
    "display" : "Cetirizina 1 mg/mL solução oral"
  },
  {
    "code" : "BR0298444",
    "display" : "Cromoglicato Dissódico 40 mg/mL solução spray"
  },
  {
    "code" : "BR0298445",
    "display" : "Cromoglicato Dissódico 20 mg/mL (2%) solução oftálmica"
  },
  {
    "code" : "BR0298445-1",
    "display" : "Cromoglicato Dissódico 20 mg/mL (2%) solução oftálmica"
  },
  {
    "code" : "BR0298446",
    "display" : "Cromoglicato Dissódico 40 mg/mL (4%) solução oftálmica"
  },
  {
    "code" : "BR0298454-1",
    "display" : "Dexclorfeniramina 0,4 mg/mL xarope"
  },
  {
    "code" : "BR0298454-2",
    "display" : "Dexclorfeniramina 0,4 mg/mL xarope"
  },
  {
    "code" : "BR0298530",
    "display" : "Estradiol 50 microgramas/24 horas + Acetato de Noretisterona 170 microgramas/24 horas adesivo transdérmico"
  },
  {
    "code" : "BR0298574-1",
    "display" : "Bambuterol 1 mg/mL solução oral"
  },
  {
    "code" : "BR0298574-2",
    "display" : "Bambuterol 1 mg/mL solução oral"
  },
  {
    "code" : "BR0298574-3",
    "display" : "Bambuterol 1 mg/mL solução oral"
  },
  {
    "code" : "BR0298574-4",
    "display" : "Bambuterol 1 mg/mL solução oral"
  },
  {
    "code" : "BR0298574-5",
    "display" : "Bambuterol 1 mg/mL solução oral"
  },
  {
    "code" : "BR0298582",
    "display" : "Brometo de Pinavério 100 mg comprimido"
  },
  {
    "code" : "BR0298734",
    "display" : "Ciclosporina 0,5 mg/mL (0,05%) solução oftálmica"
  },
  {
    "code" : "BR0298768",
    "display" : "Paroxetina 10 mg comprimido"
  },
  {
    "code" : "BR0298769",
    "display" : "Paroxetina 40 mg comprimido"
  },
  {
    "code" : "BR0299128",
    "display" : "Clofazimina 50 mg cápsula"
  },
  {
    "code" : "BR0299129",
    "display" : "Clofazimina 100 mg cápsula"
  },
  {
    "code" : "BR0299236-1",
    "display" : "Dexpantenol 50 mg/g pomada"
  },
  {
    "code" : "BR0299236-2",
    "display" : "Dexpantenol 50 mg/g pomada"
  },
  {
    "code" : "BR0299317",
    "display" : "Fentanila 0,1 mg/2 mL + Droperidol 5 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0299656",
    "display" : "Lidocaína 20 mg/mL + Cloreto de Benzalcônio 1,3 mg/mL solução spray"
  },
  {
    "code" : "BR0299675",
    "display" : "Manitol 50 g/ 250 mL (20%) solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0299675-2",
    "display" : "Manitol 100 g/500 mL (20%) solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0299690-1",
    "display" : "Acetato de Metilprednisolona 40 mg/1 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0299690-2",
    "display" : "Acetato de Metilprednisolona 80 mg/2 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0299690-3",
    "display" : "Acetato de Metilprednisolona 200 mg/5 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0299692",
    "display" : "Amorolfina 50 mg/mL esmalte"
  },
  {
    "code" : "BR0299693",
    "display" : "Amorolfina 2,5 mg/g creme"
  },
  {
    "code" : "BR0299766",
    "display" : "Etambutol 400 mg comprimido"
  },
  {
    "code" : "BR0300252",
    "display" : "Glicose 20% + Cloreto de Sódio 0,9% solução para injeção 1 L;  frasco"
  },
  {
    "code" : "BR0300252-1",
    "display" : "Glicose 20% + Cloreto de Sódio 0,9% solução para injeção 500 mL;  frasco"
  },
  {
    "code" : "BR0300252-2",
    "display" : "Glicose 20% + Cloreto de Sódio 0,9% solução para injeção 250 mL;  frasco"
  },
  {
    "code" : "BR0300257",
    "display" : "Levodropropizina 6 mg/mL xarope"
  },
  {
    "code" : "BR0300259",
    "display" : "Levodropropizina 30 mg/mL solução oral"
  },
  {
    "code" : "BR0300498",
    "display" : "Sucralfato 200 mg/mL suspensão oral"
  },
  {
    "code" : "BR0300722",
    "display" : "Fenobarbital 200 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0300723",
    "display" : "Fenobarbital 40 mg/mL solução oral"
  },
  {
    "code" : "BR0300725",
    "display" : "Fenobarbital 200 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0300733",
    "display" : "Fosfato Dissódico de Dexametasona 2 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0300745",
    "display" : "Pancreatina 25.000 unidades cápsula"
  },
  {
    "code" : "BR0300745E",
    "display" : "Pancreatina 25.000 unidades cápsula"
  },
  {
    "code" : "BR0300988",
    "display" : "Periciazina 10 mg/mL solução oral"
  },
  {
    "code" : "BR0300989",
    "display" : "Periciazina 40 mg/mL solução oral"
  },
  {
    "code" : "BR0301493",
    "display" : "Hidrocortisona 5 mg comprimido"
  },
  {
    "code" : "BR0301591",
    "display" : "Fotemustina 208 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0301748",
    "display" : "Paracetamol 400 mg + Fenilefrina 20 mg comprimido e Paracetamol 400 mg + Carbinoxamina 4 mg comprimido"
  },
  {
    "code" : "BR0302442",
    "display" : "Duloxetina 30 mg comprimido"
  },
  {
    "code" : "BR0302443",
    "display" : "Duloxetina 60 mg cápsula"
  },
  {
    "code" : "BR0302748-1",
    "display" : "Pirazinamida 30 mg/mL suspensão oral"
  },
  {
    "code" : "BR0302748-2",
    "display" : "Pirazinamida 30 mg/mL suspensão oral"
  },
  {
    "code" : "BR0302942",
    "display" : "Ciclosporina 100 mg/mL solução oral"
  },
  {
    "code" : "BR0302942E",
    "display" : "Ciclosporina 100 mg/mL solução oral"
  },
  {
    "code" : "BR0303292-1",
    "display" : "Ringer com Lactato solução para injeção 250 mL; frasco-ampola"
  },
  {
    "code" : "BR0303292-2",
    "display" : "Ringer com Lactato solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "BR0303292-3",
    "display" : "Ringer com Lactato solução para injeção 1 L; frasco-ampola"
  },
  {
    "code" : "BR0304181",
    "display" : "Timomodulina 80 mg cápsula"
  },
  {
    "code" : "BR0304182",
    "display" : "Timomodulina 200 mg/mL xarope"
  },
  {
    "code" : "BR0304788",
    "display" : "Cinacalcete 30 mg comprimido"
  },
  {
    "code" : "BR0304790",
    "display" : "Cinacalcete 60 mg comprimido"
  },
  {
    "code" : "BR0304845",
    "display" : "Nitroglicerina 50 mg (10 mg/24 horas) adesivo transdérmico"
  },
  {
    "code" : "BR0304870",
    "display" : "Sulfato de Morfina 1 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0304870-1",
    "display" : "Sulfato de Morfina 2 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0304871",
    "display" : "Sulfato de Morfina 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0304871E",
    "display" : "Sulfato de Morfina 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0304872",
    "display" : "Sulfato de Morfina 0,2 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0304875",
    "display" : "Digoxina 0,125 mg comprimido"
  },
  {
    "code" : "BR0305106",
    "display" : "Glucagon 1 mg pó para solução para injeção; ampola"
  },
  {
    "code" : "BR0305247-1",
    "display" : "Lactulose 667 mg/mL solução oral"
  },
  {
    "code" : "BR0305247-2",
    "display" : "Lactulose 667 mg/mL xarope"
  },
  {
    "code" : "BR0305252",
    "display" : "Asparaginase 10.000 unidades internacionais pó para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305259",
    "display" : "Leuprorrelina 22,5 mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305260",
    "display" : "Leuprorrelina 11,25 mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305260E",
    "display" : "Leuprorrelina 11,25 mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305261",
    "display" : "Leuprorrelina 14 mg/2,8 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305264",
    "display" : "Levobupivacaína 100 mg/20 mL (0,5%) + Epinefrina 100 microgramas/20 mL (1:200.000) solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305265",
    "display" : "Levobupivacaína 150 mg/20 mL (0,75%) + Epinefrina 100 microgramas/20 mL (1:200.000) solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305270",
    "display" : "Levofloxacino 500 mg comprimido"
  },
  {
    "code" : "BR0305293",
    "display" : "Mitoxantrona 20 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305325",
    "display" : "Moxifloxacino 400 mg/250 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305356",
    "display" : "Nicotina 4 mg goma de mascar"
  },
  {
    "code" : "BR0305413",
    "display" : "Ginkgo biloba 120 mg comprimido"
  },
  {
    "code" : "BR0305414",
    "display" : "Ginkgo biloba 80 mg cápsula"
  },
  {
    "code" : "BR0305414-1",
    "display" : "Ginkgo biloba 80 mg comprimido"
  },
  {
    "code" : "BR0305415-1",
    "display" : "Ginkgo biloba 40 mg comprimido"
  },
  {
    "code" : "BR0305428",
    "display" : "Carmelose Sódica 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0305428-1",
    "display" : "Carmelose Sódica 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0305428-3",
    "display" : "Carmelose Sódica 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0305428-4",
    "display" : "Carmelose Sódica 10 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0305449",
    "display" : "Citrato de Potássio 540 mg (5 mEq) comprimido de liberação prolongada"
  },
  {
    "code" : "BR0305450",
    "display" : "Citrato de Potássio 1.080 mg (10 mEq) comprimido de liberação prolongada"
  },
  {
    "code" : "BR0305464-1",
    "display" : "Fluoxetina 10 mg comprimido"
  },
  {
    "code" : "BR0305464-2",
    "display" : "Fluoxetina 10 mg cápsula"
  },
  {
    "code" : "BR0305483",
    "display" : "Maprotilina 25 mg comprimido"
  },
  {
    "code" : "BR0305484",
    "display" : "Maprotilina 75 mg comprimido"
  },
  {
    "code" : "BR0305487",
    "display" : "Mebeverina 200 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0305490",
    "display" : "Metilfenidato 30 mg cápsula de liberação modificada"
  },
  {
    "code" : "BR0305490-1",
    "display" : "Metilfenidato 40 mg cápsula de liberação modificada"
  },
  {
    "code" : "BR0305491",
    "display" : "Pioglitazona 45 mg comprimido"
  },
  {
    "code" : "BR0305492",
    "display" : "Pioglitazona 30 mg comprimido"
  },
  {
    "code" : "BR0305493",
    "display" : "Pioglitazona 15 mg comprimido"
  },
  {
    "code" : "BR0305494",
    "display" : "Didrogesterona 10 mg comprimido"
  },
  {
    "code" : "BR0305649E",
    "display" : "Formoterol 12 microgramas + Budesonida 400 micrograma cápsula para inalação"
  },
  {
    "code" : "BR0305650",
    "display" : "Formoterol 12 microgramas + Budesonida 400 micrograma cápsula para inalação"
  },
  {
    "code" : "BR0305652",
    "display" : "Formoterol 12 microgramas/dose + Budesonida 400 microgramas/dose pó para inalação"
  },
  {
    "code" : "BR0305652E",
    "display" : "Formoterol 12 microgramas/dose + Budesonida 400 microgramas/dose pó para inalação"
  },
  {
    "code" : "BR0305714",
    "display" : "Nitrofurantoína 5 mg/mL suspensão oral"
  },
  {
    "code" : "BR0305717",
    "display" : "Norepinefrina 4 mg/4 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0305718",
    "display" : "Norepinefrina 4 mg/4 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0305725",
    "display" : "Octreotida 0,1 mg/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305725E",
    "display" : "Octreotida 0,1 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0305726E",
    "display" : "Octreotida 0,5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0305727",
    "display" : "Octreotida 0,05 mg/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305935-1",
    "display" : "Propofol 100 mg/10 mL emulsão para injeção; ampola"
  },
  {
    "code" : "BR0305935-2",
    "display" : "Propofol 200 mg/20 mL emulsão para injeção; ampola"
  },
  {
    "code" : "BR0305935-3",
    "display" : "Propofol 500 mg/50 mL emulsão para injeção; ampola"
  },
  {
    "code" : "BR0305938",
    "display" : "Dicloridrato de Quinina 600 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0306145",
    "display" : "Valsartana 160 mg comprimido"
  },
  {
    "code" : "BR0306146",
    "display" : "Valsartana 320 mg comprimido"
  },
  {
    "code" : "BR0306355",
    "display" : "Diclofenaco Sódico 50 mg + Codeína 50 mg comprimido"
  },
  {
    "code" : "BR0306361",
    "display" : "Carbonato de Cálcio 1,5 g (Cálcio 600 mg) + Colecalciferol 400 unidades internacionais comprimido"
  },
  {
    "code" : "BR0306465",
    "display" : "Trometamol Cetorolaco 30 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0306685",
    "display" : "Nateglinida 120 mg comprimido"
  },
  {
    "code" : "BR0306686",
    "display" : "Nicergolina 30 mg comprimido"
  },
  {
    "code" : "BR0306687",
    "display" : "Alfuzosina 10 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0306947",
    "display" : "Oseltamivir 75 mg cápsula"
  },
  {
    "code" : "BR0306971",
    "display" : "Oseltamivir 15 mg/mL solução oral"
  },
  {
    "code" : "BR0307780",
    "display" : "Gatifloxacino 3 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0308071",
    "display" : "Simeticona 80 mg/mL + Homatropina 2,5 mg/mL solução oral"
  },
  {
    "code" : "BR0308224",
    "display" : "Metilfenidato 18 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0308225",
    "display" : "Metilfenidato 54 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0308226",
    "display" : "Metilfenidato 36 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0308373",
    "display" : "Flucitosina 500 mg comprimido"
  },
  {
    "code" : "BR0308654",
    "display" : "Omalizumabe 150 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0308718",
    "display" : "Acitretina 25 mg cápsula"
  },
  {
    "code" : "BR0308718E",
    "display" : "Acitretina 25 mg cápsula"
  },
  {
    "code" : "BR0308719E",
    "display" : "Acitretina 10 mg cápsula"
  },
  {
    "code" : "BR0308721",
    "display" : "Ácido Alendrônico 10 mg comprimido"
  },
  {
    "code" : "BR0308726",
    "display" : "Benzoato de Benzila 250 mg/mL emulsão"
  },
  {
    "code" : "BR0308726-1",
    "display" : "Benzoato de Benzila 250 mg/mL emulsão"
  },
  {
    "code" : "BR0308729",
    "display" : "Bezafibrato 400 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0308729E",
    "display" : "Bezafibrato 400 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0308732",
    "display" : "Ácido Valproico 50 mg/mL xarope"
  },
  {
    "code" : "BR0308736-1",
    "display" : "Cetoconazol 20 mg/g creme"
  },
  {
    "code" : "BR0308736-2",
    "display" : "Cetoconazol 20 mg/g creme"
  },
  {
    "code" : "BR0308736-3",
    "display" : "Cetoconazol 20 mg/g creme"
  },
  {
    "code" : "BR0308738",
    "display" : "Ciprofibrato 100 mg comprimido"
  },
  {
    "code" : "BR0308738E",
    "display" : "Ciprofibrato 100 mg comprimido"
  },
  {
    "code" : "BR0308802-1",
    "display" : "Fator VIII 500 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0308805",
    "display" : "Fator IX 500 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0308874",
    "display" : "Pentamidina 300 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0308877",
    "display" : "Sevoflurano líquido para inalação 250 mL"
  },
  {
    "code" : "BR0308877-1",
    "display" : "Sevoflurano líquido para inalação 100 mL"
  },
  {
    "code" : "BR0308882",
    "display" : "Sulfametoxazol 400 mg + Trimetoprima 80 mg comprimido"
  },
  {
    "code" : "BR0308883",
    "display" : "Sulfametoxazol 800 mg + Trimetoprima 160 mg comprimido"
  },
  {
    "code" : "BR0308884-1",
    "display" : "Sulfametoxazol 40 mg/mL + Trimetoprima 8 mg/mL suspensão oral"
  },
  {
    "code" : "BR0308884-2",
    "display" : "Sulfametoxazol 40 mg/mL + Trimetoprima 8 mg/mL suspensão oral"
  },
  {
    "code" : "BR0308884-3",
    "display" : "Sulfametoxazol 40 mg/mL + Trimetoprima 8 mg/mL suspensão oral"
  },
  {
    "code" : "BR0308884-4",
    "display" : "Sulfametoxazol 40 mg/mL + Trimetoprima 8 mg/mL suspensão oral"
  },
  {
    "code" : "BR0308885",
    "display" : "Sulfametoxazol 400 mg/5 mL + Trimetoprima 80 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0309040",
    "display" : "Ácido Ursodesoxicólico 300 mg comprimido"
  },
  {
    "code" : "BR0309042",
    "display" : "Folinato de Cálcio 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0309045",
    "display" : "Ácido Épsilon-Aminocaproico 4 g/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0309095",
    "display" : "Formoterol 6 microgramas/dose + Budesonida 200 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "BR0309097",
    "display" : "Formoterol 6 microgramas/dose + Budesonida 100 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "BR0309432",
    "display" : "Cilazapril 1 mg comprimido"
  },
  {
    "code" : "BR0309433",
    "display" : "Cilazapril 2,5 mg comprimido"
  },
  {
    "code" : "BR0309434",
    "display" : "Cilazapril 5 mg comprimido"
  },
  {
    "code" : "BR0309437",
    "display" : "Tramadol 100 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0309437-1",
    "display" : "Tramadol 100 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0309441",
    "display" : "Tramadol 100 mg comprimido"
  },
  {
    "code" : "BR0309530-1",
    "display" : "Glicosamina 1,5 g pó para solução oral"
  },
  {
    "code" : "BR0309530-2",
    "display" : "Glicosamina 1,5 g pó para solução oral"
  },
  {
    "code" : "BR0310761",
    "display" : "Laronidase 2,9 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0311143",
    "display" : "Benzoato de Benzila 100 mg/g sabonete"
  },
  {
    "code" : "BR0311143-1",
    "display" : "Benzoato de Benzila 100 mg/g sabonete"
  },
  {
    "code" : "BR0311390-1",
    "display" : "Bevacizumabe 100 mg/4 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0311390-2",
    "display" : "Bevacizumabe 400 mg/16 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0311465",
    "display" : "Sulfato de Zinco 1 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0312388",
    "display" : "Permetrina 10 mg/mL (1%) xampu"
  },
  {
    "code" : "BR0312390",
    "display" : "Hipromelose 3 mg/mL + Dextrana 1 mg/mL + Glicerol 2 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0312568",
    "display" : "Erlotinibe 100 mg comprimido"
  },
  {
    "code" : "BR0312569",
    "display" : "Erlotinibe 150 mg comprimido"
  },
  {
    "code" : "BR0312860",
    "display" : "Fluormetolona 1 mg/mL (0,1%) solução oftálmica"
  },
  {
    "code" : "BR0312860-1",
    "display" : "Fluormetolona 1 mg/mL (0,1%) solução oftálmica"
  },
  {
    "code" : "BR0313000",
    "display" : "Tipranavir 250 mg cápsula"
  },
  {
    "code" : "BR0313186",
    "display" : "Clotrimazol 10 mg/g + Dexametasona 0,4 mg/g creme"
  },
  {
    "code" : "BR0313591",
    "display" : "Policresuleno 18 mg/g gel"
  },
  {
    "code" : "BR0313592",
    "display" : "Policresuleno 360 mg/g solução"
  },
  {
    "code" : "BR0313593",
    "display" : "Policresuleno 90 mg óvulo"
  },
  {
    "code" : "BR0313594",
    "display" : "Policresuleno 240 mg + Cinchocaína 24 mg supositório"
  },
  {
    "code" : "BR0313595",
    "display" : "Policresuleno 100 mg/g + Cinchocaína 10 mg/g pomada"
  },
  {
    "code" : "BR0313689",
    "display" : "Fosfato de Potássio 20 mEq/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0314373-1",
    "display" : "Cumarina 5 mg/mL + Heparina sódica 50 unidades internacionais/mL creme"
  },
  {
    "code" : "BR0314373-2",
    "display" : "Cumarina 5 mg/mL + Heparina sódica 50 unidades internacionais/mL creme"
  },
  {
    "code" : "BR0314373-3",
    "display" : "Cumarina 5 mg/mL + Heparina sódica 50 unidades internacionais/mL creme"
  },
  {
    "code" : "BR0314373-4",
    "display" : "Cumarina 5 mg/mL + Heparina sódica 50 unidades internacionais/mL creme"
  },
  {
    "code" : "BR0314517-1",
    "display" : "Azitromicina 40 mg/mL suspensão oral"
  },
  {
    "code" : "BR0314517-2",
    "display" : "Azitromicina 40 mg/mL suspensão oral"
  },
  {
    "code" : "BR0314517-3",
    "display" : "Azitromicina 40 mg/mL suspensão oral"
  },
  {
    "code" : "BR0314517-4",
    "display" : "Azitromicina 1,5 g pó para suspensão oral"
  },
  {
    "code" : "BR0315088",
    "display" : "Entecavir 0,5 mg comprimido"
  },
  {
    "code" : "BR0315088E",
    "display" : "Entecavir 0,5 mg comprimido"
  },
  {
    "code" : "BR0315089",
    "display" : "Entecavir 1 mg comprimido"
  },
  {
    "code" : "BR0315089E",
    "display" : "Entecavir 1 mg comprimido"
  },
  {
    "code" : "BR0315483",
    "display" : "Fludroxicortida 0,125 mg/g + Neomicina 3,5 mg/g creme"
  },
  {
    "code" : "BR0315604",
    "display" : "Monossialogangliosídeo 100 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0315610",
    "display" : "Palonosetrona 0,25 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0315734",
    "display" : "Galantamina 24 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0315734E",
    "display" : "Galantamina 24 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0315735",
    "display" : "Galantamina 16 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0315735E",
    "display" : "Galantamina 16 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0318305",
    "display" : "Ácido Salicílico 170 mg/mL + Ácido Láctico 150 mg/mL solução tópica"
  },
  {
    "code" : "BR0318309",
    "display" : "Dipropionato de Betametasona 0,5 mg/g + Ácido salicílico 30 mg/g pomada"
  },
  {
    "code" : "BR0318943",
    "display" : "Cloreto de Sódio 9 mg/mL (0,9%) + Cloreto de Benzalcônio 0,1 mg/mL (0,01%) + Nafazolina 0,5 mg/mL (0,05%) solução nasal"
  },
  {
    "code" : "BR0318945",
    "display" : "Citalopram 40 mg comprimido"
  },
  {
    "code" : "BR0318969",
    "display" : "Di-hidroergocristina 3 mg + Flunarizina 10 mg comprimido"
  },
  {
    "code" : "BR0318988",
    "display" : "Somatropina 8 unidades internacionais"
  },
  {
    "code" : "BR0318993",
    "display" : "Triflusal 300 mg cápsula"
  },
  {
    "code" : "BR0319000-1",
    "display" : "Brimonidina 2 mg/mL + Timolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0319000-2",
    "display" : "Brimonidina 2 mg/mL + Timolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0319004",
    "display" : "Dexametasona 0,75 mg comprimido"
  },
  {
    "code" : "BR0319128",
    "display" : "Primidona 100 mg comprimido"
  },
  {
    "code" : "BR0319128E",
    "display" : "Primidona 100 mg comprimido"
  },
  {
    "code" : "BR0319763",
    "display" : "Bronfeniramina 0,4 mg/mL + Fenilefrina 1 mg/mL xarope"
  },
  {
    "code" : "BR0319764",
    "display" : "Bronfeniramina 2 mg/mL + Fenilefrina 2,5 mg/mL solução oral"
  },
  {
    "code" : "BR0319883",
    "display" : "Sildenafila 20 mg comprimido"
  },
  {
    "code" : "BR0319883E",
    "display" : "Sildenafila 20 mg comprimido"
  },
  {
    "code" : "BR0320338",
    "display" : "Sulbutiamina 200 mg comprimido"
  },
  {
    "code" : "BR0320796",
    "display" : "Desmopressina 15 microgramas/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0320824",
    "display" : "Benazepril 5 mg comprimido"
  },
  {
    "code" : "BR0320825",
    "display" : "Benazepril 10 mg comprimido"
  },
  {
    "code" : "BR0320829",
    "display" : "Benazepril 10 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0321234-1",
    "display" : "Dexametasona 1 mg/mL + Neomicina 3,5 mg/mL + Polimixina B 6.000 unidades internacionais/mL solução oftálmica"
  },
  {
    "code" : "BR0321804",
    "display" : "Topotecana 4 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0322033",
    "display" : "Alfalutropina 75 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0322254",
    "display" : "Estazolam 2 mg comprimido"
  },
  {
    "code" : "BR0322435",
    "display" : "Fanciclovir 500 mg comprimido"
  },
  {
    "code" : "BR0322436",
    "display" : "Fanciclovir 125 mg comprimido"
  },
  {
    "code" : "BR0323004",
    "display" : "Isoxsuprina 10 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0323096",
    "display" : "Bromazepam 2,5 mg/mL solução oral"
  },
  {
    "code" : "BR0323548",
    "display" : "Bromazepam 1 mg + Sulpirida 25 mg comprimido"
  },
  {
    "code" : "BR0324358",
    "display" : "Anfotericina B Complexo Lipídico 100 mg/20 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0324414",
    "display" : "Lamotrigina 50 mg comprimido"
  },
  {
    "code" : "BR0324414E",
    "display" : "Lamotrigina 50 mg comprimido"
  },
  {
    "code" : "BR0324415",
    "display" : "Etoricoxibe 90 mg comprimido"
  },
  {
    "code" : "BR0324587",
    "display" : "Dicloridrato de Manidipino 20 mg comprimido"
  },
  {
    "code" : "BR0325456",
    "display" : "Dicloridrato de Manidipino 10 mg comprimido"
  },
  {
    "code" : "BR0325836",
    "display" : "Deferasirox 250 mg comprimido para suspensão"
  },
  {
    "code" : "BR0325836E",
    "display" : "Deferasirox 250 mg comprimido para suspensão"
  },
  {
    "code" : "BR0325837",
    "display" : "Deferasirox 500 mg comprimido para suspensão"
  },
  {
    "code" : "BR0325837E",
    "display" : "Deferasirox 500 mg comprimido para suspensão"
  },
  {
    "code" : "BR0326010",
    "display" : "Triancinolona Acetonida 1 mg/g pomada"
  },
  {
    "code" : "BR0326057",
    "display" : "Glicinato Férrico 300 mg (Ferro 60 mg) comprimido"
  },
  {
    "code" : "BR0326613",
    "display" : "Glicinato Férrico 500 mg (Ferro 100 mg) comprimido mastigável"
  },
  {
    "code" : "BR0326789",
    "display" : "Cefaclor 500 mg comprimido"
  },
  {
    "code" : "BR0326902",
    "display" : "Etambutol 25 mg/mL suspensão oral"
  },
  {
    "code" : "BR0327566",
    "display" : "Ácido Tranexâmico 250 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0327699-1",
    "display" : "Permanganato de Potássio 100 mg comprimido"
  },
  {
    "code" : "BR0327699-2",
    "display" : "Permanganato de Potássio 100 mg pó"
  },
  {
    "code" : "BR0327766-1",
    "display" : "Carbonato de Cálcio 1,5 g (Cálcio 600 mg) + Colecalciferol 200 unidades internacionais comprimido"
  },
  {
    "code" : "BR0327792",
    "display" : "Cefalexina 25 mg/mL suspensão oral"
  },
  {
    "code" : "BR0327792-1",
    "display" : "Cefalexina 25 mg/mL suspensão oral"
  },
  {
    "code" : "BR0327794",
    "display" : "Ciprofloxacino 3 mg/g + Dexametasona 1 mg/g pomada oftálmica"
  },
  {
    "code" : "BR0327802",
    "display" : "Clortalidona 25 mg + Amilorida 5 mg comprimido"
  },
  {
    "code" : "BR0328106",
    "display" : "Clomifeno 50 mg comprimido"
  },
  {
    "code" : "BR0328205",
    "display" : "Mesilato de Codergocrina 1 mg/mL solução oral"
  },
  {
    "code" : "BR0328513",
    "display" : "Artesunato 60 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0328531",
    "display" : "Valproato de sódio 300 mg comprimido gastrorresistente"
  },
  {
    "code" : "BR0328535-1",
    "display" : "Valproato de Sódio 200 mg/mL solução oral"
  },
  {
    "code" : "BR0328810",
    "display" : "Lamivudina 10 mg/mL solução oral"
  },
  {
    "code" : "BR0328810E",
    "display" : "Lamivudina 10 mg/mL solução oral"
  },
  {
    "code" : "BR0328959",
    "display" : "Dantroleno 25 mg cápsula"
  },
  {
    "code" : "BR0328960",
    "display" : "Dantroleno 100 mg cápsula"
  },
  {
    "code" : "BR0328992",
    "display" : "Tolterodina 4 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0329341",
    "display" : "Tadalafila 20 mg comprimido"
  },
  {
    "code" : "BR0329352",
    "display" : "Pizotifeno 0,5 g comprimido"
  },
  {
    "code" : "BR0329359",
    "display" : "Tiocolchicosídeo 4 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0329507",
    "display" : "Retinol 100.000 unidades internacionais cápsula"
  },
  {
    "code" : "BR0329508",
    "display" : "Retinol 200.000 unidades internacionals cápsula"
  },
  {
    "code" : "BR0329610",
    "display" : "Acetato de Racealfatocoferol 400 mg cápsula"
  },
  {
    "code" : "BR0330113-1",
    "display" : "Ganciclovir 250 mg/250 mL solução para injeção; frasco"
  },
  {
    "code" : "BR0330113-2",
    "display" : "Ganciclovir 500 mg/500 mL solução para injeção; frasco"
  },
  {
    "code" : "BR0330114",
    "display" : "Ganciclovir 500 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0330115",
    "display" : "Ganciclovir 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0330335",
    "display" : "Sorafenibe 200 mg comprimido"
  },
  {
    "code" : "BR0331153",
    "display" : "Álcool Polivinílico 14 mg/mL + Povidona 6 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0331158",
    "display" : "Ciprofloxacino 3 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0331166",
    "display" : "Fluormetolona 2,5 mg/mL (0,25%) solução oftálmica"
  },
  {
    "code" : "BR0331223-1",
    "display" : "Teriparatida 600 microgramas/2,4 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "BR0331296",
    "display" : "Tegaserode 6 mg comprimido"
  },
  {
    "code" : "BR0331308",
    "display" : "Anlodipino 5 mg + Atenolol 50 mg cápsula"
  },
  {
    "code" : "BR0331309",
    "display" : "Anlodipino 5 mg + Atenolol 25 mg cápsula"
  },
  {
    "code" : "BR0331388",
    "display" : "Sitagliptina 50 mg comprimido"
  },
  {
    "code" : "BR0331389",
    "display" : "Sitagliptina 100 mg comprimido"
  },
  {
    "code" : "BR0331539",
    "display" : "Tigeciclina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0331555-1",
    "display" : "Cefalexina 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0331555-2",
    "display" : "Cefalexina 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0331938",
    "display" : "Pemetrexede 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0331980",
    "display" : "Ciproterona 100 mg comprimido"
  },
  {
    "code" : "BR0332382",
    "display" : "Cidofovir 375 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0332383",
    "display" : "Idursulfase 6 mg/3 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0332426",
    "display" : "Hidróxido de Alumínio 37 mg/mL + Hidróxido de Magnésio 35,6 mg/mL suspensão oral"
  },
  {
    "code" : "BR0332468-1",
    "display" : "Sulfato Ferroso 25 mg/mL (Ferro 5 mg/mL) xarope"
  },
  {
    "code" : "BR0332468-2",
    "display" : "Sulfato Ferroso 25 mg/mL (Ferro 5 mg/mL) xarope"
  },
  {
    "code" : "BR0332754",
    "display" : "Ibuprofeno 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0332755-3",
    "display" : "Ibuprofeno 100 mg/mL suspensão oral"
  },
  {
    "code" : "BR0332755-6",
    "display" : "Ibuprofeno 100 mg/mL suspensão oral"
  },
  {
    "code" : "BR0332761",
    "display" : "Sumatriptana 25 mg comprimido"
  },
  {
    "code" : "BR0332764",
    "display" : "Darunavir 300 mg comprimido"
  },
  {
    "code" : "BR0332788",
    "display" : "Propionato de Fluticasona 125 microgramas/dose + Salmeterol 25 microgramas/dose suspensão aerossol; inalador"
  },
  {
    "code" : "BR0332789",
    "display" : "Propionato de Fluticasona 50 microgramas/dose + Salmeterol 25 microgramas/dose suspensão aerossol; inalador"
  },
  {
    "code" : "BR0332794",
    "display" : "Gestodeno 0,075 mg + Etinilestradiol 0,02 mg comprimido"
  },
  {
    "code" : "BR0332795",
    "display" : "Gestodeno 0,075 mg + Etinilestradiol 0,03 mg comprimido"
  },
  {
    "code" : "BR0332848",
    "display" : "Calcipotriol 50 microgramas/g + Dipropionato de Betametasona 0,5 mg/g pomada"
  },
  {
    "code" : "BR0332849-1",
    "display" : "Calcipotriol 50 microgramas/g pomada"
  },
  {
    "code" : "BR0332849-2",
    "display" : "Calcipotriol 50 microgramas/g pomada"
  },
  {
    "code" : "BR0332849E",
    "display" : "Calcipotriol 50 microgramas/g pomada"
  },
  {
    "code" : "BR0332888",
    "display" : "Anfotericina B 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0332917",
    "display" : "Vasopressina 20 unidades/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0332984",
    "display" : "Coaltar 40 mg/mL xampu"
  },
  {
    "code" : "BR0332985",
    "display" : "Levofloxacino 500 mg/100 mL solução para injeção; frasco"
  },
  {
    "code" : "BR0332986",
    "display" : "Levofloxacino 500 mg/20 mL solução para injeção; frasco"
  },
  {
    "code" : "BR0332987",
    "display" : "Levofloxacino 250 mg comprimido"
  },
  {
    "code" : "BR0333130-1",
    "display" : "Cefuroxima 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0333130-2",
    "display" : "Cefuroxima 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0333142",
    "display" : "Alprostadil 500 microgramas/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0333446",
    "display" : "Palivizumabe 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0333447",
    "display" : "Infliximabe 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0333447E",
    "display" : "Infliximabe 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0333496",
    "display" : "Sotalol 120 mg comprimido"
  },
  {
    "code" : "BR0333568",
    "display" : "Tacrolimo 3 mg/g (0,3%) creme"
  },
  {
    "code" : "BR0333569-1",
    "display" : "Tacrolimo 1 mg/g pomada"
  },
  {
    "code" : "BR0333569-2",
    "display" : "Tacrolimo 1 mg/g pomada"
  },
  {
    "code" : "BR0333569-3",
    "display" : "Tacrolimo 0,3 mg/g pomada"
  },
  {
    "code" : "BR0333791",
    "display" : "Clodronato Dissódico 300 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0334016-1",
    "display" : "Propionato de Fluticasona 50 microgramas/dose suspensão aerossol; inalador"
  },
  {
    "code" : "BR0334016-2",
    "display" : "Propionato de Fluticasona 50 microgramas/dose suspensão aerossol; inalador"
  },
  {
    "code" : "BR0334712",
    "display" : "Fulvestranto 250 mg/5mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0335091",
    "display" : "Acetilcisteína 300 mg/3 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0335097-1",
    "display" : "Cloranfenicol 250 mg comprimido"
  },
  {
    "code" : "BR0335097-2",
    "display" : "Cloranfenicol 250 mg cápsula"
  },
  {
    "code" : "BR0335098",
    "display" : "Cloranfenicol 500 mg comprimido"
  },
  {
    "code" : "BR0335100",
    "display" : "Cloranfenicol 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0335101-1",
    "display" : "Cloranfenicol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0335101-2",
    "display" : "Cloranfenicol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0335103",
    "display" : "Cloranfenicol 25 mg/mL suspensão oral"
  },
  {
    "code" : "BR0335103-1",
    "display" : "Cloranfenicol 25 mg/mL suspensão oral"
  },
  {
    "code" : "BR0335104",
    "display" : "Cloranfenicol 30 mg/mL suspensão oral"
  },
  {
    "code" : "BR0335106",
    "display" : "Cloranfenicol 25 mg/mL + Lidocaína 30 mg/mL solução otológica"
  },
  {
    "code" : "BR0335112",
    "display" : "Pentoxifilina 100 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0335968",
    "display" : "Vardenafila 10 mg comprimido"
  },
  {
    "code" : "BR0335969",
    "display" : "Vardenafila 20 mg comprimido"
  },
  {
    "code" : "BR0336680",
    "display" : "Fosamprenavir 700 mg comprimido"
  },
  {
    "code" : "BR0337468-2",
    "display" : "Desloratadina 0,5 mg/mL xarope"
  },
  {
    "code" : "BR0337468-3",
    "display" : "Desloratadina 0,5 mg/mL xarope"
  },
  {
    "code" : "BR0337468-4",
    "display" : "Desloratadina 1,25 mg/mL solução oral"
  },
  {
    "code" : "BR0337472",
    "display" : "Insulina Detemir 100 unidades/mL solução para injeção 3 mL; dispositivo para injeção"
  },
  {
    "code" : "BR0337473",
    "display" : "Insulina Detemir 100 unidades/mL solução para injeção 3 mL; carpule"
  },
  {
    "code" : "BR0337478-1",
    "display" : "Propionato de Fluticasona 100 microgramas/dose + Salmeterol 50 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "BR0337478-2",
    "display" : "Propionato de Fluticasona 100 microgramas/dose + Salmeterol 50 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "BR0337678",
    "display" : "Ácido Acetilsalicílico 100 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0337679",
    "display" : "Ácido Acetilsalicílico 300 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0338134",
    "display" : "Espironolactona 50 mg comprimido"
  },
  {
    "code" : "BR0338288",
    "display" : "Undecanoato de Testosterona 1 g/4 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0338297",
    "display" : "Voriconazol 200 mg comprimido"
  },
  {
    "code" : "BR0338298",
    "display" : "Voriconazol 200 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0338332",
    "display" : "Acetato de Zinco 1 mEq/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0338411",
    "display" : "Ácido Zoledrônico 4 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0338413",
    "display" : "Dactinomicina 0,5 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0338883",
    "display" : "Calcitonina (Salmão) 200 unidades internacionais/dose solução spray"
  },
  {
    "code" : "BR0338883E",
    "display" : "Calcitonina (Salmão) 200 unidades internacionais/dose solução spray"
  },
  {
    "code" : "BR0338888E",
    "display" : "Calcitonina (Salmão) 50 unidades internacionais/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0338890E",
    "display" : "Calcitonina (Salmão) 100 unidades internacionais/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0339534",
    "display" : "Cloreto de Sódio 30 mg/mL solução spray"
  },
  {
    "code" : "BR0339846",
    "display" : "Cefepima 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0339847",
    "display" : "Cefepima 2 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0339979",
    "display" : "Somatropina 5 mg/1,5 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "BR0339980",
    "display" : "Somatropina 10 mg/1,5 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "BR0339981",
    "display" : "Somatropina 15 mg/1,5 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "BR0340100",
    "display" : "Cetoprofeno 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0340103",
    "display" : "Cetoprofeno 150 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0340104",
    "display" : "Cetoprofeno 200 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0340105",
    "display" : "Cetoprofeno 100 mg comprimido"
  },
  {
    "code" : "BR0340107",
    "display" : "Cetoprofeno 100 mg supositório"
  },
  {
    "code" : "BR0340117",
    "display" : "Vareniclina 0,5 mg comprimido"
  },
  {
    "code" : "BR0340118",
    "display" : "Vareniclina 1 mg comprimido"
  },
  {
    "code" : "BR0340120",
    "display" : "Vareniclina 1 mg comprimido e Vareniclina 0,5 mg comprimido"
  },
  {
    "code" : "BR0340121",
    "display" : "Vareniclina 1 mg comprimido e Vareniclina 0,5 mg comprimido"
  },
  {
    "code" : "BR0340122",
    "display" : "Vareniclina 1 mg comprimido e Vareniclina 0,5 mg comprimido"
  },
  {
    "code" : "BR0340128",
    "display" : "Cetotifeno 0,25 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0340148",
    "display" : "Ciclofosfamida 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340149",
    "display" : "Ciclofosfamida 200 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340153",
    "display" : "Ciclopirox Olamina 10 mg/mL solução"
  },
  {
    "code" : "BR0340167",
    "display" : "Cimetidina 300 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0340177",
    "display" : "Besilato de Cisatracúrio 150 mg/30 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340178-1",
    "display" : "Besilato de Cisatracúrio 10 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0340178-2",
    "display" : "Besilato de Cisatracúrio 20 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0340182",
    "display" : "Cisplatina 10 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340183",
    "display" : "Cisplatina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340184",
    "display" : "Cisplatina 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340190",
    "display" : "Citarabina 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340191",
    "display" : "Citarabina 100 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340193-1",
    "display" : "Citarabina 100 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340193-2",
    "display" : "Citarabina 500 mg/25 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340194",
    "display" : "Citarabina 500 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340195 -1",
    "display" : "Citarabina 100 mg/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340195-2",
    "display" : "Citarabina 500 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340195-3",
    "display" : "Citarabina 1 g/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340195-4",
    "display" : "Citarabina 2 g/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340202-1",
    "display" : "Cladribina 5 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0340202-2",
    "display" : "Cladribina 10 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0340206",
    "display" : "Clonidina 0,15 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0340207",
    "display" : "Clorpromazina 40 mg/mL solução oral"
  },
  {
    "code" : "BR0340419",
    "display" : "Di-hidroergotamina 1 mg + Dipirona 350 mg + Cafeína 100 mg comprimido"
  },
  {
    "code" : "BR0340764",
    "display" : "Dipropionato de Betametasona 1 mg/mL + Ácido salicílico 3 mg/mL solução"
  },
  {
    "code" : "BR0340783-1",
    "display" : "Hidróxido de Alumínio 61,5 mg/mL suspensão oral"
  },
  {
    "code" : "BR0340783-1E",
    "display" : "Hidróxido de Alumínio 61,5 mg/mL suspensão oral"
  },
  {
    "code" : "BR0340783-2",
    "display" : "Hidróxido de Alumínio 61,5 mg/mL suspensão oral"
  },
  {
    "code" : "BR0340783-2E",
    "display" : "Hidróxido de Alumínio 61,5 mg/mL suspensão oral"
  },
  {
    "code" : "BR0340783-3",
    "display" : "Hidróxido de Alumínio 61,5 mg/mL suspensão oral"
  },
  {
    "code" : "BR0340783-3E",
    "display" : "Hidróxido de Alumínio 61,5 mg/mL suspensão oral"
  },
  {
    "code" : "BR0340783-4",
    "display" : "Hidróxido de Alumínio 61,5 mg/mL suspensão oral"
  },
  {
    "code" : "BR0341064",
    "display" : "Podofilotoxina 1,5 mg/g creme"
  },
  {
    "code" : "BR0341108",
    "display" : "Mesilato de Codergocrina 4,5 mg comprimido"
  },
  {
    "code" : "BR0341109",
    "display" : "Mesilato de Codergocrina 0,3 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0341180",
    "display" : "Poliestirenossulfonato de Cálcio 30 g (900 mg/g) pó para suspensão"
  },
  {
    "code" : "BR0341829",
    "display" : "Zopiclona 7,5 mg comprimido"
  },
  {
    "code" : "BR0341851",
    "display" : "Fluvoxamina 100 mg comprimido"
  },
  {
    "code" : "BR0341882",
    "display" : "Cianocobalamina 1 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0342108",
    "display" : "Progesterona 80 mg/g gel vaginal"
  },
  {
    "code" : "BR0342134",
    "display" : "Succinato Sódico de Hidrocortisona 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342153",
    "display" : "Ergometrina 0,2 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0342178",
    "display" : "Etoposídeo 100 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342180-1",
    "display" : "Cetuximabe 100 mg/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342193-1",
    "display" : "Docetaxel 20 mg/0,5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342193-2",
    "display" : "Docetaxel 80 mg/2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342258",
    "display" : "Imipeném 500 mg + Cilastatina 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342319",
    "display" : "Ziprasidona 40 mg cápsula"
  },
  {
    "code" : "BR0342319E",
    "display" : "Ziprasidona 40 mg cápsula"
  },
  {
    "code" : "BR0342320",
    "display" : "Ziprasidona 80 mg cápsula"
  },
  {
    "code" : "BR0342320E",
    "display" : "Ziprasidona 80 mg cápsula"
  },
  {
    "code" : "BR0342327",
    "display" : "Varfarina 7,5 mg comprimido"
  },
  {
    "code" : "BR0342469",
    "display" : "Fenilbutazona 200 mg comprimido"
  },
  {
    "code" : "BR0342501",
    "display" : "Fenofibrato 250 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0342501E",
    "display" : "Fenofibrato 250 mg cápsula de liberação retardada"
  },
  {
    "code" : "BR0342526",
    "display" : "Brometo de Tiotrópio 18 micrograma cápsula para inalação"
  },
  {
    "code" : "BR0342666",
    "display" : "Gentamicina 3 mg/g pomada oftálmica"
  },
  {
    "code" : "BR0342680",
    "display" : "Acetato de Triptorrelina 11,25 mg/2 mL suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "BR0342680E",
    "display" : "Acetato de Triptorrelina 11,25 mg pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342682",
    "display" : "Acetato de Triptorrelina 3,75 mg pó e diluente para suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "BR0342682E",
    "display" : "Acetato de Triptorrelina 3,75 mg pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342737",
    "display" : "Heparina Sódica 200 unidades internacionais/g gel"
  },
  {
    "code" : "BR0342739",
    "display" : "Heparina Sódica 10.000 unidades internacionais/ mL solução"
  },
  {
    "code" : "BR0342746",
    "display" : "Acetato de Glatirâmer 20 mg/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0342746E",
    "display" : "Acetato de Glatirâmer 20 mg pó para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342979",
    "display" : "Octreotida 10 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342979E",
    "display" : "Octreotida 10 mg pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342980-2",
    "display" : "Octreotida 20 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342980E",
    "display" : "Octreotida 20 mg pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342981",
    "display" : "Octreotida 30 mg pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342981E",
    "display" : "Octreotida 30 mg pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0343125",
    "display" : "Anlodipino 2,5 mg + Losartana 50 mg cápsula"
  },
  {
    "code" : "BR0343126",
    "display" : "Anlodipino 5 mg + Losartana 100 mg cápsula"
  },
  {
    "code" : "BR0343437",
    "display" : "Estradiol 1 mg/g (0,1%) gel"
  },
  {
    "code" : "BR0343494",
    "display" : "Espiramicina 1.500.000 unidades internacionais comprimido"
  },
  {
    "code" : "BR0343573",
    "display" : "Betaistina 24 mg comprimido"
  },
  {
    "code" : "BR0343604",
    "display" : "Ureia 200 mg/g creme"
  },
  {
    "code" : "BR0343607",
    "display" : "Etanercepte 25 mg pó para solução para injeção; ampola"
  },
  {
    "code" : "BR0343607E",
    "display" : "Etanercepte 25 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0343608",
    "display" : "Etanercepte 50 mg pó para solução para injeção; ampola"
  },
  {
    "code" : "BR0343608E",
    "display" : "Etanercepte 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0343877",
    "display" : "Ácido Acetilsalicílico 200 mg comprimido"
  },
  {
    "code" : "BR0344014",
    "display" : "Clonazepam 0,25 mg comprimido sublingual"
  },
  {
    "code" : "BR0344562",
    "display" : "Sunitinibe 25 mg cápsula"
  },
  {
    "code" : "BR0344563",
    "display" : "Sunitinibe 12,5 mg cápsula"
  },
  {
    "code" : "BR0344564",
    "display" : "Sunitinibe 50 mg cápsula"
  },
  {
    "code" : "BR0345001",
    "display" : "Miglustate 100 mg cápsula"
  },
  {
    "code" : "BR0345001E",
    "display" : "Miglustate 100 mg cápsula"
  },
  {
    "code" : "BR0345240-1",
    "display" : "Hidrocortisona 10 mg/g creme"
  },
  {
    "code" : "BR0345240-2",
    "display" : "Hidrocortisona 10 mg/g creme"
  },
  {
    "code" : "BR0345240-3",
    "display" : "Hidrocortisona 10 mg/g creme"
  },
  {
    "code" : "BR0345241",
    "display" : "Hidrocortisona 10 mg/g pomada"
  },
  {
    "code" : "BR0345259",
    "display" : "Metoprolol 5 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0345259-1",
    "display" : "Metoprolol 5 mg/5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0345300",
    "display" : "Metronidazol 100 mg/g creme vaginal"
  },
  {
    "code" : "BR0345638",
    "display" : "Cloranfenicol 4 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0345783",
    "display" : "Ureia 100 mg/g creme"
  },
  {
    "code" : "BR0345783-1",
    "display" : "Ureia 100 mg/g creme"
  },
  {
    "code" : "BR0345783-2",
    "display" : "Ureia 100 mg/g creme"
  },
  {
    "code" : "BR0345866",
    "display" : "Levodopa 100 + Carbidopa 25 mg + Entacapona 200 mg comprimido"
  },
  {
    "code" : "BR0346231",
    "display" : "Lactato de Amônia 120 mg/g + Alantoína 1 mg/g loção"
  },
  {
    "code" : "BR0346580",
    "display" : "Fator VIII 250 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0346586-1",
    "display" : "Beclometasona 50 microgramas/dose solução aerossol; inalador"
  },
  {
    "code" : "BR0346586-2",
    "display" : "Beclometasona 50 microgramas/dose solução aerossol; inalador"
  },
  {
    "code" : "BR0348362",
    "display" : "Pirimetamina 2 mg/mL suspensão oral"
  },
  {
    "code" : "BR0349475",
    "display" : "Salicilato de Metila 0,02 mL/g + Terebenthina 0,05 mL/g + Cânfora 30mg/g  + Mentol 5 mg/g pomada"
  },
  {
    "code" : "BR0349475-1",
    "display" : "Salicilato de Metila 0,02 mL/g + Terebenthina 0,05 mL/g + Cânfora 30mg/g  + Mentol 5 mg/g pomada"
  },
  {
    "code" : "BR0350587-1",
    "display" : "Lopinavir 80 mg/mL + Ritonavir 20 mg/mL solução oral"
  },
  {
    "code" : "BR0350587-2",
    "display" : "Lopinavir 80 mg/mL + Ritonavir 20 mg/mL solução oral"
  },
  {
    "code" : "BR0350588",
    "display" : "Lopinavir 133,3 mg + Ritonavir 33,3 mg cápsula"
  },
  {
    "code" : "BR0350589",
    "display" : "Lopinavir 200 mg + Ritonavir 50 mg comprimido"
  },
  {
    "code" : "BR0350613",
    "display" : "Imiquimode 50 mg/g creme"
  },
  {
    "code" : "BR0351443",
    "display" : "Rabeprazol 10 mg comprimido gastrorresistente"
  },
  {
    "code" : "BR0351444",
    "display" : "Rabeprazol 20 mg comprimido gastrorresistente"
  },
  {
    "code" : "BR0351479",
    "display" : "Etodolaco 400 mg comprimido"
  },
  {
    "code" : "BR0351480",
    "display" : "Etodolaco 300 mg comprimido"
  },
  {
    "code" : "BR0352129",
    "display" : "Dexclorfeniramina 6 mg comprimido"
  },
  {
    "code" : "BR0352179-1",
    "display" : "Valerato de Betametasona 1 mg/g creme"
  },
  {
    "code" : "BR0352179-2",
    "display" : "Valerato de Betametasona 1 mg/g creme"
  },
  {
    "code" : "BR0352180",
    "display" : "Valerato de Betametasona 1 mg/g pomada"
  },
  {
    "code" : "BR0352192",
    "display" : "Ringer solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "BR0352193",
    "display" : "Tobramicina 3 mg/mL (0,3%) + Dexametasona 1 mg/mL (0,1%) suspensão oftálmica"
  },
  {
    "code" : "BR0352194",
    "display" : "Tioridazina 30 mg/mL solução oral"
  },
  {
    "code" : "BR0352204",
    "display" : "Dexmedetomidina 200 microgramas /2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0352245",
    "display" : "Sildenafila 100 mg comprimido"
  },
  {
    "code" : "BR0352301",
    "display" : "Indapamida 1,5 mg comprimido"
  },
  {
    "code" : "BR0352314",
    "display" : "Pantoprazol 40 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0352317",
    "display" : "Água para injeção 1 L Sistema Fechado; frasco-ampola"
  },
  {
    "code" : "BR0352394",
    "display" : "Budesonida 400 microgramas cápsula para inalação"
  },
  {
    "code" : "BR0352394E",
    "display" : "Budesonida 400 microgramas cápsula para inalação"
  },
  {
    "code" : "BR0352395",
    "display" : "Budesonida 200 microgramas cápsula para inalação"
  },
  {
    "code" : "BR0352395E",
    "display" : "Budesonida 200 microgramas pó aerossol"
  },
  {
    "code" : "BR0352397",
    "display" : "Budesonida 200 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "BR0352397E",
    "display" : "Budesonida 200 microgramas cápsula para inalação"
  },
  {
    "code" : "BR0352411",
    "display" : "Beclometasona 400 microgramas/mL + Salbutamol 800 microgramas/mL suspensão para inalação 2 mL; flaconete"
  },
  {
    "code" : "BR0352414E",
    "display" : "Mesalazina 500 mg supositório"
  },
  {
    "code" : "BR0352847-1",
    "display" : "Pipotiazina 25 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0352847-2",
    "display" : "Pipotiazina 100 mg/4 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0352911",
    "display" : "Divalproato de sódio 125 mg cápsula"
  },
  {
    "code" : "BR0352912",
    "display" : "Divalproato de sódio 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0352932",
    "display" : "Ácido Salicílico 270 mg/g gel"
  },
  {
    "code" : "BR0352933-1",
    "display" : "Levetiracetam 100 mg/mL solução oral"
  },
  {
    "code" : "BR0352933-2",
    "display" : "Levetiracetam 100 mg/mL solução oral"
  },
  {
    "code" : "BR0352933-3",
    "display" : "Levetiracetam 100 mg/mL solução oral"
  },
  {
    "code" : "BR0353332",
    "display" : "Raltegravir 400 mg comprimido"
  },
  {
    "code" : "BR0353333",
    "display" : "Amoxicilina 875 mg + Ácido Clavulânico 125 mg comprimido"
  },
  {
    "code" : "BR0353334",
    "display" : "Pegvisomanto 10 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0353397-1",
    "display" : "Beractanto 100 mg/4 mL suspensão intratraqueal; frasco-ampola"
  },
  {
    "code" : "BR0353397-2",
    "display" : "Beractanto 200 mg/8 mL suspensão intratraqueal; frasco-ampola"
  },
  {
    "code" : "BR0353398-1",
    "display" : "Alfaporactanto 120 mg/1,5 mL suspensão intratraqueal; frasco-ampola"
  },
  {
    "code" : "BR0353398-2",
    "display" : "Alfaporactanto 240 mg/3 mL suspensão intratraqueal; frasco-ampola"
  },
  {
    "code" : "BR0353813",
    "display" : "Mirtazapina 15 mg comprimido para suspensão"
  },
  {
    "code" : "BR0354242",
    "display" : "Metoxisaleno 10 mg cápsula"
  },
  {
    "code" : "BR0354314",
    "display" : "Cimetidina 400 mg comprimido"
  },
  {
    "code" : "BR0354317",
    "display" : "Acarbose 100 mg comprimido"
  },
  {
    "code" : "BR0354498",
    "display" : "Lercanidipino 20 mg comprimido"
  },
  {
    "code" : "BR0354516",
    "display" : "Glipizida 5 mg comprimido"
  },
  {
    "code" : "BR0354627E",
    "display" : "Hidróxido de Alumínio 230 mg comprimido"
  },
  {
    "code" : "BR0354632",
    "display" : "Olopatadina 1 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0354633",
    "display" : "Olopatadina 2 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0354953",
    "display" : "Somatostatina 3 mg pó para injeção; frasco-ampola"
  },
  {
    "code" : "BR0355786",
    "display" : "Acetilcisteína 40 mg/mL xarope"
  },
  {
    "code" : "BR0355786-1",
    "display" : "Acetilcisteína 40 mg/mL xarope"
  },
  {
    "code" : "BR0355794",
    "display" : "Moxifloxacino 5 mg/mL + Dexametasona 1 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0356051",
    "display" : "Ácido Zoledrônico 5 mg/100 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0356452",
    "display" : "Travoprosta 0,04 mg/mL + Timolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0356452-1",
    "display" : "Travoprosta 0,04 mg/mL + Timolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0356453",
    "display" : "Tianeptina 12,5 mg comprimido"
  },
  {
    "code" : "BR0356602",
    "display" : "Estrogênios Conjugados 0,3 mg comprimido"
  },
  {
    "code" : "BR0356701",
    "display" : "Desogestrel 75 microgramas comprimido"
  },
  {
    "code" : "BR0356952",
    "display" : "Acetilcisteína 600 mg comprimido efervescente"
  },
  {
    "code" : "BR0357058",
    "display" : "Paroxetina 15 mg comprimido"
  },
  {
    "code" : "BR0357061",
    "display" : "Valsartana 80 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "BR0357062",
    "display" : "Valsartana 160 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "BR0357063",
    "display" : "Valsartana 320 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "BR0357064",
    "display" : "Vildagliptina 50 mg + Metformina 500 mg comprimido"
  },
  {
    "code" : "BR0357066",
    "display" : "Vildagliptina 50 mg + Metformina 850 mg comprimido"
  },
  {
    "code" : "BR0357071",
    "display" : "Citrato de Cálcio 2.370 mg (Cálcio 500 mg) + Colecalciferol 200 unidades internacionais pó para suspensão oral"
  },
  {
    "code" : "BR0357118",
    "display" : "Beta-agalsidase 5 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0357119",
    "display" : "Beta-agalsidase 35 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0357213",
    "display" : "Metoclopramida 7 mg + Simeticona 40 mg + Pepsina 50 mg cápsula"
  },
  {
    "code" : "BR0357657",
    "display" : "Etravirina 100 mg comprimido"
  },
  {
    "code" : "BR0357788",
    "display" : "Mepivacaína 54 mg/1,8 mL solução para injeção; carpule"
  },
  {
    "code" : "BR0358123",
    "display" : "Ranibizumabe 2,3 mg/2,3 mL suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "BR0358449",
    "display" : "Darifenacina 7,5 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0358450",
    "display" : "Darifenacina 15 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0358753",
    "display" : "Misoprostol 25 microgramas comprimido"
  },
  {
    "code" : "BR0358754",
    "display" : "Misoprostol 100 microgramas comprimido"
  },
  {
    "code" : "BR0358755",
    "display" : "Misoprostol 200 microgramas comprimido vaginal"
  },
  {
    "code" : "BR0359135",
    "display" : "Dasatinibe 20 mg comprimido"
  },
  {
    "code" : "BR0359136",
    "display" : "Dasatinibe 50 mg comprimido"
  },
  {
    "code" : "BR0359286",
    "display" : "Hedera helix 7 mg/mL xarope"
  },
  {
    "code" : "BR0359766",
    "display" : "Hialuronato de Sódio 40 mg/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0360824",
    "display" : "Paliperidona 3 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0360826",
    "display" : "Paliperidona 9 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0361174",
    "display" : "Lapatinibe 250 mg comprimido"
  },
  {
    "code" : "BR0361382",
    "display" : "Deferiprona 500 mg comprimido"
  },
  {
    "code" : "BR0361382E",
    "display" : "Deferiprona 500 mg comprimido"
  },
  {
    "code" : "BR0361791",
    "display" : "Diclofenaco Dietilamônio 11,6 mg/g gel"
  },
  {
    "code" : "BR0362057",
    "display" : "Rivastigmina 4,6 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "BR0362058",
    "display" : "Rivastigmina 9,5 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "BR0362059",
    "display" : "Rivastigmina 13,3 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "BR0362259",
    "display" : "Trazodona 100 mg comprimido"
  },
  {
    "code" : "BR0362260",
    "display" : "Trazodona 150 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0362266",
    "display" : "Aprepitanto 80 mg cápsula e Aprepitanto 125 mg cápsula"
  },
  {
    "code" : "BR0362661-1",
    "display" : "Clindamicina 20 mg/g (2%) creme"
  },
  {
    "code" : "BR0362661-2",
    "display" : "Clindamicina 20 mg/g (2%) creme"
  },
  {
    "code" : "BR0362718",
    "display" : "Bisoprolol 5 mg comprimido"
  },
  {
    "code" : "BR0362719",
    "display" : "Bisoprolol 1,25 mg comprimido"
  },
  {
    "code" : "BR0362720",
    "display" : "Bisoprolol 2,5 mg comprimido"
  },
  {
    "code" : "BR0362721",
    "display" : "Bisoprolol 10 mg comprimido"
  },
  {
    "code" : "BR0362802",
    "display" : "Vildagliptina 50 mg comprimido"
  },
  {
    "code" : "BR0363379",
    "display" : "Cloridrato de Quinina 100 mg + Papaverina 40 mg comprimido"
  },
  {
    "code" : "BR0363560",
    "display" : "Diclofenaco Sódico 50 mg + Tiamina 50 mg + Piridoxina 50 mg + Cianocobalamina 1 mg comprimido"
  },
  {
    "code" : "BR0363561",
    "display" : "Hidroxocobalamina 5 mg/1 mL solução para injeção; ampola e Dipirona 500 mg/1 mL + Dexametasona 1,5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0363597-1",
    "display" : "Permetrina 50 mg/mL loção"
  },
  {
    "code" : "BR0363597-2",
    "display" : "Permetrina 50 mg/mL loção"
  },
  {
    "code" : "BR0363778",
    "display" : "Flunitrazepam 2 mg comprimido"
  },
  {
    "code" : "BR0363843",
    "display" : "Atazanavir 300 mg cápsula"
  },
  {
    "code" : "BR0363933",
    "display" : "Maraviroque 150 mg comprimido"
  },
  {
    "code" : "BR0363934",
    "display" : "Maraviroque 300 mg comprimido"
  },
  {
    "code" : "BR0364037",
    "display" : "Rifampicina 150 mg + Isoniazida 75 mg + Pirazinamida 400 mg + Etambutol 275 mg comprimido"
  },
  {
    "code" : "BR0364324",
    "display" : "Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0364780",
    "display" : "Aripiprazol 10 mg comprimido"
  },
  {
    "code" : "BR0364781",
    "display" : "Aripiprazol 20 mg comprimido"
  },
  {
    "code" : "BR0364789",
    "display" : "Isotretinoína 0,5 mg/g gel"
  },
  {
    "code" : "BR0364816",
    "display" : "Lenalidomida 25 mg comprimido"
  },
  {
    "code" : "BR0364917",
    "display" : "Anlodipino 5 mg + Benazepril 20 mg cápsula"
  },
  {
    "code" : "BR0365047",
    "display" : "Lenalidomida 5 mg cápsula"
  },
  {
    "code" : "BR0365048",
    "display" : "Lenalidomida 10 mg comprimido"
  },
  {
    "code" : "BR0365441",
    "display" : "Oxibutinina 10 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0365451",
    "display" : "Abatacepte 250 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0365451E",
    "display" : "Abatacepte 250 mg pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0365454",
    "display" : "Sorbitol 714 mg/g + Laurilsulfato de Sódio 7,7 mg/g supositório"
  },
  {
    "code" : "BR0366861",
    "display" : "Peróxido de Benzoíla 50 mg/g gel"
  },
  {
    "code" : "BR0366861 -2",
    "display" : "Peróxido de Benzoíla 50 mg/g gel"
  },
  {
    "code" : "BR0366861-3",
    "display" : "Peróxido de Benzoíla 50 mg/g gel"
  },
  {
    "code" : "BR0366883",
    "display" : "Alisquireno 150 mg comprimido"
  },
  {
    "code" : "BR0366884",
    "display" : "Alisquireno 300 mg comprimido"
  },
  {
    "code" : "BR0366913",
    "display" : "Cloreto de Sódio 0,9% + Glicose 5% solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "BR0366914",
    "display" : "Nafazolina 0,12 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0367512",
    "display" : "Pirimetamina 5 mg/mL solução oral"
  },
  {
    "code" : "BR0367514",
    "display" : "Hidróxido de Alumínio 230 mg comprimido"
  },
  {
    "code" : "BR0367664",
    "display" : "Natalizumabe 300 mg/15 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0367692",
    "display" : "Ácido Nicotínico 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0367692E",
    "display" : "Ácido Nicotínico 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0367693",
    "display" : "Ácido Nicotínico 750 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0367693E",
    "display" : "Ácido Nicotínico 750 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0367699",
    "display" : "Hidroxiapatita 800 mg comprimido"
  },
  {
    "code" : "BR0367724",
    "display" : "Levodopa 150 + Carbidopa 37,5 mg + Entacapona 200 mg comprimido"
  },
  {
    "code" : "BR0367725",
    "display" : "Policresuleno 50 mg/g + Cinchocaína 10 mg/g pomada"
  },
  {
    "code" : "BR0367765",
    "display" : "Gelatina 3,5% solução para injeção 500 mL; bisnaga"
  },
  {
    "code" : "BR0367897",
    "display" : "Imunoglobulina humana 500 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0368168",
    "display" : "Fosfato Dissódico de Dexametasona 2 mg/1 mL + Acetato de Dexametasona 8 mg/1 mL suspensão para injeção; ampola"
  },
  {
    "code" : "BR0368612",
    "display" : "Nitazoxanida 500 mg comprimido"
  },
  {
    "code" : "BR0368640",
    "display" : "Nitazoxanida 20 mg/mL suspensão oral"
  },
  {
    "code" : "BR0368654",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0368694",
    "display" : "Eculizumabe 300 mg/30 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0368799",
    "display" : "Ubidecarenona 50 mg comprimido"
  },
  {
    "code" : "BR0368899",
    "display" : "Clindamicina 10 mg/mL (1%) + Peróxido de Benzoíla 50 mg/mL (5%) gel"
  },
  {
    "code" : "BR0368903",
    "display" : "Bisacodil 5 mg + Docusato de Sódio 60 mg comprimido"
  },
  {
    "code" : "BR0369106",
    "display" : "Vimpocetina 5 mg comprimido"
  },
  {
    "code" : "BR0369175E",
    "display" : "Mesalazina 10 mg/mL suspensão retal"
  },
  {
    "code" : "BR0369176",
    "display" : "Everolimo 0,5 mg comprimido"
  },
  {
    "code" : "BR0369176E",
    "display" : "Everolimo 0,5 mg comprimido"
  },
  {
    "code" : "BR0369178",
    "display" : "Everolimo 0,75 mg comprimido"
  },
  {
    "code" : "BR0369178E",
    "display" : "Everolimo 0,75 mg comprimido"
  },
  {
    "code" : "BR0369179",
    "display" : "Everolimo 1 mg comprimido"
  },
  {
    "code" : "BR0369179E",
    "display" : "Everolimo 1 mg comprimido"
  },
  {
    "code" : "BR0370117",
    "display" : "Etexilato de Dabigatrana 110 mg cápsula"
  },
  {
    "code" : "BR0370119",
    "display" : "Artesunato 25 mg + Mefloquina 55 mg comprimido"
  },
  {
    "code" : "BR0370119-1",
    "display" : "Artesunato 25 mg + Mefloquina 55 mg comprimido"
  },
  {
    "code" : "BR0370119-2",
    "display" : "Artesunato 25 mg + Mefloquina 55 mg comprimido"
  },
  {
    "code" : "BR0370120",
    "display" : "Artesunato 100 mg + Mefloquina 220 mg comprimido"
  },
  {
    "code" : "BR0370120-1",
    "display" : "Artesunato 100 mg + Mefloquina 220 mg comprimido"
  },
  {
    "code" : "BR0370120-2",
    "display" : "Artesunato 100 mg + Mefloquina 220 mg comprimido"
  },
  {
    "code" : "BR0370525",
    "display" : "Valsartana 160 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "BR0370560",
    "display" : "Alfa1antitripsina 1 g /50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0371273-1",
    "display" : "Cloreto de Sódio 9 mg/mL (0,9%) solução"
  },
  {
    "code" : "BR0371273-2",
    "display" : "Cloreto de Sódio 9 mg/mL (0,9%) solução"
  },
  {
    "code" : "BR0372204",
    "display" : "Dutasterida 0,5 mg comprimido"
  },
  {
    "code" : "BR0372335",
    "display" : "Metronidazol 100 mg/g gel vaginal"
  },
  {
    "code" : "BR0372372",
    "display" : "Gentamicina 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0373165",
    "display" : "Capreomicina 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0373415",
    "display" : "Daptomicina 500 mg pó para injeção; frasco-ampola"
  },
  {
    "code" : "BR0373792",
    "display" : "Ibuprofeno 400 mg + Arginina 370 mg granulado"
  },
  {
    "code" : "BR0373909-1",
    "display" : "Hipromelose 3 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0373909-2",
    "display" : "Hipromelose 3 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0373909-3",
    "display" : "Hipromelose 3 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0373909-4",
    "display" : "Hipromelose 0,2 mg/mL (0,02%) solução oftálmica"
  },
  {
    "code" : "BR0373910-1",
    "display" : "Hipromelose 2 mg/mL (0,2%) solução oftálmica"
  },
  {
    "code" : "BR0373910-2",
    "display" : "Hipromelose 2 mg/mL (0,2%) solução oftálmica"
  },
  {
    "code" : "BR0373910-3",
    "display" : "Hipromelose 2 mg/mL (0,2%) solução oftálmica"
  },
  {
    "code" : "BR0373949",
    "display" : "Pindolol 10 mg comprimido"
  },
  {
    "code" : "BR0374155",
    "display" : "Rifampicina 150 mg + Isoniazida 75 mg comprimido"
  },
  {
    "code" : "BR0374313",
    "display" : "Ácido Paraminossalicílico 4 g granulado"
  },
  {
    "code" : "BR0374816",
    "display" : "Cipionato de Testosterona 200 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0374967",
    "display" : "Nilotinibe 200 mg cápsula"
  },
  {
    "code" : "BR0375387-1",
    "display" : "Polietilenoglicol (400) 3 mg/mL + Propilenoglicol 4 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0375387-2",
    "display" : "Polietilenoglicol (400) 3 mg/mL + Propilenoglicol 4 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0375387-3",
    "display" : "Polietilenoglicol (400) 3 mg/mL + Propilenoglicol 4 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0375474-1",
    "display" : "Cloreto de Sódio 9 mg/mL (0,9%) solução nasal"
  },
  {
    "code" : "BR0375474-2",
    "display" : "Cloreto de Sódio 9 mg/mL (0,9%) solução nasal"
  },
  {
    "code" : "BR0375474-3",
    "display" : "Cloreto de Sódio 9 mg/mL (0,9%) solução nasal"
  },
  {
    "code" : "BR0376105",
    "display" : "Nicotina 7 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "BR0376106",
    "display" : "Nicotina 14 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "BR0376107",
    "display" : "Nicotina 21 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "BR0376357",
    "display" : "Valsartana 40 mg comprimido"
  },
  {
    "code" : "BR0376502",
    "display" : "Ranelato de Estrôncio 2 g granulado"
  },
  {
    "code" : "BR0376502-1",
    "display" : "Ranelato de Estrôncio 2 g granulado"
  },
  {
    "code" : "BR0376695",
    "display" : "Piridoxina 50 mg comprimido"
  },
  {
    "code" : "BR0377008",
    "display" : "Zanamivir 5 mg/dose pó para inalação; inalador"
  },
  {
    "code" : "BR0377422",
    "display" : "Ácido Fusídico 20 mg/g + Valerato de Betametasona 1 mg/g creme"
  },
  {
    "code" : "BR0377899",
    "display" : "Valeriana officinalis 50 mg cápsula"
  },
  {
    "code" : "BR0378055",
    "display" : "Fosfomicina 3 g granulado"
  },
  {
    "code" : "BR0379002",
    "display" : "Anidulafungina 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0379469-1",
    "display" : "Hidrato de Cloral 100 mg/mL (10%) solução oral"
  },
  {
    "code" : "BR0379469-2",
    "display" : "Hidrato de Cloral 100 mg/mL (10%) solução oral"
  },
  {
    "code" : "BR0379902",
    "display" : "Oseltamivir 30 mg cápsula"
  },
  {
    "code" : "BR0379962",
    "display" : "Oseltamivir 45 mg cápsula"
  },
  {
    "code" : "BR0380017",
    "display" : "Insulina Glulisina 100 unidades internacionais/mL solução para injeção 3 mL; carpule"
  },
  {
    "code" : "BR0380419",
    "display" : "Bimatoprosta 0,3 mg/mL + Timolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0380545",
    "display" : "Lopinavir 100 mg + Ritonavir 25 mg comprimido"
  },
  {
    "code" : "BR0380823",
    "display" : "Paliperidona 6 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0380855",
    "display" : "Diclofenaco Dietilamônio 11,6 mg/g solução aerossol"
  },
  {
    "code" : "BR0380865",
    "display" : "Polimixina B 10.000 unidades internacionais/mL + Neomicina 3,5 mg/mL + Fluocinolona 0,25 mg/mL + Lidocaína 20 mg/mL solução otológica"
  },
  {
    "code" : "BR0381063",
    "display" : "Sitagliptina 50 mg + Metformina 500 mg comprimido"
  },
  {
    "code" : "BR0381066",
    "display" : "Anlodipino 5 mg + Ramipril 10 mg cápsula"
  },
  {
    "code" : "BR0381073",
    "display" : "Mercaptamina 150 mg comprimido"
  },
  {
    "code" : "BR0381288",
    "display" : "Rifabutina 150 mg cápsula"
  },
  {
    "code" : "BR0381879",
    "display" : "Omeprazol 10 mg comprimido gastrorresistente"
  },
  {
    "code" : "BR0381880",
    "display" : "Omeprazol 20 mg comprimido gastrorresistente"
  },
  {
    "code" : "BR0381881",
    "display" : "Omeprazol 40 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0382197",
    "display" : "Trimetazidina 35 mg comprimido"
  },
  {
    "code" : "BR0382563",
    "display" : "Cloreto de Sódio 10% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0382939",
    "display" : "Decitabina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0383272",
    "display" : "Imiglucerase 400 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0383272E",
    "display" : "Imiglucerase 400 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0383409",
    "display" : "Carmelose Sódica 5 mg/mL (0,5%) + Glicerol 9 mg/mL (0,9%) solução oftálmica"
  },
  {
    "code" : "BR0383409-3",
    "display" : "Carmelose Sódica 5 mg/mL (0,5%) + Glicerol 9 mg/mL (0,9%) solução oftálmica"
  },
  {
    "code" : "BR0383417",
    "display" : "Ciclesonida 160 microgramas solução para inalação"
  },
  {
    "code" : "BR0383436",
    "display" : "Azacitidina 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0383485",
    "display" : "Tenecteplase 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0383660",
    "display" : "Brometo de Tiotrópio 2,5 microgramas/dose solução para inalação; inalador"
  },
  {
    "code" : "BR0383688",
    "display" : "Insulina Asparte bifásica (30/70) 100 unidades/mL suspensão para injeção 3 mL; carpule"
  },
  {
    "code" : "BR0383688-1",
    "display" : "Insulina Asparte bifásica (30/70) 100 unidades/mL suspensão para injeção 3 mL; dispositivo para injeção"
  },
  {
    "code" : "BR0383786",
    "display" : "Vinorelbina 10 mg/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0383786-1",
    "display" : "Vinorelbina 50 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0383788",
    "display" : "Vinorelbina 20 mg cápsula"
  },
  {
    "code" : "BR0383790",
    "display" : "Vinorelbina 30 mg cápsula"
  },
  {
    "code" : "BR0383791",
    "display" : "Ácido Alendrônico 70 mg + Colecalciferol 2.800 unidades internacionais comprimido"
  },
  {
    "code" : "BR0384297",
    "display" : "Mercaptamina 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0384298",
    "display" : "Hidrocortisona 10 mg comprimido"
  },
  {
    "code" : "BR0384467",
    "display" : "Nepafenaco 1 mg/mL suspensão oftálmica"
  },
  {
    "code" : "BR0384537",
    "display" : "Peróxido de Benzoíla 25 mg/g gel"
  },
  {
    "code" : "BR0384537-2",
    "display" : "Peróxido de Benzoíla 25 mg/g gel"
  },
  {
    "code" : "BR0384830",
    "display" : "Ácido Tranexâmico 500 mg comprimido"
  },
  {
    "code" : "BR0384894",
    "display" : "Propafenona 150 mg comprimido"
  },
  {
    "code" : "BR0385153",
    "display" : "Trometamol Cetorolaco 10 mg comprimido sublingual"
  },
  {
    "code" : "BR0385435",
    "display" : "Betametasona 0,5 mg comprimido"
  },
  {
    "code" : "BR0385436",
    "display" : "Betametasona 2 mg comprimido"
  },
  {
    "code" : "BR0385446",
    "display" : "Betametasona 0,5 mg/mL solução oral"
  },
  {
    "code" : "BR0385450",
    "display" : "Hidroquinona 40 mg/g gel"
  },
  {
    "code" : "BR0386026",
    "display" : "Ácido Folínico 0,5 mg/mL solução oral"
  },
  {
    "code" : "BR0386041",
    "display" : "Hidroxicloroquina 200 mg comprimido"
  },
  {
    "code" : "BR0386396",
    "display" : "Amoxicilina 80 mg/mL + Ácido Clavulânico 11,4 mg/mL suspensão oral"
  },
  {
    "code" : "BR0386482",
    "display" : "Fosfato de Cálcio Tribásico 1.661 g (Cálcio 600 mg) + Colecalciferol 400 unidades internacionais comprimido"
  },
  {
    "code" : "BR0386846",
    "display" : "Policarbofila 500 mg comprimido"
  },
  {
    "code" : "BR0386959",
    "display" : "Paracetamol 32 mg/mL suspensão oral"
  },
  {
    "code" : "BR038719",
    "display" : "Acitretina 10 mg cápsula"
  },
  {
    "code" : "BR0387341",
    "display" : "Formoterol 6 microgramas + Budesonida 200 microgramas cápsula para inalação"
  },
  {
    "code" : "BR0387341E",
    "display" : "Formoterol 6 microgramas + Budesonida 200 microgramas cápsula para inalação"
  },
  {
    "code" : "BR0387438",
    "display" : "Cafeína 5 mg/mL xarope"
  },
  {
    "code" : "BR0387628",
    "display" : "Arginina 250 mg comprimido"
  },
  {
    "code" : "BR0387981",
    "display" : "Risperidona 25 mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0387982",
    "display" : "Risperidona 37,5 mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0387983",
    "display" : "Risperidona 50 mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0387985",
    "display" : "Zuclopentixol 25 mg comprimido"
  },
  {
    "code" : "BR0388383-1",
    "display" : "Tocilizumabe 80 mg/4 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0388383-2",
    "display" : "Tocilizumabe 200 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0388383E",
    "display" : "Tocilizumabe 80 mg/4 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0388387",
    "display" : "Levodopa 50 + Carbidopa 12,5 mg + Entacapona 200 mg comprimido"
  },
  {
    "code" : "BR0388392",
    "display" : "Rosuvastatina 40 mg comprimido"
  },
  {
    "code" : "BR0388399",
    "display" : "Olmesartana Medoxomila 20 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "BR0388401",
    "display" : "Olmesartana Medoxomila 40 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "BR0388402",
    "display" : "Olmesartana Medoxomila 40 mg + Anlodipino 10 mg comprimido"
  },
  {
    "code" : "BR0388403",
    "display" : "Glimepirida 3 mg comprimido"
  },
  {
    "code" : "BR0388555",
    "display" : "Aspartato de Ornitina 5 g/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0388556",
    "display" : "Ornitina 3 g granulado"
  },
  {
    "code" : "BR0388569",
    "display" : "Ácido Ibandrônico 150 mg comprimido"
  },
  {
    "code" : "BR0388712",
    "display" : "Pregabalina 75 mg cápsula"
  },
  {
    "code" : "BR0388796",
    "display" : "Metformina 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0388797",
    "display" : "Metformina 750 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0388866",
    "display" : "Alentuzumabe 30 mg/ 1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0389398",
    "display" : "Trióxido de Arsênio 10 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0389480",
    "display" : "Tobramicina 60 mg/mL solução para inalação 5 mL; ampola"
  },
  {
    "code" : "BR0389637-1",
    "display" : "Fexofenadina 6 mg/mL solução oral"
  },
  {
    "code" : "BR0389637-2",
    "display" : "Fexofenadina 6 mg/mL suspensão oral"
  },
  {
    "code" : "BR0389710",
    "display" : "Adapaleno 3 mg/g gel"
  },
  {
    "code" : "BR0389802",
    "display" : "Gestodeno 0,06 mg + Etinilestradiol 0,015 mg comprimido"
  },
  {
    "code" : "BR0389863",
    "display" : "Sugamadex 200 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0389863-1",
    "display" : "Sugamadex 500 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0389957-1",
    "display" : "Dipirona 300 mg + Escopolamina 6,5 microgramas + Hiosciamina 104 microgramas + Homatropina 1 mg comprimido"
  },
  {
    "code" : "BR0389957-2",
    "display" : "Dipirona 300 mg/mL + Escopolamina 6,5 microgramas/mL + Hiosciamina 104 microgramas/mL + Homatropina 1 mg/mL solução oral"
  },
  {
    "code" : "BR0390005",
    "display" : "Quetiapina 50 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0390006",
    "display" : "Quetiapina 300 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0390006E",
    "display" : "Quetiapina 300 mg comprimido"
  },
  {
    "code" : "BR0390007",
    "display" : "Quetiapina 200 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0390008-1",
    "display" : "Cetuximabe 50 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0390008-2",
    "display" : "Cetuximabe 100 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0390008-4",
    "display" : "Cetuximabe 500 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0390333",
    "display" : "Tipranavir 100 mg/mL solução oral"
  },
  {
    "code" : "BR0390354",
    "display" : "Fosamprenavir 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0390440-1",
    "display" : "Exenatida 300 microgramas/1,2 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "BR0390440-2",
    "display" : "Exenatida 600 microgramas/2,4 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "BR0390441-1",
    "display" : "Carbômer 3 mg/g (0,3%) gel oftálmico"
  },
  {
    "code" : "BR0390441-2",
    "display" : "Carbômer 3 mg/g (0,3%) gel oftálmico"
  },
  {
    "code" : "BR0390598-1",
    "display" : "Fator VIII (Recombinante) 250 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0390598-2",
    "display" : "Fator VIII (Recombinante) 500 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0390598-3",
    "display" : "Fator VIII (Recombinante) 1.000 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0390643",
    "display" : "Tensirolimo 30 mg/1,2 mL solução e diluente para injeção; frasco-ampola"
  },
  {
    "code" : "BR0391324",
    "display" : "Hidroquinona 40 mg/g + Tretinoína 0,5 mg/g + Fluocinolona Acetonida 0,1 mg/g creme"
  },
  {
    "code" : "BR0391336",
    "display" : "Alfataliglicerase 200 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0391336E",
    "display" : "Alfataliglicerase 200 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0391938",
    "display" : "Colecalciferol 3.300 unidades internacionais/mL solução oral"
  },
  {
    "code" : "BR0392111",
    "display" : "Pregabalina 150 mg cápsula"
  },
  {
    "code" : "BR0392113",
    "display" : "Risperidona 0,25 mg comprimido"
  },
  {
    "code" : "BR0392113/00111",
    "display" : "Risperidona 0,25 mg comprimido"
  },
  {
    "code" : "BR0392114",
    "display" : "Risperidona 0,5 mg comprimido"
  },
  {
    "code" : "BR0392118-1",
    "display" : "Simeticona 75 mg/mL suspensão oral"
  },
  {
    "code" : "BR0392118-2",
    "display" : "Simeticona 75 mg/mL suspensão oral"
  },
  {
    "code" : "BR0392118-3",
    "display" : "Simeticona 75 mg/mL suspensão oral"
  },
  {
    "code" : "BR0392118-4",
    "display" : "Simeticona 75 mg/mL suspensão oral"
  },
  {
    "code" : "BR0392264",
    "display" : "Carbamazepina 20 mg/mL xarope"
  },
  {
    "code" : "BR0392403",
    "display" : "Brimonidina 1 mg/mL (0,1%) solução oftálmica"
  },
  {
    "code" : "BR0392423",
    "display" : "Dexpantenol 50 mg/g pomada"
  },
  {
    "code" : "BR0392593",
    "display" : "Hidróxido de Alumínio 178 mg + Hidróxido de Magnésio 185 mg + Carbonato de Cálcio 231,5 mg pastilha"
  },
  {
    "code" : "BR0392617",
    "display" : "Tianfenicol 500 mg comprimido"
  },
  {
    "code" : "BR0392662",
    "display" : "Cetoprofeno 160 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0392663",
    "display" : "Cetoprofeno 320 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0392708",
    "display" : "Sitagliptina 50 mg + Metformina 850 mg comprimido"
  },
  {
    "code" : "BR0392714",
    "display" : "Óxido de Zinco 200 mg/g creme"
  },
  {
    "code" : "BR0392760",
    "display" : "Propionato de Fluticasona 250 microgramas/dose suspensão aerossol; inalador"
  },
  {
    "code" : "BR0392762",
    "display" : "Propionato de Fluticasona 250 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "BR0393034",
    "display" : "Saxagliptina 5 mg comprimido"
  },
  {
    "code" : "BR0393138",
    "display" : "Everolimo 5 mg comprimido"
  },
  {
    "code" : "BR0393139",
    "display" : "Everolimo 10 mg comprimido"
  },
  {
    "code" : "BR0393161",
    "display" : "Levotiroxina Sódica 38 microgramas comprimido"
  },
  {
    "code" : "BR0393327",
    "display" : "Ciprofloxacino 2 mg/mL + Hidrocortisona 10 mg/mL suspensão otológica"
  },
  {
    "code" : "BR0393328",
    "display" : "Cloreto de Potássio 60 mg/mL xarope"
  },
  {
    "code" : "BR0393331",
    "display" : "Desogestrel 0,15 mg + Etinilestradiol 0,03 mg comprimido"
  },
  {
    "code" : "BR0393342-1",
    "display" : "Pelargonium sidoides 825 mg/mL solução oral"
  },
  {
    "code" : "BR0393342-2",
    "display" : "Pelargonium sidoides 825 mg/mL solução oral"
  },
  {
    "code" : "BR0393493",
    "display" : "Acetilcisteína 10 mg/mL + Tuaminoeptano 5 mg/mL solução nasal"
  },
  {
    "code" : "BR0393565",
    "display" : "Furazolidona 200 mg comprimido"
  },
  {
    "code" : "BR0393729",
    "display" : "Oxicodona 10 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0393730",
    "display" : "Oxicodona 20 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0393731",
    "display" : "Oxicodona 40 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0393740",
    "display" : "Levonorgestrel 0,1 mg + Etinilestradiol 0,02 mg comprimido"
  },
  {
    "code" : "BR0393779",
    "display" : "Darunavir 75 mg comprimido"
  },
  {
    "code" : "BR0393780",
    "display" : "Darunavir 600 mg comprimido"
  },
  {
    "code" : "BR0393781",
    "display" : "Darunavir 150 mg comprimido"
  },
  {
    "code" : "BR0393803",
    "display" : "Ácido Fólico 5 mg/mL solução oral"
  },
  {
    "code" : "BR0393808",
    "display" : "Valsartana 160 mg + Anlodipino 10 mg comprimido"
  },
  {
    "code" : "BR0393831",
    "display" : "Ciclobenzaprina 5 mg + Clonixinato de Lisina 125 mg comprimido"
  },
  {
    "code" : "BR0393886",
    "display" : "Enfuvirtida 108 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0393920",
    "display" : "Etonogestrel 68 mg implante; dispositivo"
  },
  {
    "code" : "BR0393953",
    "display" : "Temozolomida 140 mg cápsula"
  },
  {
    "code" : "BR0393999",
    "display" : "Benzoato de Sódio 100 mg/mL solução oral"
  },
  {
    "code" : "BR0394026",
    "display" : "Levobupivacaína 50 mg/20 mL (0,25%) + Epinefrina 100 microgramas/20 mL (1:200.000) solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0394103",
    "display" : "Rivaroxabana 10 mg comprimido"
  },
  {
    "code" : "BR0394258",
    "display" : "Ferripolimaltose 50 mg/mL solução oral"
  },
  {
    "code" : "BR0394263-1",
    "display" : "Hidroxizina 2 mg/mL xarope"
  },
  {
    "code" : "BR0394263-2",
    "display" : "Hidroxizina 2 mg/mL solução oral"
  },
  {
    "code" : "BR0394310",
    "display" : "Betainterferona 1a 6.000.000 unidades internacionais (22 microgramas)/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0394311",
    "display" : "Betainterferona 1a 12.000.000 unidades internacionais (44 microgramas)/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0394314",
    "display" : "Betainterferona 1a 6.000.000 unidades internacionais (30 microgramas) solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0394650",
    "display" : "Metoprolol 100 mg comprimido"
  },
  {
    "code" : "BR0394662",
    "display" : "Neomicina 5 mg/g pomada"
  },
  {
    "code" : "BR0394667",
    "display" : "Nifedipino 60 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0394675-1",
    "display" : "Cloreto de Sódio 6,371 mg/mL + Acetato de Sódio 3,95 mg/mL + Cloreto de Potássio 0,746 mg/mL + Cloreto de Cálcio 0,515 mg/mL + Cloreto de Magnésio 0,305 mg/mL + Citrato de Sódio 1,67 mg/mL solução oftálmica 250 mL; bolsa"
  },
  {
    "code" : "BR0394675-2",
    "display" : "Cloreto de Sódio 6,371 mg/mL + Acetato de Sódio 3,95 mg/mL + Cloreto de Potássio 0,746 mg/mL + Cloreto de Cálcio 0,515 mg/mL + Cloreto de Magnésio 0,305 mg/mL + Citrato de Sódio 1,67 mg/mL solução oftálmica 500 mL; bolsa"
  },
  {
    "code" : "BR0394677E",
    "display" : "Alfavelaglicerase 200 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0394678E",
    "display" : "Alfavelaglicerase 400 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0394681",
    "display" : "Fibrinogênio 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0394754",
    "display" : "Hipromelose 3,2 mg/mL + Cetrimida 0,1 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0394789",
    "display" : "Itraconazol 10 mg/mL suspensão oral"
  },
  {
    "code" : "BR0394789-1",
    "display" : "Itraconazol 10 mg/mL suspensão oral"
  },
  {
    "code" : "BR0394804",
    "display" : "Paclitaxel 100 mg/16,7 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0394804-4",
    "display" : "Paclitaxel 300 mg/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0394865",
    "display" : "Ácido Tióctico 600 mg comprimido"
  },
  {
    "code" : "BR0394910",
    "display" : "Cloreto de Sódio 4,5 mg/g gel"
  },
  {
    "code" : "BR0394910-1",
    "display" : "Cloreto de Sódio 4,5 mg/g gel"
  },
  {
    "code" : "BR0394915",
    "display" : "Anlodipino 2,5 mg + Benazepril 10 mg cápsula"
  },
  {
    "code" : "BR0394916",
    "display" : "Anlodipino 5 mg + Benazepril 10 mg cápsula"
  },
  {
    "code" : "BR0395144",
    "display" : "Flufenazina 5 mg comprimido"
  },
  {
    "code" : "BR0395146",
    "display" : "Cobamamida 5 mg comprimido mastigável"
  },
  {
    "code" : "BR0395147",
    "display" : "Diazepam 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0395156",
    "display" : "Pimetixeno 0,1 mg/mL xarope"
  },
  {
    "code" : "BR0395161",
    "display" : "Piribedil 50 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0395162",
    "display" : "Valsartana 320 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "BR0395437",
    "display" : "Vildagliptina 50 mg + Metformina 1 g comprimido"
  },
  {
    "code" : "BR0395438",
    "display" : "Nafazolina 1 mg/mL + Mepiramina 0,2 mg/mL + Dexpantenol 5 mg/mL solução nasal"
  },
  {
    "code" : "BR0395438-1",
    "display" : "Nafazolina 1 mg/mL + Mepiramina 0,2 mg/mL + Dexpantenol 5 mg/mL solução nasal"
  },
  {
    "code" : "BR0395439",
    "display" : "Furoato de Fluticasona 27,5 microgramas/dose suspensão spray"
  },
  {
    "code" : "BR0395465",
    "display" : "Ácido Nicotínico 1 g comprimido de liberação prolongada"
  },
  {
    "code" : "BR0395517",
    "display" : "Canaquinumabe 150 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0395518",
    "display" : "Paracetamol 500 mg + Codeína 15 mg cápsula"
  },
  {
    "code" : "BR0395519",
    "display" : "Ibuprofeno 400 mg + Paracetamol 400 mg + Carisoprodol 200 mg + Piridoxina 50 mg  cápsula"
  },
  {
    "code" : "BR0395520",
    "display" : "Aspartato de Magnésio 50 mg + Carbonato de Cálcio 1,25 g (Cálcio 500 mg) + Ranitidina 150 mg + Colecalciferol 400 unidades internacionais cápsula"
  },
  {
    "code" : "BR0395558",
    "display" : "Ácido Salicílico 5% pomada"
  },
  {
    "code" : "BR0395601",
    "display" : "Ácido Nicotínico 250 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0395601E",
    "display" : "Ácido Nicotínico 250 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0395602",
    "display" : "Ácido Gamaminobutírico 100 mg/mL + Lisina 100 mg/mL + Tiamina 4 mg/mL + Piridoxina 8 mg/mL + Cálcio 8 mg/mL xarope"
  },
  {
    "code" : "BR0395608",
    "display" : "Brometo de Pinavério 50 mg comprimido"
  },
  {
    "code" : "BR0395609",
    "display" : "Ácido Ascórbico 1 g + Citrato de Zinco 10 mg comprimido efervescente"
  },
  {
    "code" : "BR0395616",
    "display" : "Mometasona 400 microgramas cápsula para inalação"
  },
  {
    "code" : "BR0395620",
    "display" : "Glycine max (Isoflavona de Soja) 150 mg cápsula"
  },
  {
    "code" : "BR0395627",
    "display" : "Polimixina B 10.000 unidades internacionais/mL + Neomicina 10 mg/mL + Fludrocortisona 1 mg/mL + Lidocaína 40 mg/mL solução otológica"
  },
  {
    "code" : "BR0395716",
    "display" : "Schinus terebenthifolius 0,67 mL/g creme"
  },
  {
    "code" : "BR0395716-1",
    "display" : "Schinus terebenthifolius 0,67 mL/g creme"
  },
  {
    "code" : "BR0395716-2",
    "display" : "Schinus terebenthifolius 0,67 mL/g creme"
  },
  {
    "code" : "BR0395718",
    "display" : "Sildenafila 12,5 mg cápsula"
  },
  {
    "code" : "BR0395719",
    "display" : "Fluoxetina 60 mg cápsula"
  },
  {
    "code" : "BR0395720",
    "display" : "Carnitina 1 g cápsula"
  },
  {
    "code" : "BR0395726-1",
    "display" : "Oxomemazina 0,332 mg/mL + Guaifenesina 6,66 mg/mL + Benzoato de Sódio 6,66 mg/mL + Paracetamol 6,66 mg/mL xarope"
  },
  {
    "code" : "BR0395726-2",
    "display" : "Oxomemazina 0,332 mg/mL + Guaifenesina 6,66 mg/mL + Benzoato de Sódio 6,66 mg/mL + Paracetamol 6,66 mg/mL xarope"
  },
  {
    "code" : "BR0395730-1",
    "display" : "Hidróxido de Alumínio 60 mg/mL + Hidróxido de Magnésio 40 mg/mL suspensão oral"
  },
  {
    "code" : "BR0395730-2",
    "display" : "Hidróxido de Alumínio 60 mg/mL + Hidróxido de Magnésio 40 mg/mL suspensão oral"
  },
  {
    "code" : "BR0395730-3",
    "display" : "Hidróxido de Alumínio 60 mg/mL + Hidróxido de Magnésio 40 mg/mL suspensão oral"
  },
  {
    "code" : "BR0395797",
    "display" : "Levonorgestrel 0,05 mg + Etinilestradiol 0,03 mg comprimido e Levonorgestrel 0,075 mg + Etinilestradiol 0,04 mg comprimido e Levonorgestrel 0,125 mg + Etinilestradiol 0,03 mg comprimido"
  },
  {
    "code" : "BR0395807",
    "display" : "Brinzolamida 10 mg/mL + Timolol 5 mg/mL suspensão oftálmica"
  },
  {
    "code" : "BR0395836",
    "display" : "Metronidazol 250 mg/g + Nistatina 100.000 unidades internacionais/g + Cloreto de Benzalcônio 1,25 mg/g creme vaginal"
  },
  {
    "code" : "BR0395837",
    "display" : "Alcatrão Mineral 1% pomada"
  },
  {
    "code" : "BR0395844",
    "display" : "Glimepirida 2 mg + Metformina 1 g comprimido"
  },
  {
    "code" : "BR0395845",
    "display" : "Ureia 50 mg/g (5%) creme"
  },
  {
    "code" : "BR0395885",
    "display" : "Triclosana 1% sabonete"
  },
  {
    "code" : "BR0395886",
    "display" : "Triclosana 1% sabonete"
  },
  {
    "code" : "BR0395908",
    "display" : "Anlodipino 5 mg + Losartana 50 mg comprimido"
  },
  {
    "code" : "BR0395910",
    "display" : "Valsartana 320 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0395947",
    "display" : "Ácido Cítrico 70 mg/mL + Citrato de Sódio 98 mg/mL + Citrato de Potássio 108 mg/mL xarope"
  },
  {
    "code" : "BR0395949",
    "display" : "Risedronato Sódico 150 mg comprimido"
  },
  {
    "code" : "BR0395950",
    "display" : "Desvenlafaxina 50 mg comprimido"
  },
  {
    "code" : "BR0395952",
    "display" : "Lactase 3.000 unidades internacionais cápsula"
  },
  {
    "code" : "BR0396029",
    "display" : "Valerato de Betametasona 2,5 mg/g + Hialuronidase 150 UTR/g pomada"
  },
  {
    "code" : "BR0396047",
    "display" : "Prometazina 0,565 mg/mL + Sulfoguaiacol de Potássio 9 mg/mL xarope"
  },
  {
    "code" : "BR0396051",
    "display" : "Insulina Asparte 100 unidades/mL solução para injeção 3 mL; dispositivo para injeção"
  },
  {
    "code" : "BR0396081",
    "display" : "Amissulprida 50 mg comprimido"
  },
  {
    "code" : "BR0396086",
    "display" : "Sapropterina 100 mg comprimido"
  },
  {
    "code" : "BR0396087",
    "display" : "Aminaftona 75 mg comprimido"
  },
  {
    "code" : "BR0396379",
    "display" : "Prednisolona 11 mg/mL solução oral"
  },
  {
    "code" : "BR0396555",
    "display" : "Betametasona 0,1 mg/ mL elixir"
  },
  {
    "code" : "BR0396557",
    "display" : "Valsartana 160 mg + Hidroclorotiazida 12,5 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "BR0396558",
    "display" : "Valsartana 160 mg + Hidroclorotiazida 25 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "BR0396559",
    "display" : "Valsartana 160 mg + Hidroclorotiazida 25 mg + Anlodipino 10 mg comprimido"
  },
  {
    "code" : "BR0396561",
    "display" : "Hidromorfona 16 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0396604",
    "display" : "Biperideno 5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0396668",
    "display" : "Mesilato de Codergocrina 6 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0396702",
    "display" : "Nebivolol 5 mg comprimido"
  },
  {
    "code" : "BR0396703",
    "display" : "Nimesulida Betaciclodextrina 400 mg comprimido"
  },
  {
    "code" : "BR0396853-1",
    "display" : "Fenilefrina 1 mg/mL + Tetracaína 10 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0396853-2",
    "display" : "Fenilefrina 1 mg/mL + Tetracaína 10 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0396947",
    "display" : "Sulfato Ferroso 50 mg/mL (Ferro 10 mg/mL) xarope"
  },
  {
    "code" : "BR0397074",
    "display" : "Lidocaína 21 mg/mL + Cloreto de Benzetônio 1,33 mg/mL solução spray"
  },
  {
    "code" : "BR0397333",
    "display" : "Brometo de Otilônio 40 mg comprimido"
  },
  {
    "code" : "BR0397434",
    "display" : "Formoterol 12 microgramas + Budesonida 200 microgramas cápsula para inalação"
  },
  {
    "code" : "BR0397438",
    "display" : "Glimepirida 6 mg comprimido"
  },
  {
    "code" : "BR0397450",
    "display" : "Modafinila 100 mg comprimido"
  },
  {
    "code" : "BR0397451",
    "display" : "Modafinila 200 mg comprimido"
  },
  {
    "code" : "BR0397462-1",
    "display" : "Carbômer 2 mg/g + Sorbitol 48,5 mg/g gel oftálmico"
  },
  {
    "code" : "BR0397462-2",
    "display" : "Carbômer 2 mg/g + Sorbitol 48,5 mg/g gel oftálmico"
  },
  {
    "code" : "BR0397475",
    "display" : "Betametildigoxina 0,1 mg comprimido"
  },
  {
    "code" : "BR0397542",
    "display" : "Alfafolitropina 300 unidades internacionais (22 microgramas)/0,5 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "BR0397543",
    "display" : "Alfafolitropina 450 unidades internacionais (33 microgramas)/0,75 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "BR0397544",
    "display" : "Alfafolitropina 900 unidades internacionais (66 microgramas)/1,5 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "BR0397549",
    "display" : "Menotropina 75 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0397566",
    "display" : "Cefalexina 100 mg/mL suspensão oral"
  },
  {
    "code" : "BR0397600",
    "display" : "Sitagliptina 50 mg + Metformina 1 g comprimido"
  },
  {
    "code" : "BR0397872",
    "display" : "Hidróxido de Magnésio 85,5 mg/mL suspensão oftálmica"
  },
  {
    "code" : "BR0397910",
    "display" : "Queratina 20 mg + Cistina 20 mg + Ácido paraminobenzóico 20 mg + Levedura 100 mg + Tiamina 60 mg + Pantotenato de Cálcio 60 mg cápsula"
  },
  {
    "code" : "BR0397912",
    "display" : "Agomelatina 25 mg comprimido"
  },
  {
    "code" : "BR0398187",
    "display" : "Retinol 3.000 unidades internacionais/mL + Colecalciferol 800 unidades internacionais/mL solução oral"
  },
  {
    "code" : "BR0398268",
    "display" : "Valsartana 320 mg + Anlodipino 10 mg comprimido"
  },
  {
    "code" : "BR0398269",
    "display" : "Anfepramona 75 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0398382",
    "display" : "Ciclesonida 50 microgramas suspensão nasal"
  },
  {
    "code" : "BR0398382-1",
    "display" : "Ciclesonida 50 microgramas suspensão nasal"
  },
  {
    "code" : "BR0398689",
    "display" : "Levodopa 100 mg + Benserazida 25 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0398702U0005",
    "display" : "Medroxiprogesterona 150 mg/1 mL suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "BR0398707",
    "display" : "Bleomicina 15 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0398711",
    "display" : "Propionato de Fluticasona 125 microgramas/dose + Salmeterol 25 microgramas/dose suspensão aerossol; inalador"
  },
  {
    "code" : "BR0398939",
    "display" : "Ácido Ibandrônico 3 mg/3 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0399010",
    "display" : "Insulina Glargina 100 unidades/mL solução para injeção 3 mL; dispositivo para injeção"
  },
  {
    "code" : "BR0399052",
    "display" : "Carbonato de Magnésio 67 mg + Carbonato de Bismuto 3,3 mg + Carbonato de Cálcio 521 mg + Bicarbonato de Sódio 63,7 mg pastilha"
  },
  {
    "code" : "BR0399065",
    "display" : "Triexifenidil 2 mg comprimido"
  },
  {
    "code" : "BR0399161",
    "display" : "Clemastina 1 mg/g + Dexametasona 0,5 mg/g creme"
  },
  {
    "code" : "BR0399441",
    "display" : "Uncaria tomentosa 50 mg/g (5%) gel"
  },
  {
    "code" : "BR0399597",
    "display" : "Diazóxido 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0399799",
    "display" : "Sultiamo 50 mg comprimido"
  },
  {
    "code" : "BR0399988",
    "display" : "Ferripolimaltose 100 mg + Ácido Fólico 0,35 mg comprimido mastigável"
  },
  {
    "code" : "BR0399995",
    "display" : "Posaconazol 40 mg/mL suspensão oral"
  },
  {
    "code" : "BR0399996",
    "display" : "Pazopanibe 400 mg comprimido"
  },
  {
    "code" : "BR0399997",
    "display" : "Pazopanibe 200 mg comprimido"
  },
  {
    "code" : "BR0400002",
    "display" : "Cabazitaxel 60 mg/1,5 mL solução e diluente para injeção; frasco-ampola"
  },
  {
    "code" : "BR0400091",
    "display" : "Anlodipino 5 mg + Atorvastatina 10 mg comprimido"
  },
  {
    "code" : "BR0400390",
    "display" : "Buclizina 25 mg comprimido"
  },
  {
    "code" : "BR0400436",
    "display" : "Valproato de sódio 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0400470",
    "display" : "Lisado bacteriano de Escherichia coli 6 mg cápsula"
  },
  {
    "code" : "BR0400471",
    "display" : "Lisados bacterianos 7 mg cápsula"
  },
  {
    "code" : "BR0400476",
    "display" : "Paricalcitol 5 microgramas/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0400480",
    "display" : "Estradiol 1 mg + Drospirenona 2 mg comprimido"
  },
  {
    "code" : "BR0400486",
    "display" : "Bortezomibe 1 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0400563",
    "display" : "Ustequinumabe 45 mg/0,5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0400564-1",
    "display" : "Arteméter 20 mg + Lumefantrina 120 mg comprimido"
  },
  {
    "code" : "BR0400564-2",
    "display" : "Arteméter 20 mg + Lumefantrina 120 mg comprimido"
  },
  {
    "code" : "BR0400564-3",
    "display" : "Arteméter 20 mg + Lumefantrina 120 mg comprimido"
  },
  {
    "code" : "BR0400564-4",
    "display" : "Arteméter 20 mg + Lumefantrina 120 mg comprimido"
  },
  {
    "code" : "BR0400579",
    "display" : "Cordia verbenacea 5 mg/g solução aerossol"
  },
  {
    "code" : "BR0400597",
    "display" : "Fentanila 12 microgramas/hora adesivo transdérmico"
  },
  {
    "code" : "BR0400852",
    "display" : "Ticagrelor 90 mg comprimido"
  },
  {
    "code" : "BR0400853",
    "display" : "Ivabradina 5 mg comprimido"
  },
  {
    "code" : "BR0400854",
    "display" : "Ivabradina 7,5 mg comprimido"
  },
  {
    "code" : "BR0400877",
    "display" : "Estradiol 2 mg comprimido e Estradiol 2 mg + Levonorgestrel 0,25 mg comprimido"
  },
  {
    "code" : "BR0400921",
    "display" : "Cloreto de Benzalcônio 0,2 mg/g + Brometo de Cetrimônio 2 mg/g creme"
  },
  {
    "code" : "BR0400927",
    "display" : "Diosmina 900 mg + Hesperidina 100 mg granulado"
  },
  {
    "code" : "BR0400973",
    "display" : "Glicinato Férrico 250 mg/mL solução oral"
  },
  {
    "code" : "BR0401321",
    "display" : "Amissulprida 200 mg comprimido"
  },
  {
    "code" : "BR0401324",
    "display" : "Insulina Lispro Bifásica (50/50) 100 unidades/mL suspensão para injeção 3 mL; carpule"
  },
  {
    "code" : "BR0401325",
    "display" : "Insulina Lispro Bifásica (50/50) 100 unidades/mL suspensão para injeção 3 mL; dispositivo para injeção"
  },
  {
    "code" : "BR0401411",
    "display" : "Óxido de Zinco 100 mg/g + Colecalciferol  400 unidades internacionais/g + Retinol 1.000 unidades internacionais/g pomada"
  },
  {
    "code" : "BR0401579",
    "display" : "Brosimum gaudichaudii 200 mg/g pomada"
  },
  {
    "code" : "BR0401579-1",
    "display" : "Brosimum gaudichaudii 200 mg/g pomada"
  },
  {
    "code" : "BR0401891",
    "display" : "Cianocobalamina 1 mg/1 mL solução para injeção; ampola e Tiamina 100 mg/1 mL + Piridoxina 100 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0402195",
    "display" : "Drospirenona 3 mg + Etinilestradiol 0,03 mg comprimido"
  },
  {
    "code" : "BR0402259",
    "display" : "Etexilato de Dabigatrana 150 mg cápsula"
  },
  {
    "code" : "BR0402531",
    "display" : "Betafolitropina 300 unidades internacionais/0,48 mL solução para injeção; carpule"
  },
  {
    "code" : "BR0402625",
    "display" : "Minociclina 100 mg cápsula"
  },
  {
    "code" : "BR0402991",
    "display" : "Saxagliptina 2,5 mg comprimido"
  },
  {
    "code" : "BR0403023",
    "display" : "Salbutamol 1 mg/mL solução para inalação 2,5 mL; ampola"
  },
  {
    "code" : "BR0403033",
    "display" : "Panitumumabe 100 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0403359-1",
    "display" : "Insulina Glulisina 100 unidades internacionais/mL solução para injeção 3 mL; carpule"
  },
  {
    "code" : "BR0403359-2",
    "display" : "Insulina Glulisina 100 unidades internacionais/mL solução para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "BR0403473",
    "display" : "Retinol 10 mg/g gel oftálmico"
  },
  {
    "code" : "BR0403990",
    "display" : "Roflumilaste 500 microgramas comprimido"
  },
  {
    "code" : "BR0403991",
    "display" : "Dipropionato de Betametasona 0,5 mg/mL + Ácido salicílico 20 mg/mL solução"
  },
  {
    "code" : "BR0404174",
    "display" : "Viminol 70 mg cápsula"
  },
  {
    "code" : "BR0404346",
    "display" : "Indacaterol 150 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "BR0404403",
    "display" : "Delapril 30 mg + Manidipino 10 mg comprimido"
  },
  {
    "code" : "BR0404404",
    "display" : "Hypericum perforatum 300 mg cápsula"
  },
  {
    "code" : "BR0404406",
    "display" : "Silybum marianum 100 mg comprimido"
  },
  {
    "code" : "BR0404421-1",
    "display" : "Stryphnodendron barbatiman 60 mg/g (6%) pomada"
  },
  {
    "code" : "BR0404421-2",
    "display" : "Stryphnodendron barbatiman 60 mg/g (6%) pomada"
  },
  {
    "code" : "BR0404425-1",
    "display" : "Benzocaína 45 mg/g + Triclosana 5 mg/g + Mentol 5 mg/g creme"
  },
  {
    "code" : "BR0404425-2",
    "display" : "Benzocaína 45 mg/g + Triclosana 5 mg/g + Mentol 5 mg/g creme"
  },
  {
    "code" : "BR0404429",
    "display" : "Glicinato de Magnésio 722,22 mg + Piridoxina 1 mg comprimido"
  },
  {
    "code" : "BR0404443",
    "display" : "Arginina 185 mg + Ornitina 60 mg + Citrulina 5 mg comprimido"
  },
  {
    "code" : "BR0404444",
    "display" : "Salicilato de Bismuto 500 mg cápsula"
  },
  {
    "code" : "BR0404448",
    "display" : "Indacaterol 300 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "BR0404612",
    "display" : "Pramipexol 1,5 mg comprimido"
  },
  {
    "code" : "BR0404655",
    "display" : "Ambrisentana 5 mg comprimido"
  },
  {
    "code" : "BR0404655E",
    "display" : "Ambrisentana 5 mg comprimido"
  },
  {
    "code" : "BR0404656",
    "display" : "Ambrisentana 10 mg comprimido"
  },
  {
    "code" : "BR0404656E",
    "display" : "Ambrisentana 10 mg comprimido"
  },
  {
    "code" : "BR0404690",
    "display" : "Glycine max (Isoflavona de Soja) 75 mg cápsula"
  },
  {
    "code" : "BR0404790",
    "display" : "Boceprevir 200 mg cápsula"
  },
  {
    "code" : "BR0404790E",
    "display" : "Boceprevir 200 mg cápsula"
  },
  {
    "code" : "BR0405149",
    "display" : "Captopril 10 mg/mL solução oral"
  },
  {
    "code" : "BR040521",
    "display" : "Pemetrexede 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0405210",
    "display" : "Acetato de Metilprednisolona 0,12% suspensão oftálmica"
  },
  {
    "code" : "BR0405899",
    "display" : "Desvenlafaxina 100 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0405900",
    "display" : "Benzocaína 45 mg/g + Triclosana 5 mg/g + Mentol 5 mg/g solução aerossol"
  },
  {
    "code" : "BR0405962",
    "display" : "Nimotuzumabe 50 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0405965",
    "display" : "Insulina Lispro Bifásica (25/75) 100 unidades/mL suspensão para injeção 3 mL; dispositivo para injeção"
  },
  {
    "code" : "BR0405997",
    "display" : "Bimatoprosta 0,1 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0405997-1",
    "display" : "Bimatoprosta 0,1 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0405998",
    "display" : "Insulina Lispro 100 unidades/mL solução para injeção 3 mL; dispositivo para injeção"
  },
  {
    "code" : "BR0406013",
    "display" : "Estradiol 1 mg comprimido"
  },
  {
    "code" : "BR0406015-1",
    "display" : "Oxibutinina 1 mg/mL solução oral"
  },
  {
    "code" : "BR0406015-2",
    "display" : "Oxibutinina 1 mg/mL solução oral"
  },
  {
    "code" : "BR0406015-3",
    "display" : "Oxibutinina 1 mg/mL solução oral"
  },
  {
    "code" : "BR0406081",
    "display" : "Lornoxicam 8 mg comprimido"
  },
  {
    "code" : "BR0406230",
    "display" : "Solifenacina 5 mg comprimido"
  },
  {
    "code" : "BR0406231",
    "display" : "Solifenacina 10 mg comprimido"
  },
  {
    "code" : "BR0406477",
    "display" : "Dexametasona 1 mg/g + Neomicina 5 mg/g creme"
  },
  {
    "code" : "BR0406485",
    "display" : "Betaepoetina Metoxipolietilenoglicol 50 microgramas/0,3 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0406487",
    "display" : "Levocetirizina 5 mg comprimido"
  },
  {
    "code" : "BR0406518",
    "display" : "Docetaxel 20 mg/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0406518-1",
    "display" : "Docetaxel 80 mg/4 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0406520E",
    "display" : "Alfaepoetina 3.000 unidades internacionais/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0406602",
    "display" : "Alisquireno 300 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0406799",
    "display" : "Sulfato Ferroso 68 mg/mL (Ferro 13,7 mg/mL) solução oral"
  },
  {
    "code" : "BR0406941",
    "display" : "Glicinato Férrico 150 mg (Ferro 30 mg) comprimido"
  },
  {
    "code" : "BR0406953",
    "display" : "Carbonato de Cálcio 50 mg + Colecalciferol 0,25 unidades internacionais pastilha"
  },
  {
    "code" : "BR0406975",
    "display" : "Ácido Valpróico 1 g/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0406975-1",
    "display" : "Ácido Valpróico 200 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0406975-3",
    "display" : "Ácido Valpróico 500 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0406992",
    "display" : "Nimesulida 200 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0407013",
    "display" : "Mentol 150 mg/g + Cânfora 100 mg/g  + Salicilato de Metila 80 mg/g + Óleo de Eucalipto 50 mg/g pomada"
  },
  {
    "code" : "BR0407013-1",
    "display" : "Mentol 150 mg/g + Cânfora 100 mg/g  + Salicilato de Metila 80 mg/g + Óleo de Eucalipto 50 mg/g pomada"
  },
  {
    "code" : "BR0407030-1",
    "display" : "Sulfato de Magnésio 990 mg/g pó para solução oral"
  },
  {
    "code" : "BR0407030-2",
    "display" : "Sulfato de Magnésio 990 mg/g pó para solução oral"
  },
  {
    "code" : "BR0407033",
    "display" : "Valproato de sódio 300 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0407036",
    "display" : "Valeriana officinalis 250 mg + Humulus lupulus 60 mg comprimido"
  },
  {
    "code" : "BR0407039",
    "display" : "Ciproeptadina 0,8 mg/mL + Cobamamida 0,2 mg/mL xarope"
  },
  {
    "code" : "BR0407066",
    "display" : "Glimepirida 4 mg + Metformina 1 g comprimido"
  },
  {
    "code" : "BR0407075",
    "display" : "Ciclobenzaprina 5 mg + Cafeína 30 mg comprimido"
  },
  {
    "code" : "BR0407076",
    "display" : "Drospirenona 3 mg + Etinilestradiol 0,02 mg comprimido"
  },
  {
    "code" : "BR0407214",
    "display" : "Linagliptina 5 mg comprimido"
  },
  {
    "code" : "BR0407326",
    "display" : "Lisdexanfetamina 70 mg cápsula"
  },
  {
    "code" : "BR0407327",
    "display" : "Lisdexanfetamina 50 mg cápsula"
  },
  {
    "code" : "BR0407328",
    "display" : "Lisdexanfetamina 30 mg cápsula"
  },
  {
    "code" : "BR0407441",
    "display" : "Beclometasona 100 microgramas/dose + Formoterol 6 microgramas/dose solução aerossol; inalador"
  },
  {
    "code" : "BR0407531",
    "display" : "Liraglutida 18 mg/3 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "BR0407704",
    "display" : "Prasugrel 5 mg comprimido"
  },
  {
    "code" : "BR0407705",
    "display" : "Prasugrel 10 mg comprimido"
  },
  {
    "code" : "BR0407989",
    "display" : "Ribavirina 200 mg cápsula"
  },
  {
    "code" : "BR0408470",
    "display" : "Mesalazina 1,2 g comprimido de liberação prolongada"
  },
  {
    "code" : "BR0408845",
    "display" : "Xilazina 200 mg/10 mL solução para injeção; frasco"
  },
  {
    "code" : "BR0409539",
    "display" : "Benznidazol 12,5 mg comprimido"
  },
  {
    "code" : "BR0409591",
    "display" : "Pramipexol 0,375 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0409592",
    "display" : "Pramipexol 3 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0410019",
    "display" : "Eltrombopague 25 mg comprimido"
  },
  {
    "code" : "BR0410020",
    "display" : "Eltrombopague 50 mg comprimido"
  },
  {
    "code" : "BR0410023",
    "display" : "Dipirona 1 g comprimido"
  },
  {
    "code" : "BR0410714",
    "display" : "Hidrato de Cloral 160 mg/mL solução oral"
  },
  {
    "code" : "BR0410989",
    "display" : "Benfotiamina 150 mg comprimido"
  },
  {
    "code" : "BR0411397",
    "display" : "Paliperidona 75 mg/0,75 mL suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "BR0411397-1",
    "display" : "Paliperidona 100 mg/1 mL suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "BR0411397-2",
    "display" : "Paliperidona 150 mg/1,5 mL suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "BR0411397-3",
    "display" : "Paliperidona 75 mg/0,75 mL suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "BR0411397-4",
    "display" : "Paliperidona 50 mg/0,5 mL suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "BR0412031",
    "display" : "Dasatinibe 100 mg comprimido"
  },
  {
    "code" : "BR0412091",
    "display" : "Rivaroxabana 20 mg comprimido"
  },
  {
    "code" : "BR0412092",
    "display" : "Rivaroxabana 15 mg comprimido"
  },
  {
    "code" : "BR0412094",
    "display" : "Fingolimode 0,5 mg cápsula"
  },
  {
    "code" : "BR0412094E",
    "display" : "Fingolimode 0,5 mg cápsula"
  },
  {
    "code" : "BR0412122",
    "display" : "Betacaroteno 5 mg cápsula"
  },
  {
    "code" : "BR0412375",
    "display" : "Oseltamivir 25 mg cápsula"
  },
  {
    "code" : "BR0412376",
    "display" : "Oseltamivir 20 mg cápsula"
  },
  {
    "code" : "BR0412419",
    "display" : "Oseltamivir 12 mg cápsula"
  },
  {
    "code" : "BR0412431",
    "display" : "Rupatadina 10 mg comprimido"
  },
  {
    "code" : "BR0412432",
    "display" : "Cloreto de Sódio 175,5 mg/mL (17,55%) solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0412470",
    "display" : "Telaprevir 375 mg comprimido"
  },
  {
    "code" : "BR0412470E",
    "display" : "Telaprevir 375 mg comprimido"
  },
  {
    "code" : "BR0412718",
    "display" : "Icatibanto 30 mg/3 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0412776",
    "display" : "Abiraterona 250 mg comprimido"
  },
  {
    "code" : "BR0412786",
    "display" : "Ácido Fólico 0,8 mg + Cianocobalamina 0,4 mg + Piridoxina 4 mg comprimido"
  },
  {
    "code" : "BR0412830",
    "display" : "Brentuximabe Vedotina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0412833",
    "display" : "Tadalafila 5 mg comprimido"
  },
  {
    "code" : "BR0412840",
    "display" : "Bilastina 20 mg comprimido"
  },
  {
    "code" : "BR0412963",
    "display" : "Simeticona 40 mg comprimido"
  },
  {
    "code" : "BR0412965",
    "display" : "Simeticona 75 mg/mL solução oral"
  },
  {
    "code" : "BR0412965-1",
    "display" : "Simeticona 75 mg/mL suspensão oral"
  },
  {
    "code" : "BR0412965-2",
    "display" : "Simeticona 75 mg/mL solução oral"
  },
  {
    "code" : "BR0413041",
    "display" : "Plerixafor 24 mg/1,2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0413606",
    "display" : "Midodrina 5 mg comprimido"
  },
  {
    "code" : "BR0413607",
    "display" : "Midodrina 2,5 mg comprimido"
  },
  {
    "code" : "BR0413608",
    "display" : "Midodrina 10 mg comprimido"
  },
  {
    "code" : "BR0413768",
    "display" : "Bupropiona 300 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0413882",
    "display" : "Ácido Alendrônico 70 mg + Colecalciferol 5.600 unidades internacionais comprimido"
  },
  {
    "code" : "BR0414431",
    "display" : "Golimumabe 50 mg/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0414431E",
    "display" : "Golimumabe 50 mg/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0414435E",
    "display" : "Certolizumabe Pegol 200 mg/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0414454",
    "display" : "Carnitina 50 mg/mL xarope"
  },
  {
    "code" : "BR0414455",
    "display" : "Arginina 400 mg/mL xarope"
  },
  {
    "code" : "BR0414456",
    "display" : "Benzoato de Sódio 200 mg/mL xarope"
  },
  {
    "code" : "BR0414456-1",
    "display" : "Benzoato de Sódio 200 mg/mL xarope"
  },
  {
    "code" : "BR0414456-2",
    "display" : "Benzoato de Sódio 200 mg/mL xarope"
  },
  {
    "code" : "BR0414657",
    "display" : "Tobramicina 75 mg/mL solução para inalação 4 mL; flaconete"
  },
  {
    "code" : "BR0414847",
    "display" : "Carbonato de Lodenafila 80 mg comprimido"
  },
  {
    "code" : "BR0414848",
    "display" : "Terconazol 8 mg/g creme vaginal"
  },
  {
    "code" : "BR0415027",
    "display" : "Podofilina 25% suspensão"
  },
  {
    "code" : "BR0415027-1",
    "display" : "Podofilina 25% solução"
  },
  {
    "code" : "BR0415213",
    "display" : "Ácido Alendrônico 70 mg comprimido e Carbonato de Cálcio 1,25 g (Cálcio 500 mg) + Colecalciferol 200 unidades internacionais comprimido"
  },
  {
    "code" : "BR0415504",
    "display" : "Extrato de Allii cepae L. 100 mg/g + Alantoína 10 mg/g + Heparina Sódica 0,4 mg/g gel"
  },
  {
    "code" : "BR0415509",
    "display" : "Tafluprosta 15 microgramas/mL solução oftálmica"
  },
  {
    "code" : "BR0415778",
    "display" : "Alisquireno 150 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0415781",
    "display" : "Estradiol 1 mg + Enantato de Noretisterona 500 microgramas comprimido"
  },
  {
    "code" : "BR0416528",
    "display" : "Eritropoietina (Humana Recombinante) 4.000 unidades internacionais pó para suspensão para injeção; ampola"
  },
  {
    "code" : "BR0416618",
    "display" : "Cloranfenicol 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0416731",
    "display" : "Medroxiprogesterona 25 mg/0,5 mL + Estradiol 5 mg/0,5 mL suspensão para injeção; ampola"
  },
  {
    "code" : "BR0416784",
    "display" : "Macrogol (4000) 10 g granulado"
  },
  {
    "code" : "BR0417026",
    "display" : "Asenapina 5 mg comprimido sublingual"
  },
  {
    "code" : "BR0417028",
    "display" : "Asenapina 10 mg comprimido sublingual"
  },
  {
    "code" : "BR0417032",
    "display" : "Cefalexina 1 g comprimido"
  },
  {
    "code" : "BR0417156",
    "display" : "Metenamina 120 mg + Cloreto de Metiltionínio 20 mg comprimido"
  },
  {
    "code" : "BR0417571",
    "display" : "Trioxisaleno 10 mg cápsula"
  },
  {
    "code" : "BR0417713",
    "display" : "Gliclazida 60 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0418793",
    "display" : "Vemurafenibe 240 mg comprimido"
  },
  {
    "code" : "BR0420469",
    "display" : "Heparina Sódica 50 unidades internacionais/g + Nicotinato de Benzila 2 mg/g pomada"
  },
  {
    "code" : "BR0420599",
    "display" : "Sulfato de Morfina 0,1 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0421127",
    "display" : "Metoprolol 100 mg + Hidroclorotiazida 12,5 mg comprimido de liberação pronlongada"
  },
  {
    "code" : "BR0421223",
    "display" : "Denosumabe 60 mg/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0421663",
    "display" : "Nitrato de Butoconazol 5 mg/g creme vaginal"
  },
  {
    "code" : "BR0421665",
    "display" : "Bisglicinato Ferroso 30 mg/mL (Ferro 6 mg/mL) + Ácido Fólico 0,2 mg/mL solução oral"
  },
  {
    "code" : "BR0422070",
    "display" : "Ureia 20% + Ácido Salicílico 3% creme"
  },
  {
    "code" : "BR0423916",
    "display" : "Rosuvastatina 5 mg comprimido"
  },
  {
    "code" : "BR0424169",
    "display" : "Levanlodipino 5 mg comprimido"
  },
  {
    "code" : "BR0424170",
    "display" : "Levanlodipino 2,5 mg comprimido"
  },
  {
    "code" : "BR0425182",
    "display" : "Dextrocetamina 500 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0425182-1",
    "display" : "Dextrocetamina 100 mg/2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0425580",
    "display" : "Zolpidem 5 mg comprimido sublingual"
  },
  {
    "code" : "BR0425582",
    "display" : "Lamotrigina 200 mg comprimido"
  },
  {
    "code" : "BR0425676",
    "display" : "Diazóxido 25 mg cápsula"
  },
  {
    "code" : "BR0425719",
    "display" : "Bumetanida 1 mg comprimido"
  },
  {
    "code" : "BR0425824",
    "display" : "Ubidecarenona 200 mg cápsula"
  },
  {
    "code" : "BR0426071",
    "display" : "Mirtazapina 60 mg cápsula"
  },
  {
    "code" : "BR0426207",
    "display" : "Lisinopril 10 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0426208",
    "display" : "Telmisartana 80 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "BR0426892",
    "display" : "Tizanidina 4 mg comprimido"
  },
  {
    "code" : "BR0426921",
    "display" : "Baclofeno 20 mg comprimido"
  },
  {
    "code" : "BR0426922",
    "display" : "Silybum marianum 200 mg cápsula"
  },
  {
    "code" : "BR0426931",
    "display" : "Cassia angustifolia 240 mg + Tamarindus indica 11,7 mg + Cassia fistula 11,7 mg +  Coriandrum sativum 5,4 mg cápsula"
  },
  {
    "code" : "BR0427335",
    "display" : "Tenofovir 300 mg + Lamivudina 300 mg + Efavirenz 600 mg comprimido"
  },
  {
    "code" : "BR0427409",
    "display" : "Everolimo 2,5 mg comprimido"
  },
  {
    "code" : "BR0427532",
    "display" : "Pertuzumabe 420 mg/14 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0427533",
    "display" : "Ipilimumabe 50 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0427533-1",
    "display" : "Ipilimumabe 200 mg/40 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0427613",
    "display" : "Belimumabe 120 mg pó para solução para injeção; ampola"
  },
  {
    "code" : "BR0427614",
    "display" : "Belimumabe 400 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0427719",
    "display" : "Prucaloprida 2 mg comprimido"
  },
  {
    "code" : "BR0428050",
    "display" : "Raltegravir 100 mg comprimido"
  },
  {
    "code" : "BR0428076",
    "display" : "Fenoterol 0,05 mg /dose + Brometo de Ipratrópio 0,02 mg/dose solução aerossol"
  },
  {
    "code" : "BR0428423",
    "display" : "Tenofovir 300 mg + Lamivudina 300 mg comprimido"
  },
  {
    "code" : "BR0428425",
    "display" : "Diosmina 900 mg + Hesperidina 100 mg comprimido"
  },
  {
    "code" : "BR0428705",
    "display" : "Dutasterida 0,5 mg + Tansulosina 0,4 mg cápsula"
  },
  {
    "code" : "BR0428744-1",
    "display" : "Colecalciferol 5.600 unidades internacionais/mL solução oral"
  },
  {
    "code" : "BR0428744-2",
    "display" : "Colecalciferol 5.600 unidades internacionais/mL solução oral"
  },
  {
    "code" : "BR0428786",
    "display" : "Albumina Humana 100 mg/mL (10%) solução para injeção 50 mL; frasco-ampola"
  },
  {
    "code" : "BR0428804",
    "display" : "Bendamustina 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0428952",
    "display" : "Brosimum gaudichaudii 400 mg comprimido"
  },
  {
    "code" : "BR0429055",
    "display" : "Doxazosina 5 mg + Finasterida 2 mg cápsula"
  },
  {
    "code" : "BR0429102",
    "display" : "Fampridina 10 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0429151",
    "display" : "Ácido Gamaminobutírico 50 mg + Lisina 50 mg + Tiamina 2 mg + Piridoxina 4 mg + Cálcio 4 mg comprimido"
  },
  {
    "code" : "BR0429217",
    "display" : "Fator VIII 1.000 unidades internacionais + Fator von Willebrand 2.400 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0429549",
    "display" : "Dienogeste 2 mg comprimido"
  },
  {
    "code" : "BR0429846",
    "display" : "Apixabana 5 mg comprimido"
  },
  {
    "code" : "BR0429847",
    "display" : "Apixabana 2,5 mg comprimido"
  },
  {
    "code" : "BR0429879",
    "display" : "Saxagliptina 5 mg + Metformina 1 g comprimido de liberação prolongada"
  },
  {
    "code" : "BR0430050-1",
    "display" : "Arginina 250 mg/mL xarope"
  },
  {
    "code" : "BR0430315",
    "display" : "Aflibercepte 11,12 mg/0,278 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0430403",
    "display" : "Trastuzumabe 100 mg pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0430404",
    "display" : "Ibrutinibe 140 mg cápsula"
  },
  {
    "code" : "BR0430434",
    "display" : "Colecalciferol 5.000 unidades internacionais comprimido"
  },
  {
    "code" : "BR0431097",
    "display" : "Colecalciferol 7.000 unidades internacionais cápsula"
  },
  {
    "code" : "BR0431098",
    "display" : "Colecalciferol 50.000 unidades internacionais cápsula"
  },
  {
    "code" : "BR0431100",
    "display" : "Codeína 45 mg comprimido"
  },
  {
    "code" : "BR0431160",
    "display" : "Paracetamol 400 mg + Famotidina 20 mg + Tramadol 20 mg cápsula"
  },
  {
    "code" : "BR0431163",
    "display" : "Podofilina 20% solução"
  },
  {
    "code" : "BR0431222",
    "display" : "Ubidecarenona 300 mg cápsula"
  },
  {
    "code" : "BR0431311",
    "display" : "Hidróxido de Alumínio 37 mg/mL + Hidróxido de Magnésio 40 mg/mL + Simeticona 5 mg/mL suspensão oral"
  },
  {
    "code" : "BR0431312",
    "display" : "Levotiroxina Sódica 137 microgramas comprimido"
  },
  {
    "code" : "BR0431314",
    "display" : "Itraconazol 20 mg/mL suspensão oral"
  },
  {
    "code" : "BR0431319",
    "display" : "Cloreto de Cetilpiridínio 0,5 mg/mL + Benzocaína 4 mg/mL solução spray"
  },
  {
    "code" : "BR0431569",
    "display" : "Pinus pinaster 50 mg comprimido"
  },
  {
    "code" : "BR0431570",
    "display" : "Saxagliptina 2,5 mg + Metformina 1 g comprimido de liberação prolongada"
  },
  {
    "code" : "BR0431599",
    "display" : "Sofosbuvir 400 mg comprimido"
  },
  {
    "code" : "BR0431599E",
    "display" : "Sofosbuvir 400 mg comprimido"
  },
  {
    "code" : "BR0431716",
    "display" : "Naproxeno 500 mg + Esomeprazol 20 mg comprimido de liberação modificada"
  },
  {
    "code" : "BR0431717",
    "display" : "Dexametasona 0,7 mg implante; dispositivo"
  },
  {
    "code" : "BR0431732",
    "display" : "Daclatasvir 60 mg comprimido"
  },
  {
    "code" : "BR0431732E",
    "display" : "Daclatasvir 60 mg comprimido"
  },
  {
    "code" : "BR0431752",
    "display" : "Simeprevir 150 mg cápsula"
  },
  {
    "code" : "BR0431752E",
    "display" : "Simeprevir 150 mg cápsula"
  },
  {
    "code" : "BR0432140",
    "display" : "Piridoxina 500 mg comprimido"
  },
  {
    "code" : "BR0432197",
    "display" : "Glycine max (Isoflavona de Soja) 125 mg comprimido"
  },
  {
    "code" : "BR0432635",
    "display" : "Carboximaltose Férrica 500 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0432637",
    "display" : "Crizotinibe 250 mg cápsula"
  },
  {
    "code" : "BR0432741",
    "display" : "Hialuronato de Sódio 0,15% solução oftálmica"
  },
  {
    "code" : "BR0432742",
    "display" : "Magaldrato 80 mg/mL + Simeticona 10 mg/mL solução oral"
  },
  {
    "code" : "BR0432781",
    "display" : "Valeriana officinalis 225,75 mg comprimido"
  },
  {
    "code" : "BR0432783",
    "display" : "Pantoprazol 40 mg cápsula"
  },
  {
    "code" : "BR0432784",
    "display" : "Pertuzumabe 420 mg/14 mL solução para injeção; frasco-ampola e Trastuzumabe 440 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0432908",
    "display" : "Dapagliflozina 10 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0432926",
    "display" : "Mometasona 100 microgramas + Formoterol 50 microgramas pó para inalação oral"
  },
  {
    "code" : "BR0432995",
    "display" : "Mometasona 200 microgramas/dose + Formoterol 5 microgramas/dose suspensão aerossol"
  },
  {
    "code" : "BR0433019",
    "display" : "Romiplostim 250 microgramas pó para injeção; frasco-ampola"
  },
  {
    "code" : "BR0433022",
    "display" : "Sulfadiazina 150 mg/mL solução oral"
  },
  {
    "code" : "BR0433023",
    "display" : "Citrato de Cálcio (Cálcio 250  mg) + Colecalciferol 2,5 micrograma comprimido"
  },
  {
    "code" : "BR0433077",
    "display" : "Fenofibrato 160 mg comprimido"
  },
  {
    "code" : "BR0433100",
    "display" : "Furoato de Fluticasona 100 microgramas/dose + Vilanterol 25 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "BR0433148",
    "display" : "Lisados bacterianos 3,5 mg cápsula"
  },
  {
    "code" : "BR0433171",
    "display" : "Pitavastatina 2 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0433257",
    "display" : "Hidróxido de Alumínio 60 mg/mL suspensão oral"
  },
  {
    "code" : "BR0433257-1",
    "display" : "Hidróxido de Alumínio 60 mg/mL solução oral"
  },
  {
    "code" : "BR0433279",
    "display" : "Divalproato de sódio 250 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0433428",
    "display" : "Retinol 5.000 unidades internacionais + Piridoxina 100 mg + Racealfatocoferol 300 mg cápsula"
  },
  {
    "code" : "BR0433494",
    "display" : "Peróxido de Uréia 100 mg/mL solução otológica"
  },
  {
    "code" : "BR0433514",
    "display" : "Subgalato de Bismuto 1,5 mg/g + Óxido de Zinco 45 mg/g gel"
  },
  {
    "code" : "BR0433517",
    "display" : "Valerato de Estradiol 8 mg + Dienogeste 5 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0433548",
    "display" : "Valsartana 320 mg + Hidroclorotiazida 25 mg + Anlodipino 10 mg comprimido"
  },
  {
    "code" : "BR0433685",
    "display" : "Ruxolitinibe 20 mg comprimido"
  },
  {
    "code" : "BR0433687",
    "display" : "Dolutegravir 50 mg comprimido"
  },
  {
    "code" : "BR0433690",
    "display" : "Enzalutamida 40 mg cápsula"
  },
  {
    "code" : "BR0433812",
    "display" : "Tranilcipromina 10 mg comprimido"
  },
  {
    "code" : "BR0434051",
    "display" : "Schinus terebenthifolius 7% creme vaginal"
  },
  {
    "code" : "BR0434091",
    "display" : "Ácido Folínico 7,5 mg/mL solução oral"
  },
  {
    "code" : "BR0434111",
    "display" : "Amitriptilina 10 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0434125",
    "display" : "Colecalciferol 1.000 unidades internacionais comprimido de liberação prolongada"
  },
  {
    "code" : "BR0434128",
    "display" : "Ácido Fólico 800 microgramas + Acetato de Racealfatocoferol 20 mg cápsula"
  },
  {
    "code" : "BR0434130",
    "display" : "Pirenoxina Sódica 0,85 mg comprimido e diluente para solução oftálmica"
  },
  {
    "code" : "BR0434254",
    "display" : "Canagliflozina 300 mg comprimido"
  },
  {
    "code" : "BR0434406",
    "display" : "Lacosamida 100 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0434765E",
    "display" : "Abatacepte 125 mg/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0434796-1",
    "display" : "Levocetirizina 5 mg/mL solução oral"
  },
  {
    "code" : "BR0434797",
    "display" : "Bisoprolol 10 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "BR0434872",
    "display" : "Tofacitinibe 5 mg comprimido"
  },
  {
    "code" : "BR0434874",
    "display" : "Empagliflozina 25 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0434945",
    "display" : "Trifolium pratense 100 mg comprimido"
  },
  {
    "code" : "BR0434946",
    "display" : "Retinol 20.000 unidades internacionais/mL + Colecalciferol 1.600 unidades internacionais/mL + Racealfatocoferol 30 mg/mL solução oral"
  },
  {
    "code" : "BR0435101",
    "display" : "Paracetamol 500 mg + Amitriptilina 25 mg + Meloxicam 7,5 mg cápsula"
  },
  {
    "code" : "BR0435102",
    "display" : "Paracetamol 500 mg + Amitriptilina 25 mg + Ciclobenzaprina 5 mg + Meloxicam 7,5 mg cápsula"
  },
  {
    "code" : "BR0435105",
    "display" : "Polypodium leucotomos 250 mg comprimido"
  },
  {
    "code" : "BR0435186",
    "display" : "Metoxisaleno 1 mg/g (0,1%) creme"
  },
  {
    "code" : "BR0435187",
    "display" : "Metoxisaleno 2 mg/g (0,2%) creme"
  },
  {
    "code" : "BR0435189",
    "display" : "Paracetamol 500 mg + Meloxicam 15 mg + Ciclobenzaprina 5 mg cápsula"
  },
  {
    "code" : "BR0435285",
    "display" : "Hialuronato de Sódio 1,6% solução para injeção 0,8 mL; seringa preenchida"
  },
  {
    "code" : "BR0435334/0003E",
    "display" : "Daclatasvir 30 mg comprimido"
  },
  {
    "code" : "BR0435442",
    "display" : "Idebenona 150 mg cápsula"
  },
  {
    "code" : "BR0435539",
    "display" : "Lacosamida 50 mg comprimido"
  },
  {
    "code" : "BR0435950",
    "display" : "Telmisartana 40 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "BR0436169",
    "display" : "Alogliptina 25 mg comprimido"
  },
  {
    "code" : "BR0436234",
    "display" : "Escitalopram 20 mg/mL solução oral"
  },
  {
    "code" : "BR0436234-1",
    "display" : "Escitalopram 20 mg/mL solução oral"
  },
  {
    "code" : "BR0436345",
    "display" : "Nintedanibe 150 mg cápsula"
  },
  {
    "code" : "BR0436433",
    "display" : "Fenticonazol 20 mg/mL solução spray"
  },
  {
    "code" : "BR0436480",
    "display" : "Furoato de Fluticasona 200 microgramas/dose + Vilanterol 25 microgramas/dose pó para inalação"
  },
  {
    "code" : "BR0436500",
    "display" : "Anlodipino 10 mg + Ramipril 10 mg cápsula"
  },
  {
    "code" : "BR0436508",
    "display" : "Alfaestradiol 0,25 mg/mL solução"
  },
  {
    "code" : "BR0436550",
    "display" : "Simeticona 125 mg cápsula"
  },
  {
    "code" : "BR0436703",
    "display" : "Gatifloxacino 3 mg/mL + Prednisolona 10 mg/mL suspensão oftálmica"
  },
  {
    "code" : "BR0436705-1",
    "display" : "Buprenorfina 5 microgramas/hora adesivo transdérmico"
  },
  {
    "code" : "BR0436705-2",
    "display" : "Buprenorfina 10 microgramas/hora adesivo transdérmico"
  },
  {
    "code" : "BR0436705-3",
    "display" : "Buprenorfina 20 microgramas/hora adesivo transdérmico"
  },
  {
    "code" : "BR0436711",
    "display" : "Etravirina 200 mg comprimido"
  },
  {
    "code" : "BR0436769",
    "display" : "Vortioxetina 10 mg comprimido"
  },
  {
    "code" : "BR0437051",
    "display" : "Lacosamida 10 mg/mL solução oral"
  },
  {
    "code" : "BR0437078",
    "display" : "Empagliflozina 10 mg comprimido"
  },
  {
    "code" : "BR0437083",
    "display" : "Secuquinumabe 150 mg/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0437284",
    "display" : "Levetiracetam 750 mg comprimido"
  },
  {
    "code" : "BR0437357",
    "display" : "Rotigotina 6 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "BR0437374",
    "display" : "Levotiroxina Sódica 37,5 microgramas comprimido"
  },
  {
    "code" : "BR0437989",
    "display" : "Indacaterol 110 microgramas + Glicopirrônio 50 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "BR0437993",
    "display" : "Brometo de Umeclidíno 62,5 microgramas/dose + Vilanterol 25 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "BR0437994",
    "display" : "Lacosamida 150 mg comprimido"
  },
  {
    "code" : "BR0438039",
    "display" : "Alogliptina 12,5 mg comprimido"
  },
  {
    "code" : "BR0438041",
    "display" : "Alogliptina 6,25 mg comprimido"
  },
  {
    "code" : "BR0438280",
    "display" : "Levotiroxina Sódica 62,5 microgramas comprimido"
  },
  {
    "code" : "BR0609095E",
    "display" : "Formoterol 6 microgramas/dose + Budesonida 200 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "BR3933803",
    "display" : "Ácido Fólico 5%"
  },
  {
    "code" : "BR427335",
    "display" : "Tenofovir 300 mg + Lamivudina 300 mg + Efavirenz 600 mg comprimido"
  },
  {
    "code" : "BR0465425",
    "display" : "Metformina 850 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0267613U0042",
    "display" : "Captopril 25 mg comprimido"
  },
  {
    "code" : "BR0270130U0042",
    "display" : "Levodopa 250 mg + Carbidopa 25 mg comprimido"
  },
  {
    "code" : "BR0270127U0041",
    "display" : "Levodopa 100 mg + Benserazida 25 mg cápsula"
  },
  {
    "code" : "BR0270128U0042",
    "display" : "Levodopa 100 mg + Benserazida 25 mg comprimido"
  },
  {
    "code" : "BR0267690U0042",
    "display" : "Metformina 500 mg comprimido"
  },
  {
    "code" : "BR0267691U0042",
    "display" : "Metformina 850 mg comprimido"
  },
  {
    "code" : "BR0267772U0042",
    "display" : "Propranolol 40 mg comprimido"
  },
  {
    "code" : "BR0267587U0061",
    "display" : "Beclometasona 200 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "BR0267586U0041",
    "display" : "Beclometasona 200 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "BR0267581U0084",
    "display" : "Beclometasona 250 microgramas/dose solução oral"
  },
  {
    "code" : "BR0267582U0084",
    "display" : "Beclometasona 50 microgramas/dose suspensão spray"
  },
  {
    "code" : "BR0346586U0084",
    "display" : "Beclometasona 50 microgramas/dose solução aerossol; inalador"
  },
  {
    "code" : "BR0270846U0005",
    "display" : "Estradiol 5 mg/1 mL + Enantato de Noretisterona 50 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0267671U0042",
    "display" : "Glibenclamida 5 mg comprimido"
  },
  {
    "code" : "BR0267674U0042",
    "display" : "Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "BR0272789U0042",
    "display" : "Levonorgestrel 0,15 mg + Etinilestradiol 0,03 mg comprimido"
  },
  {
    "code" : "BR0268856U0042",
    "display" : "Losartana 50 mg comprimido"
  },
  {
    "code" : "BR0272581U0106",
    "display" : "Timolol 5 mg/mL (0,5%) solução oftálmica"
  },
  {
    "code" : "BR0272582U0106",
    "display" : "Timolol 2,5 mg/mL (0,25%) solução oftálmica"
  },
  {
    "code" : "BR0267651U0042",
    "display" : "Enalapril 10 mg comprimido"
  },
  {
    "code" : "BR0267733U0042",
    "display" : "Noretisterona 0,35 mg comprimido"
  },
  {
    "code" : "BR0267746U0042",
    "display" : "Sinvastatina 10 mg comprimido"
  },
  {
    "code" : "BR0267747U0042",
    "display" : "Sinvastatina 20 mg comprimido"
  },
  {
    "code" : "BR0267745U0042",
    "display" : "Sinvastatina 40 mg comprimido"
  },
  {
    "code" : "BR0268303U0063",
    "display" : "Salbutamol 5 mg/mL solução para inalação 10 mL; frasco"
  },
  {
    "code" : "BR0294887U0084",
    "display" : "Salbutamol 100 microgramas/dose suspensão aerossol; inalador"
  },
  {
    "code" : "BR0271154U0063",
    "display" : "Insulina Humana Regular 100 unidades internacionais/mL solução para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "BR0271154U0137",
    "display" : "Insulina Humana Regular 100 unidades internacionais/mL solução para injeção 3 mL; carpule"
  },
  {
    "code" : "BR0271157U0063",
    "display" : "Insulina Humana NPH 100 unidades internacionais/mL suspensão para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "BR0271157U0137",
    "display" : "Insulina Humana NPH 100 unidades internacionais/mL suspensão para injeção 3 mL; carpule"
  },
  {
    "code" : "BR0368922-1",
    "display" : "Ácido Acético 2%"
  },
  {
    "code" : "BR0368922-2",
    "display" : "Ácido Acético 2%"
  },
  {
    "code" : "BR0368922",
    "display" : "Ácido Acético 2%"
  },
  {
    "code" : "BR0368921-3",
    "display" : "Ácido Acético 3%"
  },
  {
    "code" : "BR0368921",
    "display" : "Ácido Acético 3%"
  },
  {
    "code" : "BR0368919-2",
    "display" : "Ácido Acético 5%"
  },
  {
    "code" : "BR0368919-4",
    "display" : "Ácido Acético 5%"
  },
  {
    "code" : "BR0368919-3",
    "display" : "Ácido Acético 5%"
  },
  {
    "code" : "BR0368919-1",
    "display" : "Ácido Acético 5%"
  },
  {
    "code" : "BR0368919",
    "display" : "Ácido Acético 5%"
  },
  {
    "code" : "BR0268289",
    "display" : "Ácido Bórico 2%"
  },
  {
    "code" : "BR0268290",
    "display" : "Ácido Bórico 3%"
  },
  {
    "code" : "BR0395558-1",
    "display" : "Ácido Salicílico 20mg/g"
  },
  {
    "code" : "BR0269070-2",
    "display" : "Ácido Tricloroacético 30% solução"
  },
  {
    "code" : "BR0269070-1",
    "display" : "Ácido Tricloroacético 30% solução"
  },
  {
    "code" : "BR0269070",
    "display" : "Ácido Tricloroacético 30% solução"
  },
  {
    "code" : "BR0269068-1",
    "display" : "Ácido Tricloroacético 50% solução"
  },
  {
    "code" : "BR0269068-2",
    "display" : "Ácido Tricloroacético 50% solução"
  },
  {
    "code" : "BR0269068-3",
    "display" : "Ácido Tricloroacético 50% solução"
  },
  {
    "code" : "BR0269068",
    "display" : "Ácido Tricloroacético 50% solução"
  },
  {
    "code" : "BR0286359-1",
    "display" : "Ácido Tricloroacético 60% solução"
  },
  {
    "code" : "BR0269072",
    "display" : "Ácido Tricloroacético 75% solução"
  },
  {
    "code" : "BR0269072-1",
    "display" : "Ácido Tricloroacético 75% solução"
  },
  {
    "code" : "BR0269073-1",
    "display" : "Ácido Tricloroacético 80% solução"
  },
  {
    "code" : "BR0269073-3",
    "display" : "Ácido Tricloroacético 80% solução"
  },
  {
    "code" : "BR0269073-2",
    "display" : "Ácido Tricloroacético 80% solução"
  },
  {
    "code" : "BR0269073",
    "display" : "Ácido Tricloroacético 80% solução"
  },
  {
    "code" : "BR0269069",
    "display" : "Ácido Tricloroacético 90% solução"
  },
  {
    "code" : "BR0269069-1",
    "display" : "Ácido Tricloroacético 90% solução"
  },
  {
    "code" : "BR0269069-2",
    "display" : "Ácido Tricloroacético 90% solução"
  },
  {
    "code" : "BR0269943-3",
    "display" : "Álcool Etílico 70% Gel"
  },
  {
    "code" : "BR0269941-1",
    "display" : "Álcool Etílico 70% Solução"
  },
  {
    "code" : "BR0269941",
    "display" : "Álcool Etílico 70% Solução"
  },
  {
    "code" : "BR0269943-4",
    "display" : "Álcool Etílico 70% Gel"
  },
  {
    "code" : "BR0269943-1",
    "display" : "Álcool Etílico 70% Gel"
  },
  {
    "code" : "BR0269943-2",
    "display" : "Álcool Etílico 70% Gel"
  },
  {
    "code" : "BR0328596",
    "display" : "Álcool Etílico 99% Solução"
  },
  {
    "code" : "BR0357239",
    "display" : "Álcool Etílico 99% Solução"
  },
  {
    "code" : "BR0269462",
    "display" : "Ácido Alendrônico 70 mg comprimido"
  },
  {
    "code" : "BR0266628",
    "display" : "Alfaepoetina 2.000 unidades internacionais/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271356-1",
    "display" : "Alprazolam 1 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0436416",
    "display" : "Alteplase 10 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271100",
    "display" : "Amoxicilina 1 g + Ácido Clavulânico 200 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0437411",
    "display" : "Arginina 0,25mg/mL Xarope"
  },
  {
    "code" : "BR0400564",
    "display" : "Arteméter 20 mg + Lumefantrina 120 mg comprimido"
  },
  {
    "code" : "BR0267590",
    "display" : "Beclometasona 250 microgramas/dose solução aerossol; inalador"
  },
  {
    "code" : "BR0394316",
    "display" : "Betainterferona 1b 9.600.000 unidades internacionais (300 microgramas) pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0349666",
    "display" : "Nitrato de Prata 5g Bastão"
  },
  {
    "code" : "BR0404846",
    "display" : "Somatropina 12 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0318989",
    "display" : "Somatropina 16 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0406930",
    "display" : "Somatropina 24 unidades internacionais"
  },
  {
    "code" : "BR0318990",
    "display" : "Somatropina 36 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0308890",
    "display" : "Zidovudina 10 mg/mL xarope"
  },
  {
    "code" : "BR0400982",
    "display" : "Sulfato de Zinco 2,5mg"
  },
  {
    "code" : "BR0433249",
    "display" : "Sulfato de Zinco 4mg"
  },
  {
    "code" : "BR0277433",
    "display" : "Betainterferona 1a 6.000.000 unidades internacionais (30 microgramas) solução para injeção; frasco-ampola"
  }]
}

```
