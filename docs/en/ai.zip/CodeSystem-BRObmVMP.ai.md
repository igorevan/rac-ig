# Terminologia de Produto Medicinal Virtual (VMP) na Ontologia Brasileira de Medicamentos (OBM) - Guia de Implementação do Registro de Atendimento Clínico (RAC) da RNDS v1.0.0-release

## CodeSystem: Terminologia de Produto Medicinal Virtual (VMP) na Ontologia Brasileira de Medicamentos (OBM) 

 
Apresenta o Produto Medicinal Virtual (VMP) e seu Código na Ontologia Brasileira de Medicamentos (OBM) 

This Code system is referenced in the definition of the following value sets:

* [Terminologia dos medicamentos](ValueSet-BRTerminologiaMedicamento.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRObmVMP",
  "meta" : {
    "lastUpdated" : "2022-04-06T12:48:11.6743763+03:00"
  },
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/fhir/r4/rac/1.0.0/ImplementationGuide/br.gov.saude.rac.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/fhir/r4/rac/1.0.0/ImplementationGuide/br.gov.saude.rac.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmVMP",
  "version" : "1.0.0-release",
  "name" : "BRObmVMP",
  "title" : "Terminologia de Produto Medicinal Virtual (VMP) na Ontologia Brasileira de Medicamentos (OBM)",
  "status" : "active",
  "experimental" : false,
  "date" : "2022-04-06T12:48:11.6743763+03:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Apresenta o Produto Medicinal Virtual (VMP) e seu Código na Ontologia Brasileira de Medicamentos (OBM)",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "@brasil12070954154",
    "display" : "Abacavir 20 mg/mL solução oral"
  },
  {
    "code" : "@brasil12751888652",
    "display" : "Abacavir 300 mg comprimido"
  },
  {
    "code" : "@brasil14258676378",
    "display" : "Abacavir 600 mg + Lamivudina 300 mg comprimido"
  },
  {
    "code" : "@brasil15224574230",
    "display" : "Abatacepte 125 mg/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil13729806302",
    "display" : "Abatacepte 250 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10440089348",
    "display" : "Abatacepte 250 mg pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16177720655",
    "display" : "Abciximabe 10 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10731260971",
    "display" : "Abiraterona 250 mg comprimido"
  },
  {
    "code" : "@brasil15400639207",
    "display" : "Acarbose 100 mg comprimido"
  },
  {
    "code" : "@brasil14809413434",
    "display" : "Acarbose 50 mg comprimido"
  },
  {
    "code" : "@brasil11225715326",
    "display" : "Acebrofilina 10 mg/mL xarope"
  },
  {
    "code" : "@brasil15361639804",
    "display" : "Acebrofilina 5 mg/mL gel"
  },
  {
    "code" : "@brasil10031395041",
    "display" : "Acebrofilina 5 mg/mL xarope"
  },
  {
    "code" : "@brasil17845149855",
    "display" : "Aceclofenaco 100 mg comprimido"
  },
  {
    "code" : "@brasil18395339657",
    "display" : "Aceclofenaco 15 mg/g creme"
  },
  {
    "code" : "@brasil14661950108",
    "display" : "Aceponato de Metilprednisolona 1 mg/g creme"
  },
  {
    "code" : "@brasil14533461903",
    "display" : "Aceponato de Metilprednisolona 1 mg/g loção"
  },
  {
    "code" : "@brasil19985230032",
    "display" : "Aceponato de Metilprednisolona 1 mg/mL solução"
  },
  {
    "code" : "@brasil12537636478",
    "display" : "Acetato de Clostebol 5 mg/g + Neomicina 5 mg/g creme"
  },
  {
    "code" : "@brasil14063335892",
    "display" : "Acetato de Clostebol 5 mg/g + Neomicina 5 mg/g creme vaginal"
  },
  {
    "code" : "@brasil13262060314",
    "display" : "Acetato de Dexametasona 16 mg/2 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19839601654",
    "display" : "Acetato de Glatirâmer 20 mg pó para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16961431284",
    "display" : "Acetato de Glatirâmer 20 mg/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil19825800180",
    "display" : "Acetato de Metilprednisolona 0,12% suspensão oftálmica"
  },
  {
    "code" : "@brasil18875092637",
    "display" : "Acetato de Metilprednisolona 200 mg/5 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16907362812",
    "display" : "Acetato de Metilprednisolona 40 mg/1 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10080245862",
    "display" : "Acetato de Metilprednisolona 80 mg/2 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14797509287",
    "display" : "Acetato de Noretisterona 10 mg comprimido"
  },
  {
    "code" : "@brasil19890114290",
    "display" : "Acetato de Racealfatocoferol 1.000 unidades internacionais cápsula"
  },
  {
    "code" : "@brasil16314771161",
    "display" : "Acetato de Racealfatocoferol 400 mg cápsula"
  },
  {
    "code" : "@brasil10969626223",
    "display" : "Acetato de Racealfatocoferol 400 unidades internacionais cápsula"
  },
  {
    "code" : "@brasil14221821318",
    "display" : "Acetato de Sódio 20 mEq/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16306757474",
    "display" : "Acetato de Triptorrelina 0,1 mg/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil14278890511",
    "display" : "Acetato de Triptorrelina 11,25 mg pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18480421171",
    "display" : "Acetato de Triptorrelina 11,25 mg/2 mL suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil10914469780",
    "display" : "Acetato de Triptorrelina 3,75 mg pó e diluente para suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil10341965508",
    "display" : "Acetato de Triptorrelina 3,75 mg pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18873156315",
    "display" : "Acetato de Zinco 1 mEq/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15078567260",
    "display" : "Acetato de Zuclopentixol 50 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17867958337",
    "display" : "Acetazolamida 250 mg comprimido"
  },
  {
    "code" : "@brasil16047114109",
    "display" : "Acetilcisteína 10 mg/mL + Tuaminoeptano 5 mg/mL solução nasal"
  },
  {
    "code" : "@brasil12649900653",
    "display" : "Acetilcisteína 100 mg granulado"
  },
  {
    "code" : "@brasil12054381017",
    "display" : "Acetilcisteína 11,5 mg/mL solução spray"
  },
  {
    "code" : "@brasil13006038602",
    "display" : "Acetilcisteína 20 mg/mL xarope"
  },
  {
    "code" : "@brasil11239736573",
    "display" : "Acetilcisteína 200 mg comprimido efervescente"
  },
  {
    "code" : "@brasil17479410707",
    "display" : "Acetilcisteína 200 mg granulado"
  },
  {
    "code" : "@brasil18047327377",
    "display" : "Acetilcisteína 300 mg/3 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16083298283",
    "display" : "Acetilcisteína 40 mg/mL xarope"
  },
  {
    "code" : "@brasil17983500460",
    "display" : "Acetilcisteína 600 mg comprimido efervescente"
  },
  {
    "code" : "@brasil19447351887",
    "display" : "Acetilcisteína 600 mg granulado"
  },
  {
    "code" : "@brasil16313627599",
    "display" : "Aciclovir 200 mg comprimido"
  },
  {
    "code" : "@brasil19699184678",
    "display" : "Aciclovir 250 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17808962581",
    "display" : "Aciclovir 250 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18928083951",
    "display" : "Aciclovir 30 mg/g pomada oftálmica"
  },
  {
    "code" : "@brasil17617636924",
    "display" : "Aciclovir 400 mg comprimido"
  },
  {
    "code" : "@brasil10494434926",
    "display" : "Aciclovir 50 mg/g (5%) creme"
  },
  {
    "code" : "@brasil17404320673",
    "display" : "Ácido Acético 2%"
  },
  {
    "code" : "@brasil11434748657",
    "display" : "Ácido Acético 3%"
  },
  {
    "code" : "@brasil14960781571",
    "display" : "Ácido Acético 5%"
  },
  {
    "code" : "@brasil12284659725",
    "display" : "Ácido Acetilsalicílico 100 mg + Carbonato de Magnésio 30 mg + Glicinato de Alumínio 15 mg comprimido"
  },
  {
    "code" : "@brasil17514022519",
    "display" : "Ácido Acetilsalicílico 100 mg + Mononitrato de Isossorbida 40 mg cápsula"
  },
  {
    "code" : "@brasil18518712638",
    "display" : "Ácido Acetilsalicílico 100 mg comprimido"
  },
  {
    "code" : "@brasil12722401014",
    "display" : "Ácido Acetilsalicílico 100 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil13272112795",
    "display" : "Ácido Acetilsalicílico 100 mg comprimido e Clopidogrel 75 mg comprimido"
  },
  {
    "code" : "@brasil18988849564",
    "display" : "Ácido Acetilsalicílico 100 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil14142558204",
    "display" : "Ácido Acetilsalicílico 100 mg comprimido mastigável"
  },
  {
    "code" : "@brasil17784482125",
    "display" : "Ácido Acetilsalicílico 200 mg + Carbonato de Magnésio 60 mg + Glicinato de Alumínio 30 mg comprimido"
  },
  {
    "code" : "@brasil17254217113",
    "display" : "Ácido Acetilsalicílico 200 mg comprimido"
  },
  {
    "code" : "@brasil10667938040",
    "display" : "Ácido Acetilsalicílico 250 mg + Paracetamol 200 mg + Cafeína 50 mg comprimido"
  },
  {
    "code" : "@brasil10002627427",
    "display" : "Ácido Acetilsalicílico 250 mg + Paracetamol 250 mg + Cafeína 65 mg comprimido"
  },
  {
    "code" : "@brasil15084283969",
    "display" : "Ácido Acetilsalicílico 300 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil14798527623",
    "display" : "Ácido Acetilsalicílico 300 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil10849223769",
    "display" : "Ácido Acetilsalicílico 325 mg comprimido"
  },
  {
    "code" : "@brasil10735984760",
    "display" : "Ácido Acetilsalicílico 400 mg + Ácido Ascórbico 200 mg comprimido"
  },
  {
    "code" : "@brasil19220676978",
    "display" : "Ácido Acetilsalicílico 400 mg + Ácido Ascórbico 240 mg comprimido efervescente"
  },
  {
    "code" : "@brasil11097392896",
    "display" : "Ácido Acetilsalicílico 400 mg + Cafeína 50 mg comprimido"
  },
  {
    "code" : "@brasil13514897573",
    "display" : "Ácido Acetilsalicílico 400 mg + Dexcloferniramina 1 mg + Fenilefrina 10 mg + Cafeína 30 mg comprimido"
  },
  {
    "code" : "@brasil14652560533",
    "display" : "Ácido Acetilsalicílico 500 mg + Cafeína 30 mg comprimido"
  },
  {
    "code" : "@brasil12202814566",
    "display" : "Ácido Acetilsalicílico 500 mg comprimido"
  },
  {
    "code" : "@brasil15650582764",
    "display" : "Ácido Acetilsalicílico 500 mg comprimido de liberação modificada"
  },
  {
    "code" : "@brasil13857331259",
    "display" : "Ácido Acetilsalicílico 500 mg comprimido efervescente"
  },
  {
    "code" : "@brasil19176163391",
    "display" : "Ácido Acetilsalicílico 650 mg + Cafeína 65 mg comprimido"
  },
  {
    "code" : "@brasil10775886894",
    "display" : "Ácido Acetilsalicílico 81 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil12334908313",
    "display" : "Ácido Acetilsalicílico 85 mg comprimido"
  },
  {
    "code" : "@brasil10846856636",
    "display" : "Ácido Alendrônico 10 mg comprimido"
  },
  {
    "code" : "@brasil13097338147",
    "display" : "Ácido Alendrônico 70 mg + Colecalciferol 2.800 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil13715786963",
    "display" : "Ácido Alendrônico 70 mg + Colecalciferol 5.600 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil13392882460",
    "display" : "Ácido Alendrônico 70 mg comprimido"
  },
  {
    "code" : "@brasil15478619322",
    "display" : "Ácido Alendrônico 70 mg comprimido e Carbonato de Cálcio 1,25 g (Cálcio 500 mg) + Colecalciferol 200 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil15666579542",
    "display" : "Ácido Ascórbico 1 g + Arginina 1 g comprimido efervescente"
  },
  {
    "code" : "@brasil11023170053",
    "display" : "Ácido Ascórbico 1 g + Citrato de Zinco 10 mg comprimido efervescente"
  },
  {
    "code" : "@brasil13220713959",
    "display" : "Ácido Ascórbico 1 g + Glicose 5 g granulado"
  },
  {
    "code" : "@brasil13561659606",
    "display" : "Ácido Ascórbico 1 g comprimido efervescente"
  },
  {
    "code" : "@brasil17528914395",
    "display" : "Ácido Ascórbico 1 g/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17208457724",
    "display" : "Ácido Ascórbico 2 g comprimido efervescente"
  },
  {
    "code" : "@brasil12546761335",
    "display" : "Ácido Ascórbico 200 mg/mL solução oral"
  },
  {
    "code" : "@brasil17475312944",
    "display" : "Ácido Ascórbico 250 mg comprimido vaginal"
  },
  {
    "code" : "@brasil11122546000",
    "display" : "Ácido Ascórbico 500 mg + Arginina 500 mg comprimido efervescente"
  },
  {
    "code" : "@brasil12023541834",
    "display" : "Ácido Ascórbico 500 mg + Carbonato de Cálcio 600 mg comprimido efervescente"
  },
  {
    "code" : "@brasil19414638073",
    "display" : "Ácido Ascórbico 500 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil15357310114",
    "display" : "Ácido Ascórbico 500 mg comprimido"
  },
  {
    "code" : "@brasil10102548095",
    "display" : "Ácido Ascórbico 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil14902831086",
    "display" : "Ácido Ascórbico 500 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16001500863",
    "display" : "Ácido Azeláico 150 mg/g gel"
  },
  {
    "code" : "@brasil19432392788",
    "display" : "Ácido Azeláico 200 mg/g creme"
  },
  {
    "code" : "@brasil10499662197",
    "display" : "Ácido Bórico 2%"
  },
  {
    "code" : "@brasil17615966578",
    "display" : "Ácido Bórico 3%"
  },
  {
    "code" : "@brasil18853072455",
    "display" : "Ácido Bórico 30 mg/g + Ácido Salicílico 3,52 mg/g + Enxofre 176 mg/g + Óxido de Zinco 117,3 mg/g pó"
  },
  {
    "code" : "@brasil10860170870",
    "display" : "Ácido Cítrico 70 mg/mL + Citrato de Sódio 98 mg/mL + Citrato de Potássio 108 mg/mL xarope"
  },
  {
    "code" : "@brasil12939482919",
    "display" : "Ácido Épsilon-Aminocaproico 1 g/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15518190538",
    "display" : "Ácido Épsilon-Aminocaproico 100 mg/mL xarope"
  },
  {
    "code" : "@brasil17381126103",
    "display" : "Ácido Épsilon-Aminocaproico 25 mg/mL + Benzoato de Sódio 50 mg/mL + Guaifenesina 10 mg/mL + Cloreto de Amônio 10 mg/mL xarope"
  },
  {
    "code" : "@brasil16644244477",
    "display" : "Ácido Épsilon-Aminocaproico 4 g/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19098677790",
    "display" : "Ácido Épsilon-Aminocaproico 500 mg comprimido"
  },
  {
    "code" : "@brasil17758414173",
    "display" : "Ácido Fólico 0,2 mg/mL solução oral"
  },
  {
    "code" : "@brasil19517213392",
    "display" : "Ácido Fólico 0,4 mg/mL solução oral"
  },
  {
    "code" : "@brasil17593860715",
    "display" : "Ácido Fólico 0,8 mg + Cianocobalamina 0,4 mg + Piridoxina 4 mg comprimido"
  },
  {
    "code" : "@brasil18503561594",
    "display" : "Ácido Fólico 2 mg comprimido"
  },
  {
    "code" : "@brasil19988975802",
    "display" : "Ácido Fólico 400 microgramas + Dextroalfatocoferol 10 mg cápsula"
  },
  {
    "code" : "@brasil14883001766",
    "display" : "Ácido Fólico 5 mg + Ácido Ascórbico 100 mg comprimido"
  },
  {
    "code" : "@brasil19733958493",
    "display" : "Ácido Fólico 5 mg comprimido"
  },
  {
    "code" : "@brasil17119167470",
    "display" : "Ácido Fólico 5 mg/mL solução oral"
  },
  {
    "code" : "@brasil16580846612",
    "display" : "Ácido Fólico 5%"
  },
  {
    "code" : "@brasil14569521688",
    "display" : "Ácido Fólico 800 microgramas + Acetato de Racealfatocoferol 20 mg cápsula"
  },
  {
    "code" : "@brasil10668413145",
    "display" : "Ácido Folínico 0,5 mg/mL solução oral"
  },
  {
    "code" : "@brasil10467029520",
    "display" : "Ácido Folínico 7,5 mg/mL solução oral"
  },
  {
    "code" : "@brasil15201957992",
    "display" : "Ácido Fusídico 20 mg/g + Acetato de Hidrocortisona 10 mg/g creme"
  },
  {
    "code" : "@brasil11256078183",
    "display" : "Ácido Fusídico 20 mg/g + Valerato de Betametasona 1 mg/g creme"
  },
  {
    "code" : "@brasil10022009908",
    "display" : "Ácido Fusídico 20 mg/g creme"
  },
  {
    "code" : "@brasil10777176050",
    "display" : "Ácido Gamaminobutírico 100 mg/mL + Lisina 100 mg/mL + Tiamina 4 mg/mL + Piridoxina 8 mg/mL + Cálcio 8 mg/mL xarope"
  },
  {
    "code" : "@brasil17668895428",
    "display" : "Ácido Gamaminobutírico 200 mg/mL xarope"
  },
  {
    "code" : "@brasil13508015845",
    "display" : "Ácido Gamaminobutírico 250 mg comprimido"
  },
  {
    "code" : "@brasil13775513071",
    "display" : "Ácido Gamaminobutírico 50 mg + Lisina 50 mg + Tiamina 2 mg + Piridoxina 4 mg + Cálcio 4 mg comprimido"
  },
  {
    "code" : "@brasil13945669543",
    "display" : "Ácido Hialurônico 2 mg/g creme"
  },
  {
    "code" : "@brasil15435752825",
    "display" : "Ácido Ibandrônico 150 mg comprimido"
  },
  {
    "code" : "@brasil15409353770",
    "display" : "Ácido Ibandrônico 3 mg/3 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil10253415963",
    "display" : "Ácido Mefenâmico 500 mg comprimido"
  },
  {
    "code" : "@brasil11397755546",
    "display" : "Ácido Nalidíxico 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil19002069083",
    "display" : "Ácido Nalidíxico 500 mg comprimido"
  },
  {
    "code" : "@brasil19408324591",
    "display" : "Ácido Nicotínico 1 g comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil16302680079",
    "display" : "Ácido Nicotínico 250 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil10755705870",
    "display" : "Ácido Nicotínico 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil10999468713",
    "display" : "Ácido Nicotínico 750 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil10992193054",
    "display" : "Ácido Paraminossalicílico 4 g granulado"
  },
  {
    "code" : "@brasil17367736413",
    "display" : "Ácido Salicílico 100 mg/mL solução"
  },
  {
    "code" : "@brasil18824858280",
    "display" : "Ácido Salicílico 170 mg/mL + Ácido Láctico 150 mg/mL solução tópica"
  },
  {
    "code" : "@brasil14495628441",
    "display" : "Ácido Salicílico 20 mg/mL + Coaltar 8,5 mg/mL xampu"
  },
  {
    "code" : "@brasil10056333634",
    "display" : "Ácido Salicílico 20mg/g"
  },
  {
    "code" : "@brasil14966488455",
    "display" : "Ácido Salicílico 270 mg/g gel"
  },
  {
    "code" : "@brasil16270009032",
    "display" : "Ácido Salicílico 280 mg/g pasta"
  },
  {
    "code" : "@brasil12744338318",
    "display" : "Ácido Salicílico 30 mg/g + Enxofre 100 mg/g sabonete"
  },
  {
    "code" : "@brasil10651072747",
    "display" : "Ácido Salicílico 30 mg/mL + Enxofre 30 mg/mL solução"
  },
  {
    "code" : "@brasil14176044978",
    "display" : "Ácido Salicílico 5% pomada"
  },
  {
    "code" : "@brasil14250097836",
    "display" : "Ácido Tióctico 600 mg comprimido"
  },
  {
    "code" : "@brasil14244282238",
    "display" : "Ácido Tranexâmico 250 mg comprimido"
  },
  {
    "code" : "@brasil11087267994",
    "display" : "Ácido Tranexâmico 250 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17232435248",
    "display" : "Ácido Tranexâmico 500 mg comprimido"
  },
  {
    "code" : "@brasil10539128640",
    "display" : "Ácido Tricloroacético 30% solução"
  },
  {
    "code" : "@brasil12526642606",
    "display" : "Ácido Tricloroacético 50% solução"
  },
  {
    "code" : "@brasil11015827422",
    "display" : "Ácido Tricloroacético 60% solução"
  },
  {
    "code" : "@brasil17499209601",
    "display" : "Ácido Tricloroacético 75% solução"
  },
  {
    "code" : "@brasil14448566048",
    "display" : "Ácido Tricloroacético 80% solução"
  },
  {
    "code" : "@brasil19745201745",
    "display" : "Ácido Tricloroacético 90% solução"
  },
  {
    "code" : "@brasil11639410760",
    "display" : "Ácido Undecilênico 2 mg/g pó"
  },
  {
    "code" : "@brasil10486004910",
    "display" : "Ácido Undecilênico 40 mg/mL solução"
  },
  {
    "code" : "@brasil18471117994",
    "display" : "Ácido Ursodesoxicólico 150 mg comprimido"
  },
  {
    "code" : "@brasil19622743565",
    "display" : "Ácido Ursodesoxicólico 300 mg comprimido"
  },
  {
    "code" : "@brasil12700364153",
    "display" : "Ácido Ursodesoxicólico 50 mg comprimido"
  },
  {
    "code" : "@brasil11465811087",
    "display" : "Ácido Valpróico 1 g/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14952278615",
    "display" : "Ácido Valpróico 200 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17428916614",
    "display" : "Ácido Valproico 250 mg cápsula"
  },
  {
    "code" : "@brasil10363960125",
    "display" : "Ácido Valproico 250 mg comprimido"
  },
  {
    "code" : "@brasil14003965111",
    "display" : "Ácido Valproico 50 mg/mL xarope"
  },
  {
    "code" : "@brasil17303247559",
    "display" : "Ácido valpróico 500 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil17725831936",
    "display" : "Ácido Valpróico 500 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16622874331",
    "display" : "Ácido Zoledrônico 4 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14562930597",
    "display" : "Ácido Zoledrônico 4 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12155721328",
    "display" : "Ácido Zoledrônico 4 mg/100 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11072216359",
    "display" : "Ácido Zoledrônico 4 mg/5 mL solução e diluente para injeção; frasco-ampola + bolsa"
  },
  {
    "code" : "@brasil10727847022",
    "display" : "Ácido Zoledrônico 4 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10377431436",
    "display" : "Ácido Zoledrônico 5 mg/100 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19147302133",
    "display" : "Acitretina 10 mg cápsula"
  },
  {
    "code" : "@brasil12883600202",
    "display" : "Acitretina 25 mg cápsula"
  },
  {
    "code" : "@brasil18666719595",
    "display" : "Adalimumabe 40 mg/0,8 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil18198420485",
    "display" : "Adalimumabe 40 mg/0,8 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10760607961",
    "display" : "Adapaleno 1 mg/g + Clindamicina 10 mg/g gel"
  },
  {
    "code" : "@brasil11695967503",
    "display" : "Adapaleno 1 mg/g + Clindamicina 10 mg/g gel de liberação prolongada"
  },
  {
    "code" : "@brasil15963778443",
    "display" : "Adapaleno 1 mg/g + Peróxido de Benzoíla 25 mg/g gel"
  },
  {
    "code" : "@brasil18699882027",
    "display" : "Adapaleno 1 mg/g creme"
  },
  {
    "code" : "@brasil18888478117",
    "display" : "Adapaleno 1 mg/g gel"
  },
  {
    "code" : "@brasil15485208401",
    "display" : "Adapaleno 3 mg/g gel"
  },
  {
    "code" : "@brasil11838882808",
    "display" : "Adefovir 10 mg comprimido"
  },
  {
    "code" : "@brasil14665898674",
    "display" : "Adenosina 6 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18837583704",
    "display" : "Afatinibe 20 mg comprimido"
  },
  {
    "code" : "@brasil12380148881",
    "display" : "Afatinibe 30 mg comprimido"
  },
  {
    "code" : "@brasil15387993598",
    "display" : "Afatinibe 40 mg comprimido"
  },
  {
    "code" : "@brasil19539918859",
    "display" : "Aflibercepte 100 mg/4 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19314645740",
    "display" : "Aflibercepte 11,12 mg/0,278 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14668964839",
    "display" : "Aflibercepte 200 mg/8 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15353857626",
    "display" : "Aflibercepte 6,6 mg/0,165 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil10077928937",
    "display" : "Agomelatina 25 mg comprimido"
  },
  {
    "code" : "@brasil16325797368",
    "display" : "Água do Mar 9 mg/mL solução spray"
  },
  {
    "code" : "@brasil16939773974",
    "display" : "Água para injeção 1 L Sistema Fechado; frasco-ampola"
  },
  {
    "code" : "@brasil13428970912",
    "display" : "Água para injeção 1 L; bolsa"
  },
  {
    "code" : "@brasil13950203836",
    "display" : "Água para injeção 10 mL; ampola"
  },
  {
    "code" : "@brasil16311637148",
    "display" : "Água para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "@brasil11625310387",
    "display" : "Água para injeção 100 mL; bolsa"
  },
  {
    "code" : "@brasil12516556644",
    "display" : "Água para injeção 100 mL; frasco-ampola"
  },
  {
    "code" : "@brasil15766175244",
    "display" : "Água para injeção 125 mL; bolsa"
  },
  {
    "code" : "@brasil10222668712",
    "display" : "Água para injeção 2 L; frasco-ampola"
  },
  {
    "code" : "@brasil13918676965",
    "display" : "Água para injeção 2 mL; ampola"
  },
  {
    "code" : "@brasil13957101202",
    "display" : "Água para injeção 20 mL; ampola"
  },
  {
    "code" : "@brasil11886982927",
    "display" : "Água para injeção 20 mL; frasco-ampola"
  },
  {
    "code" : "@brasil13074483276",
    "display" : "Água para injeção 250 mL; bolsa"
  },
  {
    "code" : "@brasil18304455081",
    "display" : "Água para injeção 250 mL; frasco-ampola"
  },
  {
    "code" : "@brasil18966367120",
    "display" : "Água para injeção 3 mL; ampola"
  },
  {
    "code" : "@brasil11989500495",
    "display" : "Água para injeção 4 mL; ampola"
  },
  {
    "code" : "@brasil18202079270",
    "display" : "Água para injeção 5 mL; ampola"
  },
  {
    "code" : "@brasil16527096000",
    "display" : "Água para injeção 50 mL; bolsa"
  },
  {
    "code" : "@brasil11624564482",
    "display" : "Água para injeção 50 mL; frasco-ampola"
  },
  {
    "code" : "@brasil19917370628",
    "display" : "Água para injeção 500 mL; bolsa"
  },
  {
    "code" : "@brasil12595909900",
    "display" : "Água para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "@brasil16259546638",
    "display" : "Água para irrigação 2 L; frasco-ampola"
  },
  {
    "code" : "@brasil10225598103",
    "display" : "Água para irrigação 3 L; bolsa"
  },
  {
    "code" : "@brasil14198978955",
    "display" : "Alanilglutamina 10 g/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11642199270",
    "display" : "Alanilglutamina 20 g/100 mL solução para injeção; bolsa"
  },
  {
    "code" : "@brasil11492635859",
    "display" : "Alanilglutamina 20 g/100 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15397743846",
    "display" : "Albendazol 200 mg comprimido"
  },
  {
    "code" : "@brasil12853358277",
    "display" : "Albendazol 40 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil18229034716",
    "display" : "Albendazol 400 mg comprimido"
  },
  {
    "code" : "@brasil19971868188",
    "display" : "Albendazol 400 mg comprimido mastigável"
  },
  {
    "code" : "@brasil16441231365",
    "display" : "Albendazol 80 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil16455372706",
    "display" : "Albumina Humana 100 mg/mL (10%) solução para injeção 50 mL; frasco-ampola"
  },
  {
    "code" : "@brasil15638129016",
    "display" : "Albumina Humana 20% solução para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "@brasil16493339645",
    "display" : "Albumina Humana 20% solução para injeção 100 mL; frasco-ampola"
  },
  {
    "code" : "@brasil15552311487",
    "display" : "Albumina Humana 20% solução para injeção 50 mL; frasco-ampola"
  },
  {
    "code" : "@brasil18281538809",
    "display" : "Albumina Humana 5% solução para injeção 100 mL; frasco-ampola"
  },
  {
    "code" : "@brasil14750759893",
    "display" : "Albumina Humana 5% solução para injeção 250 mL; frasco-ampola"
  },
  {
    "code" : "@brasil18909183346",
    "display" : "Albumina Humana 5% solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "@brasil13024648690",
    "display" : "Alcaftadina 2,5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil15987750873",
    "display" : "Alcatrão Mineral 1% pomada"
  },
  {
    "code" : "@brasil16195080433",
    "display" : "Álcool Etílico 70% Gel"
  },
  {
    "code" : "@brasil10429893917",
    "display" : "Álcool Etílico 70% Solução"
  },
  {
    "code" : "@brasil19685720724",
    "display" : "Álcool Etílico 99% Solução"
  },
  {
    "code" : "@brasil18090855941",
    "display" : "Álcool Polivinílico 14 mg/mL + Fenilefrina 1,2 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil12559758649",
    "display" : "Álcool Polivinílico 14 mg/mL + Povidona 6 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil17601257595",
    "display" : "Álcool Polivinílico 14 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil17421956011",
    "display" : "Aldesleucina 18.000.000 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10390310650",
    "display" : "Alentuzumabe 12 mg/1,2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17430749214",
    "display" : "Alentuzumabe 30 mg/ 1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13192487481",
    "display" : "Alfa-Agalsidase 3,5 mg/3,5 mL solução para injeção frasco-ampola"
  },
  {
    "code" : "@brasil17280583079",
    "display" : "Alfa-Aglicosidase 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19444822834",
    "display" : "Alfa1antitripsina 1 g /50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16227284878",
    "display" : "Alfa1antitripsina 1 g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14903648657",
    "display" : "Alfacalcidol 0,25 microgramas cápsula"
  },
  {
    "code" : "@brasil15148395284",
    "display" : "Alfacalcidol 1 micrograma cápsula"
  },
  {
    "code" : "@brasil11801048303",
    "display" : "Alfacorifolitropina 150 unidades internacionais (100 microgramas)/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil16869294554",
    "display" : "Alfacorifolitropina 200 unidades internacionais (150 microgramas)/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil16386089655",
    "display" : "Alfacoriogonadotropina 6.500 unidades internacionais (250 microgramas)/0,5 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil10846259528",
    "display" : "Alfacoriogonadotropina 6.500 unidades internacionais (250 microgramas)/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil14307164598",
    "display" : "Alfadarbepoetina 10 microgramas/0,4 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil10012479162",
    "display" : "Alfadarbepoetina 100 microgramas/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil11472625471",
    "display" : "Alfadarbepoetina 150 microgramas/0,3 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil17867574278",
    "display" : "Alfadarbepoetina 20 microgramas/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil16230284827",
    "display" : "Alfadarbepoetina 30 microgramas/0,3 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil18120424548",
    "display" : "Alfadarbepoetina 300 microgramas/0,6 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil17567245993",
    "display" : "Alfadarbepoetina 40 microgramas/0,4 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil17705113213",
    "display" : "Alfadarbepoetina 50 microgramas/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil12281455845",
    "display" : "Alfadarbepoetina 500 microgramas/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil14615332244",
    "display" : "Alfadarbepoetina 60 microgramas/0,3 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil17158212825",
    "display" : "Alfadarbepoetina 80 microgramas/0,4 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil18054423160",
    "display" : "Alfadornase 1 mg/mL solução para inalação 2,5 mL; ampola"
  },
  {
    "code" : "@brasil11368924584",
    "display" : "Alfaeftrenonacogue 1.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18489102811",
    "display" : "Alfaeftrenonacogue 2.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14593756639",
    "display" : "Alfaeftrenonacogue 250 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14381846620",
    "display" : "Alfaeftrenonacogue 3.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17411022172",
    "display" : "Alfaeftrenonacogue 500 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11326099010",
    "display" : "Alfaelosulfase 5 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16025282167",
    "display" : "Alfaepoetina 1.000 unidades internacionais/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil18879157190",
    "display" : "Alfaepoetina 1.000 unidades internacionais/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10423176176",
    "display" : "Alfaepoetina 10.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18127935404",
    "display" : "Alfaepoetina 10.000 unidades internacionais/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17815270867",
    "display" : "Alfaepoetina 10.000 unidades internacionais/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil12188790534",
    "display" : "Alfaepoetina 2.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15045180715",
    "display" : "Alfaepoetina 2.000 unidades internacionais/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil18670191901",
    "display" : "Alfaepoetina 2.000 unidades internacionais/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11537224399",
    "display" : "Alfaepoetina 3.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13184813532",
    "display" : "Alfaepoetina 3.000 unidades internacionais/0,3 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil19133939973",
    "display" : "Alfaepoetina 3.000 unidades internacionais/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18182034703",
    "display" : "Alfaepoetina 30.000 unidades internacionais/0,75 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil17807829162",
    "display" : "Alfaepoetina 4.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10985950631",
    "display" : "Alfaepoetina 4.000 unidades internacionais/0,4 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil16582990954",
    "display" : "Alfaepoetina 4.000 unidades internacionais/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19675504963",
    "display" : "Alfaepoetina 4.000 unidades internacionais/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil13335229867",
    "display" : "Alfaepoetina 40.000 unidades internacionais/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil12146127904",
    "display" : "Alfaeptacogue Ativado 100.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13942092417",
    "display" : "Alfaeptacogue Ativado 250.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10286968740",
    "display" : "Alfaeptacogue Ativado 50.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14468056254",
    "display" : "Alfaestradiol 0,25 mg/mL solução"
  },
  {
    "code" : "@brasil16131796142",
    "display" : "Alfafolitropina 1.050 unidades internacionais/2 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil19851798832",
    "display" : "Alfafolitropina 150 unidades internacionais + Alfalutropina 75 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13640886295",
    "display" : "Alfafolitropina 150 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17180050532",
    "display" : "Alfafolitropina 300 unidades internacionais (22 microgramas)/0,5 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil19935395743",
    "display" : "Alfafolitropina 37,5 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17932665558",
    "display" : "Alfafolitropina 450 unidades internacionais (33 microgramas)/0,75 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil14064102734",
    "display" : "Alfafolitropina 450 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18962259736",
    "display" : "Alfafolitropina 75 unidades internacionais (5,5 microgramas) pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16955011417",
    "display" : "Alfafolitropina 75 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11979637994",
    "display" : "Alfafolitropina 900 unidades internacionais (66 microgramas)/1,5 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil17816703250",
    "display" : "Alfainterferona 2a 1.000.000 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19270445953",
    "display" : "Alfainterferona 2a 3.000.000 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19069195284",
    "display" : "Alfainterferona 2a 3.000.000 unidades internacionais/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil10226101269",
    "display" : "Alfainterferona 2a 4.500.000 unidades internacionais/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil12781043007",
    "display" : "Alfainterferona 2a 5.000.000 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16540775415",
    "display" : "Alfainterferona 2a 9.000.000 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12673169319",
    "display" : "Alfainterferona 2a 9.000.000 unidades internacionais/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil12579925843",
    "display" : "Alfainterferona 2b 10.000.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19385850846",
    "display" : "Alfainterferona 2b 3.000.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15111836272",
    "display" : "Alfainterferona 2b 5.000.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12098219143",
    "display" : "Alfalutropina 75 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16857591741",
    "display" : "Alfalutropina 75 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14468526312",
    "display" : "Alfamoroctocogue 1.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18524065573",
    "display" : "Alfamoroctocogue 250 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11740511870",
    "display" : "Alfamoroctocogue 500 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10454815094",
    "display" : "Alfanonacogue 1.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12762443294",
    "display" : "Alfanonacogue 2.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15418849795",
    "display" : "Alfanonacogue 250 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12274010349",
    "display" : "Alfanonacogue 500 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18755308433",
    "display" : "Alfapeginterferona 2a 135 microgramas/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil12292339141",
    "display" : "Alfapeginterferona 2a 180 microgramas/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil18974076879",
    "display" : "Alfapeginterferona 2a 180 microgramas/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14756670559",
    "display" : "Alfapeginterferona 2a 90 microgramas/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil12833394363",
    "display" : "Alfapeginterferona 2b 108 microgramas pó e diluente para solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil16963184881",
    "display" : "Alfapeginterferona 2b 118,4 microgramas pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13900672907",
    "display" : "Alfapeginterferona 2b 135 microgramas pó e diluente para solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil16799966259",
    "display" : "Alfapeginterferona 2b 148 microgramas pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16011446513",
    "display" : "Alfapeginterferona 2b 162 microgramas pó e diluente para solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil17043141951",
    "display" : "Alfapeginterferona 2b 177,6 microgramas pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18862293201",
    "display" : "Alfapeginterferona 2b 202,5 microgramas pó e diluente para solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil13277962963",
    "display" : "Alfapeginterferona 2b 222 microgramas pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15769429015",
    "display" : "Alfapeginterferona 2b 296 microgramas pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17717719530",
    "display" : "Alfapeginterferona 2b 444 microgramas pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14057009548",
    "display" : "Alfapeginterferona 2b 67,5 microgramas pó e diluente para solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil16326540759",
    "display" : "Alfapeginterferona 2b 888 microgramas pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14832468045",
    "display" : "Alfaporactanto 120 mg/1,5 mL suspensão intratraqueal; frasco-ampola"
  },
  {
    "code" : "@brasil17894643969",
    "display" : "Alfaporactanto 240 mg/3 mL suspensão intratraqueal; frasco-ampola"
  },
  {
    "code" : "@brasil15148019374",
    "display" : "Alfasimoctocogue 1.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14099198200",
    "display" : "Alfasimoctocogue 2.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11552594211",
    "display" : "Alfasimoctocogue 250 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12606508984",
    "display" : "Alfasimoctocogue 500 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15538771463",
    "display" : "Alfataliglicerase 200 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14753790640",
    "display" : "Alfatirotropina 1,1 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19295340541",
    "display" : "Alfavelaglicerase 200 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19581075699",
    "display" : "Alfavelaglicerase 400 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13070279081",
    "display" : "Alfentanila 2,72 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12679875764",
    "display" : "Alfentanila 5,44 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15826372163",
    "display" : "Alfuzosina 10 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil13431931801",
    "display" : "Algestona 150 mg/1 mL + Estradiol 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19263858531",
    "display" : "Alginato de Sódio 100 mg/mL + Bicarbonato de Potássio 20 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil13330147938",
    "display" : "Alginato de Sódio 250 mg + Bicarbonato de Sódio 133,5 mg + Carbonato de Cálcio 80 mg comprimido mastigável"
  },
  {
    "code" : "@brasil10485697946",
    "display" : "Alginato de Sódio 50 mg/mL + Bicarbonato de Sódio 26,7 mg/mL + Carbonato de Cálcio 16 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil11997607974",
    "display" : "Alirocumabe 150 mg/1 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil14798889535",
    "display" : "Alirocumabe 75 mg/1 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil13711275404",
    "display" : "Alisquireno 150 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil13686675273",
    "display" : "Alisquireno 150 mg comprimido"
  },
  {
    "code" : "@brasil15693596782",
    "display" : "Alisquireno 300 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil10954260183",
    "display" : "Alisquireno 300 mg comprimido"
  },
  {
    "code" : "@brasil17366458843",
    "display" : "Alizaprida 50 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19191841890",
    "display" : "Almitrina 50 mg comprimido"
  },
  {
    "code" : "@brasil16148175303",
    "display" : "Alogliptina 12,5 mg + Metformina 1 g comprimido"
  },
  {
    "code" : "@brasil17462740676",
    "display" : "Alogliptina 12,5 mg + Metformina 500 mg comprimido"
  },
  {
    "code" : "@brasil13770892966",
    "display" : "Alogliptina 12,5 mg + Metformina 850 mg comprimido"
  },
  {
    "code" : "@brasil19067204331",
    "display" : "Alogliptina 12,5 mg comprimido"
  },
  {
    "code" : "@brasil19089539085",
    "display" : "Alogliptina 25 mg + Pioglitazona 15 mg comprimido"
  },
  {
    "code" : "@brasil16960204257",
    "display" : "Alogliptina 25 mg + Pioglitazona 30 mg comprimido"
  },
  {
    "code" : "@brasil12627994549",
    "display" : "Alogliptina 25 mg + Pioglitazona 45 mg comprimido"
  },
  {
    "code" : "@brasil12440136252",
    "display" : "Alogliptina 25 mg comprimido"
  },
  {
    "code" : "@brasil14999068578",
    "display" : "Alogliptina 6,25 mg comprimido"
  },
  {
    "code" : "@brasil12173511349",
    "display" : "Aloína 8 mg + Atropa Belladonna 10 mg + Cloreto de Metiltionínio 10 mg + Extrato de Cana-do-brejo 20 mg + Teobromina 30 mg comprimido"
  },
  {
    "code" : "@brasil17334158006",
    "display" : "Alopurinol 100 mg comprimido"
  },
  {
    "code" : "@brasil19589999995",
    "display" : "Alopurinol 300 mg comprimido"
  },
  {
    "code" : "@brasil15947526268",
    "display" : "Alprazolam 0,25 mg comprimido"
  },
  {
    "code" : "@brasil16995579828",
    "display" : "Alprazolam 0,5 mg comprimido"
  },
  {
    "code" : "@brasil12075004457",
    "display" : "Alprazolam 0,5 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil15417163356",
    "display" : "Alprazolam 0,5 mg comprimido sublingual"
  },
  {
    "code" : "@brasil18431558596",
    "display" : "Alprazolam 1 mg comprimido"
  },
  {
    "code" : "@brasil14936609671",
    "display" : "Alprazolam 1 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil17347964277",
    "display" : "Alprazolam 2 mg comprimido"
  },
  {
    "code" : "@brasil13150043219",
    "display" : "Alprazolam 2 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil19930101230",
    "display" : "Alprostadil 10 microgramas pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18001624062",
    "display" : "Alprostadil 20 microgramas pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10879439608",
    "display" : "Alprostadil 20 microgramas pó para solução para injeção; ampola"
  },
  {
    "code" : "@brasil19774500250",
    "display" : "Alprostadil 500 microgramas/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17871467607",
    "display" : "Alteplase 10 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14518775216",
    "display" : "Alteplase 20 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16551673481",
    "display" : "Alteplase 400 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18979473567",
    "display" : "Alteplase 50 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11573747601",
    "display" : "Amantadina 100 mg comprimido"
  },
  {
    "code" : "@brasil18357925001",
    "display" : "Ambrisentana 10 mg comprimido"
  },
  {
    "code" : "@brasil14971459278",
    "display" : "Ambrisentana 5 mg comprimido"
  },
  {
    "code" : "@brasil10886650057",
    "display" : "Ambroxol 20 mg pastilha"
  },
  {
    "code" : "@brasil17288450333",
    "display" : "Ambroxol 3 mg/mL xarope"
  },
  {
    "code" : "@brasil11725654444",
    "display" : "Ambroxol 6 mg/mL xarope"
  },
  {
    "code" : "@brasil19923882296",
    "display" : "Ambroxol 7,5 mg/mL solução"
  },
  {
    "code" : "@brasil14323747458",
    "display" : "Ambroxol 7,5 mg/mL solução para inalação 2 mL; flaconete"
  },
  {
    "code" : "@brasil15526993045",
    "display" : "Ambroxol 75 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil14704713572",
    "display" : "Amicacina 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15429222503",
    "display" : "Amicacina 250 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11420343704",
    "display" : "Amicacina 250 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13359642831",
    "display" : "Amicacina 500 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12341475701",
    "display" : "Aminaftona 75 mg comprimido"
  },
  {
    "code" : "@brasil18444010751",
    "display" : "Aminofilina 100 mg comprimido"
  },
  {
    "code" : "@brasil14897153687",
    "display" : "Aminofilina 200 mg comprimido"
  },
  {
    "code" : "@brasil12272390649",
    "display" : "Aminofilina 240 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13779102035",
    "display" : "Aminofilina 240 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18774664929",
    "display" : "Aminofilina 240 mg/mL solução oral"
  },
  {
    "code" : "@brasil16045837126",
    "display" : "Amiodarona 100 mg comprimido"
  },
  {
    "code" : "@brasil11203156523",
    "display" : "Amiodarona 150 mg/3 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16348257367",
    "display" : "Amiodarona 200 mg comprimido"
  },
  {
    "code" : "@brasil17049826081",
    "display" : "Amissulprida 200 mg comprimido"
  },
  {
    "code" : "@brasil16204358613",
    "display" : "Amissulprida 50 mg comprimido"
  },
  {
    "code" : "@brasil15049457581",
    "display" : "Amitriptilina 10 mg comprimido"
  },
  {
    "code" : "@brasil15517315029",
    "display" : "Amitriptilina 10 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil14125555579",
    "display" : "Amitriptilina 12,5 mg + Clordiazepóxido 5 mg cápsula"
  },
  {
    "code" : "@brasil19872315132",
    "display" : "Amitriptilina 25 mg comprimido"
  },
  {
    "code" : "@brasil10748500134",
    "display" : "Amitriptilina 75 mg comprimido"
  },
  {
    "code" : "@brasil11470242412",
    "display" : "Amorolfina 2,5 mg/g creme"
  },
  {
    "code" : "@brasil13028379056",
    "display" : "Amorolfina 50 mg/mL esmalte"
  },
  {
    "code" : "@brasil10907279364",
    "display" : "Amoxicilina 1 g + Ácido Clavulânico 200 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14746093436",
    "display" : "Amoxicilina 1 g + Ácido Clavulânico 200 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11008629398",
    "display" : "Amoxicilina 1 g + Sulbactam 500 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16021786494",
    "display" : "Amoxicilina 100 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil15441961804",
    "display" : "Amoxicilina 120 mg/mL + Ácido Clavulânico 8,58 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil15502781834",
    "display" : "Amoxicilina 200 mg/mL + Sulbactam 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil17429706086",
    "display" : "Amoxicilina 25 mg/mL + Ácido Clavulânico 6,25 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil19201198608",
    "display" : "Amoxicilina 25 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil14052388204",
    "display" : "Amoxicilina 40 mg/mL + Ácido Clavulânico 5,7 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil14337371972",
    "display" : "Amoxicilina 40 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil12689743127",
    "display" : "Amoxicilina 50 mg/mL + Ácido Clavulânico 12,5 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil16996767898",
    "display" : "Amoxicilina 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil18599704519",
    "display" : "Amoxicilina 500 mg + Ácido Clavulânico 100 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12577634650",
    "display" : "Amoxicilina 500 mg + Ácido Clavulânico 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15097499530",
    "display" : "Amoxicilina 500 mg + Ácido Clavulânico 125 mg comprimido"
  },
  {
    "code" : "@brasil19892832373",
    "display" : "Amoxicilina 500 mg + Sulbactam 250 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12898180271",
    "display" : "Amoxicilina 500 mg cápsula"
  },
  {
    "code" : "@brasil12138198372",
    "display" : "Amoxicilina 500 mg cápsula e Claritromicina 500 mg comprimido e Esomeprazol 20 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil16546064163",
    "display" : "Amoxicilina 500 mg comprimido"
  },
  {
    "code" : "@brasil11156371505",
    "display" : "Amoxicilina 80 mg/mL + Ácido Clavulânico 11,4 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil18502017293",
    "display" : "Amoxicilina 80 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil17338707871",
    "display" : "Amoxicilina 875 mg + Ácido Clavulânico 125 mg comprimido"
  },
  {
    "code" : "@brasil17207736443",
    "display" : "Amoxicilina 875 mg + Sulbactam 125 mg comprimido"
  },
  {
    "code" : "@brasil10752400885",
    "display" : "Amoxicilina 875 mg comprimido"
  },
  {
    "code" : "@brasil14680852725",
    "display" : "Ampicilina 1 g + Sulbactam 500 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11219507418",
    "display" : "Ampicilina 1 g + Sulbactam 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12778781318",
    "display" : "Ampicilina 1 g comprimido"
  },
  {
    "code" : "@brasil10292901954",
    "display" : "Ampicilina 1 g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11542603820",
    "display" : "Ampicilina 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17212964003",
    "display" : "Ampicilina 2 g + Sulbactam 1 g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18311837293",
    "display" : "Ampicilina 2 g + Sulbactam 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10338854546",
    "display" : "Ampicilina 3 g pó para suspensão oral"
  },
  {
    "code" : "@brasil17763373242",
    "display" : "Ampicilina 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil16296420306",
    "display" : "Ampicilina 500 mg cápsula"
  },
  {
    "code" : "@brasil11982865865",
    "display" : "Ampicilina 500 mg comprimido"
  },
  {
    "code" : "@brasil13764995273",
    "display" : "Ampicilina 500 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12600523700",
    "display" : "Ampicilina 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11159997517",
    "display" : "Amprenavir 15 mg/mL solução oral"
  },
  {
    "code" : "@brasil19404988258",
    "display" : "Amprenavir 150 mg cápsula"
  },
  {
    "code" : "@brasil15435358224",
    "display" : "Anagrelida 0,5 mg cápsula"
  },
  {
    "code" : "@brasil14932311431",
    "display" : "Anastrozol 1 mg comprimido"
  },
  {
    "code" : "@brasil14150018098",
    "display" : "Anfepramona 75 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil12715530117",
    "display" : "Anfotericina B 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16541130053",
    "display" : "Anfotericina B 50 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19570286159",
    "display" : "Anfotericina B 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12335225502",
    "display" : "Anfotericina B Complexo Lipídico 100 mg/20 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10456993951",
    "display" : "Anfotericina B Lipossomal 100 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17820670507",
    "display" : "Anfotericina B Lipossomal 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10207544825",
    "display" : "Anidulafungina 100 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19316342340",
    "display" : "Anidulafungina 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15469390846",
    "display" : "Anlodipino 10 mg + Atorvastatina 10 mg comprimido"
  },
  {
    "code" : "@brasil19462970893",
    "display" : "Anlodipino 10 mg + Atorvastatina 20 mg comprimido"
  },
  {
    "code" : "@brasil12997884668",
    "display" : "Anlodipino 10 mg + Ramipril 10 mg cápsula"
  },
  {
    "code" : "@brasil13459362668",
    "display" : "Anlodipino 10 mg comprimido"
  },
  {
    "code" : "@brasil11007842570",
    "display" : "Anlodipino 2,5 mg + Benazepril 10 mg cápsula"
  },
  {
    "code" : "@brasil12126308494",
    "display" : "Anlodipino 2,5 mg + Enalapril 10 mg cápsula"
  },
  {
    "code" : "@brasil11617581956",
    "display" : "Anlodipino 2,5 mg + Losartana 50 mg cápsula"
  },
  {
    "code" : "@brasil12468541498",
    "display" : "Anlodipino 2,5 mg + Ramipril 5 mg comprimido"
  },
  {
    "code" : "@brasil19571362750",
    "display" : "Anlodipino 2,5 mg comprimido"
  },
  {
    "code" : "@brasil16283034509",
    "display" : "Anlodipino 5 mg + Atenolol 25 mg cápsula"
  },
  {
    "code" : "@brasil13886368351",
    "display" : "Anlodipino 5 mg + Atenolol 25 mg comprimido"
  },
  {
    "code" : "@brasil16875247485",
    "display" : "Anlodipino 5 mg + Atenolol 50 mg cápsula"
  },
  {
    "code" : "@brasil11818972435",
    "display" : "Anlodipino 5 mg + Atenolol 50 mg comprimido"
  },
  {
    "code" : "@brasil17637634888",
    "display" : "Anlodipino 5 mg + Atorvastatina 10 mg comprimido"
  },
  {
    "code" : "@brasil15709364650",
    "display" : "Anlodipino 5 mg + Atorvastatina 20 mg comprimido"
  },
  {
    "code" : "@brasil17608015067",
    "display" : "Anlodipino 5 mg + Benazepril 10 mg cápsula"
  },
  {
    "code" : "@brasil11661150167",
    "display" : "Anlodipino 5 mg + Benazepril 20 mg cápsula"
  },
  {
    "code" : "@brasil15481705939",
    "display" : "Anlodipino 5 mg + Enalapril 10 mg cápsula"
  },
  {
    "code" : "@brasil11055756630",
    "display" : "Anlodipino 5 mg + Enalapril 20 mg cápsula"
  },
  {
    "code" : "@brasil15680280014",
    "display" : "Anlodipino 5 mg + Enalapril 20 mg comprimido"
  },
  {
    "code" : "@brasil10855852365",
    "display" : "Anlodipino 5 mg + Losartana 100 mg cápsula"
  },
  {
    "code" : "@brasil12549475749",
    "display" : "Anlodipino 5 mg + Losartana 50 mg cápsula"
  },
  {
    "code" : "@brasil14015344281",
    "display" : "Anlodipino 5 mg + Losartana 50 mg comprimido"
  },
  {
    "code" : "@brasil10352913364",
    "display" : "Anlodipino 5 mg + Ramipril 10 mg cápsula"
  },
  {
    "code" : "@brasil12435429376",
    "display" : "Anlodipino 5 mg + Ramipril 2,5 mg cápsula"
  },
  {
    "code" : "@brasil17517348691",
    "display" : "Anlodipino 5 mg + Ramipril 5 mg cápsula"
  },
  {
    "code" : "@brasil15887639684",
    "display" : "Anlodipino 5 mg comprimido"
  },
  {
    "code" : "@brasil15943804536",
    "display" : "Antimoniato de Meglumina 300 mg/mL solução para injeção 5 mL; ampola"
  },
  {
    "code" : "@brasil15075332600",
    "display" : "Apixabana 2,5 mg comprimido"
  },
  {
    "code" : "@brasil13091875996",
    "display" : "Apixabana 5 mg comprimido"
  },
  {
    "code" : "@brasil13366705506",
    "display" : "Aprepitanto 80 mg cápsula e Aprepitanto 125 mg cápsula"
  },
  {
    "code" : "@brasil11268168911",
    "display" : "Arginina 0,25mg/mL Xarope"
  },
  {
    "code" : "@brasil14571165463",
    "display" : "Arginina 1 g comprimido"
  },
  {
    "code" : "@brasil19355289840",
    "display" : "Arginina 1,5 g comprimido efervescente"
  },
  {
    "code" : "@brasil16796876587",
    "display" : "Arginina 185 mg + Ornitina 60 mg + Citrulina 5 mg comprimido"
  },
  {
    "code" : "@brasil16782900937",
    "display" : "Arginina 250 mg comprimido"
  },
  {
    "code" : "@brasil13033958116",
    "display" : "Arginina 250 mg/mL xarope"
  },
  {
    "code" : "@brasil12553433935",
    "display" : "Arginina 400 mg/mL xarope"
  },
  {
    "code" : "@brasil17085708589",
    "display" : "Arginina 500 mg comprimido"
  },
  {
    "code" : "@brasil13060577531",
    "display" : "Aripiprazol 10 mg comprimido"
  },
  {
    "code" : "@brasil14379598575",
    "display" : "Aripiprazol 15 mg comprimido"
  },
  {
    "code" : "@brasil19052305935",
    "display" : "Aripiprazol 20 mg comprimido"
  },
  {
    "code" : "@brasil14143063549",
    "display" : "Aripiprazol 30 mg comprimido"
  },
  {
    "code" : "@brasil13665295636",
    "display" : "Arteméter 20 mg + Lumefantrina 120 mg comprimido"
  },
  {
    "code" : "@brasil15015909348",
    "display" : "Arteméter 80 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10666176685",
    "display" : "Artesunato 100 mg + Mefloquina 220 mg comprimido"
  },
  {
    "code" : "@brasil15153384444",
    "display" : "Artesunato 25 mg + Mefloquina 55 mg comprimido"
  },
  {
    "code" : "@brasil13559999840",
    "display" : "Artesunato 60 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16776661784",
    "display" : "Asenapina 10 mg comprimido sublingual"
  },
  {
    "code" : "@brasil18431295991",
    "display" : "Asenapina 5 mg comprimido sublingual"
  },
  {
    "code" : "@brasil10764150889",
    "display" : "Asparaginase 10.000 unidades internacionais pó para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19676454381",
    "display" : "Aspartato de Magnésio 50 mg + Carbonato de Cálcio 1,25 g (Cálcio 500 mg) + Ranitidina 150 mg + Colecalciferol 400 unidades internacionais cápsula"
  },
  {
    "code" : "@brasil14826781659",
    "display" : "Aspartato de Ornitina 5 g/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11377281742",
    "display" : "Atazanavir 150 mg cápsula"
  },
  {
    "code" : "@brasil16212497422",
    "display" : "Atazanavir 200 mg cápsula"
  },
  {
    "code" : "@brasil18123066757",
    "display" : "Atazanavir 300 mg cápsula"
  },
  {
    "code" : "@brasil19820724872",
    "display" : "Atenolol 100 mg + Clortalidona 25 mg comprimido"
  },
  {
    "code" : "@brasil10110905085",
    "display" : "Atenolol 100 mg comprimido"
  },
  {
    "code" : "@brasil10850918441",
    "display" : "Atenolol 25 mg + Clortalidona 12,5 mg comprimido"
  },
  {
    "code" : "@brasil17739192038",
    "display" : "Atenolol 25 mg comprimido"
  },
  {
    "code" : "@brasil10529810329",
    "display" : "Atenolol 50 mg + Clortalidona 12,5 mg comprimido"
  },
  {
    "code" : "@brasil16623758436",
    "display" : "Atenolol 50 mg comprimido"
  },
  {
    "code" : "@brasil19761194668",
    "display" : "Atorvastatina 10 mg comprimido"
  },
  {
    "code" : "@brasil12640979561",
    "display" : "Atorvastatina 20 mg comprimido"
  },
  {
    "code" : "@brasil12874912760",
    "display" : "Atorvastatina 40 mg comprimido"
  },
  {
    "code" : "@brasil18812069861",
    "display" : "Atorvastatina 80 mg comprimido"
  },
  {
    "code" : "@brasil10520364930",
    "display" : "Atosibana 6,75 mg/0,9 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19397283175",
    "display" : "Atosibana 7,5 mg/mL solução para injeção 5 mL; frasco-ampola"
  },
  {
    "code" : "@brasil19033311034",
    "display" : "Atropina 0,25 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18030119497",
    "display" : "Atropina 0,5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18164376482",
    "display" : "Atropina 0,5 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18247045098",
    "display" : "Atropina 10 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil10706731499",
    "display" : "Atropina 5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil19889457316",
    "display" : "Axitinibe 1 mg comprimido"
  },
  {
    "code" : "@brasil10980465933",
    "display" : "Axitinibe 5 mg comprimido"
  },
  {
    "code" : "@brasil15250970417",
    "display" : "Azacitidina 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11872757850",
    "display" : "Azacitidina 100 mg pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19053267908",
    "display" : "Azatioprina 50 mg comprimido"
  },
  {
    "code" : "@brasil12569561704",
    "display" : "Azelastina 1 mg/mL solução aerossol"
  },
  {
    "code" : "@brasil12595569408",
    "display" : "Azelastina 1 mg/mL solução spray"
  },
  {
    "code" : "@brasil13507556451",
    "display" : "Azelastina 137 microgramas/dose + Fluticasona 50 microgramas/dose suspensão spray"
  },
  {
    "code" : "@brasil17519033202",
    "display" : "Azilsartana Medoxomila 20 mg + Clortalidona 12,5 mg comprimido"
  },
  {
    "code" : "@brasil14108108163",
    "display" : "Azilsartana Medoxomila 40 mg + Clortalidona 12,5 mg comprimido"
  },
  {
    "code" : "@brasil18889679980",
    "display" : "Azilsartana Medoxomila 40 mg + Clortalidona 25 mg comprimido"
  },
  {
    "code" : "@brasil18219908165",
    "display" : "Azilsartana Medoxomila 40 mg comprimido"
  },
  {
    "code" : "@brasil18363857061",
    "display" : "Azilsartana Medoxomila 80 mg comprimido"
  },
  {
    "code" : "@brasil12617753121",
    "display" : "Azitromicina 1 g comprimido"
  },
  {
    "code" : "@brasil16681405310",
    "display" : "Azitromicina 1,5 g pó para suspensão oral"
  },
  {
    "code" : "@brasil17096750843",
    "display" : "Azitromicina 40 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil18704124341",
    "display" : "Azitromicina 500 mg cápsula"
  },
  {
    "code" : "@brasil12624051804",
    "display" : "Azitromicina 500 mg comprimido"
  },
  {
    "code" : "@brasil14967909626",
    "display" : "Azitromicina 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12583296812",
    "display" : "Azitromicina 600 mg pó para suspensão oral"
  },
  {
    "code" : "@brasil18915829422",
    "display" : "Azitromicina 900 mg pó para suspensão oral"
  },
  {
    "code" : "@brasil15349975716",
    "display" : "Aztreonam 1 g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10364414070",
    "display" : "Aztreonam 1 g pó e diluente para solução para injeção; frasco-ampola + bolsa"
  },
  {
    "code" : "@brasil16665482311",
    "display" : "Aztreonam 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15056349684",
    "display" : "Bacillus cereus 1.000.000 endósporos/mL suspensão oral"
  },
  {
    "code" : "@brasil19053175874",
    "display" : "Baclofeno 10 mg comprimido"
  },
  {
    "code" : "@brasil18758826569",
    "display" : "Baclofeno 20 mg comprimido"
  },
  {
    "code" : "@brasil18041676884",
    "display" : "Bambuterol 1 mg/mL solução oral"
  },
  {
    "code" : "@brasil13633389167",
    "display" : "Bamifilina 300 mg comprimido"
  },
  {
    "code" : "@brasil17342960513",
    "display" : "Bamifilina 600 mg comprimido"
  },
  {
    "code" : "@brasil11171940034",
    "display" : "Basiliximabe 20 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10052184154",
    "display" : "Basiliximabe 20 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17764415597",
    "display" : "Beclometasona 100 microgramas/dose + Formoterol 6 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "@brasil15818604635",
    "display" : "Beclometasona 100 microgramas/dose + Formoterol 6 microgramas/dose solução aerossol; inalador"
  },
  {
    "code" : "@brasil16969685885",
    "display" : "Beclometasona 100 microgramas/dose solução aerossol; inalador"
  },
  {
    "code" : "@brasil15502404294",
    "display" : "Beclometasona 100 microgramas/dose suspensão spray"
  },
  {
    "code" : "@brasil13224013160",
    "display" : "Beclometasona 200 microgramas cápsula para inalação"
  },
  {
    "code" : "@brasil11781884190",
    "display" : "Beclometasona 200 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "@brasil17180592590",
    "display" : "Beclometasona 200 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "@brasil13210773609",
    "display" : "Beclometasona 200 microgramas/dose solução aerossol; inalador"
  },
  {
    "code" : "@brasil16805578176",
    "display" : "Beclometasona 250 microgramas/dose solução aerossol; inalador"
  },
  {
    "code" : "@brasil11836539377",
    "display" : "Beclometasona 250 microgramas/dose solução oral"
  },
  {
    "code" : "@brasil12123065684",
    "display" : "Beclometasona 400 micrograma cápsula para inalação"
  },
  {
    "code" : "@brasil13613357676",
    "display" : "Beclometasona 400 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "@brasil17532192473",
    "display" : "Beclometasona 400 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "@brasil10368179221",
    "display" : "Beclometasona 400 microgramas/mL + Salbutamol 800 microgramas/mL suspensão para inalação 2 mL; flaconete"
  },
  {
    "code" : "@brasil19081511252",
    "display" : "Beclometasona 400 microgramas/mL suspensão para inalação 2 mL; flaconete"
  },
  {
    "code" : "@brasil11982990168",
    "display" : "Beclometasona 50 microgramas/dose + Salbutamol 100 microgramas/dose suspensão aerossol; inalador"
  },
  {
    "code" : "@brasil17546884841",
    "display" : "Beclometasona 50 microgramas/dose solução aerossol; inalador"
  },
  {
    "code" : "@brasil16043298481",
    "display" : "Beclometasona 50 microgramas/dose suspensão spray"
  },
  {
    "code" : "@brasil13100097199",
    "display" : "Belatacepte 250 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16362711204",
    "display" : "Belimumabe 120 mg pó para solução para injeção; ampola"
  },
  {
    "code" : "@brasil17427840042",
    "display" : "Belimumabe 120 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14810833328",
    "display" : "Belimumabe 400 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10241426927",
    "display" : "Bemiparina Sódica 10.000 unidades internacionais/0,4 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil17691314840",
    "display" : "Bemiparina Sódica 2.500 unidades internacionais/0,2 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil17732293732",
    "display" : "Bemiparina Sódica 3.500 unidades internacionais/0,2 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil14740741358",
    "display" : "Bemiparina Sódica 5.000 unidades internacionais/0,2 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil16941133751",
    "display" : "Bemiparina Sódica 7.500 unidades internacionais/0,3 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil11532751377",
    "display" : "Benazepril 10 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil18374221517",
    "display" : "Benazepril 10 mg comprimido"
  },
  {
    "code" : "@brasil18467280693",
    "display" : "Benazepril 5 mg + Hidroclorotiazida 6,25 mg comprimido"
  },
  {
    "code" : "@brasil17633914747",
    "display" : "Benazepril 5 mg comprimido"
  },
  {
    "code" : "@brasil11535327490",
    "display" : "Benciclano 100 mg comprimido"
  },
  {
    "code" : "@brasil16045786314",
    "display" : "Benciclano 200 mg comprimido"
  },
  {
    "code" : "@brasil12957927465",
    "display" : "Bendamustina 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13671851812",
    "display" : "Benfotiamina 150 mg comprimido"
  },
  {
    "code" : "@brasil12329063612",
    "display" : "Benzbromarona 100 mg comprimido"
  },
  {
    "code" : "@brasil19029550661",
    "display" : "Benzidamina 1,5 mg/mL colutório"
  },
  {
    "code" : "@brasil12230737117",
    "display" : "Benzidamina 1,5 mg/mL colutório spray"
  },
  {
    "code" : "@brasil17171060503",
    "display" : "Benzidamina 3 mg pastilha"
  },
  {
    "code" : "@brasil12951195790",
    "display" : "Benzidamina 30 mg/mL solução oral"
  },
  {
    "code" : "@brasil13610837591",
    "display" : "Benzidamina 5 mg/g creme"
  },
  {
    "code" : "@brasil16364619745",
    "display" : "Benzidamina 50 mg/mL solução vaginal"
  },
  {
    "code" : "@brasil13394389191",
    "display" : "Benzidamina 500 mg pó"
  },
  {
    "code" : "@brasil10483444993",
    "display" : "Benzilpenicilina Benzatina 1.200.000 unidades internacionais pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11593824019",
    "display" : "Benzilpenicilina Benzatina 1.200.000 unidades internacionais pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16518785427",
    "display" : "Benzilpenicilina Benzatina 1.200.000 unidades/ 4 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17812455385",
    "display" : "Benzilpenicilina Benzatina 600.000 unidades internacionais pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14092238938",
    "display" : "Benzilpenicilina Benzatina 600.000 unidades internacionais pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15375084796",
    "display" : "Benzilpenicilina Potássica 1.000.000 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11410290179",
    "display" : "Benzilpenicilina Potássica 1.000.000 unidades internacionais/2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14746290597",
    "display" : "Benzilpenicilina Potássica 5.000.000 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11548569705",
    "display" : "Benzilpenicilina Procaína 300.000 unidades internacionais + Benzilpenicilina Potássica 100.000 unidades internacionais pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18727415070",
    "display" : "Benzilpenicilina Procaína 300.000 unidades internacionais + Benzilpenicilina Potássica 100.000 unidades internacionais pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10232382769",
    "display" : "Benznidazol 100 mg comprimido"
  },
  {
    "code" : "@brasil16773940012",
    "display" : "Benznidazol 12,5 mg comprimido"
  },
  {
    "code" : "@brasil14388589777",
    "display" : "Benzoato de Benzila 0,2 mL/mL emulsão"
  },
  {
    "code" : "@brasil10577912982",
    "display" : "Benzoato de Benzila 0,25 mL/mL emulsão"
  },
  {
    "code" : "@brasil12094046884",
    "display" : "Benzoato de Benzila 100 mg/g sabonete"
  },
  {
    "code" : "@brasil16567704207",
    "display" : "Benzoato de Benzila 250 mg/mL emulsão"
  },
  {
    "code" : "@brasil12584141354",
    "display" : "Benzoato de Sódio 100 mg/mL solução oral"
  },
  {
    "code" : "@brasil11006503328",
    "display" : "Benzoato de Sódio 200 mg/mL xarope"
  },
  {
    "code" : "@brasil16520181349",
    "display" : "Benzocaína 0,2 mg/mL + Borato de Sódio 60 mg/mL + Cloreto de Cetilpiridínio 1 mg/mL colutório"
  },
  {
    "code" : "@brasil11427497053",
    "display" : "Benzocaína 1,25 mg/g + Epinefrina 6,25/g microgramas + Fenol 5 mg/g + Mentol 0,75 mg/g + Extrato de Erva-de-bicho 75 mg/g + Extrato de Hamamelis virginiana 50 mg/g + Extrato de Sambaíba 50 mg/g pomada retal"
  },
  {
    "code" : "@brasil19871976839",
    "display" : "Benzocaína 200 mg/g gel"
  },
  {
    "code" : "@brasil13844568619",
    "display" : "Benzocaína 45 mg/g + Triclosana 5 mg/g + Mentol 5 mg/g creme"
  },
  {
    "code" : "@brasil16116044851",
    "display" : "Benzocaína 45 mg/g + Triclosana 5 mg/g + Mentol 5 mg/g solução aerossol"
  },
  {
    "code" : "@brasil16951779690",
    "display" : "Benzocaína 5 mg + Cloreto de Dequalínio 0,25 mg pastilha"
  },
  {
    "code" : "@brasil17868699232",
    "display" : "Benzocaína 5 mg/mL + Tirotricina 1 mg/mL solução spray"
  },
  {
    "code" : "@brasil15098708535",
    "display" : "Benzocaína 6 mg/g + Bicarbonato de Sódio 884 mg/g + Cloreto de Potássio 110 mg/g pó"
  },
  {
    "code" : "@brasil11429238394",
    "display" : "Benzoilmetronidazol 40 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil19406347449",
    "display" : "Benzoilmetronidazol 62,5 mg/g + Nistatina 25.000 unidades internacionais/g + Cloreto de Benzalcônio 1,25 mg/g creme vaginal"
  },
  {
    "code" : "@brasil11394294174",
    "display" : "Beractanto 100 mg/4 mL suspensão intratraqueal; frasco-ampola"
  },
  {
    "code" : "@brasil15544981513",
    "display" : "Beractanto 200 mg/8 mL suspensão intratraqueal; frasco-ampola"
  },
  {
    "code" : "@brasil17898840453",
    "display" : "Besifloxacino 6 mg/mL (0,6%) solução oftálmica"
  },
  {
    "code" : "@brasil17047663969",
    "display" : "Besilato de Atracúrio 25 mg/2,5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19968490850",
    "display" : "Besilato de Atracúrio 50 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15972353214",
    "display" : "Besilato de Cisatracúrio 10 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18141966272",
    "display" : "Besilato de Cisatracúrio 150 mg/30 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12653668673",
    "display" : "Besilato de Cisatracúrio 20 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11943432130",
    "display" : "Beta-agalsidase 35 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14459757835",
    "display" : "Beta-agalsidase 5 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19913325857",
    "display" : "Betacaroteno 5 mg cápsula"
  },
  {
    "code" : "@brasil16201093275",
    "display" : "Betaepoetina 10.000 unidades internacionais/0,6 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil16026779109",
    "display" : "Betaepoetina Metoxipolietilenoglicol 100 microgramas/0,3 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil19947336602",
    "display" : "Betaepoetina Metoxipolietilenoglicol 120 microgramas/0,3 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil18439720474",
    "display" : "Betaepoetina Metoxipolietilenoglicol 150 microgramas/0,3 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil12454618086",
    "display" : "Betaepoetina Metoxipolietilenoglicol 200 microgramas/0,3 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil19787103615",
    "display" : "Betaepoetina Metoxipolietilenoglicol 360 microgramas/0,6 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil18853939545",
    "display" : "Betaepoetina Metoxipolietilenoglicol 50 microgramas/0,3 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil11571664130",
    "display" : "Betaepoetina Metoxipolietilenoglicol 75 microgramas/0,3 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil17440444143",
    "display" : "Betafolitropina 100 unidades internacionais/0,5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11831455352",
    "display" : "Betafolitropina 300 unidades internacionais/0,48 mL solução para injeção; carpule"
  },
  {
    "code" : "@brasil11371924635",
    "display" : "Betafolitropina 50 unidades internacionais/0,5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19970403116",
    "display" : "Betafolitropina 600 unidades internacionais/0,84 mL solução para injeção; carpule"
  },
  {
    "code" : "@brasil15158502770",
    "display" : "Betainterferona 1a 12.000.000 unidades internacionais (44 microgramas)/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil14538291052",
    "display" : "Betainterferona 1a 132 microgramas/1,5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11498469477",
    "display" : "Betainterferona 1a 6.000.000 unidades internacionais (22 microgramas)/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil14535643209",
    "display" : "Betainterferona 1a 6.000.000 unidades internacionais (30 microgramas) solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13092156352",
    "display" : "Betainterferona 1a 6.000.000 unidades internacionais (30 microgramas)/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil18575681668",
    "display" : "Betainterferona 1a 66 microgramas/1,5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10590632771",
    "display" : "Betainterferona 1b 9.600.000 unidades internacionais (300 microgramas) pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12907300686",
    "display" : "Betainterferona 1b 9.600.000 unidades internacionais (300 microgramas) pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19244826163",
    "display" : "Betaistina 16 mg comprimido"
  },
  {
    "code" : "@brasil18736710433",
    "display" : "Betaistina 24 mg comprimido"
  },
  {
    "code" : "@brasil11602868782",
    "display" : "Betaistina 8 mg comprimido"
  },
  {
    "code" : "@brasil16768455919",
    "display" : "Betametasona 0,1 mg/ mL elixir"
  },
  {
    "code" : "@brasil13908370241",
    "display" : "Betametasona 0,5 mg comprimido"
  },
  {
    "code" : "@brasil11547690276",
    "display" : "Betametasona 0,5 mg/mL solução oral"
  },
  {
    "code" : "@brasil10131548642",
    "display" : "Betametasona 1 mg/mL + Clorfenesina 10 mg/mL + Tetracaína 5 mg/mL solução otológica"
  },
  {
    "code" : "@brasil16911319927",
    "display" : "Betametasona 2 mg comprimido"
  },
  {
    "code" : "@brasil19139742177",
    "display" : "Betametasona 4 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18810006488",
    "display" : "Betametildigoxina 0,1 mg comprimido"
  },
  {
    "code" : "@brasil10154191599",
    "display" : "Betanecol 10 mg cápsula"
  },
  {
    "code" : "@brasil12044397919",
    "display" : "Betapeginterferona 1a 125 microgramas/0,5 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil10494322170",
    "display" : "Betapeginterferona 1a 125 microgramas/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil11661814600",
    "display" : "Betapeginterferona 1a 63 microgramas/0,5 mL solução para injeção; dispositivo para injeção e Betapeginterferona 1a 94 microgramas/0,5 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil16826106798",
    "display" : "Betapeginterferona 1a 63 microgramas/0,5 mL solução para injeção; seringa preenchida e Betapeginterferona 1a 94 microgramas/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil12332063513",
    "display" : "Betaxolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil14040890412",
    "display" : "Bevacizumabe 100 mg/4 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14716779322",
    "display" : "Bevacizumabe 400 mg/16 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11292174747",
    "display" : "Bezafibrato 200 mg comprimido"
  },
  {
    "code" : "@brasil12408133057",
    "display" : "Bezafibrato 400 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil19350384853",
    "display" : "Bicalutamida 50 mg comprimido"
  },
  {
    "code" : "@brasil13507692322",
    "display" : "Bicarbonato de Sódio 1,64 g + Carbonato de Sódio 400 mg + Ácido Acetilsalicílico 325 mg + Ácido Cítrico 1,5 g comprimido efervescente"
  },
  {
    "code" : "@brasil10452309995",
    "display" : "Bicarbonato de Sódio 1,85 g + Carbonato de Sódio 400 mg + Ácido Acetilsalicílico 325 mg + Ácido Cítrico 1,41 g comprimido efervescente"
  },
  {
    "code" : "@brasil19548039014",
    "display" : "Bicarbonato de Sódio 10% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "@brasil13640547732",
    "display" : "Bicarbonato de Sódio 2,15 g + Ácido Cítrico 2,15 g + Carbonato de Sódio 500 mg pó efervescente"
  },
  {
    "code" : "@brasil16496799192",
    "display" : "Bicarbonato de Sódio 2,24 g + Ácido Cítrico 2,13 g + Carbonato de Sódio 500 mg pó efervescente"
  },
  {
    "code" : "@brasil18321368104",
    "display" : "Bicarbonato de Sódio 2,28 g + Ácido Cítrico 2,17 g + Carbonato de Sódio 490 mg pó efervescente"
  },
  {
    "code" : "@brasil16919781607",
    "display" : "Bicarbonato de Sódio 2,3 g + Ácido Cítrico 2,2 g + Carbonato de Sódio 500 mg pó efervescente"
  },
  {
    "code" : "@brasil17414675658",
    "display" : "Bicarbonato de Sódio 2,31 g + Ácido Cítrico 2,13 g + Carbonato de Sódio 500 mg pó efervescente"
  },
  {
    "code" : "@brasil18600805817",
    "display" : "Bicarbonato de Sódio 2,31 g + Ácido Cítrico 2,19 g + Carbonato de Sódio 450 mg pó efervescente"
  },
  {
    "code" : "@brasil13758296204",
    "display" : "Bicarbonato de Sódio 2,31 g + Carbonato de Sódio 450 mg granulado efervescente"
  },
  {
    "code" : "@brasil18800390937",
    "display" : "Bicarbonato de Sódio 3,2 g + Carbonato de Cálcio 738,8 mg + Carbonato de Magnésio 738,8 mg + Carbonato de Bismuto 178,7 mg granulado"
  },
  {
    "code" : "@brasil13955011193",
    "display" : "Bicarbonato de Sódio 430 mg/g + Ácido Cítrico 430 mg/g + Carbonato de Sódio 100 mg/g  pó efervescente"
  },
  {
    "code" : "@brasil19377555025",
    "display" : "Bicarbonato de Sódio 448 mg/g + Ácido Cítrico 426 mg/g + Carbonato de Sódio 100 mg/g  pó efervescente"
  },
  {
    "code" : "@brasil12148614312",
    "display" : "Bicarbonato de Sódio 456 mg/g + Ácido Cítrico 434 mg/g + Carbonato de Sódio 98 mg/g  pó efervescente"
  },
  {
    "code" : "@brasil14923380243",
    "display" : "Bicarbonato de Sódio 460 mg/g + Ácido Cítrico 440 mg/g + Carbonato de Sódio 100 mg/g  pó efervescente"
  },
  {
    "code" : "@brasil15616854069",
    "display" : "Bicarbonato de Sódio 462 mg/g + Ácido Cítrico 426 mg/g + Carbonato de Sódio 100 mg/g  pó efervescente"
  },
  {
    "code" : "@brasil18859942664",
    "display" : "Bicarbonato de Sódio 462 mg/g + Ácido Cítrico 438 mg/g + Carbonato de Sódio 90 mg/g  granulado efervescente"
  },
  {
    "code" : "@brasil18260557713",
    "display" : "Bicarbonato de Sódio 649 mg/g + Carbonato de Cálcio 146,67 mg/g + Carbonato de Magnésio 146,67 mg/g + Carbonato de Bismuto 35,8 mg/g pó para solução oral"
  },
  {
    "code" : "@brasil13972693469",
    "display" : "Bicarbonato de Sódio 8,4% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "@brasil19726407488",
    "display" : "Bicarbonato de Sódio 8,4% solução para injeção 20 mL; ampola"
  },
  {
    "code" : "@brasil14178672956",
    "display" : "Bicarbonato de Sódio 8,4% solução para injeção 250 mL; bolsa"
  },
  {
    "code" : "@brasil18497010112",
    "display" : "Bicarbonato de Sódio 8,4% solução para injeção 250 mL; frasco-ampola"
  },
  {
    "code" : "@brasil17153379568",
    "display" : "Bicarbonato de Sódio 84 mg/mL (8,4%) solução para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "@brasil19101366807",
    "display" : "Bicarbonato de Sódio 84 mg/mL (8,4%) solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "@brasil17121120388",
    "display" : "Bifonazol 10 mg/g creme"
  },
  {
    "code" : "@brasil12652841295",
    "display" : "Bilastina 20 mg comprimido"
  },
  {
    "code" : "@brasil14777275559",
    "display" : "Bimatoprosta 0,1 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil10431438367",
    "display" : "Bimatoprosta 0,3 mg/mL + Timolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil18603116140",
    "display" : "Bimatoprosta 0,3 mg/mL solução"
  },
  {
    "code" : "@brasil12796644057",
    "display" : "Bimatoprosta 0,3 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil18140248736",
    "display" : "Biotina 2,5 mg cápsula"
  },
  {
    "code" : "@brasil12875400335",
    "display" : "Biperideno 2 mg comprimido"
  },
  {
    "code" : "@brasil15375423993",
    "display" : "Biperideno 4 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil16282292943",
    "display" : "Biperideno 5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18004807742",
    "display" : "Bisacodil 5 mg + Docusato de Sódio 60 mg comprimido"
  },
  {
    "code" : "@brasil15365042941",
    "display" : "Bisacodil 5 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil15979966245",
    "display" : "Bisglicinato Ferroso 15 mg/mL (Ferro 3 mg/mL) + Ácido Fólico 0,5 mg/mL solução oral"
  },
  {
    "code" : "@brasil12036383497",
    "display" : "Bisglicinato Ferroso 15 mg/mL (Ferro 3 mg/mL) solução oral"
  },
  {
    "code" : "@brasil11846178500",
    "display" : "Bisglicinato Ferroso 150 mg (Ferro 30 mg) + Ácido Fólico 5 mg comprimido"
  },
  {
    "code" : "@brasil10147922941",
    "display" : "Bisglicinato Ferroso 150 mg (Ferro 30 mg) comprimido"
  },
  {
    "code" : "@brasil10166165296",
    "display" : "Bisglicinato Ferroso 30 mg/mL (Ferro 6 mg/mL) + Ácido Fólico 0,2 mg/mL solução oral"
  },
  {
    "code" : "@brasil10524892564",
    "display" : "Bisglicinato Ferroso 30 mg/mL (Ferro 6 mg/mL) solução oral"
  },
  {
    "code" : "@brasil19554923388",
    "display" : "Bisoprolol 1,25 mg comprimido"
  },
  {
    "code" : "@brasil18347890708",
    "display" : "Bisoprolol 10 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "@brasil14248182319",
    "display" : "Bisoprolol 10 mg + Hidroclorotiazida 6,25 mg comprimido"
  },
  {
    "code" : "@brasil13991009958",
    "display" : "Bisoprolol 10 mg comprimido"
  },
  {
    "code" : "@brasil18378240388",
    "display" : "Bisoprolol 2,5 mg + Hidroclorotiazida 6,25 mg comprimido"
  },
  {
    "code" : "@brasil17927869098",
    "display" : "Bisoprolol 2,5 mg comprimido"
  },
  {
    "code" : "@brasil19925659762",
    "display" : "Bisoprolol 5 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil11035242276",
    "display" : "Bisoprolol 5 mg + Hidroclorotiazida 6,25 mg comprimido"
  },
  {
    "code" : "@brasil19681977720",
    "display" : "Bisoprolol 5 mg comprimido"
  },
  {
    "code" : "@brasil17551802588",
    "display" : "Bleomicina 15 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13359262376",
    "display" : "Bleomicina 15 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16982494839",
    "display" : "Boceprevir 200 mg cápsula"
  },
  {
    "code" : "@brasil11395277036",
    "display" : "Bortezomibe 1 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14269137245",
    "display" : "Bortezomibe 3,5 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17713631676",
    "display" : "Bosentana 125 mg comprimido"
  },
  {
    "code" : "@brasil15166022678",
    "display" : "Bosentana 62,5 mg comprimido"
  },
  {
    "code" : "@brasil11267980570",
    "display" : "Brentuximabe Vedotina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19253294567",
    "display" : "Brimonidina 1 mg/mL (0,1%) solução oftálmica"
  },
  {
    "code" : "@brasil10642803059",
    "display" : "Brimonidina 1,5 mg/mL (0,15%) solução oftálmica"
  },
  {
    "code" : "@brasil12426220179",
    "display" : "Brimonidina 2 mg/mL (0,2%) solução oftálmica"
  },
  {
    "code" : "@brasil18432347920",
    "display" : "Brimonidina 2 mg/mL + Timolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil17046409719",
    "display" : "Brimonidina 5 mg/g gel"
  },
  {
    "code" : "@brasil16542982454",
    "display" : "Brinzolamida 10 mg/mL + Brimonidina 2 mg/mL suspensão oftálmica"
  },
  {
    "code" : "@brasil13122395427",
    "display" : "Brinzolamida 10 mg/mL + Timolol 5 mg/mL suspensão oftálmica"
  },
  {
    "code" : "@brasil15620635230",
    "display" : "Brinzolamida 10 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil16632809382",
    "display" : "Brinzolamida 10 mg/mL suspensão oftálmica"
  },
  {
    "code" : "@brasil17592660175",
    "display" : "Bromazepam 1 mg + Sulpirida 25 mg comprimido"
  },
  {
    "code" : "@brasil17031026059",
    "display" : "Bromazepam 2,5 mg/mL solução oral"
  },
  {
    "code" : "@brasil17860715720",
    "display" : "Bromazepam 3 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil11500985389",
    "display" : "Bromazepam 3 mg comprimido"
  },
  {
    "code" : "@brasil15238640134",
    "display" : "Bromazepam 6 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil10869751237",
    "display" : "Bromazepam 6 mg comprimido"
  },
  {
    "code" : "@brasil18665909065",
    "display" : "Brometo de Glicopirrônio 50 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "@brasil18097507484",
    "display" : "Brometo de Ipratrópio 0,02 mg/dose pó para inalação"
  },
  {
    "code" : "@brasil16459425608",
    "display" : "Brometo de Ipratrópio 0,25 mg/mL solução para inalação 15 mL; frasco"
  },
  {
    "code" : "@brasil19107584317",
    "display" : "Brometo de Ipratrópio 0,25 mg/mL solução para inalação 20 mL; frasco"
  },
  {
    "code" : "@brasil11533632232",
    "display" : "Brometo de Ipratrópio 20 microgramas/dose + Salbutamol 100 microgramas/dose suspensão aerossol"
  },
  {
    "code" : "@brasil11526201004",
    "display" : "Brometo de Ipratrópio 20 microgramas/dose solução aerossol; inalador"
  },
  {
    "code" : "@brasil19079162289",
    "display" : "Brometo de Otilônio 40 mg comprimido"
  },
  {
    "code" : "@brasil10028395307",
    "display" : "Brometo de Pancurônio 4 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18585197875",
    "display" : "Brometo de Pinavério 100 mg comprimido"
  },
  {
    "code" : "@brasil13329659692",
    "display" : "Brometo de Pinavério 50 mg comprimido"
  },
  {
    "code" : "@brasil12819161202",
    "display" : "Brometo de Piridostigmina 60 mg comprimido"
  },
  {
    "code" : "@brasil16933021680",
    "display" : "Brometo de Rocurônio 50 mg/5 mL solução par ainjeção; ampola"
  },
  {
    "code" : "@brasil13486136749",
    "display" : "Brometo de Rocurônio 50 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13698464336",
    "display" : "Brometo de Tiotrópio 18 micrograma cápsula para inalação"
  },
  {
    "code" : "@brasil18207133222",
    "display" : "Brometo de Tiotrópio 2,5 microgramas/dose solução para inalação; inalador"
  },
  {
    "code" : "@brasil11676257271",
    "display" : "Brometo de Umeclidíno 62,5 microgramas/dose + Vilanterol 25 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "@brasil13273591112",
    "display" : "Brometo de Umeclidíno 62,5 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "@brasil13532491421",
    "display" : "Brometo de Vecurônio 10 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13858515706",
    "display" : "Brometo de Vecurônio 4 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17191384206",
    "display" : "Bromexina 0,8 mg/mL xarope"
  },
  {
    "code" : "@brasil11105412719",
    "display" : "Bromexina 1,6 mg/mL xarope"
  },
  {
    "code" : "@brasil15824494868",
    "display" : "Bromexina 2 mg/mL solução"
  },
  {
    "code" : "@brasil10441164327",
    "display" : "Bromocriptina 2,5 mg comprimido"
  },
  {
    "code" : "@brasil11188689442",
    "display" : "Bromocriptina 5 mg cápsula de liberação retardada"
  },
  {
    "code" : "@brasil11505369982",
    "display" : "Bromoprida 1 mg/mL solução oral"
  },
  {
    "code" : "@brasil10266191241",
    "display" : "Bromoprida 10 mg cápsula"
  },
  {
    "code" : "@brasil17776648817",
    "display" : "Bromoprida 10 mg comprimido"
  },
  {
    "code" : "@brasil16046598771",
    "display" : "Bromoprida 10 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19660285420",
    "display" : "Bromoprida 4 mg/mL solução oral"
  },
  {
    "code" : "@brasil14369926781",
    "display" : "Bronfeniramina 0,2 mg/mL + Pseudoefedrina 3 mg/mL elixir"
  },
  {
    "code" : "@brasil10802655946",
    "display" : "Bronfeniramina 0,4 mg/mL + Fenilefrina 1 mg/mL xarope"
  },
  {
    "code" : "@brasil10588606949",
    "display" : "Bronfeniramina 0,8 mg/mL + Fenilefrina 1 mg/mL elixir"
  },
  {
    "code" : "@brasil12972075549",
    "display" : "Bronfeniramina 12 mg + Fenilefrina 15 mg comprimido"
  },
  {
    "code" : "@brasil11921241526",
    "display" : "Bronfeniramina 12 mg + Fenilefrina 15 mg comprimido de liberação modificada"
  },
  {
    "code" : "@brasil12491860036",
    "display" : "Bronfeniramina 2 mg/mL + Fenilefrina 2,5 mg/mL solução oral"
  },
  {
    "code" : "@brasil10072189326",
    "display" : "Bronfeniramina 4 mg + Fenilefrina 5 mg comprimido"
  },
  {
    "code" : "@brasil15264630991",
    "display" : "Bronfeniramina 4 mg + Pseudoefedrina 60 mg cápsula"
  },
  {
    "code" : "@brasil14877346496",
    "display" : "Brosimum gaudichaudii 200 mg/g pomada"
  },
  {
    "code" : "@brasil15236634345",
    "display" : "Brosimum gaudichaudii 400 mg comprimido"
  },
  {
    "code" : "@brasil12164314539",
    "display" : "Buclizina 25 mg comprimido"
  },
  {
    "code" : "@brasil19361492197",
    "display" : "Budesonida 0,25 mg/mL suspensão para inalação 2 mL; frasco"
  },
  {
    "code" : "@brasil13361495735",
    "display" : "Budesonida 0,5 mg/mL suspensão para inalação 2 mL; frasco"
  },
  {
    "code" : "@brasil17886543968",
    "display" : "Budesonida 0,5 mg/mL suspensão para inalação 5 mL; frasco"
  },
  {
    "code" : "@brasil17656451739",
    "display" : "Budesonida 100 microgramas/dose suspensão spray"
  },
  {
    "code" : "@brasil12560576741",
    "display" : "Budesonida 100 microgramas/pó para inalação"
  },
  {
    "code" : "@brasil15500923650",
    "display" : "Budesonida 200 microgramas cápsula para inalação"
  },
  {
    "code" : "@brasil13339630953",
    "display" : "Budesonida 200 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "@brasil16643414585",
    "display" : "Budesonida 200 microgramas pó aerossol"
  },
  {
    "code" : "@brasil16536956219",
    "display" : "Budesonida 200 microgramas/dose suspensão aerossol"
  },
  {
    "code" : "@brasil11874056207",
    "display" : "Budesonida 3 mg cápsula gastrorresistente"
  },
  {
    "code" : "@brasil10367794911",
    "display" : "Budesonida 32 microgramas/dose solução nasal"
  },
  {
    "code" : "@brasil11647919984",
    "display" : "Budesonida 32 microgramas/dose suspensão spray"
  },
  {
    "code" : "@brasil19534801540",
    "display" : "Budesonida 400 microgramas cápsula para inalação"
  },
  {
    "code" : "@brasil10557349807",
    "display" : "Budesonida 400 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "@brasil13435450458",
    "display" : "Budesonida 50 microgramas/dose solução nasal"
  },
  {
    "code" : "@brasil16303593222",
    "display" : "Budesonida 50 microgramas/dose suspensão aerossol"
  },
  {
    "code" : "@brasil19469235294",
    "display" : "Budesonida 50 microgramas/dose suspensão spray"
  },
  {
    "code" : "@brasil16988588082",
    "display" : "Budesonida 64 microgramas/dose solução nasal"
  },
  {
    "code" : "@brasil17964218543",
    "display" : "Budesonida 64 microgramas/dose suspensão spray"
  },
  {
    "code" : "@brasil17104793177",
    "display" : "Bumetanida 1 mg comprimido"
  },
  {
    "code" : "@brasil13345729458",
    "display" : "Bupivacaína 100 mg/20 mL (0,5%) + Epinefrina 100 microgramas/20 mL (1:200.000) solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14325799600",
    "display" : "Bupivacaína 100 mg/20 mL (0,5%) solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13315190013",
    "display" : "Bupivacaína 150 mg/20 mL (0,75%) + Epinefrina 100 microgramas/20 mL (1:200.000) solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18013441857",
    "display" : "Bupivacaína 150 mg/20 mL (0,75%) solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15124631583",
    "display" : "Bupivacaína 20 mg/4 mL (0,5%) + Glicose 320 mg/4 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16629593246",
    "display" : "Bupivacaína 20 mg/4 mL + Glicose 320 mg/4 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13068089328",
    "display" : "Bupivacaína 50 mg/20 mL (0,25%) + Epinefrina 100 microgramas/20 mL (1:200.000) solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16447542602",
    "display" : "Bupivacaína 50 mg/20 mL (0,25%) solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18746824876",
    "display" : "Bupivacaína Isobárica 20 mg/4 mL (0,5%) solução para injeção; ampola"
  },
  {
    "code" : "@brasil15267172552",
    "display" : "Bupivacaína Isobárica 5% solução para injeção 4 mL; frasco-ampola"
  },
  {
    "code" : "@brasil13327472919",
    "display" : "Buprenorfina 10 microgramas/hora adesivo transdérmico"
  },
  {
    "code" : "@brasil17807509578",
    "display" : "Buprenorfina 20 microgramas/hora adesivo transdérmico"
  },
  {
    "code" : "@brasil19730120522",
    "display" : "Buprenorfina 5 microgramas/hora adesivo transdérmico"
  },
  {
    "code" : "@brasil13138149214",
    "display" : "Bupropiona 150 mg comprimido"
  },
  {
    "code" : "@brasil11643989291",
    "display" : "Bupropiona 150 mg comprimido de liberação modificada"
  },
  {
    "code" : "@brasil16748747969",
    "display" : "Bupropiona 150 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil13800190298",
    "display" : "Bupropiona 300 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil14272729812",
    "display" : "Bupropiona 300 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil13003036437",
    "display" : "Buspirona 10 mg comprimido"
  },
  {
    "code" : "@brasil17782539972",
    "display" : "Buspirona 5 mg comprimido"
  },
  {
    "code" : "@brasil12546268646",
    "display" : "Busserelina 6,6 mg implante; seringa preenchida"
  },
  {
    "code" : "@brasil18040483655",
    "display" : "Bussulfano 2 mg comprimido"
  },
  {
    "code" : "@brasil17352896924",
    "display" : "Bussulfano 60 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13732059274",
    "display" : "Butenafina 10 mg/g creme"
  },
  {
    "code" : "@brasil16306074685",
    "display" : "Cabazitaxel 60 mg/1,5 mL solução e diluente para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11821997780",
    "display" : "Cabergolina 0,5 mg comprimido"
  },
  {
    "code" : "@brasil15198796590",
    "display" : "Cafeína 20 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15502789275",
    "display" : "Cafeína 5 mg/mL xarope"
  },
  {
    "code" : "@brasil19206323052",
    "display" : "Calcipotriol 50 microgramas/g + Dipropionato de Betametasona 0,5 mg/g gel"
  },
  {
    "code" : "@brasil12954206822",
    "display" : "Calcipotriol 50 microgramas/g + Dipropionato de Betametasona 0,5 mg/g pomada"
  },
  {
    "code" : "@brasil17931042067",
    "display" : "Calcipotriol 50 microgramas/g pomada"
  },
  {
    "code" : "@brasil17857163218",
    "display" : "Calcitonina (Salmão) 100 unidades internacionais/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13856462959",
    "display" : "Calcitonina (Salmão) 200 unidades internacionais/dose solução spray"
  },
  {
    "code" : "@brasil17071283837",
    "display" : "Calcitonina (Salmão) 50 unidades internacionais/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16480369572",
    "display" : "Calcitriol 0,25 microgramas cápsula"
  },
  {
    "code" : "@brasil13989127699",
    "display" : "Calcitriol 1 micrograma cápsula"
  },
  {
    "code" : "@brasil12115325937",
    "display" : "Calcitriol 1 microgramas/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11145822359",
    "display" : "Calendula officinalis 130 mg/g + Óxido de Zinco 130 mg/g pomada"
  },
  {
    "code" : "@brasil16576593569",
    "display" : "Cambendazol 180 mg comprimido"
  },
  {
    "code" : "@brasil13061508845",
    "display" : "Cambendazol 5 mg/mL + Mebendazol 13,33 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil16133468984",
    "display" : "Cambendazol 6 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil15377679060",
    "display" : "Cambendazol 75 mg + Mebendazol 200 mg comprimido"
  },
  {
    "code" : "@brasil11167379105",
    "display" : "Canagliflozina 100 mg comprimido"
  },
  {
    "code" : "@brasil19944678216",
    "display" : "Canagliflozina 300 mg comprimido"
  },
  {
    "code" : "@brasil18440191053",
    "display" : "Canaquinumabe 150 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10986415007",
    "display" : "Candesartana 16 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil16305526657",
    "display" : "Candesartana 16 mg comprimido"
  },
  {
    "code" : "@brasil17259068577",
    "display" : "Candesartana 16 mg comprimido e Felodipino 2,5 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil18317545937",
    "display" : "Candesartana 16 mg comprimido e Felodipino 5 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil16107115125",
    "display" : "Candesartana 32 mg comprimido"
  },
  {
    "code" : "@brasil17531406251",
    "display" : "Candesartana 8 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil19738491259",
    "display" : "Candesartana 8 mg comprimido"
  },
  {
    "code" : "@brasil14807595585",
    "display" : "Cânfora 12,5 mg + Eucaliptol 30 mg + Mentol 4 mg + Guaiacol 12,5 mg supositório"
  },
  {
    "code" : "@brasil12743803785",
    "display" : "Cânfora 25 mg/g + Eucaliptol 100 mg/g + Mentol 50 mg/g + Guaiacol 10 mg/g bálsamo"
  },
  {
    "code" : "@brasil14864512061",
    "display" : "Capecitabina 150 mg comprimido"
  },
  {
    "code" : "@brasil11916920990",
    "display" : "Capecitabina 500 mg comprimido"
  },
  {
    "code" : "@brasil13000263554",
    "display" : "Capreomicina 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16819045483",
    "display" : "Capsaicina 0,25 mg/g creme"
  },
  {
    "code" : "@brasil10610653096",
    "display" : "Capsaicina 0,25 mg/mL loção"
  },
  {
    "code" : "@brasil15973333496",
    "display" : "Capsaicina 0,75 mg/g creme"
  },
  {
    "code" : "@brasil13934634870",
    "display" : "Captopril 10 mg/mL solução oral"
  },
  {
    "code" : "@brasil19271585389",
    "display" : "Captopril 12,5 mg comprimido"
  },
  {
    "code" : "@brasil15989078901",
    "display" : "Captopril 25 mg comprimido"
  },
  {
    "code" : "@brasil12352332045",
    "display" : "Captopril 50 mg comprimido"
  },
  {
    "code" : "@brasil15925661422",
    "display" : "Carbacol 0,2 mg/2 mL solução para injeção intraocular; frasco-ampola"
  },
  {
    "code" : "@brasil17199526303",
    "display" : "Carbamazepina 20 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil16268325591",
    "display" : "Carbamazepina 20 mg/mL xarope"
  },
  {
    "code" : "@brasil17821534076",
    "display" : "Carbamazepina 200 mg comprimido"
  },
  {
    "code" : "@brasil17468762086",
    "display" : "Carbamazepina 200 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil17761147074",
    "display" : "Carbamazepina 400 mg comprimido"
  },
  {
    "code" : "@brasil11984347617",
    "display" : "Carbamazepina 400 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil17961291499",
    "display" : "Carbocisteína 20 mg/mL xarope"
  },
  {
    "code" : "@brasil11571765970",
    "display" : "Carbocisteína 250 mg granulado"
  },
  {
    "code" : "@brasil18454461578",
    "display" : "Carbocisteína 50 mg/mL solução oral"
  },
  {
    "code" : "@brasil16280386582",
    "display" : "Carbocisteína 50 mg/mL xarope"
  },
  {
    "code" : "@brasil12104275152",
    "display" : "Carbômer 2 mg/g (0,2%) gel oftálmico"
  },
  {
    "code" : "@brasil16528183533",
    "display" : "Carbômer 2 mg/g + Sorbitol 48,5 mg/g gel oftálmico"
  },
  {
    "code" : "@brasil15064702083",
    "display" : "Carbômer 3 mg/g (0,3%) gel oftálmico"
  },
  {
    "code" : "@brasil12779589250",
    "display" : "Carbonato de Cálcio + Lactogliconato de Cálcio 1.000 mg comprimido"
  },
  {
    "code" : "@brasil14309827361",
    "display" : "Carbonato de Cálcio + Lactogliconato de Cálcio 500 mg comprimido"
  },
  {
    "code" : "@brasil16874116077",
    "display" : "Carbonato de Cálcio 1,25 g (Cálcio 500 mg) + Colecalciferol 200 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil14293256087",
    "display" : "Carbonato de Cálcio 1,25 g (Cálcio 500 mg) + Colecalciferol 210 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil15524674946",
    "display" : "Carbonato de Cálcio 1,25 g (Cálcio 500 mg) + Colecalciferol 400 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil14775080590",
    "display" : "Carbonato de Cálcio 1,25 g (Cálcio 500 mg) + Colecalciferol 600 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil18948527580",
    "display" : "Carbonato de Cálcio 1,25 g (Cálcio 500 mg) comprimido"
  },
  {
    "code" : "@brasil18105595285",
    "display" : "Carbonato de Cálcio 1,25 g (Cálcio 500 mg) comprimido mastigável"
  },
  {
    "code" : "@brasil17565306337",
    "display" : "Carbonato de Cálcio 1,5 g (Cálcio 600 mg) + Colecalciferol 200 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil10907045742",
    "display" : "Carbonato de Cálcio 1,5 g (Cálcio 600 mg) + Colecalciferol 400 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil14709136619",
    "display" : "Carbonato de Cálcio 1,5 g (Cálcio 600 mg) + Colecalciferol 400 unidades internacionais comprimido mastigável"
  },
  {
    "code" : "@brasil19677286201",
    "display" : "Carbonato de Cálcio 1,5 g (Cálcio 600 mg) + Colecalciferol 600 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil10536492783",
    "display" : "Carbonato de Cálcio 50 mg + Colecalciferol 0,25 unidades internacionais pastilha"
  },
  {
    "code" : "@brasil17033438622",
    "display" : "Carbonato de Cálcio 750 mg comprimido mastigável"
  },
  {
    "code" : "@brasil11412318097",
    "display" : "Carbonato de Lítio 300 mg comprimido"
  },
  {
    "code" : "@brasil17178610270",
    "display" : "Carbonato de Lítio 450 mg comprimido"
  },
  {
    "code" : "@brasil16148623716",
    "display" : "Carbonato de lítio 450 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil14367761903",
    "display" : "Carbonato de Lodenafila 80 mg comprimido"
  },
  {
    "code" : "@brasil13555774774",
    "display" : "Carbonato de Magnésio 67 mg + Carbonato de Bismuto 3,3 mg + Carbonato de Cálcio 521 mg + Bicarbonato de Sódio 63,7 mg pastilha"
  },
  {
    "code" : "@brasil18695104575",
    "display" : "Carboplatina 150 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11899976069",
    "display" : "Carboplatina 150 mg/15 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11782006212",
    "display" : "Carboplatina 450 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15064731904",
    "display" : "Carboplatina 450 mg/45 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18367321050",
    "display" : "Carboplatina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16642409846",
    "display" : "Carboplatina 50 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11053355717",
    "display" : "Carboximaltose Férrica 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16403087419",
    "display" : "Carboximaltose Férrica 500 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17856269605",
    "display" : "Carfilzomibe 60 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10280970315",
    "display" : "Carmelose Sódica 10 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil12055528248",
    "display" : "Carmelose Sódica 10 mg/mL solução spray"
  },
  {
    "code" : "@brasil10509022035",
    "display" : "Carmelose Sódica 5 mg/mL (0,5%) + Glicerol 9 mg/mL (0,9%) solução oftálmica"
  },
  {
    "code" : "@brasil16851902375",
    "display" : "Carmelose Sódica 5 mg/mL + Glicerol 10 mg/mL + Polissorbato 5 mg/mL emulsão oftálmica"
  },
  {
    "code" : "@brasil18447576581",
    "display" : "Carmelose Sódica 5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil13785906696",
    "display" : "Carmustina 100 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14727576741",
    "display" : "Carmustina 7,7 mg implante"
  },
  {
    "code" : "@brasil10500290607",
    "display" : "Carnitina 1 g cápsula"
  },
  {
    "code" : "@brasil13122365066",
    "display" : "Carnitina 200 mg/mL xarope"
  },
  {
    "code" : "@brasil14740311618",
    "display" : "Carnitina 50 mg/mL xarope"
  },
  {
    "code" : "@brasil15907049406",
    "display" : "Carvedilol 12,5 mg comprimido"
  },
  {
    "code" : "@brasil11002636002",
    "display" : "Carvedilol 25 mg comprimido"
  },
  {
    "code" : "@brasil12621513513",
    "display" : "Carvedilol 3,125 mg comprimido"
  },
  {
    "code" : "@brasil18640319888",
    "display" : "Carvedilol 6,25 mg comprimido"
  },
  {
    "code" : "@brasil15421880459",
    "display" : "Caspofungina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15256697622",
    "display" : "Caspofungina 70 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15887046748",
    "display" : "Cassia angustifolia 240 mg + Tamarindus indica 11,7 mg + Cassia fistula 11,7 mg +  Coriandrum sativum 5,4 mg cápsula"
  },
  {
    "code" : "@brasil14108783912",
    "display" : "Cefaclor 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil18924011855",
    "display" : "Cefaclor 500 mg cápsula"
  },
  {
    "code" : "@brasil12033010284",
    "display" : "Cefaclor 500 mg comprimido"
  },
  {
    "code" : "@brasil17052016207",
    "display" : "Cefaclor 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil12292880966",
    "display" : "Cefaclor 75 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil18927287083",
    "display" : "Cefaclor 750 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil17132825632",
    "display" : "Cefadroxila 100 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil17210197956",
    "display" : "Cefadroxila 50 mg/mL solução oral"
  },
  {
    "code" : "@brasil18855370252",
    "display" : "Cefadroxila 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil11506633889",
    "display" : "Cefadroxila 500 mg cápsula"
  },
  {
    "code" : "@brasil19960029234",
    "display" : "Cefalexina 1 g comprimido"
  },
  {
    "code" : "@brasil10192072604",
    "display" : "Cefalexina 100 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil17095435052",
    "display" : "Cefalexina 25 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil19453951564",
    "display" : "Cefalexina 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil19448944113",
    "display" : "Cefalexina 500 mg cápsula"
  },
  {
    "code" : "@brasil16619748216",
    "display" : "Cefalexina 500 mg comprimido"
  },
  {
    "code" : "@brasil19167448205",
    "display" : "Cefalotina 1 g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15191386587",
    "display" : "Cefalotina 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16687083379",
    "display" : "Cefazolina 1 g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17896429082",
    "display" : "Cefazolina 1 g pó e diluente para solução para injeção; frasco-ampola + bolsa"
  },
  {
    "code" : "@brasil18148472305",
    "display" : "Cefazolina 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12981426717",
    "display" : "Cefepima 1 g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17081527966",
    "display" : "Cefepima 1 g pó e diluente para solução para injeção; frasco-ampola + bolsa"
  },
  {
    "code" : "@brasil15168202075",
    "display" : "Cefepima 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16638361909",
    "display" : "Cefepima 2 g pó e diluente para solução para injeção; frasco-ampola + bolsa"
  },
  {
    "code" : "@brasil11395593770",
    "display" : "Cefepima 2 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16478931824",
    "display" : "Cefotaxima 1 g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11473362930",
    "display" : "Cefotaxima 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16558249085",
    "display" : "Cefotaxima 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13354450261",
    "display" : "Cefoxitina 1 g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13180033650",
    "display" : "Cefoxitina 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17097504358",
    "display" : "Ceftarolina Fosamila 600 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15424171317",
    "display" : "Ceftazidima 1 g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11211195923",
    "display" : "Ceftazidima 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15828343819",
    "display" : "Ceftazidima 2 g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16486898236",
    "display" : "Ceftriaxona 1 g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14838559407",
    "display" : "Ceftriaxona 1 g pó e diluente para solução para injeção; frasco-ampola + bolsa"
  },
  {
    "code" : "@brasil17672231007",
    "display" : "Ceftriaxona 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19192290908",
    "display" : "Ceftriaxona 250 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13462237158",
    "display" : "Ceftriaxona 500 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13521142175",
    "display" : "Ceftriaxona 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13529500357",
    "display" : "Cefuroxima 125 mg comprimido"
  },
  {
    "code" : "@brasil10962289105",
    "display" : "Cefuroxima 25 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil10524559048",
    "display" : "Cefuroxima 250 mg comprimido"
  },
  {
    "code" : "@brasil12835986466",
    "display" : "Cefuroxima 250 mg pó para suspensão oral"
  },
  {
    "code" : "@brasil14756273592",
    "display" : "Cefuroxima 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil14972124950",
    "display" : "Cefuroxima 500 mg comprimido"
  },
  {
    "code" : "@brasil14352171498",
    "display" : "Cefuroxima 750 mg pó e diluente para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19821014383",
    "display" : "Cefuroxima 750 mg pó para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18165487084",
    "display" : "Celecoxibe 100 mg cápsula"
  },
  {
    "code" : "@brasil19590220355",
    "display" : "Celecoxibe 200 mg cápsula"
  },
  {
    "code" : "@brasil15988187887",
    "display" : "Certolizumabe Pegol 200 mg/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil18030194012",
    "display" : "Cetamina 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17195300129",
    "display" : "Cetamina 500 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16522344448",
    "display" : "Cetirizina 1 mg/mL solução oral"
  },
  {
    "code" : "@brasil13229811426",
    "display" : "Cetirizina 10 mg cápsula"
  },
  {
    "code" : "@brasil17445730022",
    "display" : "Cetirizina 10 mg comprimido"
  },
  {
    "code" : "@brasil12120807097",
    "display" : "Cetoconazol 20 mg/g + Dipropionato de Betametasona 0,5 mg/g + Neomicina 2,5 mg/g creme"
  },
  {
    "code" : "@brasil19890484165",
    "display" : "Cetoconazol 20 mg/g + Dipropionato de Betametasona 0,5 mg/g + Neomicina 2,5 mg/g pomada"
  },
  {
    "code" : "@brasil12765607881",
    "display" : "Cetoconazol 20 mg/g + Dipropionato de Betametasona 0,5 mg/g creme"
  },
  {
    "code" : "@brasil17142555010",
    "display" : "Cetoconazol 20 mg/g + Dipropionato de Betametasona 0,5 mg/g pomada"
  },
  {
    "code" : "@brasil14227058685",
    "display" : "Cetoconazol 20 mg/g creme"
  },
  {
    "code" : "@brasil12118789340",
    "display" : "Cetoconazol 20 mg/g xampu"
  },
  {
    "code" : "@brasil14815431407",
    "display" : "Cetoconazol 20 mg/mL xampu"
  },
  {
    "code" : "@brasil14296991650",
    "display" : "Cetoconazol 200 mg comprimido"
  },
  {
    "code" : "@brasil14290051537",
    "display" : "Cetoprofeno 1 mg/mL xarope"
  },
  {
    "code" : "@brasil13215614493",
    "display" : "Cetoprofeno 100 mg comprimido"
  },
  {
    "code" : "@brasil17903834978",
    "display" : "Cetoprofeno 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11867508264",
    "display" : "Cetoprofeno 100 mg supositório"
  },
  {
    "code" : "@brasil13459907995",
    "display" : "Cetoprofeno 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19656092894",
    "display" : "Cetoprofeno 150 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil13639984803",
    "display" : "Cetoprofeno 160 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil11628267038",
    "display" : "Cetoprofeno 20 mg/mL solução oral"
  },
  {
    "code" : "@brasil13451222918",
    "display" : "Cetoprofeno 200 mg + Omeprazol 20 mg cápsula de liberação modificada"
  },
  {
    "code" : "@brasil17054945999",
    "display" : "Cetoprofeno 200 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil15333643810",
    "display" : "Cetoprofeno 25 mg/g gel"
  },
  {
    "code" : "@brasil14402297523",
    "display" : "Cetoprofeno 320 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil17742242799",
    "display" : "Cetoprofeno 50 mg cápsula"
  },
  {
    "code" : "@brasil18346006373",
    "display" : "Cetorolaco 50 mg/mL (5%) solução oftálmica"
  },
  {
    "code" : "@brasil11498000193",
    "display" : "Cetotifeno 0,2 mg/mL xarope"
  },
  {
    "code" : "@brasil19931834608",
    "display" : "Cetotifeno 0,25 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil10515316845",
    "display" : "Cetotifeno 1 mg comprimido"
  },
  {
    "code" : "@brasil15702036185",
    "display" : "Cetotifeno 1 mg/mL solução oral"
  },
  {
    "code" : "@brasil12427081354",
    "display" : "Cetrorrelix 0,25 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14838266981",
    "display" : "Cetuximabe 100 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16697536618",
    "display" : "Cetuximabe 100 mg/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18717272362",
    "display" : "Cetuximabe 50 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12669014661",
    "display" : "Cetuximabe 500 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18919628771",
    "display" : "Cetuximabe 500 mg/100 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17165043740",
    "display" : "Cianocobalamina 1 mg + Piridoxina 100 mg + Tiamina 50 mg + Dipirona 250 mg + Carisoprodol 250 mg comprimido"
  },
  {
    "code" : "@brasil19122471266",
    "display" : "Cianocobalamina 1 mg + Tiamina 100 mg + Piridoxina 100 mg + Diclofenaco Sódico 100 mg comprimido de liberação retardada"
  },
  {
    "code" : "@brasil19582953897",
    "display" : "Cianocobalamina 1 mg/1 mL solução para injeção; ampola e Tiamina 100 mg/1 mL + Piridoxina 100 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17020550291",
    "display" : "Cianocobalamina 1 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18863545476",
    "display" : "Cianocobalamina 1,06 mg/2 mL + Piridoxina 100 mg/2 mL + Tiamina 100 mg/2 mL + Lidocaína 10,6 mg/2 mL solução para injeção; ampola e Dexametasona 5,2 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15029924142",
    "display" : "Cianocobalamina 5 mg + Piridoxina 100 mg + Tiamina 100 mg + Dexametasona 0,5 mg comprimido"
  },
  {
    "code" : "@brasil19146114836",
    "display" : "Cianocobalamina 5 mg + Tiamina 100 mg + Piridoxina 100 mg comprimido"
  },
  {
    "code" : "@brasil10202913739",
    "display" : "Cianocobalamina 5 mg/1 mL solução para injeção; ampola e Tiamina 100 mg/1 mL + Piridoxina 100 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10770925664",
    "display" : "Cianocobalamina 5 mg/2 mL + Fosfato de Dexametasona 4 mg/2 mL solução para injeção; ampola e Tiamina 100 mg/1 mL + Piridoxina 100 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17326096795",
    "display" : "Cianocobalamina 5 mg/2 mL + Tiamina 100 mg/2 mL + Piridoxina 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14035346203",
    "display" : "Cianocobalamina 5 mg/2 mL + Tiamina 100 mg/2 mL + Piridoxina 100 mg/2 mL solução para injeção; ampola e Dexametasona 4 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15188564652",
    "display" : "Cianocobalamina 5 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13376467574",
    "display" : "Ciclesonida 0,1 mg/dose solução para inalação; inalador"
  },
  {
    "code" : "@brasil17978110058",
    "display" : "Ciclesonida 0,2 mg/dose solução para inalação; inalador"
  },
  {
    "code" : "@brasil11270858813",
    "display" : "Ciclesonida 160 microgramas solução para inalação"
  },
  {
    "code" : "@brasil13700515555",
    "display" : "Ciclesonida 50 microgramas suspensão nasal"
  },
  {
    "code" : "@brasil16002044430",
    "display" : "Ciclesonida 50 microgramas/dose suspensão spray"
  },
  {
    "code" : "@brasil10732464547",
    "display" : "Ciclobenzaprina 10 mg + Cafeína 60 mg comprimido"
  },
  {
    "code" : "@brasil11439934959",
    "display" : "Ciclobenzaprina 10 mg comprimido"
  },
  {
    "code" : "@brasil13355222066",
    "display" : "Ciclobenzaprina 15 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil13681187827",
    "display" : "Ciclobenzaprina 5 mg + Cafeína 30 mg comprimido"
  },
  {
    "code" : "@brasil12872190420",
    "display" : "Ciclobenzaprina 5 mg + Clonixinato de Lisina 125 mg comprimido"
  },
  {
    "code" : "@brasil18754989920",
    "display" : "Ciclobenzaprina 5 mg comprimido"
  },
  {
    "code" : "@brasil18697398385",
    "display" : "Ciclofenila 200 mg comprimido"
  },
  {
    "code" : "@brasil10623202733",
    "display" : "Ciclofosfamida 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12059166078",
    "display" : "Ciclofosfamida 200 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15304262660",
    "display" : "Ciclofosfamida 50 mg comprimido"
  },
  {
    "code" : "@brasil14896156660",
    "display" : "Ciclofosfamida 50 mg comprimido de liberação retardada"
  },
  {
    "code" : "@brasil11900051087",
    "display" : "Ciclopentolato 10 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil14197558576",
    "display" : "Ciclopirox 80 mg/g esmalte"
  },
  {
    "code" : "@brasil19043072934",
    "display" : "Ciclopirox Olamina 10 mg/g creme"
  },
  {
    "code" : "@brasil15954208759",
    "display" : "Ciclopirox Olamina 10 mg/mL loção"
  },
  {
    "code" : "@brasil10027350102",
    "display" : "Ciclopirox Olamina 10 mg/mL solução"
  },
  {
    "code" : "@brasil11606960576",
    "display" : "Ciclosporina 0,5 mg/mL (0,05%) solução oftálmica"
  },
  {
    "code" : "@brasil17223373153",
    "display" : "Ciclosporina 0,5 mg/mL emulsão oftálmica"
  },
  {
    "code" : "@brasil16266518723",
    "display" : "Ciclosporina 10 mg cápsula"
  },
  {
    "code" : "@brasil10008429446",
    "display" : "Ciclosporina 100 mg cápsula"
  },
  {
    "code" : "@brasil15947197949",
    "display" : "Ciclosporina 100 mg/mL solução oral"
  },
  {
    "code" : "@brasil19430349699",
    "display" : "Ciclosporina 25 mg cápsula"
  },
  {
    "code" : "@brasil10346433799",
    "display" : "Ciclosporina 250 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19100782067",
    "display" : "Ciclosporina 50 mg cápsula"
  },
  {
    "code" : "@brasil11550134942",
    "display" : "Ciclosporina 50 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18856458810",
    "display" : "Cidofovir 375 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15624681007",
    "display" : "Cilazapril 1 mg comprimido"
  },
  {
    "code" : "@brasil15552442934",
    "display" : "Cilazapril 2,5 mg comprimido"
  },
  {
    "code" : "@brasil15477172605",
    "display" : "Cilazapril 5 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil12346241000",
    "display" : "Cilazapril 5 mg comprimido"
  },
  {
    "code" : "@brasil14769557903",
    "display" : "Cilostazol 100 mg comprimido"
  },
  {
    "code" : "@brasil17490390414",
    "display" : "Cilostazol 50 mg comprimido"
  },
  {
    "code" : "@brasil19753884791",
    "display" : "Cimetidina 200 mg comprimido"
  },
  {
    "code" : "@brasil17915150482",
    "display" : "Cimetidina 300 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18947832702",
    "display" : "Cimetidina 400 mg comprimido"
  },
  {
    "code" : "@brasil17863103538",
    "display" : "Cinacalcete 30 mg comprimido"
  },
  {
    "code" : "@brasil16972221494",
    "display" : "Cinacalcete 60 mg comprimido"
  },
  {
    "code" : "@brasil17674934441",
    "display" : "Cinacalcete 90 mg comprimido"
  },
  {
    "code" : "@brasil11702411240",
    "display" : "Cinarizina 25 mg comprimido"
  },
  {
    "code" : "@brasil10739240292",
    "display" : "Cinarizina 75 mg comprimido"
  },
  {
    "code" : "@brasil16479030544",
    "display" : "Cipionato de Testosterona 200 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12525867513",
    "display" : "Ciproeptadina 0,8 mg/mL + Cobamamida 0,2 mg/mL xarope"
  },
  {
    "code" : "@brasil16959204399",
    "display" : "Ciproeptadina 0,8 mg/mL + Tiamina 0,12 mg/mL + Riboflavina 0,15 mg/mL + Piridoxina 0,134 mg/mL + Nicotinamida 1,334 mg/mL + Ácido Ascórbico 4,334 mg/mL xarope"
  },
  {
    "code" : "@brasil10686922398",
    "display" : "Ciproeptadina 0,8 mg/mL xarope e Cobamamida 20 mg pó para solução oral"
  },
  {
    "code" : "@brasil11027135783",
    "display" : "Ciproeptadina 4 mg + Cobamamida 1 mg comprimido"
  },
  {
    "code" : "@brasil16502201393",
    "display" : "Ciprofibrato 100 mg comprimido"
  },
  {
    "code" : "@brasil11217799438",
    "display" : "Ciprofloxacino 1 g comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil11585695017",
    "display" : "Ciprofloxacino 2 mg/mL + Hidrocortisona 10 mg/mL suspensão otológica"
  },
  {
    "code" : "@brasil11335719404",
    "display" : "Ciprofloxacino 200 mg/100 mL solução para injeção; bolsa"
  },
  {
    "code" : "@brasil11887635980",
    "display" : "Ciprofloxacino 200 mg/100 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11287207817",
    "display" : "Ciprofloxacino 250 mg comprimido"
  },
  {
    "code" : "@brasil10415172781",
    "display" : "Ciprofloxacino 3 mg/g + Dexametasona 1 mg/g pomada oftálmica"
  },
  {
    "code" : "@brasil18973715097",
    "display" : "Ciprofloxacino 3 mg/g pomada oftálmica"
  },
  {
    "code" : "@brasil19814624840",
    "display" : "Ciprofloxacino 3 mg/mL + Dexametasona 1 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil11141112921",
    "display" : "Ciprofloxacino 3 mg/mL + Dexametasona 1 mg/mL suspensão oftálmica"
  },
  {
    "code" : "@brasil14859605797",
    "display" : "Ciprofloxacino 3 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil16024795094",
    "display" : "Ciprofloxacino 3 mg/mL solução otológica"
  },
  {
    "code" : "@brasil16461451113",
    "display" : "Ciprofloxacino 400 mg/200 mL solução para injeção; bolsa"
  },
  {
    "code" : "@brasil15784781895",
    "display" : "Ciprofloxacino 400 mg/200 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17361423499",
    "display" : "Ciprofloxacino 5 mg/mL solução otológica"
  },
  {
    "code" : "@brasil15433227292",
    "display" : "Ciprofloxacino 500 mg comprimido"
  },
  {
    "code" : "@brasil13261001847",
    "display" : "Ciprofloxacino 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil18695629720",
    "display" : "Ciproterona 100 mg comprimido"
  },
  {
    "code" : "@brasil11527965246",
    "display" : "Ciproterona 2 mg + Etinilestradiol 0,035 mg comprimido"
  },
  {
    "code" : "@brasil19722961455",
    "display" : "Ciproterona 50 mg comprimido"
  },
  {
    "code" : "@brasil18886960741",
    "display" : "Cisplatina 10 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11085851620",
    "display" : "Cisplatina 10 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16425509326",
    "display" : "Cisplatina 10 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16222381530",
    "display" : "Cisplatina 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18869992081",
    "display" : "Cisplatina 100 mg/100 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18219707520",
    "display" : "Cisplatina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15073432739",
    "display" : "Cisplatina 50 mg/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17464575726",
    "display" : "Citalopram 20 mg comprimido"
  },
  {
    "code" : "@brasil19523902970",
    "display" : "Citalopram 40 mg comprimido"
  },
  {
    "code" : "@brasil18757187758",
    "display" : "Citarabina 1 g/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18979736256",
    "display" : "Citarabina 100 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18565640884",
    "display" : "Citarabina 100 mg/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16556641454",
    "display" : "Citarabina 100 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16014047231",
    "display" : "Citarabina 2 g/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15797503128",
    "display" : "Citarabina 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17086284929",
    "display" : "Citarabina 500 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18691877961",
    "display" : "Citarabina 500 mg/25 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15761500591",
    "display" : "Citarabina 500 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18515679963",
    "display" : "Citicolina 500 mg comprimido"
  },
  {
    "code" : "@brasil15615370994",
    "display" : "Citidina 2,5 mg + Uridina 1,5 mg + Hidroxocobalamina 1 mg cápsula"
  },
  {
    "code" : "@brasil19222116234",
    "display" : "Citidina 5 mg + Uridina 3 mg + Hidroxocobalamina 2 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11953088082",
    "display" : "Citrato de Cálcio (Cálcio 250  mg) + Colecalciferol 2,5 micrograma comprimido"
  },
  {
    "code" : "@brasil18855552893",
    "display" : "Citrato de Cálcio 2.370 mg (Cálcio 500 mg) + Colecalciferol 200 unidades internacionais pó para suspensão oral"
  },
  {
    "code" : "@brasil15244819525",
    "display" : "Citrato de Cálcio 952,7 mg + Colecalciferol 200 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil18556917502",
    "display" : "Citrato de Colina 100 mg/mL + Betaína 50 mg/mL + Racemetionina 10 mg/mL solução oral"
  },
  {
    "code" : "@brasil10210039614",
    "display" : "Citrato de Colina 20 mg + Racemetionina 100 mg comprimido"
  },
  {
    "code" : "@brasil11804018430",
    "display" : "Citrato de Colina 50 mg/mL + Metionina 10 mg/mL solução oral"
  },
  {
    "code" : "@brasil16719135879",
    "display" : "Citrato de Dietilcarbamazina 50 mg comprimido"
  },
  {
    "code" : "@brasil14321078660",
    "display" : "Citrato de Potássio 1.080 mg (10 mEq) comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil19627099705",
    "display" : "Citrato de Potássio 2,16 mg/mL + Citrato de Sódio 0,94 mg/mL + Cloreto de Sódio 2,07 mg/mL + Gliconato de Zinco 0,06 mg/mL + Glicose 25 mg/mL solução oral"
  },
  {
    "code" : "@brasil11745909564",
    "display" : "Citrato de Potássio 2,16 mg/mL + Citrato de Sódio 0,98 mg/mL + Cloreto de Sódio 4,68 mg/mL + Glicose 20 mg/mL solução oral"
  },
  {
    "code" : "@brasil18164109435",
    "display" : "Citrato de Potássio 2,16 mg/mL + Cloreto de Sódio 2,05 mg/mL + Citrato de Sódio 0,98 mg/mL + Glicose 22,75 mg/mL solução oral"
  },
  {
    "code" : "@brasil14268521026",
    "display" : "Citrato de Potássio 21,60 mg/mL + Cloreto de Sódio 46,80 mg/mL + Citrato de Sódio 9,80 mg/mL + Glicose 200 mg/mL solução oral"
  },
  {
    "code" : "@brasil14250379654",
    "display" : "Citrato de Potássio 540 mg (5 mEq) comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil16973670288",
    "display" : "Citrato Férrico Amoniacal 8,5 mg/mL solução oral"
  },
  {
    "code" : "@brasil12542920914",
    "display" : "Cladribina 10 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15757185587",
    "display" : "Cladribina 5 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11993217701",
    "display" : "Cladribina 8 mg/8 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12230304173",
    "display" : "Claritromicina 25 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil12315746360",
    "display" : "Claritromicina 250 mg cápsula"
  },
  {
    "code" : "@brasil16475602951",
    "display" : "Claritromicina 250 mg comprimido"
  },
  {
    "code" : "@brasil19448094123",
    "display" : "Claritromicina 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil15716755962",
    "display" : "Claritromicina 500 mg cápsula"
  },
  {
    "code" : "@brasil15967927504",
    "display" : "Claritromicina 500 mg comprimido"
  },
  {
    "code" : "@brasil10260785752",
    "display" : "Claritromicina 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil15519047755",
    "display" : "Claritromicina 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18146795170",
    "display" : "Clemastina 0,05 mg/mL xarope"
  },
  {
    "code" : "@brasil18950663858",
    "display" : "Clemastina 1 mg comprimido"
  },
  {
    "code" : "@brasil12482836834",
    "display" : "Clemastina 1 mg/g + Dexametasona 0,5 mg/g creme"
  },
  {
    "code" : "@brasil15884059103",
    "display" : "Clindamicina 10 mg/g gel"
  },
  {
    "code" : "@brasil13206403033",
    "display" : "Clindamicina 10 mg/mL (1%) + Peróxido de Benzoíla 50 mg/mL (5%) gel"
  },
  {
    "code" : "@brasil16283039603",
    "display" : "Clindamicina 150 mg cápsula"
  },
  {
    "code" : "@brasil16013672979",
    "display" : "Clindamicina 20 mg/g (2%) creme"
  },
  {
    "code" : "@brasil11841792651",
    "display" : "Clindamicina 20 mg/g creme vaginal"
  },
  {
    "code" : "@brasil18041714770",
    "display" : "Clindamicina 300 mg cápsula"
  },
  {
    "code" : "@brasil16411549518",
    "display" : "Clindamicina 300 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13083137508",
    "display" : "Clindamicina 600 mg/4 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14881318344",
    "display" : "Clindamicina 900 mg/6 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12968075016",
    "display" : "Clioquinol 30 mg/g + Hidrocortisona 10 mg/g creme"
  },
  {
    "code" : "@brasil19473298822",
    "display" : "Clobazam 10 mg comprimido"
  },
  {
    "code" : "@brasil15820543890",
    "display" : "Clobazam 20 mg comprimido"
  },
  {
    "code" : "@brasil10534638473",
    "display" : "Clobetasol 0,5 mg/g creme"
  },
  {
    "code" : "@brasil11712452862",
    "display" : "Clobetasol 0,5 mg/g gel"
  },
  {
    "code" : "@brasil12395092911",
    "display" : "Clobetasol 0,5 mg/g pomada"
  },
  {
    "code" : "@brasil14839711415",
    "display" : "Clobetasol 0,5 mg/g solução"
  },
  {
    "code" : "@brasil12782589468",
    "display" : "Clobetasol 0,5 mg/mL loção"
  },
  {
    "code" : "@brasil15539092723",
    "display" : "Clobetasol 0,5 mg/mL solução spray"
  },
  {
    "code" : "@brasil16839952883",
    "display" : "Clobetasol 0,5 mg/mL xampu"
  },
  {
    "code" : "@brasil13143473483",
    "display" : "Clobutinol 4 mg/mL + Doxilamina 0,75 mg/mL xarope"
  },
  {
    "code" : "@brasil11522994088",
    "display" : "Clobutinol 4 mg/mL xarope"
  },
  {
    "code" : "@brasil16332647814",
    "display" : "Clobutinol 48 mg/mL + Doxilamina 9 mg/mL solução oral"
  },
  {
    "code" : "@brasil12935232726",
    "display" : "Clodronato Dissódico 1,5 g/25 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18502342176",
    "display" : "Clodronato Dissódico 300 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13655478518",
    "display" : "Clodronato Dissódico 400 mg cápsula"
  },
  {
    "code" : "@brasil15312587715",
    "display" : "Clofazimina 100 mg cápsula"
  },
  {
    "code" : "@brasil12883391996",
    "display" : "Clofazimina 50 mg cápsula"
  },
  {
    "code" : "@brasil10682823294",
    "display" : "Clomifeno 50 mg comprimido"
  },
  {
    "code" : "@brasil15952485105",
    "display" : "Clomipramina 10 mg comprimido"
  },
  {
    "code" : "@brasil17713955953",
    "display" : "Clomipramina 25 mg comprimido"
  },
  {
    "code" : "@brasil16062969485",
    "display" : "Clomipramina 75 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil19815169915",
    "display" : "Clonazepam 0,25 mg comprimido sublingual"
  },
  {
    "code" : "@brasil16694807470",
    "display" : "Clonazepam 0,5 mg comprimido"
  },
  {
    "code" : "@brasil14478370102",
    "display" : "Clonazepam 2 mg comprimido"
  },
  {
    "code" : "@brasil11227153576",
    "display" : "Clonazepam 2,5 mg/mL solução oral"
  },
  {
    "code" : "@brasil10286692789",
    "display" : "Clonidina 0,1 mg comprimido"
  },
  {
    "code" : "@brasil12019446436",
    "display" : "Clonidina 0,15 mg comprimido"
  },
  {
    "code" : "@brasil10916661210",
    "display" : "Clonidina 0,15 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18078195998",
    "display" : "Clonidina 0,2 mg comprimido"
  },
  {
    "code" : "@brasil10712324762",
    "display" : "Clonixinato de Lisina 125 mg comprimido"
  },
  {
    "code" : "@brasil15389980779",
    "display" : "Cloperastina 2 mg/mL xarope"
  },
  {
    "code" : "@brasil16445849775",
    "display" : "Cloperastina 3,54 mg/mL xarope"
  },
  {
    "code" : "@brasil17473757365",
    "display" : "Cloperastina 35,4 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil19751557994",
    "display" : "Clopidogrel 75 mg comprimido"
  },
  {
    "code" : "@brasil10419756257",
    "display" : "Clorambucila 2 mg comprimido"
  },
  {
    "code" : "@brasil19647759504",
    "display" : "Cloranfenicol 1 g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16862575053",
    "display" : "Cloranfenicol 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12848410272",
    "display" : "Cloranfenicol 10 mg/g + Colagenase 0,6 unidades internacionais/g creme vaginal"
  },
  {
    "code" : "@brasil19968224556",
    "display" : "Cloranfenicol 10 mg/g + Colagenase 0,6 unidades internacionais/g pomada"
  },
  {
    "code" : "@brasil14835580143",
    "display" : "Cloranfenicol 10 mg/g + Colagenase 0,6 unidades internacionais/g pomada vaginal"
  },
  {
    "code" : "@brasil14803389630",
    "display" : "Cloranfenicol 25 mg/mL + Lidocaína 30 mg/mL solução otológica"
  },
  {
    "code" : "@brasil17928197314",
    "display" : "Cloranfenicol 25 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil13745810037",
    "display" : "Cloranfenicol 250 mg cápsula"
  },
  {
    "code" : "@brasil18188317544",
    "display" : "Cloranfenicol 250 mg comprimido"
  },
  {
    "code" : "@brasil12584961542",
    "display" : "Cloranfenicol 30 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil17009846852",
    "display" : "Cloranfenicol 4 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil12965095668",
    "display" : "Cloranfenicol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil19943367436",
    "display" : "Cloranfenicol 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil19323728873",
    "display" : "Cloranfenicol 500 mg comprimido"
  },
  {
    "code" : "@brasil13291459066",
    "display" : "Clordiazepóxido 10 mg comprimido"
  },
  {
    "code" : "@brasil18343219874",
    "display" : "Clordiazepóxido 25 mg comprimido"
  },
  {
    "code" : "@brasil10530423130",
    "display" : "Cloreto de Benzalcônio 0,1 mg/mL + Ácido Bórico 17 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil15219361776",
    "display" : "Cloreto de Benzalcônio 0,1 mg/mL + Cloreto de Sódio 9 mg/mL solução nasal"
  },
  {
    "code" : "@brasil18063202887",
    "display" : "Cloreto de Benzalcônio 0,2 mg/g + Brometo de Cetrimônio 2 mg/g creme"
  },
  {
    "code" : "@brasil12328957180",
    "display" : "Cloreto de Cetilpiridínio 0,5 mg/mL + Benzocaína 4 mg/mL solução spray"
  },
  {
    "code" : "@brasil15000946562",
    "display" : "Cloreto de Cetilpiridínio 1,34 mg pastilha"
  },
  {
    "code" : "@brasil18637674457",
    "display" : "Cloreto de Cetilpiridínio 1,466 mg + Benzocaína 10 mg pastilha"
  },
  {
    "code" : "@brasil17343816808",
    "display" : "Cloreto de Colina 25 mg + Racemetionina 100 mg + Inositol 50 mg + Cianocobalamina 2 microgramas comprimido"
  },
  {
    "code" : "@brasil10585079658",
    "display" : "Cloreto de Potássio 0,191% + Cloreto de Sódio 0,4% + Glicose 5% solução para injeção 1 L; bolsa"
  },
  {
    "code" : "@brasil14218426582",
    "display" : "Cloreto de Potássio 0,191% + Cloreto de Sódio 0,6% + Glicose 5% solução para injeção 1 L; bolsa"
  },
  {
    "code" : "@brasil19336894245",
    "display" : "Cloreto de Potássio 0,191% + Cloreto de Sódio 0,8% + Glicose 5% solução para injeção 1 L; bolsa"
  },
  {
    "code" : "@brasil15753291336",
    "display" : "Cloreto de Potássio 1,49 mg/mL + Cloreto de Sódio 2,34 mg/mL + Citrato de Sódio 1,96 mg/mL + Glicose 19,83 mg/mL solução oral"
  },
  {
    "code" : "@brasil18071330046",
    "display" : "Cloreto de Potássio 1,5 mg/mL + Citrato de Sódio 2,89 mg/mL + Cloreto de Sódio 1,75 mg/mL + Gliconato de Zinco 0,06 mg/mL + Glicose 11,88 mg/mL solução oral"
  },
  {
    "code" : "@brasil14604706506",
    "display" : "Cloreto de Potássio 10% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "@brasil15232899723",
    "display" : "Cloreto de Potássio 14,91 mg/mL + Cloreto de Sódio 23,4 mg/mL + Citato de Sódio 19,61 mg/mL + Glicose 198,28 mg/mL solução oral"
  },
  {
    "code" : "@brasil12135276525",
    "display" : "Cloreto de Potássio 15% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "@brasil16538208541",
    "display" : "Cloreto de Potássio 19,1% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "@brasil19913727015",
    "display" : "Cloreto de Potássio 373 mg + Citrato de Sódio 490 mg + Cloreto de Sódio 438 mg + Glicose 6 g pó para solução oral"
  },
  {
    "code" : "@brasil13563337411",
    "display" : "Cloreto de Potássio 60 mg/mL solução oral"
  },
  {
    "code" : "@brasil15030665167",
    "display" : "Cloreto de Potássio 60 mg/mL xarope"
  },
  {
    "code" : "@brasil15612773004",
    "display" : "Cloreto de Potássio 600 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil17438246929",
    "display" : "Cloreto de Potássio 749 mg + Citrato de Sódio 1,49 mg + Cloreto de Sódio 1,75 mg + Glicose 9,9 g pó para solução oral"
  },
  {
    "code" : "@brasil18409380183",
    "display" : "Cloreto de Potássio 75 mEq/L solução oral"
  },
  {
    "code" : "@brasil13291546257",
    "display" : "Cloreto de Sódio 0,52% + Gliconato de Sódio 0,5% + Acetato de Sódio 0,36% + Cloreto de Potássio 0,03% + Cloreto de Magnésio 0,03% solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "@brasil12036230425",
    "display" : "Cloreto de Sódio 0,52% + Gliconato de Sódio 0,50% + Acetato de Sódio 0,36% + Cloreto de Potássio 0,03% + Cloreto de Magnésio 0,03% solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "@brasil13485540209",
    "display" : "Cloreto de Sódio 0,9% + Glicose 10% solução para injeção 250 mL; frasco-ampola"
  },
  {
    "code" : "@brasil19768201352",
    "display" : "Cloreto de Sódio 0,9% + Glicose 5% solução para injeção 1 L; bolsa"
  },
  {
    "code" : "@brasil18187098229",
    "display" : "Cloreto de Sódio 0,9% + Glicose 5% solução para injeção 1 L; frasco-ampola"
  },
  {
    "code" : "@brasil18883874338",
    "display" : "Cloreto de Sódio 0,9% + Glicose 5% solução para injeção 250 mL; bolsa"
  },
  {
    "code" : "@brasil11496201101",
    "display" : "Cloreto de Sódio 0,9% + Glicose 5% solução para injeção 250 mL; frasco-ampola"
  },
  {
    "code" : "@brasil12800288760",
    "display" : "Cloreto de Sódio 0,9% + Glicose 5% solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "@brasil10974827091",
    "display" : "Cloreto de Sódio 0,9% + Glicose 5% solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "@brasil14960770824",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 1 L; bolsa"
  },
  {
    "code" : "@brasil16651493483",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 1 L; frasco-ampola"
  },
  {
    "code" : "@brasil11563190762",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "@brasil12062092955",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 100 mL; bolsa"
  },
  {
    "code" : "@brasil16534767118",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 100 mL; frasco-ampola"
  },
  {
    "code" : "@brasil11531849736",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 125 mL; frasco-ampola"
  },
  {
    "code" : "@brasil19979748099",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 20 mL; ampola"
  },
  {
    "code" : "@brasil16711649079",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 20 mL; frasco-ampola"
  },
  {
    "code" : "@brasil14819423522",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 250 mL; bolsa"
  },
  {
    "code" : "@brasil13072347484",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 250 mL; frasco-ampola"
  },
  {
    "code" : "@brasil14999793277",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 50 mL; bolsa"
  },
  {
    "code" : "@brasil14468865443",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 50 mL; frasco-ampola"
  },
  {
    "code" : "@brasil13318142454",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "@brasil14555869496",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "@brasil19918341690",
    "display" : "Cloreto de Sódio 0,9% solução para irrigação 2 L; bolsa"
  },
  {
    "code" : "@brasil17006136351",
    "display" : "Cloreto de Sódio 0,9% solução para irrigação 3 L; bolsa"
  },
  {
    "code" : "@brasil16628327681",
    "display" : "Cloreto de Sódio 10% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "@brasil13966014620",
    "display" : "Cloreto de Sódio 10% solução para injeção 20 mL; ampola"
  },
  {
    "code" : "@brasil18411285724",
    "display" : "Cloreto de Sódio 175,5 mg/mL (17,55%) solução para injeção 10 mL; ampola"
  },
  {
    "code" : "@brasil10422752703",
    "display" : "Cloreto de Sódio 20% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "@brasil17024230347",
    "display" : "Cloreto de Sódio 20% solução para injeção 20 mL; ampola"
  },
  {
    "code" : "@brasil14391008459",
    "display" : "Cloreto de Sódio 30 mg/mL solução spray"
  },
  {
    "code" : "@brasil15988415474",
    "display" : "Cloreto de Sódio 4,5 mg/g gel"
  },
  {
    "code" : "@brasil10306471585",
    "display" : "Cloreto de Sódio 50 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil17253331500",
    "display" : "Cloreto de Sódio 6 mg/g gel"
  },
  {
    "code" : "@brasil15634878765",
    "display" : "Cloreto de Sódio 6,371 mg/mL + Acetato de Sódio 3,95 mg/mL + Cloreto de Potássio 0,746 mg/mL + Cloreto de Cálcio 0,515 mg/mL + Cloreto de Magnésio 0,305 mg/mL + Citrato de Sódio 1,67 mg/mL solução oftálmica 250 mL; bolsa"
  },
  {
    "code" : "@brasil16650130771",
    "display" : "Cloreto de Sódio 6,371 mg/mL + Acetato de Sódio 3,95 mg/mL + Cloreto de Potássio 0,746 mg/mL + Cloreto de Cálcio 0,515 mg/mL + Cloreto de Magnésio 0,305 mg/mL + Citrato de Sódio 1,67 mg/mL solução oftálmica 500 mL; bolsa"
  },
  {
    "code" : "@brasil19020112973",
    "display" : "Cloreto de Sódio 9 mg/mL (0,9%) + Cloreto de Benzalcônio 0,1 mg/mL (0,01%) + Nafazolina 0,5 mg/mL (0,05%) solução nasal"
  },
  {
    "code" : "@brasil10975829735",
    "display" : "Cloreto de Sódio 9 mg/mL (0,9%) solução"
  },
  {
    "code" : "@brasil17872599899",
    "display" : "Cloreto de Sódio 9 mg/mL (0,9%) solução nasal"
  },
  {
    "code" : "@brasil12915478005",
    "display" : "Cloreto de Sódio 9 mg/mL (0,9%) suspensão para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "@brasil15369597062",
    "display" : "Cloreto de Suxametônio 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16260260459",
    "display" : "Cloreto de Suxametônio 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13760744242",
    "display" : "Clorexidina 0,2% solução"
  },
  {
    "code" : "@brasil18166139615",
    "display" : "Clorexidina 10 mg/mL solução"
  },
  {
    "code" : "@brasil11552488412",
    "display" : "Clorexidina 10 mg/mL solução spray"
  },
  {
    "code" : "@brasil13529305460",
    "display" : "Clorfeniramina 1 mg + Ácido Ascórbico 50 mg + Dipirona 100 mg comprimido"
  },
  {
    "code" : "@brasil10123622211",
    "display" : "Cloridrato de Aminolevulinato 160 mg/g creme"
  },
  {
    "code" : "@brasil13932443319",
    "display" : "Cloridrato de Articaína 72 mg/1,8 mL + Epinefrina 18 microgramas/1,8 mL (1:100.000) solução para injeção; carpule"
  },
  {
    "code" : "@brasil18730148977",
    "display" : "Cloridrato de Difenidramina 1,5 mg/mL + Paracetamol 12 mg/mL + Pseudoefedrina 1,5 mg/mL + Dropropizina 1,5 mg/mL xarope"
  },
  {
    "code" : "@brasil14420086371",
    "display" : "Cloridrato de Difenidramina 10 mg/mL + Calamina 80 mg/mL + Cânfora 1 mg/mL loção"
  },
  {
    "code" : "@brasil16109762549",
    "display" : "Cloridrato de Difenidramina 5 mg/mL + Cloreto de Amônio 25 mg/mL gel oral"
  },
  {
    "code" : "@brasil19045030695",
    "display" : "Cloridrato de Levomepromazina 40 mg/mL solução oral"
  },
  {
    "code" : "@brasil18952268070",
    "display" : "Cloridrato de Midazolam 50 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18603773113",
    "display" : "Cloridrato de Oxitetraciclina 30 mg/g + Hidrocortisona 10 mg/g pomada"
  },
  {
    "code" : "@brasil13472494596",
    "display" : "Cloridrato de Pilocarpina 10 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil12632282247",
    "display" : "Cloridrato de Pilocarpina 20 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil18443317819",
    "display" : "Cloridrato de Pilocarpina 40 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil11347837960",
    "display" : "Cloridrato de Prometazina 25 mg comprimido"
  },
  {
    "code" : "@brasil17856892064",
    "display" : "Cloridrato de Quinina 100 mg + Papaverina 40 mg comprimido"
  },
  {
    "code" : "@brasil11138484105",
    "display" : "Cloridrato de Sevelâmer 400 mg comprimido"
  },
  {
    "code" : "@brasil15462612466",
    "display" : "Cloridrato de Sevelâmer 800 mg comprimido"
  },
  {
    "code" : "@brasil18650587281",
    "display" : "Cloridrato de Tansulosina 0,4mg"
  },
  {
    "code" : "@brasil12196048359",
    "display" : "Clormadinona 2 mg + Etinilestradiol 0,02 mg comprimido"
  },
  {
    "code" : "@brasil10850498173",
    "display" : "Clormadinona 2 mg + Etinilestradiol 0,03 mg comprimido"
  },
  {
    "code" : "@brasil10790050737",
    "display" : "Cloroquina 150 mg comprimido"
  },
  {
    "code" : "@brasil10068666347",
    "display" : "Cloroquina 250 mg comprimido"
  },
  {
    "code" : "@brasil16316056758",
    "display" : "Clorpromazina 100 mg comprimido"
  },
  {
    "code" : "@brasil10942250843",
    "display" : "Clorpromazina 25 mg comprimido"
  },
  {
    "code" : "@brasil19883254373",
    "display" : "Clorpromazina 25 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14671211711",
    "display" : "Clorpromazina 25 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19384932189",
    "display" : "Clorpromazina 40 mg/mL solução oral"
  },
  {
    "code" : "@brasil17262326875",
    "display" : "Clorpropamida 250 mg comprimido"
  },
  {
    "code" : "@brasil17404114208",
    "display" : "Clortalidona 12,5 mg comprimido"
  },
  {
    "code" : "@brasil18028034750",
    "display" : "Clortalidona 25 mg + Amilorida 5 mg comprimido"
  },
  {
    "code" : "@brasil15703496396",
    "display" : "Clortalidona 25 mg comprimido"
  },
  {
    "code" : "@brasil17903863979",
    "display" : "Clortalidona 50 mg comprimido"
  },
  {
    "code" : "@brasil10234530613",
    "display" : "Clorzoxazona 200 mg + Paracetamol 300 mg comprimido"
  },
  {
    "code" : "@brasil19335816267",
    "display" : "Clotrimazol 10 mg/g (1%) creme"
  },
  {
    "code" : "@brasil19463028476",
    "display" : "Clotrimazol 10 mg/g + Dexametasona 0,4 mg/g creme"
  },
  {
    "code" : "@brasil16248640459",
    "display" : "Clotrimazol 10 mg/g creme vaginal"
  },
  {
    "code" : "@brasil18300097665",
    "display" : "Clotrimazol 10 mg/mL (1%) solução"
  },
  {
    "code" : "@brasil14804969032",
    "display" : "Clotrimazol 10 mg/mL solução spray"
  },
  {
    "code" : "@brasil15829327520",
    "display" : "Clotrimazol 20 mg/g creme vaginal"
  },
  {
    "code" : "@brasil14970314058",
    "display" : "Clotrimazol 500 mg comprimido vaginal"
  },
  {
    "code" : "@brasil18746728148",
    "display" : "Cloxazolam 1 mg comprimido"
  },
  {
    "code" : "@brasil19661284058",
    "display" : "Cloxazolam 2 mg comprimido"
  },
  {
    "code" : "@brasil16167114530",
    "display" : "Cloxazolam 4 mg comprimido"
  },
  {
    "code" : "@brasil14778116767",
    "display" : "Clozapina 100 mg comprimido"
  },
  {
    "code" : "@brasil15594557033",
    "display" : "Clozapina 25 mg comprimido"
  },
  {
    "code" : "@brasil12557594460",
    "display" : "Coaltar 40 mg/mL xampu"
  },
  {
    "code" : "@brasil17822372537",
    "display" : "Cobamamida 5 mg comprimido mastigável"
  },
  {
    "code" : "@brasil13663982797",
    "display" : "Cobimetinibe 20 mg comprimido"
  },
  {
    "code" : "@brasil15574052467",
    "display" : "Codeína 3 mg/mL solução oral"
  },
  {
    "code" : "@brasil10265851541",
    "display" : "Codeína 30 mg comprimido"
  },
  {
    "code" : "@brasil18786213180",
    "display" : "Codeína 45 mg comprimido"
  },
  {
    "code" : "@brasil19308918721",
    "display" : "Codeína 60 mg comprimido"
  },
  {
    "code" : "@brasil16921417103",
    "display" : "Codeína 60 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12789366404",
    "display" : "Colagenase 0,6 unidades/g pomada"
  },
  {
    "code" : "@brasil19648742971",
    "display" : "Colagenase 1,2 unidades/g pomada"
  },
  {
    "code" : "@brasil16875517531",
    "display" : "Colchicina 0,5 mg comprimido"
  },
  {
    "code" : "@brasil14275974801",
    "display" : "Colchicina 1 mg comprimido"
  },
  {
    "code" : "@brasil17015001368",
    "display" : "Colecalciferol 1.000 unidades internacionais cápsula"
  },
  {
    "code" : "@brasil17999579027",
    "display" : "Colecalciferol 1.000 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil15564981590",
    "display" : "Colecalciferol 1.000 unidades internacionais comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil19833159491",
    "display" : "Colecalciferol 10.000 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil15086953270",
    "display" : "Colecalciferol 2.000 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil14795015690",
    "display" : "Colecalciferol 3.300 unidades internacionais/mL solução oral"
  },
  {
    "code" : "@brasil16696266694",
    "display" : "Colecalciferol 5.000 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil19370440065",
    "display" : "Colecalciferol 5.600 unidades internacionais/mL solução oral"
  },
  {
    "code" : "@brasil16634817705",
    "display" : "Colecalciferol 50.000 unidades internacionais cápsula"
  },
  {
    "code" : "@brasil17554453784",
    "display" : "Colecalciferol 50.000 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil11062043830",
    "display" : "Colecalciferol 7.000 unidades internacionais cápsula"
  },
  {
    "code" : "@brasil15720560777",
    "display" : "Colecalciferol 7.000 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil12801687215",
    "display" : "Colestiramina 4 g pó para suspensão oral"
  },
  {
    "code" : "@brasil18147097086",
    "display" : "Colistimetato de Sódio 1.000.000 unidades internacionais pó para solução; frasco-ampola"
  },
  {
    "code" : "@brasil17117203860",
    "display" : "Colistina 150 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11765582142",
    "display" : "Concentrado de Complexo Protrombínico 250 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14571360697",
    "display" : "Concentrado de Complexo Protrombínico 500 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15649126660",
    "display" : "Concentrado de Complexo Protrombínico 510 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17895266409",
    "display" : "Cordia verbenacea 5 mg/g solução aerossol"
  },
  {
    "code" : "@brasil12259553094",
    "display" : "Corynebacterium parvulan 10 mg/5 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12454241738",
    "display" : "Crizotinibe 200 mg cápsula"
  },
  {
    "code" : "@brasil17002137764",
    "display" : "Crizotinibe 250 mg cápsula"
  },
  {
    "code" : "@brasil16393713834",
    "display" : "Cromoglicato Dissódico 20 mg/mL (2%) solução oftálmica"
  },
  {
    "code" : "@brasil17196698566",
    "display" : "Cromoglicato Dissódico 20 mg/mL solução spray"
  },
  {
    "code" : "@brasil13213514994",
    "display" : "Cromoglicato Dissódico 40 mg/mL (4%) solução oftálmica"
  },
  {
    "code" : "@brasil10755352591",
    "display" : "Cromoglicato Dissódico 40 mg/mL solução spray"
  },
  {
    "code" : "@brasil13569437109",
    "display" : "Cumarina 15 mg + Troxerrutina 90 mg comprimido"
  },
  {
    "code" : "@brasil17980054995",
    "display" : "Cumarina 15 mg + Troxerrutina 90 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil13205922433",
    "display" : "Cumarina 5 mg/mL + Heparina sódica 50 unidades internacionais/mL creme"
  },
  {
    "code" : "@brasil18109468124",
    "display" : "Dabrafenibe 50 mg cápsula"
  },
  {
    "code" : "@brasil17006134507",
    "display" : "Dabrafenibe 75 mg cápsula"
  },
  {
    "code" : "@brasil11144728353",
    "display" : "Dacarbazina 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12358029057",
    "display" : "Dacarbazina 200 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18667280363",
    "display" : "Dacarbazina 600 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13286233387",
    "display" : "Daclatasvir 30 mg comprimido"
  },
  {
    "code" : "@brasil11263057459",
    "display" : "Daclatasvir 60 mg comprimido"
  },
  {
    "code" : "@brasil18747913834",
    "display" : "Dactinomicina 0,5 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14315005617",
    "display" : "Dalteparina Sódica 2.500 unidades internacionais /0,2 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil14251178114",
    "display" : "Dalteparina Sódica 5.000 unidades internacionais /0,2 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil13421311110",
    "display" : "Danazol 100 mg cápsula"
  },
  {
    "code" : "@brasil10209452630",
    "display" : "Danazol 100 mg comprimido"
  },
  {
    "code" : "@brasil11985673988",
    "display" : "Danazol 200 mg cápsula"
  },
  {
    "code" : "@brasil11333395606",
    "display" : "Danazol 50 mg cápsula"
  },
  {
    "code" : "@brasil10392350637",
    "display" : "Dantroleno 100 mg cápsula"
  },
  {
    "code" : "@brasil10833582635",
    "display" : "Dantroleno 20 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15489926425",
    "display" : "Dantroleno 25 mg cápsula"
  },
  {
    "code" : "@brasil17775542573",
    "display" : "Dapagliflozina 10 mg + Metformina 1 g comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil17728191861",
    "display" : "Dapagliflozina 10 mg + Metformina 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil19395129296",
    "display" : "Dapagliflozina 10 mg comprimido"
  },
  {
    "code" : "@brasil13449445620",
    "display" : "Dapagliflozina 10 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil12254621098",
    "display" : "Dapagliflozina 5 mg + Metformina 1 g comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil18487887602",
    "display" : "Dapagliflozina 5 mg + Metformina 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil10310501101",
    "display" : "Dapagliflozina 5 mg comprimido"
  },
  {
    "code" : "@brasil11164840580",
    "display" : "Dapsona 100 mg comprimido"
  },
  {
    "code" : "@brasil14372030489",
    "display" : "Daptomicina 500 mg pó para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17880156371",
    "display" : "Daratumumabe 100 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11717450572",
    "display" : "Daratumumabe 400 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19575344303",
    "display" : "Darifenacina 15 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil14476262119",
    "display" : "Darifenacina 7,5 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil10469724656",
    "display" : "Darunavir 150 mg comprimido"
  },
  {
    "code" : "@brasil11155655924",
    "display" : "Darunavir 300 mg comprimido"
  },
  {
    "code" : "@brasil19603004583",
    "display" : "Darunavir 600 mg comprimido"
  },
  {
    "code" : "@brasil17761813118",
    "display" : "Darunavir 75 mg comprimido"
  },
  {
    "code" : "@brasil19917092032",
    "display" : "Dasatinibe 100 mg comprimido"
  },
  {
    "code" : "@brasil18568433333",
    "display" : "Dasatinibe 20 mg comprimido"
  },
  {
    "code" : "@brasil13546407830",
    "display" : "Dasatinibe 50 mg comprimido"
  },
  {
    "code" : "@brasil17480680062",
    "display" : "Daunorrubicina 20 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18714466939",
    "display" : "Daunorrubicina 20 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14149483752",
    "display" : "Daunorrubicina 50 mg/25 mL emulsão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15341198354",
    "display" : "Decanoato de Zuclopentixol 200 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12223198330",
    "display" : "Decitabina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10357155864",
    "display" : "Deferasirox 125 mg comprimido para suspensão"
  },
  {
    "code" : "@brasil11343360031",
    "display" : "Deferasirox 250 mg comprimido para suspensão"
  },
  {
    "code" : "@brasil12729333454",
    "display" : "Deferasirox 500 mg comprimido para suspensão"
  },
  {
    "code" : "@brasil10997372232",
    "display" : "Deferiprona 500 mg comprimido"
  },
  {
    "code" : "@brasil16023900913",
    "display" : "Deflazacorte 30 mg comprimido"
  },
  {
    "code" : "@brasil12444685698",
    "display" : "Deflazacorte 6 mg comprimido"
  },
  {
    "code" : "@brasil16460076062",
    "display" : "Deflazacorte 7,5 mg comprimido"
  },
  {
    "code" : "@brasil14403509984",
    "display" : "Degarrelix 120 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17337922421",
    "display" : "Degarrelix 80 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14286929781",
    "display" : "Delapril 30 mg + Manidipino 10 mg comprimido"
  },
  {
    "code" : "@brasil11269551822",
    "display" : "Deltametrina 0,2 mg/mL loção"
  },
  {
    "code" : "@brasil17346979887",
    "display" : "Deltametrina 0,2 mg/mL xampu"
  },
  {
    "code" : "@brasil16685285880",
    "display" : "Denosumabe 120 mg/1,7 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14623577187",
    "display" : "Denosumabe 60 mg/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil10799287426",
    "display" : "Desferroxamina 500 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15761518444",
    "display" : "Desferroxamina 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10889455312",
    "display" : "Desflurano líquido para inalação 240 mL"
  },
  {
    "code" : "@brasil16231996579",
    "display" : "Deslanosídeo 0,4 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18104918595",
    "display" : "Desloratadina 0,5 mg/mL xarope"
  },
  {
    "code" : "@brasil18367204187",
    "display" : "Desloratadina 1,25 mg/mL solução oral"
  },
  {
    "code" : "@brasil11123812319",
    "display" : "Desloratadina 2,5 mg + Pseudoefedrina 120 mg comprimido de liberação modificada"
  },
  {
    "code" : "@brasil14441351679",
    "display" : "Desloratadina 5 mg comprimido"
  },
  {
    "code" : "@brasil12430398660",
    "display" : "Desmopressina 0,1 mg comprimido"
  },
  {
    "code" : "@brasil16855302243",
    "display" : "Desmopressina 0,1 mg/mL solução nasal"
  },
  {
    "code" : "@brasil10368875003",
    "display" : "Desmopressina 0,1 mg/mL solução spray"
  },
  {
    "code" : "@brasil13785947451",
    "display" : "Desmopressina 0,2 mg comprimido"
  },
  {
    "code" : "@brasil13226415665",
    "display" : "Desmopressina 15 microgramas/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10178446377",
    "display" : "Desmopressina 4 microgramas/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19963660526",
    "display" : "Desogestrel 0,125 mg + Etinilestradiol 0,03 mg comprimido e Desogestrel 0,025 mg + Etinilestradiol 0,04 mg comprimido"
  },
  {
    "code" : "@brasil18233361892",
    "display" : "Desogestrel 0,15 mg + Etinilestradiol 0,02 mg comprimido"
  },
  {
    "code" : "@brasil13884731198",
    "display" : "Desogestrel 0,15 mg + Etinilestradiol 0,02 mg comprimido e Etinilestradiol 0,01 mg comprimido"
  },
  {
    "code" : "@brasil17997247871",
    "display" : "Desogestrel 0,15 mg + Etinilestradiol 0,03 mg comprimido"
  },
  {
    "code" : "@brasil15937620870",
    "display" : "Desogestrel 75 microgramas comprimido"
  },
  {
    "code" : "@brasil15937588367",
    "display" : "Desonida 0,5 mg/g creme"
  },
  {
    "code" : "@brasil12391977609",
    "display" : "Desonida 0,5 mg/g gel creme"
  },
  {
    "code" : "@brasil16119539937",
    "display" : "Desonida 0,5 mg/g loção"
  },
  {
    "code" : "@brasil17305233083",
    "display" : "Desonida 0,5 mg/g pomada"
  },
  {
    "code" : "@brasil10817973771",
    "display" : "Desonida 1 mg/g loção"
  },
  {
    "code" : "@brasil18247047258",
    "display" : "Desoximetasona 2,5 mg/g + Neomicina 7,145 mg/g pomada"
  },
  {
    "code" : "@brasil16656234455",
    "display" : "Desoximetasona 2,5 mg/g pomada"
  },
  {
    "code" : "@brasil14736961185",
    "display" : "Desoxirribonuclease 666 unidades/g + Fibrinolisina 1 unidade/g + Cloranfenicol 10 mg/g pomada"
  },
  {
    "code" : "@brasil10541243412",
    "display" : "Desvenlafaxina 100 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil16324030798",
    "display" : "Desvenlafaxina 50 mg comprimido"
  },
  {
    "code" : "@brasil13377466781",
    "display" : "Desvenlafaxina 50 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil17223611181",
    "display" : "Dexametasona 0,05 mg/mL + Cloranfenicol 5 mg/mL + Tetrizolina 0,25 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil15994824948",
    "display" : "Dexametasona 0,1 mg/mL elixir"
  },
  {
    "code" : "@brasil16583526138",
    "display" : "Dexametasona 0,5 mg comprimido"
  },
  {
    "code" : "@brasil13722042983",
    "display" : "Dexametasona 0,5 mg/mL + Neomicina 3,5 mg/mL + Fenilefrina 5 mg/mL solução spray"
  },
  {
    "code" : "@brasil15761927546",
    "display" : "Dexametasona 0,7 mg implante; dispositivo"
  },
  {
    "code" : "@brasil18085434377",
    "display" : "Dexametasona 0,75 mg comprimido"
  },
  {
    "code" : "@brasil16913173669",
    "display" : "Dexametasona 1 mg/g (0,1%) creme"
  },
  {
    "code" : "@brasil14094941348",
    "display" : "Dexametasona 1 mg/g + Neomicina 5 mg/g + Polimixina B 6.000 unidades internacionais/g pomada oftálmica"
  },
  {
    "code" : "@brasil16011530500",
    "display" : "Dexametasona 1 mg/g + Neomicina 5 mg/g creme"
  },
  {
    "code" : "@brasil11049154726",
    "display" : "Dexametasona 1 mg/g pomada oftálmica"
  },
  {
    "code" : "@brasil15494062978",
    "display" : "Dexametasona 1 mg/mL (0,1%) solução oftálmica"
  },
  {
    "code" : "@brasil11290350025",
    "display" : "Dexametasona 1 mg/mL + Neomicina 3,5 mg/mL + Polimixina B 6.000 unidades internacionais/mL solução oftálmica"
  },
  {
    "code" : "@brasil19695267293",
    "display" : "Dexametasona 1 mg/mL + Neomicina 3,5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil17175698313",
    "display" : "Dexametasona 1 mg/mL suspensão oftálmica"
  },
  {
    "code" : "@brasil19186512443",
    "display" : "Dexametasona 1,33 mg/mL + Neomicina 3,5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil12613775675",
    "display" : "Dexametasona 10 mg/g (1%) creme"
  },
  {
    "code" : "@brasil13603549340",
    "display" : "Dexametasona 4 mg comprimido"
  },
  {
    "code" : "@brasil18314798517",
    "display" : "Dexbronfeniramina 6 mg + Pseudoefedrina 120 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil16698104091",
    "display" : "Dexclorfeniramina 0,4 mg/mL + Betametasona 0,05 mg/mL xarope"
  },
  {
    "code" : "@brasil15998178044",
    "display" : "Dexclorfeniramina 0,4 mg/mL + Pseudoefedrina 4 mg/mL + Guaifenesina 20 mg/mL solução oral"
  },
  {
    "code" : "@brasil10084350732",
    "display" : "Dexclorfeniramina 0,4 mg/mL solução oral"
  },
  {
    "code" : "@brasil16077311406",
    "display" : "Dexclorfeniramina 0,4 mg/mL xarope"
  },
  {
    "code" : "@brasil19036169412",
    "display" : "Dexclorfeniramina 10 mg/g creme"
  },
  {
    "code" : "@brasil16959194070",
    "display" : "Dexclorfeniramina 2 mg + Betametasona 0,25 mg comprimido"
  },
  {
    "code" : "@brasil15755933480",
    "display" : "Dexclorfeniramina 2 mg comprimido"
  },
  {
    "code" : "@brasil11710156305",
    "display" : "Dexclorfeniramina 2 mg/mL + Betametasona 0,25 mg/mL solução oral"
  },
  {
    "code" : "@brasil15732775203",
    "display" : "Dexclorfeniramina 2,8 mg/mL solução oral"
  },
  {
    "code" : "@brasil18868998826",
    "display" : "Dexclorfeniramina 6 mg comprimido"
  },
  {
    "code" : "@brasil13137773453",
    "display" : "Dexclorfeniramina 6 mg comprimido de liberação modificada"
  },
  {
    "code" : "@brasil17536133225",
    "display" : "Dexlansoprazol 30 mg cápsula de liberação modificada"
  },
  {
    "code" : "@brasil12002376924",
    "display" : "Dexlansoprazol 60 mg cápsula de liberação modificada"
  },
  {
    "code" : "@brasil13121579449",
    "display" : "Dexmedetomidina 200 microgramas /2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13637120893",
    "display" : "Dexpantenol 50 mg/g gel oftálmico"
  },
  {
    "code" : "@brasil11076546534",
    "display" : "Dexpantenol 50 mg/g pomada"
  },
  {
    "code" : "@brasil10378600525",
    "display" : "Dexrazoxano 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19913161422",
    "display" : "Dextrocetamina 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15340092679",
    "display" : "Dextrocetamina 100 mg/2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15301198552",
    "display" : "Dextrocetamina 500 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13696474053",
    "display" : "Dextrometorfano 1,3 mg/mL + Guaifenesina 13,3 mg/mL xarope"
  },
  {
    "code" : "@brasil13351733248",
    "display" : "Dextrometorfano 2 mg/mL xarope"
  },
  {
    "code" : "@brasil12152764276",
    "display" : "Di-hidroergocristina 3 mg + Flunarizina 10 mg comprimido"
  },
  {
    "code" : "@brasil14454859013",
    "display" : "Di-hidroergocristina 6 mg cápsula"
  },
  {
    "code" : "@brasil18150268128",
    "display" : "Di-hidroergotamina 1 mg + Dipirona 350 mg + Cafeína 100 mg comprimido"
  },
  {
    "code" : "@brasil15632171178",
    "display" : "Di-hidroergotamina 1 mg + Paracetamol 450 mg + Cafeína 75 mg + Metoclopramida 10 mg comprimido"
  },
  {
    "code" : "@brasil16936008571",
    "display" : "Diacereína 50 mg cápsula"
  },
  {
    "code" : "@brasil14097462121",
    "display" : "Diazepam 10 mg comprimido"
  },
  {
    "code" : "@brasil16077512907",
    "display" : "Diazepam 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18987910120",
    "display" : "Diazepam 10 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19328299208",
    "display" : "Diazepam 5 mg comprimido"
  },
  {
    "code" : "@brasil12489539190",
    "display" : "Diazóxido 25 mg cápsula"
  },
  {
    "code" : "@brasil15275479102",
    "display" : "Diazóxido 300 mg/20 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15386583575",
    "display" : "Diazóxido 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil13617893962",
    "display" : "Dicicloverina 20 mg/mL solução oral"
  },
  {
    "code" : "@brasil11900029546",
    "display" : "Diclofenaco Colestiramina 140 mg cápsula"
  },
  {
    "code" : "@brasil13163710918",
    "display" : "Diclofenaco Dietilamônio 10 mg/g (1%) gel"
  },
  {
    "code" : "@brasil13550715187",
    "display" : "Diclofenaco Dietilamônio 10 mg/g gel creme"
  },
  {
    "code" : "@brasil12918866119",
    "display" : "Diclofenaco Dietilamônio 11,6 mg/g gel"
  },
  {
    "code" : "@brasil11034155143",
    "display" : "Diclofenaco Dietilamônio 11,6 mg/g gel creme"
  },
  {
    "code" : "@brasil19418314627",
    "display" : "Diclofenaco Dietilamônio 11,6 mg/g solução aerossol"
  },
  {
    "code" : "@brasil15444106919",
    "display" : "Diclofenaco Dietilamônio 23,2 mg/g gel"
  },
  {
    "code" : "@brasil15734141640",
    "display" : "Diclofenaco Potássico 15 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil12772835093",
    "display" : "Diclofenaco Potássico 2 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil15939442845",
    "display" : "Diclofenaco Potássico 25 mg comprimido"
  },
  {
    "code" : "@brasil12251741076",
    "display" : "Diclofenaco Potássico 50 mg comprimido"
  },
  {
    "code" : "@brasil12535532201",
    "display" : "Diclofenaco Potássico 50 mg comprimido para suspensão"
  },
  {
    "code" : "@brasil17514473717",
    "display" : "Diclofenaco Potássico 75 mg/3 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15859599685",
    "display" : "Diclofenaco Sódico 1 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil18795767628",
    "display" : "Diclofenaco Sódico 10 mg/g gel"
  },
  {
    "code" : "@brasil12995587877",
    "display" : "Diclofenaco Sódico 100 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil19180254411",
    "display" : "Diclofenaco Sódico 100 mg comprimido"
  },
  {
    "code" : "@brasil16996169998",
    "display" : "Diclofenaco Sódico 100 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil18526222404",
    "display" : "Diclofenaco Sódico 150 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil12943054802",
    "display" : "Diclofenaco Sódico 225 mg/3 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17391132400",
    "display" : "Diclofenaco Sódico 50 mg + Codeína 50 mg comprimido"
  },
  {
    "code" : "@brasil10459382877",
    "display" : "Diclofenaco Sódico 50 mg + Tiamina 50 mg + Piridoxina 50 mg + Cianocobalamina 1 mg comprimido"
  },
  {
    "code" : "@brasil11146139968",
    "display" : "Diclofenaco Sódico 50 mg comprimido"
  },
  {
    "code" : "@brasil10124640529",
    "display" : "Diclofenaco Sódico 50 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil14027635587",
    "display" : "Diclofenaco Sódico 75 mg comprimido"
  },
  {
    "code" : "@brasil10376337430",
    "display" : "Diclofenaco Sódico 75 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil18027714077",
    "display" : "Diclofenaco Sódico 75 mg/3 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10459733763",
    "display" : "Dicloridrato de Manidipino 10 mg comprimido"
  },
  {
    "code" : "@brasil14181132794",
    "display" : "Dicloridrato de Manidipino 20 mg comprimido"
  },
  {
    "code" : "@brasil12941863799",
    "display" : "Dicloridrato de Quinina 600 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13103132892",
    "display" : "Didanosina 100 mg comprimido"
  },
  {
    "code" : "@brasil12975094860",
    "display" : "Didanosina 25 mg comprimido"
  },
  {
    "code" : "@brasil11434067059",
    "display" : "Didanosina 250 mg cápsula gastrorresistente"
  },
  {
    "code" : "@brasil15369045449",
    "display" : "Didanosina 400 mg cápsula gastrorresistente"
  },
  {
    "code" : "@brasil12420961457",
    "display" : "Didanosina 400 mg comprimido"
  },
  {
    "code" : "@brasil19526462990",
    "display" : "Didrogesterona 10 mg comprimido"
  },
  {
    "code" : "@brasil12803909491",
    "display" : "Dienogeste 2 mg comprimido"
  },
  {
    "code" : "@brasil10581127860",
    "display" : "Dietilestilbestrol 1 mg comprimido"
  },
  {
    "code" : "@brasil16867940980",
    "display" : "Difenidramina 10 mg/g + Calamina 80 mg/g + Cânfora 1 mg/g creme"
  },
  {
    "code" : "@brasil13403309464",
    "display" : "Difenidramina 2,5 mg/mL + Cloreto de Amônio 25 mg/mL + Citrato de Sódio 11,25 mg/mL xarope"
  },
  {
    "code" : "@brasil11480463221",
    "display" : "Difenidramina 5 mg + Cloreto de Amônio 50 mg + Citrato de Sódio 10 mg pastilha"
  },
  {
    "code" : "@brasil18081886485",
    "display" : "Difenidramina 50 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12985573514",
    "display" : "Digoxina 0,05 mg/mL elixir"
  },
  {
    "code" : "@brasil12388253427",
    "display" : "Digoxina 0,125 mg comprimido"
  },
  {
    "code" : "@brasil16940738479",
    "display" : "Digoxina 0,25 mg comprimido"
  },
  {
    "code" : "@brasil12088230010",
    "display" : "Digoxina 0,5 mg/mL solução oral"
  },
  {
    "code" : "@brasil15856043663",
    "display" : "Diltiazem 120 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil17043716865",
    "display" : "Diltiazem 120 mg comprimido"
  },
  {
    "code" : "@brasil16796291298",
    "display" : "Diltiazem 180 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil15590141028",
    "display" : "Diltiazem 240 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil16198571477",
    "display" : "Diltiazem 30 mg comprimido"
  },
  {
    "code" : "@brasil17877601819",
    "display" : "Diltiazem 300 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil10080832260",
    "display" : "Diltiazem 60 mg comprimido"
  },
  {
    "code" : "@brasil13415084678",
    "display" : "Diltiazem 90 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil11457242667",
    "display" : "Diltiazem 90 mg comprimido"
  },
  {
    "code" : "@brasil11868465459",
    "display" : "Dimenidrinato 100 mg comprimido"
  },
  {
    "code" : "@brasil11879755799",
    "display" : "Dimenidrinato 2,5 mg/mL solução oral"
  },
  {
    "code" : "@brasil12115187617",
    "display" : "Dimenidrinato 25 mg cápsula"
  },
  {
    "code" : "@brasil15712509941",
    "display" : "Dimenidrinato 25 mg/mL + Piridoxina 5 mg/mL solução oral"
  },
  {
    "code" : "@brasil10892385896",
    "display" : "Dimenidrinato 30 mg/10 mL + Piridoxina 50 mg/10 mL + Glicose 1 g/10 mL + Frutose 1 g/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16553713301",
    "display" : "Dimenidrinato 50 mg + Piridoxina 10 mg comprimido"
  },
  {
    "code" : "@brasil15288463592",
    "display" : "Dimenidrinato 50 mg cápsula"
  },
  {
    "code" : "@brasil19761684674",
    "display" : "Dimenidrinato 50 mg/1 mL + Piridoxina 50 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13518177058",
    "display" : "Dimenidrinato 50 mg/1 mL + Piridoxina 50 mg/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18578546854",
    "display" : "Dimenidrinato 500 mg/10 mL + Piridoxina 500 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14146636922",
    "display" : "Dinitrato de Isossorbida 10 mg comprimido"
  },
  {
    "code" : "@brasil12231623000",
    "display" : "Dinitrato de Isossorbida 20 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil12203841182",
    "display" : "Dinitrato de Isossorbida 40 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil12027011104",
    "display" : "Dinitrato de Isossorbida 5 mg comprimido sublingual"
  },
  {
    "code" : "@brasil18852629556",
    "display" : "Dinoprostona 10 mg óvulo"
  },
  {
    "code" : "@brasil17212832155",
    "display" : "Diosmina 450 mg + Hesperidina 50 mg comprimido"
  },
  {
    "code" : "@brasil19257862472",
    "display" : "Diosmina 900 mg + Hesperidina 100 mg comprimido"
  },
  {
    "code" : "@brasil15076957515",
    "display" : "Diosmina 900 mg + Hesperidina 100 mg granulado"
  },
  {
    "code" : "@brasil13379102760",
    "display" : "Dipiridamol 10 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14043071197",
    "display" : "Dipiridamol 100 mg comprimido"
  },
  {
    "code" : "@brasil14359942612",
    "display" : "Dipiridamol 75 mg comprimido"
  },
  {
    "code" : "@brasil15247459908",
    "display" : "Dipirona 1 g comprimido"
  },
  {
    "code" : "@brasil15522274350",
    "display" : "Dipirona 1 g comprimido efervescente"
  },
  {
    "code" : "@brasil10954474154",
    "display" : "Dipirona 1 g/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15565096069",
    "display" : "Dipirona 2,5 g/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15411730458",
    "display" : "Dipirona 250 mg + Clorfeniramina 2 mg comprimido e Dipirona 250 mg + Cafeína 30 mg comprimido"
  },
  {
    "code" : "@brasil19816333258",
    "display" : "Dipirona 300 mg + Escopolamina 6,5 microgramas + Hiosciamina 104 microgramas + Homatropina 1 mg comprimido"
  },
  {
    "code" : "@brasil10925990603",
    "display" : "Dipirona 300 mg + Isometepteno 30 mg + Cafeína 30 mg comprimido"
  },
  {
    "code" : "@brasil10566353480",
    "display" : "Dipirona 300 mg supositório"
  },
  {
    "code" : "@brasil13451631285",
    "display" : "Dipirona 300 mg/mL + Escopolamina 6,5 microgramas/mL + Hiosciamina 104 microgramas/mL + Homatropina 1 mg/mL solução oral"
  },
  {
    "code" : "@brasil17145011225",
    "display" : "Dipirona 300 mg/mL + Isometepteno 50 mg/mL + Cafeína 30 mg/mL solução oral"
  },
  {
    "code" : "@brasil12244674461",
    "display" : "Dipirona 50 mg/mL solução oral"
  },
  {
    "code" : "@brasil19285065184",
    "display" : "Dipirona 500 mg + Cafeína 65 mg comprimido"
  },
  {
    "code" : "@brasil12909563045",
    "display" : "Dipirona 500 mg + Prometazina 5 mg + Adifenina 10 mg comprimido"
  },
  {
    "code" : "@brasil10832536006",
    "display" : "Dipirona 500 mg comprimido"
  },
  {
    "code" : "@brasil19222864403",
    "display" : "Dipirona 500 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12832160109",
    "display" : "Dipirona 500 mg/1,5 mL + Prometazina 5 mg/1,5 mL + Adifenina 10 mg/1,5 mL solução oral"
  },
  {
    "code" : "@brasil13314292143",
    "display" : "Dipirona 500 mg/mL solução oral"
  },
  {
    "code" : "@brasil11217217985",
    "display" : "Dipirona 750 mg/ 2 mL +  Prometazina 25 mg/ 2 mL + Adifenina 25 mg/ 2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10857984721",
    "display" : "Dipropionato de Betametasona 0,5 mg/g (0,05%) pomada"
  },
  {
    "code" : "@brasil12462762092",
    "display" : "Dipropionato de Betametasona 0,5 mg/g + Ácido salicílico 30 mg/g pomada"
  },
  {
    "code" : "@brasil12881738833",
    "display" : "Dipropionato de Betametasona 0,5 mg/g + Gentamicina 1 mg/g creme"
  },
  {
    "code" : "@brasil13673001725",
    "display" : "Dipropionato de Betametasona 0,5 mg/g + Gentamicina 1 mg/g pomada"
  },
  {
    "code" : "@brasil11267339671",
    "display" : "Dipropionato de Betametasona 0,5 mg/g creme"
  },
  {
    "code" : "@brasil14797116260",
    "display" : "Dipropionato de Betametasona 0,5 mg/mL + Ácido salicílico 20 mg/mL solução"
  },
  {
    "code" : "@brasil18758687094",
    "display" : "Dipropionato de Betametasona 1 mg/mL + Ácido salicílico 3 mg/mL solução"
  },
  {
    "code" : "@brasil11166366254",
    "display" : "Dipropionato de Betametasona 5 mg/1 mL + Fosfato Dissódico de Betametasona 2 mg/1 mL suspensão para injeção; ampola"
  },
  {
    "code" : "@brasil13020156576",
    "display" : "Dissulfiram 250 mg comprimido"
  },
  {
    "code" : "@brasil14462478834",
    "display" : "Divalproato de sódio 125 mg cápsula"
  },
  {
    "code" : "@brasil16929661878",
    "display" : "Divalproato de sódio 250 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil11789229484",
    "display" : "Divalproato de sódio 250 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil19745166206",
    "display" : "Divalproato de sódio 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil15819250628",
    "display" : "Divalproato de sódio 500 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil13982134780",
    "display" : "Dobesilato de Cálcio 500 mg cápsula"
  },
  {
    "code" : "@brasil13697005298",
    "display" : "Dobutamina 250 mg/20 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19821347126",
    "display" : "Dobutamina 250 mg/250 mL solução para injeção; bisnaga"
  },
  {
    "code" : "@brasil12535695984",
    "display" : "Dobutamina 250 mg/250 mL solução para injeção; bolsa"
  },
  {
    "code" : "@brasil12245522691",
    "display" : "Dobutamina 280 mg/20 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12974072770",
    "display" : "Docetaxel 120 mg/3 mL solução e diluente para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12472501882",
    "display" : "Docetaxel 20 mg/0,5 mL solução e diluente para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12542198748",
    "display" : "Docetaxel 20 mg/0,5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17723086863",
    "display" : "Docetaxel 20 mg/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13440291408",
    "display" : "Docetaxel 80 mg/2 mL solução e diluente para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14054638978",
    "display" : "Docetaxel 80 mg/2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18148385804",
    "display" : "Docetaxel 80 mg/4 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10943669732",
    "display" : "Dolutegravir 50 mg comprimido"
  },
  {
    "code" : "@brasil12398455376",
    "display" : "Domperidona 1 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil17497709827",
    "display" : "Domperidona 10 mg comprimido"
  },
  {
    "code" : "@brasil10190134857",
    "display" : "Donepezila 10 mg + Memantina 10 mg comprimido"
  },
  {
    "code" : "@brasil13095479041",
    "display" : "Donepezila 10 mg + Memantina 15 mg comprimido"
  },
  {
    "code" : "@brasil14906990940",
    "display" : "Donepezila 10 mg + Memantina 20 mg comprimido"
  },
  {
    "code" : "@brasil15248517891",
    "display" : "Donepezila 10 mg + Memantina 5 mg comprimido"
  },
  {
    "code" : "@brasil13999005455",
    "display" : "Donepezila 10 mg comprimido"
  },
  {
    "code" : "@brasil14648634114",
    "display" : "Donepezila 5 mg comprimido"
  },
  {
    "code" : "@brasil19391886235",
    "display" : "Dopamina 25 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13107746859",
    "display" : "Dopamina 50 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14982935007",
    "display" : "Dorzolamida 20 mg/mL + Timolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil19434987322",
    "display" : "Dorzolamida 20 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil15852411952",
    "display" : "Doxazosina 1 mg comprimido"
  },
  {
    "code" : "@brasil18896537401",
    "display" : "Doxazosina 2 mg + Finasterida 5 mg cápsula"
  },
  {
    "code" : "@brasil16064653558",
    "display" : "Doxazosina 2 mg comprimido"
  },
  {
    "code" : "@brasil13564474351",
    "display" : "Doxazosina 4 mg comprimido"
  },
  {
    "code" : "@brasil11370290834",
    "display" : "Doxazosina 4 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil18866201682",
    "display" : "Doxazosina 5 mg + Finasterida 2 mg cápsula"
  },
  {
    "code" : "@brasil15782281490",
    "display" : "Doxiciclina 100 mg cápsula de liberação modificada"
  },
  {
    "code" : "@brasil15273339537",
    "display" : "Doxiciclina 100 mg comprimido"
  },
  {
    "code" : "@brasil17542501041",
    "display" : "Doxiciclina 100 mg comprimido para solução"
  },
  {
    "code" : "@brasil18971136907",
    "display" : "Doxiciclina 200 mg cápsula de liberação modificada"
  },
  {
    "code" : "@brasil19783951703",
    "display" : "Doxorrubicina 10 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18633845370",
    "display" : "Doxorrubicina 10 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18517604699",
    "display" : "Doxorrubicina 10 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11180440392",
    "display" : "Doxorrubicina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14748725270",
    "display" : "Doxorrubicina 50 mg/25 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15028840008",
    "display" : "Doxorrubicina Lipossomal 20 mg/10 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15311551293",
    "display" : "Droperidol 2,5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12543455428",
    "display" : "Dropropizina 1,5 mg/mL xarope"
  },
  {
    "code" : "@brasil13232563204",
    "display" : "Dropropizina 3 mg/mL xarope"
  },
  {
    "code" : "@brasil14411474971",
    "display" : "Dropropizina 30 mg/mL solução oral"
  },
  {
    "code" : "@brasil12553423709",
    "display" : "Drospirenona 3 mg + Etinilestradiol 0,02 mg comprimido"
  },
  {
    "code" : "@brasil15378223987",
    "display" : "Drospirenona 3 mg + Etinilestradiol 0,03 mg comprimido"
  },
  {
    "code" : "@brasil14278244956",
    "display" : "Dulaglutida 0,75 mg/0,5 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil19415971299",
    "display" : "Dulaglutida 1,5 mg/0,5 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil11354354908",
    "display" : "Duloxetina 30 mg cápsula gastrorresistente"
  },
  {
    "code" : "@brasil15561230940",
    "display" : "Duloxetina 30 mg comprimido"
  },
  {
    "code" : "@brasil15318960075",
    "display" : "Duloxetina 60 mg cápsula"
  },
  {
    "code" : "@brasil16749699716",
    "display" : "Duloxetina 60 mg cápsula gastrorresistente"
  },
  {
    "code" : "@brasil10318784265",
    "display" : "Dutasterida 0,5 mg + Tansulosina 0,4 mg cápsula"
  },
  {
    "code" : "@brasil11788378237",
    "display" : "Dutasterida 0,5 mg + Tansulosina 0,4 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil19786540202",
    "display" : "Dutasterida 0,5 mg cápsula"
  },
  {
    "code" : "@brasil15393209134",
    "display" : "Dutasterida 0,5 mg comprimido"
  },
  {
    "code" : "@brasil19034693210",
    "display" : "Ebastina 1 mg/mL solução oral"
  },
  {
    "code" : "@brasil13070555703",
    "display" : "Ebastina 10 mg + Pseudoefedrina 120 mg cápsula"
  },
  {
    "code" : "@brasil13930668618",
    "display" : "Ebastina 10 mg comprimido"
  },
  {
    "code" : "@brasil11515276450",
    "display" : "Eculizumabe 300 mg/30 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11009165756",
    "display" : "Efavirenz 200 mg cápsula"
  },
  {
    "code" : "@brasil13283814351",
    "display" : "Efavirenz 30 mg/mL solução oral"
  },
  {
    "code" : "@brasil14225134600",
    "display" : "Efavirenz 600 mg comprimido"
  },
  {
    "code" : "@brasil14703731735",
    "display" : "Efedrina 50 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17225777316",
    "display" : "Eltrombopague 25 mg comprimido"
  },
  {
    "code" : "@brasil12696725820",
    "display" : "Eltrombopague 50 mg comprimido"
  },
  {
    "code" : "@brasil14009546537",
    "display" : "Embonato de Pirvínio 100 mg comprimido"
  },
  {
    "code" : "@brasil17316981642",
    "display" : "Embonato de Triptorrelina 11,25 mg pó e diluente para suspensão para injeção de liberação prolongada; frasco-ampola"
  },
  {
    "code" : "@brasil17511262591",
    "display" : "Embonato de Triptorrelina 22,5 mg pó e diluente para suspensão para injeção de liberação prolongada; frasco-ampola"
  },
  {
    "code" : "@brasil13389842409",
    "display" : "Embonato de Triptorrelina 3,75 mg pó e diluente para suspensão para injeção de liberação prolongada; frasco-ampola"
  },
  {
    "code" : "@brasil14663572509",
    "display" : "Empagliflozina 10 mg comprimido"
  },
  {
    "code" : "@brasil10388260669",
    "display" : "Empagliflozina 25 mg comprimido"
  },
  {
    "code" : "@brasil13199927426",
    "display" : "Empagliflozina 25 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil19205445150",
    "display" : "Enalapril 10 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "@brasil13087726786",
    "display" : "Enalapril 10 mg comprimido"
  },
  {
    "code" : "@brasil18557200726",
    "display" : "Enalapril 2,5 mg comprimido"
  },
  {
    "code" : "@brasil17082850863",
    "display" : "Enalapril 20 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil17521769726",
    "display" : "Enalapril 20 mg comprimido"
  },
  {
    "code" : "@brasil18345668582",
    "display" : "Enalapril 5 mg comprimido"
  },
  {
    "code" : "@brasil16925397566",
    "display" : "Enflurano líquido para inalação 100 mL"
  },
  {
    "code" : "@brasil11225271169",
    "display" : "Enflurano líquido para inalação 240 mL"
  },
  {
    "code" : "@brasil11829799507",
    "display" : "Enfuvirtida 108 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11048567388",
    "display" : "Enfuvirtida 108 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13039498973",
    "display" : "Enoxaparina Sódica 100 mg/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil16113418903",
    "display" : "Enoxaparina Sódica 20 mg/0,2 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil16451687202",
    "display" : "Enoxaparina Sódica 40 mg/0,4 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil17561289496",
    "display" : "Enoxaparina Sódica 60 mg/0,6 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil15599318392",
    "display" : "Enoxaparina Sódica 80 mg/0,8 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil14451403089",
    "display" : "Entacapona 200 mg comprimido"
  },
  {
    "code" : "@brasil19126666073",
    "display" : "Entecavir 0,5 mg comprimido"
  },
  {
    "code" : "@brasil12751887209",
    "display" : "Entecavir 1 mg comprimido"
  },
  {
    "code" : "@brasil11521616941",
    "display" : "Entricitabina 200 mg + Tenofovir 300 mg comprimido"
  },
  {
    "code" : "@brasil19381324702",
    "display" : "Enzalutamida 40 mg cápsula"
  },
  {
    "code" : "@brasil16184098948",
    "display" : "Epinastina 0,5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil19196911852",
    "display" : "Epinastina 10 mg comprimido"
  },
  {
    "code" : "@brasil11712236591",
    "display" : "Epinastina 2 mg/mL xarope"
  },
  {
    "code" : "@brasil16737767425",
    "display" : "Epinastina 20 mg comprimido"
  },
  {
    "code" : "@brasil17584001585",
    "display" : "Epinefrina 1 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16697625820",
    "display" : "Epirrubicina 10 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17059481297",
    "display" : "Epirrubicina 10 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13005991728",
    "display" : "Epirrubicina 20 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12328333147",
    "display" : "Epirrubicina 200 mg/100 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13851515056",
    "display" : "Epirrubicina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19643457175",
    "display" : "Epirrubicina 50 mg/25 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17065521530",
    "display" : "Ergometrina 0,2 mg comprimido"
  },
  {
    "code" : "@brasil13808830634",
    "display" : "Ergometrina 0,2 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10913582704",
    "display" : "Eribulina 1 mg/2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19078515308",
    "display" : "Eritromicina 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19205209265",
    "display" : "Eritromicina 20 mg/g (2%) gel"
  },
  {
    "code" : "@brasil12977696099",
    "display" : "Eritropoietina (Humana Recombinante) 2.000 unidades internacionais/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil18762241459",
    "display" : "Eritropoietina (Humana Recombinante) 4.000 unidades internacionais pó para suspensão para injeção; ampola"
  },
  {
    "code" : "@brasil10388388996",
    "display" : "Eritropoietina (Humana Recombinante) 4.000 unidades internacionais/0,4 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil19458948669",
    "display" : "Erlotinibe 100 mg comprimido"
  },
  {
    "code" : "@brasil10115581936",
    "display" : "Erlotinibe 150 mg comprimido"
  },
  {
    "code" : "@brasil10277207427",
    "display" : "Erlotinibe 25 mg comprimido"
  },
  {
    "code" : "@brasil12651828742",
    "display" : "Ertapeném 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16600831751",
    "display" : "Escina 10 mg/g + Polissulfato de Escina Sódica 10 mg/g + Salicilato de Dietilamina 50 mg/g gel"
  },
  {
    "code" : "@brasil12221889180",
    "display" : "Escina 10 mg/g + Salicilato de Dietilamina 50 mg/g gel"
  },
  {
    "code" : "@brasil13772977695",
    "display" : "Escitalopram 10 mg comprimido"
  },
  {
    "code" : "@brasil17483030516",
    "display" : "Escitalopram 15 mg comprimido"
  },
  {
    "code" : "@brasil15054889557",
    "display" : "Escitalopram 20 mg comprimido"
  },
  {
    "code" : "@brasil16620833235",
    "display" : "Escitalopram 20 mg/mL solução oral"
  },
  {
    "code" : "@brasil19118967109",
    "display" : "Escopolamina 10 mg + Dipirona 250 mg comprimido"
  },
  {
    "code" : "@brasil16957577034",
    "display" : "Escopolamina 10 mg + Paracetamol 500 mg comprimido"
  },
  {
    "code" : "@brasil13642533423",
    "display" : "Escopolamina 10 mg comprimido"
  },
  {
    "code" : "@brasil15271366959",
    "display" : "Escopolamina 10 mg/mL solução oral"
  },
  {
    "code" : "@brasil10959540512",
    "display" : "Escopolamina 20 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19975258231",
    "display" : "Escopolamina 20 mg/5 mL + Dipirona 2,5 g/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10081213953",
    "display" : "Escopolamina 6,67 mg/mL + Dipirona 333,4 mg/mL solução oral"
  },
  {
    "code" : "@brasil14530730008",
    "display" : "Esmolol 100 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16023598093",
    "display" : "Esmolol 100 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14956945845",
    "display" : "Esmolol 2,5 g/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15889490408",
    "display" : "Esomeprazol 20 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil11210779948",
    "display" : "Esomeprazol 40 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil12162504550",
    "display" : "Esomeprazol 40 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12163186521",
    "display" : "Espiramicina 1.500.000 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil14726349528",
    "display" : "Espiramicina 750.000 unidades internacionais + Metronidazol 125 mg comprimido"
  },
  {
    "code" : "@brasil15594714948",
    "display" : "Espironolactona 100 mg + Furosemida 20 mg cápsula"
  },
  {
    "code" : "@brasil14032375991",
    "display" : "Espironolactona 100 mg + Furosemida 20 mg comprimido"
  },
  {
    "code" : "@brasil17265826990",
    "display" : "Espironolactona 100 mg comprimido"
  },
  {
    "code" : "@brasil15766974793",
    "display" : "Espironolactona 25 mg comprimido"
  },
  {
    "code" : "@brasil15792075408",
    "display" : "Espironolactona 50 mg + Hidroclorotiazida 50 mg comprimido"
  },
  {
    "code" : "@brasil17404375826",
    "display" : "Espironolactona 50 mg comprimido"
  },
  {
    "code" : "@brasil16671566148",
    "display" : "Estavudina 1 mg/mL solução oral"
  },
  {
    "code" : "@brasil15684228664",
    "display" : "Estavudina 30 mg cápsula"
  },
  {
    "code" : "@brasil17948086248",
    "display" : "Estavudina 40 mg cápsula"
  },
  {
    "code" : "@brasil13288920206",
    "display" : "Estazolam 2 mg comprimido"
  },
  {
    "code" : "@brasil17558287499",
    "display" : "Estearato de Eritromicina 25 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil16268744286",
    "display" : "Estearato de Eritromicina 250 mg comprimido"
  },
  {
    "code" : "@brasil19379345567",
    "display" : "Estearato de Eritromicina 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil13687840273",
    "display" : "Estearato de Eritromicina 500 mg cápsula"
  },
  {
    "code" : "@brasil14594942930",
    "display" : "Estearato de Eritromicina 500 mg comprimido"
  },
  {
    "code" : "@brasil18591199486",
    "display" : "Estolato de Eritromicina 25 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil11911194138",
    "display" : "Estolato de Eritromicina 250 mg comprimido"
  },
  {
    "code" : "@brasil14750660251",
    "display" : "Estolato de Eritromicina 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil17299123243",
    "display" : "Estolato de Eritromicina 500 mg comprimido"
  },
  {
    "code" : "@brasil12491665511",
    "display" : "Estradiol 0,6 mg/g gel"
  },
  {
    "code" : "@brasil14366725732",
    "display" : "Estradiol 0,75 mg/g gel"
  },
  {
    "code" : "@brasil13542708896",
    "display" : "Estradiol 1 mg + Acetato de Noretisterona 0,5 mg comprimido"
  },
  {
    "code" : "@brasil13619562547",
    "display" : "Estradiol 1 mg + Didrogesterona 10 mg comprimido"
  },
  {
    "code" : "@brasil12948887181",
    "display" : "Estradiol 1 mg + Didrogesterona 5 mg comprimido"
  },
  {
    "code" : "@brasil13820500171",
    "display" : "Estradiol 1 mg + Drospirenona 2 mg comprimido"
  },
  {
    "code" : "@brasil13830682088",
    "display" : "Estradiol 1 mg + Enantato de Noretisterona 500 microgramas comprimido"
  },
  {
    "code" : "@brasil10721186259",
    "display" : "Estradiol 1 mg + Trimegestona 0,125 mg comprimido"
  },
  {
    "code" : "@brasil19393901766",
    "display" : "Estradiol 1 mg comprimido"
  },
  {
    "code" : "@brasil18114528549",
    "display" : "Estradiol 1 mg comprimido e Estradiol 1 mg + Didrogesterona 10 mg comprimido"
  },
  {
    "code" : "@brasil10971532836",
    "display" : "Estradiol 1 mg comprimido e Estradiol 1 mg + Gestodeno 0,25 mg comprimido"
  },
  {
    "code" : "@brasil14198395742",
    "display" : "Estradiol 1 mg comprimido e Estradiol 1 mg + Trimegestona 0,250 mg comprimido"
  },
  {
    "code" : "@brasil16157452710",
    "display" : "Estradiol 1 mg/g (0,1%) gel"
  },
  {
    "code" : "@brasil13629593106",
    "display" : "Estradiol 100 microgramas/24 horas adesivo transdérmico"
  },
  {
    "code" : "@brasil10452097178",
    "display" : "Estradiol 2 mg + Acetato de Noretisterona 1 mg comprimido"
  },
  {
    "code" : "@brasil14677689730",
    "display" : "Estradiol 2 mg + Enantato de Noretisterona 1 mg comprimido"
  },
  {
    "code" : "@brasil15978610137",
    "display" : "Estradiol 2 mg comprimido"
  },
  {
    "code" : "@brasil10339326448",
    "display" : "Estradiol 2 mg comprimido e Estradiol 2 mg + Ciproterona 1 mg comprimido"
  },
  {
    "code" : "@brasil13484086433",
    "display" : "Estradiol 2 mg comprimido e Estradiol 2 mg + Levonorgestrel 0,25 mg comprimido"
  },
  {
    "code" : "@brasil18335446767",
    "display" : "Estradiol 25 microgramas/24 horas adesivo transdérmico"
  },
  {
    "code" : "@brasil19483607222",
    "display" : "Estradiol 3 mg comprimido e Estradiol 2 mg + Dienogeste 2 mg comprimido e Estradiol 2 mg + Dienogeste 3 mg comprimido e Estradiol 1 mg comprimido"
  },
  {
    "code" : "@brasil10034199207",
    "display" : "Estradiol 5 mg/1 mL + Enantato de Noretisterona 50 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10107352248",
    "display" : "Estradiol 5 mg/1 mL + Enantato de Noretisterona 50 mg/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil18193424787",
    "display" : "Estradiol 50 microgramas/24 horas + Acetato de Noretisterona 140 microgramas/24 horas adesivo transdérmico"
  },
  {
    "code" : "@brasil12474778575",
    "display" : "Estradiol 50 microgramas/24 horas + Acetato de Noretisterona 170 microgramas/24 horas adesivo transdérmico"
  },
  {
    "code" : "@brasil13329955471",
    "display" : "Estradiol 50 microgramas/24 horas adesivo transdérmico"
  },
  {
    "code" : "@brasil19528333644",
    "display" : "Estradiol 50 microgramas/24 horas adesivo transdérmico e Estradiol 50 microgramas/24 horas + Acetato de Noretisterona 170 microgramas/24 horas adesivo transdérmico"
  },
  {
    "code" : "@brasil12741728780",
    "display" : "Estreptomicina 1 g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17221130556",
    "display" : "Estreptomicina 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17880466753",
    "display" : "Estreptoquinase 1.500.000 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15053312083",
    "display" : "Estreptoquinase 250.000 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12049733503",
    "display" : "Estreptoquinase 750.000 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11803807728",
    "display" : "Estriol 1 mg comprimido"
  },
  {
    "code" : "@brasil10197234329",
    "display" : "Estriol 1 mg/g creme vaginal"
  },
  {
    "code" : "@brasil11964611085",
    "display" : "Estriol 2 mg comprimido"
  },
  {
    "code" : "@brasil13520122163",
    "display" : "Estrogênios Conjugados 0,3 mg comprimido"
  },
  {
    "code" : "@brasil13134561322",
    "display" : "Estrogênios Conjugados 0,625 mg comprimido"
  },
  {
    "code" : "@brasil18950006986",
    "display" : "Estrogênios Conjugados 0,625 mg/g creme vaginal"
  },
  {
    "code" : "@brasil13226975511",
    "display" : "Etambutol 25 mg/mL solução oral"
  },
  {
    "code" : "@brasil17504648618",
    "display" : "Etambutol 25 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil16054494291",
    "display" : "Etambutol 400 mg comprimido"
  },
  {
    "code" : "@brasil14369602988",
    "display" : "Etanercepte 25 mg pó para solução para injeção; ampola"
  },
  {
    "code" : "@brasil14729097115",
    "display" : "Etanercepte 25 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10526421088",
    "display" : "Etanercepte 50 mg pó para solução para injeção; ampola"
  },
  {
    "code" : "@brasil11789011909",
    "display" : "Etanercepte 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15251519348",
    "display" : "Etexilato de Dabigatrana 110 mg cápsula"
  },
  {
    "code" : "@brasil13834635077",
    "display" : "Etexilato de Dabigatrana 150 mg cápsula"
  },
  {
    "code" : "@brasil19076948209",
    "display" : "Etexilato de Dabigatrana 75 mg cápsula"
  },
  {
    "code" : "@brasil16370311998",
    "display" : "Etilefrina 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16243677683",
    "display" : "Etilefrina 7,5 mg/mL solução oral"
  },
  {
    "code" : "@brasil12719193195",
    "display" : "Etinilestradiol 0,01 mg + Acetato de Noretisterona 2 mg comprimido"
  },
  {
    "code" : "@brasil11960112034",
    "display" : "Etionamida 250 mg comprimido"
  },
  {
    "code" : "@brasil14579203122",
    "display" : "Etodolaco 300 mg comprimido"
  },
  {
    "code" : "@brasil19420806148",
    "display" : "Etodolaco 400 mg comprimido"
  },
  {
    "code" : "@brasil10598710309",
    "display" : "Etodolaco 500 mg comprimido"
  },
  {
    "code" : "@brasil15771142210",
    "display" : "Etofibrato 500 mg cápsula"
  },
  {
    "code" : "@brasil16163963791",
    "display" : "Etomidato 20 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14994494759",
    "display" : "Etonogestrel 11,7 mg + Etinilestradiol 2,7 mg anel vaginal"
  },
  {
    "code" : "@brasil12036277633",
    "display" : "Etonogestrel 68 mg implante; dispositivo"
  },
  {
    "code" : "@brasil10894044572",
    "display" : "Etoposídeo 100 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17967814715",
    "display" : "Etoposídeo 100 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11924820868",
    "display" : "Etoposídeo 50 mg cápsula"
  },
  {
    "code" : "@brasil15514230908",
    "display" : "Etoricoxibe 30 mg comprimido"
  },
  {
    "code" : "@brasil11507002860",
    "display" : "Etoricoxibe 60 mg comprimido"
  },
  {
    "code" : "@brasil17934337161",
    "display" : "Etoricoxibe 90 mg comprimido"
  },
  {
    "code" : "@brasil12252358050",
    "display" : "Etossuximida 250 mg comprimido"
  },
  {
    "code" : "@brasil16818150277",
    "display" : "Etossuximida 50 mg/mL solução oral"
  },
  {
    "code" : "@brasil11350948671",
    "display" : "Etossuximida 50 mg/mL xarope"
  },
  {
    "code" : "@brasil13891799638",
    "display" : "Etravirina 100 mg comprimido"
  },
  {
    "code" : "@brasil19405729637",
    "display" : "Etravirina 200 mg comprimido"
  },
  {
    "code" : "@brasil15862971995",
    "display" : "Eucaliptol 33 mg/mL + Terpina 22 mg/mL + Mentol 22 mg/mL solução para inalação 45 mL; frasco"
  },
  {
    "code" : "@brasil11411333158",
    "display" : "Everolimo 0,5 mg comprimido"
  },
  {
    "code" : "@brasil15720316259",
    "display" : "Everolimo 0,75 mg comprimido"
  },
  {
    "code" : "@brasil14503611431",
    "display" : "Everolimo 1 mg comprimido"
  },
  {
    "code" : "@brasil19873283931",
    "display" : "Everolimo 10 mg comprimido"
  },
  {
    "code" : "@brasil19173025625",
    "display" : "Everolimo 2,5 mg comprimido"
  },
  {
    "code" : "@brasil11870903941",
    "display" : "Everolimo 5 mg comprimido"
  },
  {
    "code" : "@brasil12703090218",
    "display" : "Evolocumabe 140 mg/1 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil17301931349",
    "display" : "Evolocumabe 140 mg/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil17351479293",
    "display" : "Exemestano 25 mg comprimido"
  },
  {
    "code" : "@brasil11980681978",
    "display" : "Exenatida 300 microgramas/1,2 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil13305148409",
    "display" : "Exenatida 600 microgramas/2,4 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil14551113101",
    "display" : "Extrato de Allii cepae L. 100 mg/g + Alantoína 10 mg/g + Heparina Sódica 0,4 mg/g gel"
  },
  {
    "code" : "@brasil14440980342",
    "display" : "Extratos Alergênicos de Insetos Sugadores 1,25 microgramas/mL solução oral"
  },
  {
    "code" : "@brasil11851704605",
    "display" : "Extratos Alergênicos de Insetos Sugadores 12,5 microgramas/mL solução oral"
  },
  {
    "code" : "@brasil11519120410",
    "display" : "Extratos Alergênicos de Insetos Sugadores 125 microgramas/mL solução oral"
  },
  {
    "code" : "@brasil13288395332",
    "display" : "Extratos Alergênicos de Insetos Sugadores 6,25 microgramas/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16227363901",
    "display" : "Extratos Alergênicos de Insetos Sugadores 6,25 microgramas/5 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10817673196",
    "display" : "Extratos Alergênicos de Insetos Sugadores 62,5 microgramas/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16282069668",
    "display" : "Extratos Alergênicos de Insetos Sugadores 62,5 microgramas/5 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13388547237",
    "display" : "Extratos Alergênicos de Insetos Sugadores 625 microgramas/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18101997921",
    "display" : "Extratos Alergênicos de Insetos Sugadores 625 microgramas/5 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10187603709",
    "display" : "Ezetimiba 10 mg + Sinvastatina 10 mg comprimido"
  },
  {
    "code" : "@brasil10065287751",
    "display" : "Ezetimiba 10 mg + Sinvastatina 20 mg comprimido"
  },
  {
    "code" : "@brasil19763627934",
    "display" : "Ezetimiba 10 mg + Sinvastatina 40 mg comprimido"
  },
  {
    "code" : "@brasil13143706984",
    "display" : "Ezetimiba 10 mg + Sinvastatina 80 mg comprimido"
  },
  {
    "code" : "@brasil10754262022",
    "display" : "Ezetimiba 10 mg comprimido"
  },
  {
    "code" : "@brasil13430999901",
    "display" : "Famotidina 20 mg comprimido"
  },
  {
    "code" : "@brasil17780882265",
    "display" : "Famotidina 40 mg comprimido"
  },
  {
    "code" : "@brasil14716854610",
    "display" : "Fampridina 10 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil12360916371",
    "display" : "Fanciclovir 125 mg comprimido"
  },
  {
    "code" : "@brasil15817992253",
    "display" : "Fanciclovir 250 mg comprimido"
  },
  {
    "code" : "@brasil19781625808",
    "display" : "Fanciclovir 500 mg comprimido"
  },
  {
    "code" : "@brasil19579829291",
    "display" : "Fator de von Willebrand 1.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19790833897",
    "display" : "Fator IX 1.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11912927786",
    "display" : "Fator IX 1.200 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15221904677",
    "display" : "Fator IX 250 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15533111061",
    "display" : "Fator IX 300 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11999841584",
    "display" : "Fator IX 500 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12416674132",
    "display" : "Fator IX 500 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10999850779",
    "display" : "Fator IX 600 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11286452757",
    "display" : "Fator VIII (Recombinante) 1.000 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13917906770",
    "display" : "Fator VIII (Recombinante) 250 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16526971780",
    "display" : "Fator VIII (Recombinante) 500 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13806601951",
    "display" : "Fator VIII 1.000 unidades internacionais + Fator von Willebrand 1.200 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14799629070",
    "display" : "Fator VIII 1.000 unidades internacionais + Fator von Willebrand 2.400 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10998593326",
    "display" : "Fator VIII 1.000 unidades internacionais + Fator von Willebrand 2.600 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14227537021",
    "display" : "Fator VIII 1.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15754940327",
    "display" : "Fator VIII 1.500 unidades internacionais + Fator von Willebrand 1.800 unidades internacionais pó e diluente para solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil11155823729",
    "display" : "Fator VIII 1.500 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11473257066",
    "display" : "Fator VIII 250 unidades internacionais + Fator von Willebrand 300 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11582624558",
    "display" : "Fator VIII 250 unidades internacionais + Fator von Willebrand 500 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15145833793",
    "display" : "Fator VIII 250 unidades internacionais + Fator von Willebrand 600 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13506916409",
    "display" : "Fator VIII 250 unidades internacionais + Fator von Willebrand 650 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18498727731",
    "display" : "Fator VIII 250 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18251547605",
    "display" : "Fator VIII 450 unidades internacionais + Fator von Willebrand 400 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19058867019",
    "display" : "Fator VIII 500 unidades internacionais + Fator von Willebrand 1.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11271664481",
    "display" : "Fator VIII 500 unidades internacionais + Fator von Willebrand 1.200 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13514841498",
    "display" : "Fator VIII 500 unidades internacionais + Fator von Willebrand 1.300 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16616803803",
    "display" : "Fator VIII 500 unidades internacionais + Fator von Willebrand 600 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18643386640",
    "display" : "Fator VIII 500 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17423534072",
    "display" : "Fator VIII 500 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11090756775",
    "display" : "Fator VIII 900 unidades internacionais + Fator von Willebrand 800 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17886615280",
    "display" : "Felodipino 10 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil15235738841",
    "display" : "Felodipino 2,5 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil19953630490",
    "display" : "Felodipino 5 mg + Metoprolol 50 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil11496007377",
    "display" : "Felodipino 5 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil16644715624",
    "display" : "Femprocumona 3 mg comprimido"
  },
  {
    "code" : "@brasil19670842194",
    "display" : "Femproporex 25 mg comprimido"
  },
  {
    "code" : "@brasil17144058370",
    "display" : "Fenazopiridina 100 mg comprimido"
  },
  {
    "code" : "@brasil18966693996",
    "display" : "Fenazopiridina 200 mg comprimido"
  },
  {
    "code" : "@brasil15934671195",
    "display" : "Fenilbutazona 200 mg comprimido"
  },
  {
    "code" : "@brasil16398839889",
    "display" : "Fenilefrina 1 mg/mL + Tetracaína 10 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil17498484966",
    "display" : "Fenilefrina 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19473682397",
    "display" : "Fenilefrina 100 mg/mL (10%) solução oftálmica"
  },
  {
    "code" : "@brasil10551405045",
    "display" : "Fenitoína 100 mg comprimido"
  },
  {
    "code" : "@brasil12285496910",
    "display" : "Fenitoína 20 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil13827294877",
    "display" : "Fenitoína Sódica 25 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil11543369088",
    "display" : "Fenitoína Sódica 250 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15197460449",
    "display" : "Fenobarbital 100 mg comprimido"
  },
  {
    "code" : "@brasil16016138181",
    "display" : "Fenobarbital 200 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11465716688",
    "display" : "Fenobarbital 200 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12602548348",
    "display" : "Fenobarbital 40 mg/mL solução oral"
  },
  {
    "code" : "@brasil13789105920",
    "display" : "Fenobarbital 50 mg comprimido"
  },
  {
    "code" : "@brasil15215871216",
    "display" : "Fenofibrato 160 mg comprimido"
  },
  {
    "code" : "@brasil13913099749",
    "display" : "Fenofibrato 200 mg cápsula"
  },
  {
    "code" : "@brasil16103094578",
    "display" : "Fenofibrato 250 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil17464135108",
    "display" : "Fenofibrato 250 mg cápsula de liberação retardada"
  },
  {
    "code" : "@brasil10539938331",
    "display" : "Fenol 18,6 mg/mL + Mentol 1,3 mg/mL solução otológica"
  },
  {
    "code" : "@brasil12826156738",
    "display" : "Fenoterol 0,05 mg /dose + Brometo de Ipratrópio 0,02 mg/dose solução aerossol"
  },
  {
    "code" : "@brasil19231774450",
    "display" : "Fenoterol 0,1 mg /dose + Brometo de Ipratrópio 0,04 mg/dose solução aerossol; inalador"
  },
  {
    "code" : "@brasil18861736577",
    "display" : "Fenoterol 100 microgramas/dose solução aerossol; inalador"
  },
  {
    "code" : "@brasil14741135959",
    "display" : "Fenoterol 200 microgramas/dose solução aerossol"
  },
  {
    "code" : "@brasil10373184074",
    "display" : "Fenoterol 5 mg/mL solução"
  },
  {
    "code" : "@brasil15943319745",
    "display" : "Fenoxazolina 0,5 mg/mL solução nasal"
  },
  {
    "code" : "@brasil18279632913",
    "display" : "Fenoxazolina 1 mg/mL solução nasal"
  },
  {
    "code" : "@brasil16152184619",
    "display" : "Fenoximetilpenicilina Potássica 1.200.000 unidades internacionais solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11723023262",
    "display" : "Fenoximetilpenicilina Potássica 500.000 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil16044881254",
    "display" : "Fenoximetilpenicilina Potássica 80.000 unidades internacionais/mL solução oral"
  },
  {
    "code" : "@brasil17172700674",
    "display" : "Fentanila 0,1 mg/2 mL + Droperidol 5 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13402648132",
    "display" : "Fentanila 0,1 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14635836037",
    "display" : "Fentanila 0,25 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18564720467",
    "display" : "Fentanila 0,5 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10696590086",
    "display" : "Fentanila 100 microgramas/hora adesivo transdérmico"
  },
  {
    "code" : "@brasil19966854134",
    "display" : "Fentanila 12 microgramas/hora adesivo transdérmico"
  },
  {
    "code" : "@brasil13100920572",
    "display" : "Fentanila 25 microgramas/hora adesivo transdérmico"
  },
  {
    "code" : "@brasil19215806440",
    "display" : "Fentanila 50 microgramas/hora adesivo transdérmico"
  },
  {
    "code" : "@brasil17192040006",
    "display" : "Fentanila 75 microgramas/hora adesivo transdérmico"
  },
  {
    "code" : "@brasil12292156080",
    "display" : "Fenticonazol 20 mg/g creme"
  },
  {
    "code" : "@brasil13381494639",
    "display" : "Fenticonazol 20 mg/g creme vaginal"
  },
  {
    "code" : "@brasil14395630241",
    "display" : "Fenticonazol 20 mg/mL solução spray"
  },
  {
    "code" : "@brasil16293428134",
    "display" : "Fenticonazol 600 mg óvulo"
  },
  {
    "code" : "@brasil11059754649",
    "display" : "Ferripolimaltose 10 mg/mL xarope"
  },
  {
    "code" : "@brasil19379928277",
    "display" : "Ferripolimaltose 100 mg + Ácido Fólico 0,35 mg comprimido mastigável"
  },
  {
    "code" : "@brasil10703382258",
    "display" : "Ferripolimaltose 100 mg comprimido"
  },
  {
    "code" : "@brasil11148602971",
    "display" : "Ferripolimaltose 100 mg comprimido mastigável"
  },
  {
    "code" : "@brasil13032111350",
    "display" : "Ferripolimaltose 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14327075996",
    "display" : "Ferripolimaltose 100 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11476945085",
    "display" : "Ferripolimaltose 100 mg/mL solução oral"
  },
  {
    "code" : "@brasil16071549453",
    "display" : "Ferripolimaltose 50 mg/mL solução oral"
  },
  {
    "code" : "@brasil17255075606",
    "display" : "Ferrocarbonila 126 mg (Ferro 120 mg) comprimido"
  },
  {
    "code" : "@brasil12683564239",
    "display" : "Fexofenadina 120 mg comprimido"
  },
  {
    "code" : "@brasil12615561924",
    "display" : "Fexofenadina 180 mg + Pseudoefedrina 240 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil17350518829",
    "display" : "Fexofenadina 180 mg comprimido"
  },
  {
    "code" : "@brasil11706120837",
    "display" : "Fexofenadina 30 mg comprimido"
  },
  {
    "code" : "@brasil12933569589",
    "display" : "Fexofenadina 6 mg/mL solução oral"
  },
  {
    "code" : "@brasil15301231493",
    "display" : "Fexofenadina 6 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil17416754034",
    "display" : "Fexofenadina 60 mg + Pseudoefedrina 120 mg comprimido de liberação modificada"
  },
  {
    "code" : "@brasil15252741932",
    "display" : "Fexofenadina 60 mg comprimido"
  },
  {
    "code" : "@brasil10314813488",
    "display" : "Fibrinogênio 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19092779026",
    "display" : "Fibrinogênio 45,5 mg/mL + Aprotinina 1.500 UIC/mL + Trombina 250 unidades internacionais/mL solução"
  },
  {
    "code" : "@brasil15186795381",
    "display" : "Fibrinogênio 70 mg/mL solução e Trombina 1.000 unidades internacionais/mL + Cloreto de Cálcio 5,9 mg/mL solução"
  },
  {
    "code" : "@brasil10538987907",
    "display" : "Fibrinogênio 90 mg + Fator VIII de coagulação 60 unidades pó para solução e Aprotinina 1.000 UIC/mL solução e Trombina 500 unidades internacionais pó e diluente para solução"
  },
  {
    "code" : "@brasil15455812396",
    "display" : "Fibrinogênio 91 mg pó para solução e Aprotinina 3.000 UIC/mL solução e Trombina 500 unidades internacionais pó e diluente para solução"
  },
  {
    "code" : "@brasil15197509884",
    "display" : "Filgrastim 300 microgramas/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil15477993091",
    "display" : "Filgrastim 300 microgramas/1 mL (30 milhões de unidades internacionais/1 mL) solução para injeção; ampola"
  },
  {
    "code" : "@brasil16159104969",
    "display" : "Filgrastim 300 microgramas/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15202995504",
    "display" : "Filgrastim 300 microgramas/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil12931775442",
    "display" : "Finasterida 1 mg comprimido"
  },
  {
    "code" : "@brasil12009896664",
    "display" : "Finasterida 5 mg comprimido"
  },
  {
    "code" : "@brasil11353701539",
    "display" : "Fingolimode 0,5 mg cápsula"
  },
  {
    "code" : "@brasil14936074403",
    "display" : "Fitomenadiona 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17209525560",
    "display" : "Fitomenadiona 2 mg/0,2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19994930157",
    "display" : "Flucitosina 500 mg comprimido"
  },
  {
    "code" : "@brasil19685139271",
    "display" : "Fluconazol 100 mg cápsula"
  },
  {
    "code" : "@brasil15855025867",
    "display" : "Fluconazol 150 mg cápsula"
  },
  {
    "code" : "@brasil15344190591",
    "display" : "Fluconazol 200 mg/100 mL solução para injeção; bolsa"
  },
  {
    "code" : "@brasil18359259317",
    "display" : "Fluconazol 200 mg/100 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14000369592",
    "display" : "Fluconazol 50 mg cápsula"
  },
  {
    "code" : "@brasil16406516958",
    "display" : "Fludarabina 10 mg comprimido"
  },
  {
    "code" : "@brasil17537662923",
    "display" : "Fludarabina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14999602607",
    "display" : "Fludrocortisona 0,1 mg comprimido"
  },
  {
    "code" : "@brasil10796356591",
    "display" : "Fludroxicortida 0,125 mg/g + Clioquinol 30 mg/g creme"
  },
  {
    "code" : "@brasil19690940321",
    "display" : "Fludroxicortida 0,125 mg/g + Neomicina 3,5 mg/g creme"
  },
  {
    "code" : "@brasil10493744005",
    "display" : "Fludroxicortida 0,125 mg/g + Neomicina 3,5 mg/g pomada"
  },
  {
    "code" : "@brasil17442266787",
    "display" : "Fludroxicortida 0,125 mg/g creme"
  },
  {
    "code" : "@brasil14141433772",
    "display" : "Fludroxicortida 0,125 mg/g pomada"
  },
  {
    "code" : "@brasil17765469388",
    "display" : "Fludroxicortida 0,5 mg/mL loção"
  },
  {
    "code" : "@brasil15734110124",
    "display" : "Flufenazina 25 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12609683779",
    "display" : "Flufenazina 5 mg comprimido"
  },
  {
    "code" : "@brasil15661402814",
    "display" : "Flumazenil 0,5 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17954855389",
    "display" : "Flunarizina 10 mg cápsula"
  },
  {
    "code" : "@brasil12419005875",
    "display" : "Flunarizina 10 mg comprimido"
  },
  {
    "code" : "@brasil16384139353",
    "display" : "Flunarizina 5 mg/mL solução oral"
  },
  {
    "code" : "@brasil13783429760",
    "display" : "Flunitrazepam 1 mg comprimido"
  },
  {
    "code" : "@brasil13201153885",
    "display" : "Flunitrazepam 2 mg comprimido"
  },
  {
    "code" : "@brasil12890681234",
    "display" : "Fluocinolona 0,25 mg/mL + Nafazolina 0,5 mg/mL + Zinco 4 mg/mL + Neomicina 7 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil17180427550",
    "display" : "Fluocortolona 1 mg + Lidocaína 40 mg supositório"
  },
  {
    "code" : "@brasil17685764195",
    "display" : "Fluocortolona 1 mg/g + Lidocaína 20 mg/g creme"
  },
  {
    "code" : "@brasil10945122968",
    "display" : "Fluoresceína 1% solução oftálmica"
  },
  {
    "code" : "@brasil17561460151",
    "display" : "Fluoresceína 10% solução para injeção 5 mL; frasco-ampola"
  },
  {
    "code" : "@brasil10741518409",
    "display" : "Fluoresceína 2% solução oftálmica"
  },
  {
    "code" : "@brasil19398508106",
    "display" : "Fluormetolona 1 mg/mL (0,1%) solução oftálmica"
  },
  {
    "code" : "@brasil17684594565",
    "display" : "Fluormetolona 1 mg/mL suspensão oftálmica"
  },
  {
    "code" : "@brasil11304493649",
    "display" : "Fluormetolona 2,5 mg/mL (0,25%) solução oftálmica"
  },
  {
    "code" : "@brasil17979625841",
    "display" : "Fluoruracila 1 g/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16593872862",
    "display" : "Fluoruracila 1 g/40 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10050454734",
    "display" : "Fluoruracila 2,5 g/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15014199170",
    "display" : "Fluoruracila 250 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12211424858",
    "display" : "Fluoruracila 250 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14050900500",
    "display" : "Fluoruracila 50 mg/g creme"
  },
  {
    "code" : "@brasil12222902784",
    "display" : "Fluoruracila 500 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10905760396",
    "display" : "Fluoruracila 500 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17894527712",
    "display" : "Fluoruracila 500 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11159270955",
    "display" : "Fluoxetina 10 mg cápsula"
  },
  {
    "code" : "@brasil16527403597",
    "display" : "Fluoxetina 10 mg comprimido"
  },
  {
    "code" : "@brasil11240377519",
    "display" : "Fluoxetina 20 mg cápsula"
  },
  {
    "code" : "@brasil10360026731",
    "display" : "Fluoxetina 20 mg comprimido"
  },
  {
    "code" : "@brasil17638360658",
    "display" : "Fluoxetina 20 mg/mL solução oral"
  },
  {
    "code" : "@brasil16004428345",
    "display" : "Fluoxetina 60 mg cápsula"
  },
  {
    "code" : "@brasil12473960398",
    "display" : "Flurazepam 30 mg comprimido"
  },
  {
    "code" : "@brasil16895878198",
    "display" : "Flurbiprofeno 0,3 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil13650947261",
    "display" : "Flurbiprofeno 40 mg adesivo transdérmico"
  },
  {
    "code" : "@brasil18495094344",
    "display" : "Flurbiprofeno 8,75 mg pastilha"
  },
  {
    "code" : "@brasil15234197474",
    "display" : "Flutamida 250 mg comprimido"
  },
  {
    "code" : "@brasil12868734124",
    "display" : "Flutrimazol 10 mg/g creme"
  },
  {
    "code" : "@brasil13669838963",
    "display" : "Flutrimazol 10 mg/mL solução"
  },
  {
    "code" : "@brasil13479706134",
    "display" : "Fluvastatina 20 mg cápsula"
  },
  {
    "code" : "@brasil16256941477",
    "display" : "Fluvastatina 40 mg cápsula"
  },
  {
    "code" : "@brasil16397989377",
    "display" : "Fluvastatina 80 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil16916196667",
    "display" : "Fluvoxamina 100 mg comprimido"
  },
  {
    "code" : "@brasil14106026666",
    "display" : "Fluvoxamina 50 mg comprimido"
  },
  {
    "code" : "@brasil16755357687",
    "display" : "Folinato de Cálcio 100 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11638117768",
    "display" : "Folinato de Cálcio 15 mg comprimido"
  },
  {
    "code" : "@brasil16263806740",
    "display" : "Folinato de Cálcio 200 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10206240852",
    "display" : "Folinato de Cálcio 300 mg/30 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11156561607",
    "display" : "Folinato de Cálcio 350 mg/35 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17333825850",
    "display" : "Folinato de Cálcio 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18112632731",
    "display" : "Folinato de Cálcio 50 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19690059719",
    "display" : "Folinato de Cálcio 50 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15815305285",
    "display" : "Folinato de Cálcio 500 mg/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13280265724",
    "display" : "Fondaparinux Sódico 2,5 mg/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil17965620165",
    "display" : "Fondaparinux Sódico 7,5 mg/0,6 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil16641346602",
    "display" : "Formoterol 12 microgramas + Budesonida 200 microgramas cápsula para inalação"
  },
  {
    "code" : "@brasil18716474423",
    "display" : "Formoterol 12 microgramas + Budesonida 400 micrograma cápsula para inalação"
  },
  {
    "code" : "@brasil15510161746",
    "display" : "Formoterol 12 microgramas + Budesonida 400 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "@brasil17914929181",
    "display" : "Formoterol 12 microgramas + Propionato de Fluticasona 250 microgramas cápsula para inalação"
  },
  {
    "code" : "@brasil13466954596",
    "display" : "Formoterol 12 microgramas + Propionato de Fluticasona 250 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "@brasil12946135654",
    "display" : "Formoterol 12 microgramas cápsula para inalação"
  },
  {
    "code" : "@brasil17241611401",
    "display" : "Formoterol 12 microgramas cápsula para inalação e Budesonida 200 microgramas cápsula para inalação"
  },
  {
    "code" : "@brasil18161420269",
    "display" : "Formoterol 12 microgramas cápsula para inalação e Budesonida 200 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "@brasil19563792215",
    "display" : "Formoterol 12 microgramas cápsula para inalação e Budesonida 400 microgramas cápsula para inalação"
  },
  {
    "code" : "@brasil19125973290",
    "display" : "Formoterol 12 microgramas cápsula para inalação e Budesonida 400 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "@brasil16696540447",
    "display" : "Formoterol 12 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "@brasil19963488884",
    "display" : "Formoterol 12 microgramas/dose + Budesonida 400 microgramas/dose pó para inalação"
  },
  {
    "code" : "@brasil16200461848",
    "display" : "Formoterol 12 microgramas/dose pó para inalação"
  },
  {
    "code" : "@brasil16882327492",
    "display" : "Formoterol 6 microgramas + Budesonida 100 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "@brasil18192948630",
    "display" : "Formoterol 6 microgramas + Budesonida 200 microgramas cápsula para inalação"
  },
  {
    "code" : "@brasil18630465517",
    "display" : "Formoterol 6 microgramas + Budesonida 200 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "@brasil12606083081",
    "display" : "Formoterol 6 microgramas/dose + Budesonida 100 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "@brasil19581865507",
    "display" : "Formoterol 6 microgramas/dose + Budesonida 100 microgramas/dose suspensão aerossol; inalador"
  },
  {
    "code" : "@brasil15934456050",
    "display" : "Formoterol 6 microgramas/dose + Budesonida 200 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "@brasil10548162906",
    "display" : "Formoterol 6 microgramas/dose + Budesonida 200 microgramas/dose suspensão aerossol; inalador"
  },
  {
    "code" : "@brasil19354198600",
    "display" : "Fosamprenavir 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil14113738455",
    "display" : "Fosamprenavir 700 mg comprimido"
  },
  {
    "code" : "@brasil13204675188",
    "display" : "Fosaprepitanto Dimeglumina 150 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14327656340",
    "display" : "Fosfato de Cálcio Tribásico 1.661 g (Cálcio 600 mg) + Colecalciferol 400 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil13352040380",
    "display" : "Fosfato de Potássio 20 mEq/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19385629563",
    "display" : "Fosfato de Sódio Monobásico 160 mg/mL + Fosfato de Sódio Dibásico 60 mg/mL solução retal"
  },
  {
    "code" : "@brasil11605110587",
    "display" : "Fosfato Dissódico de Betametasona 3 mg/1 mL + Acetato de Betametasona 3 mg/1 mL suspensão para injeção; ampola"
  },
  {
    "code" : "@brasil14111496966",
    "display" : "Fosfato Dissódico de Betametasona 4 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14811751333",
    "display" : "Fosfato Dissódico de Dexametasona 10 mg/2,5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10763068282",
    "display" : "Fosfato Dissódico de Dexametasona 10 mg/2,5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16914089643",
    "display" : "Fosfato Dissódico de Dexametasona 2 mg/1 mL + Acetato de Dexametasona 8 mg/1 mL suspensão para injeção; ampola"
  },
  {
    "code" : "@brasil14710671615",
    "display" : "Fosfato Dissódico de Dexametasona 2 mg/1 mL + Acetato de Dexametasona 8 mg/1 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11992538497",
    "display" : "Fosfato Dissódico de Dexametasona 2 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14984852386",
    "display" : "Fosfato Dissódico de Dexametasona 4 mg/2 mL + Acetato de Dexametasona 16 mg/2 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15449701085",
    "display" : "Fosfomicina 3 g granulado"
  },
  {
    "code" : "@brasil17450932353",
    "display" : "Fosinopril 10 mg comprimido"
  },
  {
    "code" : "@brasil19557415663",
    "display" : "Fotemustina 208 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10957472547",
    "display" : "Frações Peptídicas Alergênicas 2.500 microgramas/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15799912255",
    "display" : "Frações Peptídicas Alergênicas 2.500 microgramas/5 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15992770878",
    "display" : "Frações Peptídicas Alergênicas 25 microgramas/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15245396554",
    "display" : "Frações Peptídicas Alergênicas 25 microgramas/5 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15727599397",
    "display" : "Frações Peptídicas Alergênicas 250 microgramas/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11615822343",
    "display" : "Frações Peptídicas Alergênicas 250 microgramas/5 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19152232722",
    "display" : "Frações Peptídicas Alergênicas 5 microgramas/mL solução oral"
  },
  {
    "code" : "@brasil19350023425",
    "display" : "Frações Peptídicas Alergênicas 50 microgramas/mL solução oral"
  },
  {
    "code" : "@brasil15280353365",
    "display" : "Frações Peptídicas Alergênicas 500 microgramas/mL solução oral"
  },
  {
    "code" : "@brasil15195618340",
    "display" : "Fralda adulta descartável"
  },
  {
    "code" : "@brasil16440158546",
    "display" : "Frutose 5% solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "@brasil19748839389",
    "display" : "Frutose 5% solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "@brasil14479533324",
    "display" : "Fulvestranto 250 mg/5mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil10434389719",
    "display" : "Fumarato de Dimetila 120 mg cápsula gastrorresistente"
  },
  {
    "code" : "@brasil17496007630",
    "display" : "Fumarato de Dimetila 240 mg cápsula gastrorresistente"
  },
  {
    "code" : "@brasil14338741491",
    "display" : "Furazolidona 200 mg comprimido"
  },
  {
    "code" : "@brasil18956095852",
    "display" : "Furoato de Fluticasona 100 microgramas/dose + Vilanterol 25 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "@brasil11150256739",
    "display" : "Furoato de Fluticasona 200 microgramas/dose + Vilanterol 25 microgramas/dose pó para inalação"
  },
  {
    "code" : "@brasil14817906397",
    "display" : "Furoato de Fluticasona 27,5 microgramas/dose suspensão spray"
  },
  {
    "code" : "@brasil10590343763",
    "display" : "Furosemida 10 mg/mL solução oral"
  },
  {
    "code" : "@brasil10062432036",
    "display" : "Furosemida 20 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18315657513",
    "display" : "Furosemida 40 mg + Amilorida 10 mg comprimido"
  },
  {
    "code" : "@brasil19072512674",
    "display" : "Furosemida 40 mg + Cloreto de Potássio 100 mg comprimido"
  },
  {
    "code" : "@brasil11262933323",
    "display" : "Furosemida 40 mg comprimido"
  },
  {
    "code" : "@brasil13825029397",
    "display" : "Gabapentina 100 mg comprimido"
  },
  {
    "code" : "@brasil19539090411",
    "display" : "Gabapentina 300 mg cápsula"
  },
  {
    "code" : "@brasil14944065542",
    "display" : "Gabapentina 400 mg cápsula"
  },
  {
    "code" : "@brasil10699850562",
    "display" : "Gabapentina 600 mg comprimido"
  },
  {
    "code" : "@brasil13835057758",
    "display" : "Galantamina 16 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil15272988773",
    "display" : "Galantamina 24 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil12718318692",
    "display" : "Galantamina 8 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil15149332735",
    "display" : "Galsulfase 5 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16904445006",
    "display" : "Ganciclovir 100 mg/100 mL solução para injeção; bolsa"
  },
  {
    "code" : "@brasil16105465967",
    "display" : "Ganciclovir 250 mg cápsula"
  },
  {
    "code" : "@brasil15201749702",
    "display" : "Ganciclovir 250 mg/250 mL solução para injeção; bolsa"
  },
  {
    "code" : "@brasil18440153483",
    "display" : "Ganciclovir 250 mg/250 mL solução para injeção; frasco"
  },
  {
    "code" : "@brasil18660164863",
    "display" : "Ganciclovir 500 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19280900552",
    "display" : "Ganciclovir 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11965534035",
    "display" : "Ganciclovir 500 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10871820207",
    "display" : "Ganciclovir 500 mg/500 mL solução para injeção; bolsa"
  },
  {
    "code" : "@brasil17569374829",
    "display" : "Ganciclovir 500 mg/500 mL solução para injeção; frasco"
  },
  {
    "code" : "@brasil16836335505",
    "display" : "Ganirrelix 250 microgramas/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil11425607605",
    "display" : "Gatifloxacino 3 mg/mL + Prednisolona 10 mg/mL suspensão oftálmica"
  },
  {
    "code" : "@brasil15553173230",
    "display" : "Gatifloxacino 3 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil16440403735",
    "display" : "Gatifloxacino 5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil15971509427",
    "display" : "Gefitinibe 250 mg comprimido"
  },
  {
    "code" : "@brasil10541942798",
    "display" : "Gelatina 0,8 g pó e Trombina 2.500 unidades internacionais pó e Cloreto de Cálcio 200 micromol/5 mL solução"
  },
  {
    "code" : "@brasil12020270461",
    "display" : "Gelatina 1,37 g pó e Trombina 5.000 unidades internacionais pó e Cloreto de Cálcio 400 micromol/10 mL solução"
  },
  {
    "code" : "@brasil11983112730",
    "display" : "Gelatina 3,5% + Cloreto de Potássio 0,038% + Cloreto de Sódio 0,85% + Cloreto de Cálcio 0,07% solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "@brasil13891191130",
    "display" : "Gelatina 3,5% solução para injeção 500 mL; bisnaga"
  },
  {
    "code" : "@brasil14073572608",
    "display" : "Gelatina 3,5% solução para injeção 500 mL; frasco"
  },
  {
    "code" : "@brasil17639689609",
    "display" : "Gemifloxacino 320 mg comprimido"
  },
  {
    "code" : "@brasil19993118660",
    "display" : "Gencitabina 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16341152363",
    "display" : "Gencitabina 200 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13275475783",
    "display" : "Genfibrozila 300 mg cápsula"
  },
  {
    "code" : "@brasil18828453800",
    "display" : "Genfibrozila 600 mg comprimido"
  },
  {
    "code" : "@brasil16122315455",
    "display" : "Genfibrozila 900 mg comprimido"
  },
  {
    "code" : "@brasil19609715135",
    "display" : "Gentamicina 1 mg/g + Desonida 0,5 mg/g gel creme"
  },
  {
    "code" : "@brasil17381569319",
    "display" : "Gentamicina 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14968492168",
    "display" : "Gentamicina 140 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19772893961",
    "display" : "Gentamicina 160 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13298402821",
    "display" : "Gentamicina 20 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14076260265",
    "display" : "Gentamicina 280 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18198992569",
    "display" : "Gentamicina 3 mg/g pomada oftálmica"
  },
  {
    "code" : "@brasil18720550962",
    "display" : "Gentamicina 3 mg/mL + Fosfato Dissódico de Betametasona 1 mg/mL solução"
  },
  {
    "code" : "@brasil11467755604",
    "display" : "Gentamicina 40 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17962145047",
    "display" : "Gentamicina 5 mg/g pomada oftálmica"
  },
  {
    "code" : "@brasil14281230319",
    "display" : "Gentamicina 5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil10261087081",
    "display" : "Gentamicina 60 mg/1,5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16111811403",
    "display" : "Gentamicina 80 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13055316816",
    "display" : "Gestodeno 0,06 mg + Etinilestradiol 0,015 mg comprimido"
  },
  {
    "code" : "@brasil19467519165",
    "display" : "Gestodeno 0,075 mg + Etinilestradiol 0,02 mg comprimido"
  },
  {
    "code" : "@brasil13624893019",
    "display" : "Gestodeno 0,075 mg + Etinilestradiol 0,03 mg comprimido"
  },
  {
    "code" : "@brasil11530074198",
    "display" : "Ginkgo biloba 120 mg comprimido"
  },
  {
    "code" : "@brasil16828155857",
    "display" : "Ginkgo biloba 40 mg comprimido"
  },
  {
    "code" : "@brasil17268317756",
    "display" : "Ginkgo biloba 80 mg cápsula"
  },
  {
    "code" : "@brasil19550557003",
    "display" : "Ginkgo biloba 80 mg comprimido"
  },
  {
    "code" : "@brasil13665297648",
    "display" : "Glibenclamida 1,25 mg + Metformina 250 mg comprimido"
  },
  {
    "code" : "@brasil17016620920",
    "display" : "Glibenclamida 2,5 mg + Metformina 500 mg comprimido"
  },
  {
    "code" : "@brasil14293131886",
    "display" : "Glibenclamida 5 mg + Metformina 1 g comprimido"
  },
  {
    "code" : "@brasil18813817153",
    "display" : "Glibenclamida 5 mg + Metformina 500 mg comprimido"
  },
  {
    "code" : "@brasil18760586433",
    "display" : "Glibenclamida 5 mg comprimido"
  },
  {
    "code" : "@brasil16930994601",
    "display" : "Glicerofosfato de Sódio 4,32 g/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12655652837",
    "display" : "Glicerofosfato de Sódio 4,32 g/20 mL suspensão para injeção; frasco"
  },
  {
    "code" : "@brasil14709727645",
    "display" : "Glicerol 120 mg/mL solução retal"
  },
  {
    "code" : "@brasil17893640087",
    "display" : "Glicerol 95% supositório"
  },
  {
    "code" : "@brasil12510265355",
    "display" : "Glicina 15 mg/mL solução para irrigação 3 L; bolsa"
  },
  {
    "code" : "@brasil14944751330",
    "display" : "Glicinato de Magnésio 722,22 mg + Piridoxina 1 mg comprimido"
  },
  {
    "code" : "@brasil17904277961",
    "display" : "Glicinato Férrico 10 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil11374323200",
    "display" : "Glicinato Férrico 15 mg/mL (Ferro 3 mg/mL) + Ácido Fólico 0,5 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil15551556380",
    "display" : "Glicinato Férrico 150 mg (Ferro 30 mg) + Ácido Fólico 5 mg comprimido"
  },
  {
    "code" : "@brasil17477525347",
    "display" : "Glicinato Férrico 150 mg (Ferro 30 mg) comprimido"
  },
  {
    "code" : "@brasil11260920641",
    "display" : "Glicinato Férrico 250 mg/mL (Ferro 50 mg/mL) + Ácido Fólico 0,2 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil10895414678",
    "display" : "Glicinato Férrico 250 mg/mL solução oral"
  },
  {
    "code" : "@brasil16987023768",
    "display" : "Glicinato Férrico 300 mg (Ferro 60 mg) comprimido"
  },
  {
    "code" : "@brasil15808153761",
    "display" : "Glicinato Férrico 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil18771229373",
    "display" : "Glicinato Férrico 500 mg (Ferro 100 mg) comprimido mastigável"
  },
  {
    "code" : "@brasil18982157704",
    "display" : "Gliclazida 30 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil11710516205",
    "display" : "Gliclazida 60 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil18351757262",
    "display" : "Gliclazida 80 mg comprimido"
  },
  {
    "code" : "@brasil15383487216",
    "display" : "Gliconato de Cálcio 10% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "@brasil14588745751",
    "display" : "Glicosamina 1,5 g + Condroitina 1,2 g granulado"
  },
  {
    "code" : "@brasil19421736874",
    "display" : "Glicosamina 1,5 g + Condroitina 1,2 g pó para solução oral"
  },
  {
    "code" : "@brasil15095674873",
    "display" : "Glicosamina 1,5 g pó para solução oral"
  },
  {
    "code" : "@brasil13886761192",
    "display" : "Glicose 10% solução para injeção 1 L; bolsa"
  },
  {
    "code" : "@brasil14826821138",
    "display" : "Glicose 10% solução para injeção 1 L; frasco-ampola"
  },
  {
    "code" : "@brasil18151359703",
    "display" : "Glicose 10% solução para injeção 250 mL; bolsa"
  },
  {
    "code" : "@brasil12186657423",
    "display" : "Glicose 10% solução para injeção 250 mL; frasco-ampola"
  },
  {
    "code" : "@brasil10377237125",
    "display" : "Glicose 10% solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "@brasil10385692035",
    "display" : "Glicose 10% solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "@brasil13349272992",
    "display" : "Glicose 20 g + Cloreto de Sódio 3,5 g + Citrato de Sódio 2,5 g + Cloreto de Potássio 1,5 g pó para solução oral"
  },
  {
    "code" : "@brasil16916069514",
    "display" : "Glicose 20% + Cloreto de Sódio 0,9% solução para injeção 1 L;  frasco"
  },
  {
    "code" : "@brasil15103288510",
    "display" : "Glicose 20% + Cloreto de Sódio 0,9% solução para injeção 250 mL;  frasco"
  },
  {
    "code" : "@brasil17613051101",
    "display" : "Glicose 20% + Cloreto de Sódio 0,9% solução para injeção 500 mL;  frasco"
  },
  {
    "code" : "@brasil12428788497",
    "display" : "Glicose 25% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "@brasil15256384223",
    "display" : "Glicose 25% solução para injeção 20 mL; ampola"
  },
  {
    "code" : "@brasil10710173546",
    "display" : "Glicose 5% solução para injeção 1 L; bolsa"
  },
  {
    "code" : "@brasil18232452288",
    "display" : "Glicose 5% solução para injeção 1 L; frasco-ampola"
  },
  {
    "code" : "@brasil17984294729",
    "display" : "Glicose 5% solução para injeção 100 mL; bolsa"
  },
  {
    "code" : "@brasil17793184989",
    "display" : "Glicose 5% solução para injeção 100 mL; frasco-ampola"
  },
  {
    "code" : "@brasil17837167099",
    "display" : "Glicose 5% solução para injeção 125 mL; bolsa"
  },
  {
    "code" : "@brasil11562937731",
    "display" : "Glicose 5% solução para injeção 125 mL; frasco-ampola"
  },
  {
    "code" : "@brasil12231802540",
    "display" : "Glicose 5% solução para injeção 250 mL; bolsa"
  },
  {
    "code" : "@brasil19401229561",
    "display" : "Glicose 5% solução para injeção 250 mL; frasco-ampola"
  },
  {
    "code" : "@brasil11420522574",
    "display" : "Glicose 5% solução para injeção 50 mL; bolsa"
  },
  {
    "code" : "@brasil14839738088",
    "display" : "Glicose 5% solução para injeção 50 mL; frasco-ampola"
  },
  {
    "code" : "@brasil15195920340",
    "display" : "Glicose 5% solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "@brasil15360251910",
    "display" : "Glicose 5% solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "@brasil18012206550",
    "display" : "Glicose 50% solução para injeção 1 L; bolsa"
  },
  {
    "code" : "@brasil15312899624",
    "display" : "Glicose 50% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "@brasil11904385034",
    "display" : "Glicose 50% solução para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "@brasil11455059368",
    "display" : "Glicose 50% solução para injeção 100 mL; bolsa"
  },
  {
    "code" : "@brasil10096713201",
    "display" : "Glicose 50% solução para injeção 20 mL; ampola"
  },
  {
    "code" : "@brasil13325907617",
    "display" : "Glicose 50% solução para injeção 20 mL; frasco-ampola"
  },
  {
    "code" : "@brasil14924469239",
    "display" : "Glicose 50% solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "@brasil12626679699",
    "display" : "Glicose 75% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "@brasil13705972174",
    "display" : "Glimepirida 1 mg comprimido"
  },
  {
    "code" : "@brasil19091737258",
    "display" : "Glimepirida 1 mg comprimido e Metformina 500 mg comprimido"
  },
  {
    "code" : "@brasil13550903612",
    "display" : "Glimepirida 2 mg + Metformina 1 g comprimido"
  },
  {
    "code" : "@brasil19032574665",
    "display" : "Glimepirida 2 mg comprimido"
  },
  {
    "code" : "@brasil18265171867",
    "display" : "Glimepirida 3 mg comprimido"
  },
  {
    "code" : "@brasil17419856177",
    "display" : "Glimepirida 4 mg + Metformina 1 g comprimido"
  },
  {
    "code" : "@brasil18401114704",
    "display" : "Glimepirida 4 mg comprimido"
  },
  {
    "code" : "@brasil18929552023",
    "display" : "Glimepirida 6 mg comprimido"
  },
  {
    "code" : "@brasil17565441034",
    "display" : "Glipizida 5 mg comprimido"
  },
  {
    "code" : "@brasil11650961125",
    "display" : "Glucagon 1 mg pó para solução para injeção; ampola"
  },
  {
    "code" : "@brasil10978777063",
    "display" : "Glucagon 1 unidade internacional pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16841056109",
    "display" : "Glucana 10 mg/5 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14486263574",
    "display" : "Glycine max (Isoflavona de Soja) 125 mg comprimido"
  },
  {
    "code" : "@brasil18569119392",
    "display" : "Glycine max (Isoflavona de Soja) 150 mg cápsula"
  },
  {
    "code" : "@brasil10736248707",
    "display" : "Glycine max (Isoflavona de Soja) 75 mg cápsula"
  },
  {
    "code" : "@brasil13612356038",
    "display" : "Glycine max 100 mg + Persea gratissima 20 mg cápsula"
  },
  {
    "code" : "@brasil12235693569",
    "display" : "Golimumabe 50 mg/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil16862595654",
    "display" : "Golimumabe 50 mg/4 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13262396428",
    "display" : "Gonadotropina Coriônica 5.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13375651260",
    "display" : "Gonadotropina Coriônica 5.000 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14495374451",
    "display" : "Gosserrelina 10,8 mg implante de liberação prolongada; seringa preenchida"
  },
  {
    "code" : "@brasil14024119817",
    "display" : "Gosserrelina 3,6 mg implante; seringa preenchida"
  },
  {
    "code" : "@brasil12194854338",
    "display" : "Granisetrona 1 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10595170128",
    "display" : "Granisetrona 3 mg/3 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17662855028",
    "display" : "Griseofulvina 500 mg comprimido"
  },
  {
    "code" : "@brasil15122594696",
    "display" : "Guaifenesina 13,3 mg/mL xarope"
  },
  {
    "code" : "@brasil14646768153",
    "display" : "Guaifenesina 16 mg/mL xarope"
  },
  {
    "code" : "@brasil17866056986",
    "display" : "Guaifenesina 20 mg/mL xarope"
  },
  {
    "code" : "@brasil10322068547",
    "display" : "Guaifenesina 6,667 mg/mL xarope"
  },
  {
    "code" : "@brasil10099459112",
    "display" : "Halobetasol 0,05 mg/g creme"
  },
  {
    "code" : "@brasil11832716828",
    "display" : "Haloperidol 1 mg comprimido"
  },
  {
    "code" : "@brasil19151370289",
    "display" : "Haloperidol 2 mg/mL solução oral"
  },
  {
    "code" : "@brasil10884447311",
    "display" : "Haloperidol 5 mg comprimido"
  },
  {
    "code" : "@brasil11153500517",
    "display" : "Haloperidol 5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11554546170",
    "display" : "Haloperidol 50 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17512739902",
    "display" : "Halotano líquido para inalação 100 mL"
  },
  {
    "code" : "@brasil19236997316",
    "display" : "Halotano líquido para inalação 250 mL"
  },
  {
    "code" : "@brasil18875675515",
    "display" : "Hedera helix 7 mg/mL xarope"
  },
  {
    "code" : "@brasil10035937110",
    "display" : "Heparina Sódica 10.000 unidades internacionais/ mL solução"
  },
  {
    "code" : "@brasil14955413884",
    "display" : "Heparina Sódica 10.000 unidades internacionais/ mL solução spray"
  },
  {
    "code" : "@brasil14977691959",
    "display" : "Heparina Sódica 200 unidades internacionais/g gel"
  },
  {
    "code" : "@brasil16785293384",
    "display" : "Heparina Sódica 25.000 unidades internacionais/ 5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10661820191",
    "display" : "Heparina Sódica 25.000 unidades internacionais/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15281000345",
    "display" : "Heparina Sódica 5.000 unidades internacionais/0,25 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10886123859",
    "display" : "Heparina Sódica 50 unidades internacionais/g + Nicotinato de Benzila 2 mg/g pomada"
  },
  {
    "code" : "@brasil17797201663",
    "display" : "Hexamidina 1 mg/mL + Tetracaína 0,5 mg/mL colutório spray"
  },
  {
    "code" : "@brasil11015186728",
    "display" : "Hialuronato de Sódio 0,15% solução oftálmica"
  },
  {
    "code" : "@brasil15641618151",
    "display" : "Hialuronato de Sódio 1,6% solução para injeção 0,8 mL; seringa preenchida"
  },
  {
    "code" : "@brasil17091067326",
    "display" : "Hialuronato de Sódio 20 mg/ 2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14754907948",
    "display" : "Hialuronato de Sódio 20 mg/2 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil10166422621",
    "display" : "Hialuronato de Sódio 25 mg/2,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil11853130432",
    "display" : "Hialuronato de Sódio 40 mg/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18122264878",
    "display" : "Hialuronidase 100 UTR/mL + Lidocaína 50 mg/mL + Neomicina 5 mg/mL solução otológica"
  },
  {
    "code" : "@brasil13585822202",
    "display" : "Hialuronidase 2.000 UTR pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13768697411",
    "display" : "Hidralazina 20 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17772216383",
    "display" : "Hidralazina 25 mg comprimido"
  },
  {
    "code" : "@brasil16338008711",
    "display" : "Hidralazina 50 mg comprimido"
  },
  {
    "code" : "@brasil17773351376",
    "display" : "Hidrato de Cloral 100 mg/mL (10%) solução oral"
  },
  {
    "code" : "@brasil14089032795",
    "display" : "Hidrato de Cloral 160 mg/mL solução oral"
  },
  {
    "code" : "@brasil15650852410",
    "display" : "Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil17891925215",
    "display" : "Hidroclorotiazida 25 mg + Amilorida 2,5 mg comprimido"
  },
  {
    "code" : "@brasil19169945108",
    "display" : "Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "@brasil11969031803",
    "display" : "Hidroclorotiazida 50 mg + Amilorida 5 mg comprimido"
  },
  {
    "code" : "@brasil13923628928",
    "display" : "Hidroclorotiazida 50 mg comprimido"
  },
  {
    "code" : "@brasil15026302135",
    "display" : "Hidrocortisona 10 mg comprimido"
  },
  {
    "code" : "@brasil19016179849",
    "display" : "Hidrocortisona 10 mg/g creme"
  },
  {
    "code" : "@brasil19696141944",
    "display" : "Hidrocortisona 10 mg/g pomada"
  },
  {
    "code" : "@brasil12303586584",
    "display" : "Hidrocortisona 5 mg comprimido"
  },
  {
    "code" : "@brasil19678240211",
    "display" : "Hidrocortisona 5 mg/g (0,5%) + Lidocaína 20 mg/g (2%) + Subgalato de Bismuto 20 mg/g (2%) + Óxido de Zinco 100 mg/g (10%) pomada"
  },
  {
    "code" : "@brasil14508605974",
    "display" : "Hidrocortisona 5 mg/g + Neomicina 5 mg/g + Troxerrutina 20 mg/g + Ácido Ascórbico 0,5 mg/g + Benzocaína 2 mg/g pomada"
  },
  {
    "code" : "@brasil11336644785",
    "display" : "Hidromorfona 16 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil14812491874",
    "display" : "Hidromorfona 32 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil15826140217",
    "display" : "Hidromorfona 8 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil16827567513",
    "display" : "Hidroquinona 40 mg/g + Ácido Glicólico 100 mg/g creme"
  },
  {
    "code" : "@brasil19445252136",
    "display" : "Hidroquinona 40 mg/g + Tretinoína 0,5 mg/g + Fluocinolona Acetonida 0,1 mg/g creme"
  },
  {
    "code" : "@brasil12054621009",
    "display" : "Hidroquinona 40 mg/g creme"
  },
  {
    "code" : "@brasil15901557564",
    "display" : "Hidroquinona 40 mg/g gel"
  },
  {
    "code" : "@brasil19066374289",
    "display" : "Hidrosmina 200 mg cápsula"
  },
  {
    "code" : "@brasil11213139956",
    "display" : "Hidroxiapatita 800 mg comprimido"
  },
  {
    "code" : "@brasil17912190077",
    "display" : "Hidroxicloroquina 200 mg comprimido"
  },
  {
    "code" : "@brasil13314425397",
    "display" : "Hidroxicloroquina 400 mg comprimido"
  },
  {
    "code" : "@brasil16641321205",
    "display" : "Hidróxido de Alumínio 120 mg/mL + Hidróxido de Magnésio 60 mg/mL + Simeticona 7 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil10953069198",
    "display" : "Hidróxido de Alumínio 141,47 mg + Hidróxido de Magnésio 185 mg + Carbonato de Cálcio 230 mg comprimido mastigável"
  },
  {
    "code" : "@brasil18448364833",
    "display" : "Hidróxido de Alumínio 153 mg + Hidróxido de Magnésio 200 mg + Simeticona 25 mg comprimido mastigável"
  },
  {
    "code" : "@brasil19192039200",
    "display" : "Hidróxido de Alumínio 159,9 mg + Hidróxido de Magnésio 208,9 mg + Carbonato de Cálcio 231,5 mg comprimido mastigável"
  },
  {
    "code" : "@brasil19500675375",
    "display" : "Hidróxido de Alumínio 178 mg + Hidróxido de Magnésio 185 mg + Carbonato de Cálcio 230 mg comprimido mastigável"
  },
  {
    "code" : "@brasil10202759531",
    "display" : "Hidróxido de Alumínio 178 mg + Hidróxido de Magnésio 185 mg + Carbonato de Cálcio 230 mg pó efervescente"
  },
  {
    "code" : "@brasil12223475119",
    "display" : "Hidróxido de Alumínio 178 mg + Hidróxido de Magnésio 185 mg + Carbonato de Cálcio 231,5 mg pastilha"
  },
  {
    "code" : "@brasil16127859413",
    "display" : "Hidróxido de Alumínio 178 mg + Hidróxido de Magnésio 185 mg + Carbonato de Cálcio 235 mg pó efervescente"
  },
  {
    "code" : "@brasil14604495869",
    "display" : "Hidróxido de Alumínio 178 mg + Hidróxido de Magnésio 185 mg pó efervescente"
  },
  {
    "code" : "@brasil10555523475",
    "display" : "Hidróxido de Alumínio 180 mg/mL + Hidróxido de Magnésio 125 mg/mL + Carbonato de Cálcio 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil17257301588",
    "display" : "Hidróxido de Alumínio 200 mg + Hidróxido de Magnésio 200 mg + Simeticona 30 mg comprimido mastigável"
  },
  {
    "code" : "@brasil13727264657",
    "display" : "Hidróxido de Alumínio 200 mg + Hidróxido de Magnésio 200 mg comprimido mastigável"
  },
  {
    "code" : "@brasil15984542010",
    "display" : "Hidróxido de Alumínio 200 mg + Hidróxido de Magnésio 200 mg pastilha"
  },
  {
    "code" : "@brasil14737339376",
    "display" : "Hidróxido de Alumínio 230 mg comprimido"
  },
  {
    "code" : "@brasil18004709841",
    "display" : "Hidróxido de Alumínio 230 mg comprimido mastigável"
  },
  {
    "code" : "@brasil19497707697",
    "display" : "Hidróxido de Alumínio 240 mg + Hidróxido de Magnésio 144 mg + Trissilicato de Magnésio 90 mg comprimido mastigável"
  },
  {
    "code" : "@brasil16693292441",
    "display" : "Hidróxido de Alumínio 300 mg comprimido"
  },
  {
    "code" : "@brasil12918641671",
    "display" : "Hidróxido de Alumínio 35,6 mg/mL + Hidróxido de Magnésio 37 mg/mL + Carbonato de Cálcio 47,6 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil16639582631",
    "display" : "Hidróxido de Alumínio 35,6 mg/mL + Hidróxido de Magnésio 37 mg/mL + Carbonato de Cálcio 48,4 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil15981178269",
    "display" : "Hidróxido de Alumínio 37 mg/mL + Hidróxido de Magnésio 35,6 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil15134354507",
    "display" : "Hidróxido de Alumínio 37 mg/mL + Hidróxido de Magnésio 40 mg/mL + Simeticona 5 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil14441988452",
    "display" : "Hidróxido de Alumínio 40 mg/mL + Carbonato de Magnésio 40 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil18130008332",
    "display" : "Hidróxido de Alumínio 40 mg/mL + Hidróxido de Magnésio 30 mg/mL + Simeticona 3 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil13364951007",
    "display" : "Hidróxido de Alumínio 40 mg/mL + Hidróxido de Magnésio 30 mg/mL + Simeticona 5 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil13776457945",
    "display" : "Hidróxido de Alumínio 40 mg/mL + Hidróxido de Magnésio 30 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil12748337743",
    "display" : "Hidróxido de Alumínio 400 mg + Hidróxido de Magnésio 400 mg comprimido mastigável"
  },
  {
    "code" : "@brasil14492265035",
    "display" : "Hidróxido de Alumínio 60 mg/mL + Hidróxido de Magnésio 20 mg/mL + Oxetacaína 2 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil14112148557",
    "display" : "Hidróxido de Alumínio 60 mg/mL + Hidróxido de Magnésio 40 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil15446246232",
    "display" : "Hidróxido de Alumínio 60 mg/mL solução oral"
  },
  {
    "code" : "@brasil15932566601",
    "display" : "Hidróxido de Alumínio 60 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil14643246916",
    "display" : "Hidróxido de Alumínio 61,5 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil12182963454",
    "display" : "Hidróxido de Alumínio 80 mg/mL + Hidróxido de Magnésio 80 mg/mL + Simeticona 6 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil17518962626",
    "display" : "Hidróxido de Magnésio 80 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil18135190611",
    "display" : "Hidróxido de Magnésio 85,5 mg/mL suspensão oftálmica"
  },
  {
    "code" : "@brasil11045923083",
    "display" : "Hidróxido de Magnésio 85,5 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil18351620655",
    "display" : "Hidróxido Férrico 100 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12672727844",
    "display" : "Hidroxietilamido 10% + Cloreto de Sódio 0,9% solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "@brasil17237672428",
    "display" : "Hidroxietilamido 6% + Cloreto de Sódio 0,6% + Cloreto de Potássio 0,04% + Cloreto de Cálcio 0,0134% + Cloreto de Magnésio 0,02% + Acetato de Sódio 0,37% solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "@brasil12237890549",
    "display" : "Hidroxietilamido 6% + Cloreto de Sódio 0,62% + Cloreto de Potássio 0,03% + Cloreto de Cálcio 0,03% + Cloreto de Magnésio 0,02% + Acetato de Sódio 0,32% + Ácido Málico 0,06% solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "@brasil10225870282",
    "display" : "Hidroxietilamido 6% + Cloreto de Sódio 0,9% solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "@brasil15057647687",
    "display" : "Hidroxietilamido 6% + Cloreto de Sódio 7,2% solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "@brasil17783304802",
    "display" : "Hidroxietilamido 6% solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "@brasil10447032814",
    "display" : "Hidroxiquinolina 0,04 mg/mL + Trolamina 140 mg/mL solução otológica"
  },
  {
    "code" : "@brasil16431865342",
    "display" : "Hidroxiquinolina 0,4 mg/mL + Trolamina 140 mg/mL solução otológica"
  },
  {
    "code" : "@brasil18247057652",
    "display" : "Hidroxiureia 500 mg cápsula"
  },
  {
    "code" : "@brasil17078273440",
    "display" : "Hidroxizina 10 mg comprimido"
  },
  {
    "code" : "@brasil15922234546",
    "display" : "Hidroxizina 2 mg/mL solução oral"
  },
  {
    "code" : "@brasil11771116797",
    "display" : "Hidroxizina 2 mg/mL xarope"
  },
  {
    "code" : "@brasil10472220852",
    "display" : "Hidroxizina 25 mg comprimido"
  },
  {
    "code" : "@brasil17203669981",
    "display" : "Hidroxocobalamina 1 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18026974272",
    "display" : "Hidroxocobalamina 15 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16388050350",
    "display" : "Hidroxocobalamina 2 mg/2 mL solução par a injeção; ampola"
  },
  {
    "code" : "@brasil15479457158",
    "display" : "Hidroxocobalamina 5 mg/1 mL solução para injeção; ampola e Dipirona 500 mg/1 mL + Dexametasona 1,5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19422918658",
    "display" : "Hidroxocobalamina 5 mg/2,5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19787253986",
    "display" : "Hipromelose 0,2 mg/mL (0,02%) solução oftálmica"
  },
  {
    "code" : "@brasil15552408316",
    "display" : "Hipromelose 2 mg/mL (0,2%) solução oftálmica"
  },
  {
    "code" : "@brasil11902106144",
    "display" : "Hipromelose 3 mg/mL + Dextrana 1 mg/mL + Glicerol 2 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil11363548580",
    "display" : "Hipromelose 3 mg/mL + Dextrana 1 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil13626646010",
    "display" : "Hipromelose 3 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil14533265179",
    "display" : "Hipromelose 3,2 mg/mL + Cetrimida 0,1 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil14075650901",
    "display" : "Hipromelose 5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil16305377292",
    "display" : "Homatropina 2 mg/mL solução oral"
  },
  {
    "code" : "@brasil19567534632",
    "display" : "Hypericum perforatum 300 mg cápsula"
  },
  {
    "code" : "@brasil10206322408",
    "display" : "Ibrutinibe 140 mg cápsula"
  },
  {
    "code" : "@brasil11106486841",
    "display" : "Ibuprofeno 100 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil15031495563",
    "display" : "Ibuprofeno 20 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil19100725908",
    "display" : "Ibuprofeno 200 mg cápsula"
  },
  {
    "code" : "@brasil18358701836",
    "display" : "Ibuprofeno 200 mg comprimido"
  },
  {
    "code" : "@brasil12788327617",
    "display" : "Ibuprofeno 30 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil18690921772",
    "display" : "Ibuprofeno 300 mg comprimido"
  },
  {
    "code" : "@brasil18738043891",
    "display" : "Ibuprofeno 400 mg + Arginina 370 mg granulado"
  },
  {
    "code" : "@brasil19012711753",
    "display" : "Ibuprofeno 400 mg + Paracetamol 400 mg + Carisoprodol 200 mg + Piridoxina 50 mg  cápsula"
  },
  {
    "code" : "@brasil15295615786",
    "display" : "Ibuprofeno 400 mg cápsula"
  },
  {
    "code" : "@brasil18461924322",
    "display" : "Ibuprofeno 400 mg comprimido"
  },
  {
    "code" : "@brasil15640036905",
    "display" : "Ibuprofeno 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil13319118676",
    "display" : "Ibuprofeno 600 mg + Arginina 555 mg granulado"
  },
  {
    "code" : "@brasil11639063684",
    "display" : "ibuprofeno 600 mg cápsula"
  },
  {
    "code" : "@brasil10174209828",
    "display" : "Ibuprofeno 600 mg comprimido"
  },
  {
    "code" : "@brasil12699364546",
    "display" : "Ibuprofeno arginina 770 mg comprimido"
  },
  {
    "code" : "@brasil17843503966",
    "display" : "Icatibanto 30 mg/3 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil13992002692",
    "display" : "Idarrubicina 10 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11805301365",
    "display" : "Idarrubicina 10 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17625305946",
    "display" : "Idarrubicina 5 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11122946571",
    "display" : "Idarrubicina 5 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16360955177",
    "display" : "Idebenona 150 mg cápsula"
  },
  {
    "code" : "@brasil15063148647",
    "display" : "Idoxuridina 10 mg comprimido e diluente"
  },
  {
    "code" : "@brasil15328383160",
    "display" : "Idursulfase 6 mg/3 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15088731575",
    "display" : "Ifosfamida 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19294457675",
    "display" : "Ifosfamida 2 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18923592992",
    "display" : "Ifosfamida 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19373454681",
    "display" : "Iloprosta 10 microgramas/mL solução para inalação 1 mL; ampola"
  },
  {
    "code" : "@brasil11692581968",
    "display" : "Imatinibe 100 mg comprimido"
  },
  {
    "code" : "@brasil18416606640",
    "display" : "Imatinibe 400 mg comprimido"
  },
  {
    "code" : "@brasil15588591316",
    "display" : "Imiglucerase 200 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11206093961",
    "display" : "Imiglucerase 400 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11153377471",
    "display" : "Imipeném 500 mg + Cilastatina 500 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10858421483",
    "display" : "Imipeném 500 mg + Cilastatina 500 mg pó e diluente para solução para injeção; frasco-ampola + bolsa"
  },
  {
    "code" : "@brasil18185965331",
    "display" : "Imipeném 500 mg + Cilastatina 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13719670569",
    "display" : "Imipramina 10 mg comprimido"
  },
  {
    "code" : "@brasil13775982355",
    "display" : "Imipramina 150 mg cápsula"
  },
  {
    "code" : "@brasil13760652628",
    "display" : "Imipramina 25 mg comprimido"
  },
  {
    "code" : "@brasil11744904472",
    "display" : "Imipramina 75 mg cápsula"
  },
  {
    "code" : "@brasil19207841267",
    "display" : "Imiquimode 50 mg/g creme"
  },
  {
    "code" : "@brasil17905885880",
    "display" : "Imunoglobulina anti-Rho (D) 1.250 unidades internacionais/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15256518231",
    "display" : "Imunoglobulina anti-Rho (D) 1.500 unidades internacionais/2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19875496651",
    "display" : "Imunoglobulina anti-Rho (D) 1.500 unidades internacionais/2 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil12951104512",
    "display" : "Imunoglobulina anti-Rho (D) 625 unidades internacionais/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11010897271",
    "display" : "Imunoglobulina antitetânica 250 unidades internacionais/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil13409735953",
    "display" : "Imunoglobulina antitetânica 500 unidades internacionais/2 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil16831074855",
    "display" : "Imunoglobulina antitimócito 25 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17205704334",
    "display" : "Imunoglobulina G 1 g/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16476320693",
    "display" : "Imunoglobulina G 10 g/200 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10764490775",
    "display" : "Imunoglobulina G 2,5 g/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19673988490",
    "display" : "Imunoglobulina G 5 g/100 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13945824943",
    "display" : "Imunoglobulina humana 1 g/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11037865225",
    "display" : "Imunoglobulina humana 1 g/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13013689165",
    "display" : "Imunoglobulina humana 10 g/100 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16384068880",
    "display" : "Imunoglobulina humana 10 g/200 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18566469118",
    "display" : "Imunoglobulina humana 2 g/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12879277217",
    "display" : "Imunoglobulina humana 2 g/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13422129016",
    "display" : "Imunoglobulina humana 2,5 g/25 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17662012628",
    "display" : "Imunoglobulina humana 2,5 g/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14275550090",
    "display" : "Imunoglobulina humana 20 g/200 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16883384198",
    "display" : "Imunoglobulina humana 20 g/400 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12760828371",
    "display" : "Imunoglobulina humana 3 g/60 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12697989140",
    "display" : "Imunoglobulina humana 320 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17355780466",
    "display" : "Imunoglobulina humana 4 g/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19039946465",
    "display" : "Imunoglobulina Humana 5 g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14610371164",
    "display" : "Imunoglobulina humana 5 g/100 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11735201599",
    "display" : "Imunoglobulina humana 5 g/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18854671806",
    "display" : "Imunoglobulina humana 500 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10522282691",
    "display" : "Imunoglobulina humana 6 g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17882366847",
    "display" : "Imunoglobulina humana 800 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18789997963",
    "display" : "Imunoglobulina humana anti-hepatite B 1.000 unidades internacionais/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16487731211",
    "display" : "Imunoglobulina humana anti-hepatite B 100 unidades internacionais/0,5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16176505884",
    "display" : "Imunoglobulina humana anti-hepatite B 5.000 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10331222339",
    "display" : "Imunoglobulina humana anti-hepatite B 500 unidades internacionais/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10880119045",
    "display" : "Imunoglobulina humana anti-hepatite B 600 unidades internacionais/3 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13219314116",
    "display" : "Indacaterol 110 microgramas + Glicopirrônio 50 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "@brasil14125224913",
    "display" : "Indacaterol 150 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "@brasil11185596417",
    "display" : "Indacaterol 300 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "@brasil18460265376",
    "display" : "Indapamida 1,5 mg comprimido"
  },
  {
    "code" : "@brasil13378869008",
    "display" : "Indapamida 1,5 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil17526835245",
    "display" : "Indapamida 2,5 mg comprimido"
  },
  {
    "code" : "@brasil18929668866",
    "display" : "Indinavir 400 mg cápsula"
  },
  {
    "code" : "@brasil12149715461",
    "display" : "Indometacina 25 mg cápsula"
  },
  {
    "code" : "@brasil13348708992",
    "display" : "Indometacina 50 mg cápsula"
  },
  {
    "code" : "@brasil18586889176",
    "display" : "Infliximabe 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13082033779",
    "display" : "Ingenol 150 microgramas/g gel"
  },
  {
    "code" : "@brasil11322320932",
    "display" : "Inibidor de C1 esterase derivado de plasma humano 500 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18763667705",
    "display" : "Insulina Asparte 100 unidades/mL solução para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "@brasil14244173944",
    "display" : "Insulina Asparte 100 unidades/mL solução para injeção 3 mL; carpule"
  },
  {
    "code" : "@brasil12914903575",
    "display" : "Insulina Asparte 100 unidades/mL solução para injeção 3 mL; dispositivo para injeção"
  },
  {
    "code" : "@brasil19902173585",
    "display" : "Insulina Asparte bifásica (30/70) 100 unidades/mL suspensão para injeção 3 mL; carpule"
  },
  {
    "code" : "@brasil17617579741",
    "display" : "Insulina Asparte bifásica (30/70) 100 unidades/mL suspensão para injeção 3 mL; dispositivo para injeção"
  },
  {
    "code" : "@brasil10573458168",
    "display" : "Insulina Degludeca 100 unidades/mL solução para injeção 3 mL; carpule"
  },
  {
    "code" : "@brasil15823913835",
    "display" : "Insulina Degludeca 100 unidades/mL solução para injeção 3 mL; dispositivo para injeção"
  },
  {
    "code" : "@brasil12891602722",
    "display" : "Insulina Detemir 100 unidades/mL solução para injeção 3 mL; carpule"
  },
  {
    "code" : "@brasil19518221316",
    "display" : "Insulina Detemir 100 unidades/mL solução para injeção 3 mL; dispositivo para injeção"
  },
  {
    "code" : "@brasil11968244743",
    "display" : "Insulina Glargina 100 unidades/mL solução para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "@brasil11667963145",
    "display" : "Insulina Glargina 100 unidades/mL solução para injeção 3 mL; carpule"
  },
  {
    "code" : "@brasil15179941266",
    "display" : "Insulina Glargina 100 unidades/mL solução para injeção 3 mL; dispositivo para injeção"
  },
  {
    "code" : "@brasil18004643308",
    "display" : "Insulina Glargina 100 unidades/mL solução para injeção 5 mL; frasco-ampola"
  },
  {
    "code" : "@brasil16242909817",
    "display" : "Insulina Glargina 300 unidades/mL solução para injeção 1,5 mL; dispositivo para injeção"
  },
  {
    "code" : "@brasil11457646358",
    "display" : "Insulina Glulisina 100 unidades internacionais/mL solução para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "@brasil18016033224",
    "display" : "Insulina Glulisina 100 unidades internacionais/mL solução para injeção 3 mL; carpule"
  },
  {
    "code" : "@brasil16210452741",
    "display" : "Insulina Glulisina 100 unidades internacionais/mL solução para injeção 3 mL; dispositivo para injeção"
  },
  {
    "code" : "@brasil10010987854",
    "display" : "Insulina Humana Isófana Bifásica (30/70) 100 unidades/mL suspensão para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "@brasil19170539804",
    "display" : "Insulina Humana Isófana Bifásica (30/70) 100 unidades/mL suspensão para injeção 3 mL; carpule"
  },
  {
    "code" : "@brasil10405039330",
    "display" : "Insulina Humana NPH 100 unidades internacionais/mL suspensão para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "@brasil15900508253",
    "display" : "Insulina Humana NPH 100 unidades internacionais/mL suspensão para injeção 3 mL; carpule"
  },
  {
    "code" : "@brasil15375108601",
    "display" : "Insulina Humana Regular 100 unidades internacionais/mL solução para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "@brasil13571397971",
    "display" : "Insulina Humana Regular 100 unidades internacionais/mL solução para injeção 3 mL; carpule"
  },
  {
    "code" : "@brasil19337040174",
    "display" : "Insulina Lispro 100 unidades/mL solução para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "@brasil13586988395",
    "display" : "Insulina Lispro 100 unidades/mL solução para injeção 3 mL; carpule"
  },
  {
    "code" : "@brasil14157103721",
    "display" : "Insulina Lispro 100 unidades/mL solução para injeção 3 mL; dispositivo para injeção"
  },
  {
    "code" : "@brasil19530354689",
    "display" : "Insulina Lispro Bifásica (25/75) 100 unidades/mL suspensão para injeção 3 mL; carpule"
  },
  {
    "code" : "@brasil10019360872",
    "display" : "Insulina Lispro Bifásica (25/75) 100 unidades/mL suspensão para injeção 3 mL; dispositivo para injeção"
  },
  {
    "code" : "@brasil12837725376",
    "display" : "Insulina Lispro Bifásica (50/50) 100 unidades/mL suspensão para injeção 3 mL; carpule"
  },
  {
    "code" : "@brasil11171908266",
    "display" : "Insulina Lispro Bifásica (50/50) 100 unidades/mL suspensão para injeção 3 mL; dispositivo para injeção"
  },
  {
    "code" : "@brasil17461661925",
    "display" : "Iobitridol 300 mg/1 mL solução para injeção 50 mL; frasco-ampola"
  },
  {
    "code" : "@brasil19710923449",
    "display" : "Iodeto de Potássio 20 mg/mL xarope"
  },
  {
    "code" : "@brasil12396266023",
    "display" : "Iodo 10 mg/mL + Óleo Vegetal 10 mg/mL + Ácido Salicílico 20 mg/mL solução"
  },
  {
    "code" : "@brasil11874295343",
    "display" : "Iodopovidona 100 mg/mL solução"
  },
  {
    "code" : "@brasil18569159104",
    "display" : "Iodopovidona 7 mg/g sabonete"
  },
  {
    "code" : "@brasil18161558048",
    "display" : "Ioimbina 5,4 mg comprimido"
  },
  {
    "code" : "@brasil10481961061",
    "display" : "Ioxitalamato de Meglumina 350 mg/mL solução para injeção 50 mL; frasco-ampola"
  },
  {
    "code" : "@brasil16925367140",
    "display" : "Ipilimumabe 200 mg/40 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14516082026",
    "display" : "Ipilimumabe 50 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17289426639",
    "display" : "Irbesartana 150 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil13245222411",
    "display" : "Irbesartana 150 mg comprimido"
  },
  {
    "code" : "@brasil14556834355",
    "display" : "Irbesartana 300 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil14788681886",
    "display" : "Irbesartana 300 mg comprimido"
  },
  {
    "code" : "@brasil15012803518",
    "display" : "Irinotecano 100 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17816722882",
    "display" : "Irinotecano 100 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19455331142",
    "display" : "Irinotecano 40 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10584982195",
    "display" : "Irinotecano 40 mg/2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18129002150",
    "display" : "Isoconazol 10 mg/g creme"
  },
  {
    "code" : "@brasil19146597988",
    "display" : "Isoconazol 10 mg/g creme vaginal"
  },
  {
    "code" : "@brasil19289240210",
    "display" : "Isoconazol 10 mg/mL solução"
  },
  {
    "code" : "@brasil16750511354",
    "display" : "Isoconazol 10 mg/mL solução spray"
  },
  {
    "code" : "@brasil15665977470",
    "display" : "Isoconazol 600 mg óvulo"
  },
  {
    "code" : "@brasil15177905870",
    "display" : "Isoflurano líquido para inalação 100 mL"
  },
  {
    "code" : "@brasil16694809333",
    "display" : "Isoflurano líquido para inalação 240 mL"
  },
  {
    "code" : "@brasil19667728885",
    "display" : "Isoniazida 100 mg comprimido"
  },
  {
    "code" : "@brasil11098956791",
    "display" : "Isotipendil 7,5 mg/g gel"
  },
  {
    "code" : "@brasil11912302664",
    "display" : "Isotretinoína 0,5 mg/g + Eritromicina 20 mg/g gel"
  },
  {
    "code" : "@brasil13860813940",
    "display" : "Isotretinoína 0,5 mg/g gel"
  },
  {
    "code" : "@brasil16795676047",
    "display" : "Isotretinoína 10 mg cápsula"
  },
  {
    "code" : "@brasil15334357613",
    "display" : "Isotretinoína 20 mg cápsula"
  },
  {
    "code" : "@brasil15917087806",
    "display" : "Isoxsuprina 10 mg comprimido"
  },
  {
    "code" : "@brasil13332853281",
    "display" : "Isoxsuprina 10 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16562205846",
    "display" : "Itraconazol 10 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil19853128285",
    "display" : "Itraconazol 100 mg cápsula"
  },
  {
    "code" : "@brasil13940543609",
    "display" : "Itraconazol 20 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil18660425559",
    "display" : "Ivabradina 5 mg comprimido"
  },
  {
    "code" : "@brasil16232235901",
    "display" : "Ivabradina 7,5 mg comprimido"
  },
  {
    "code" : "@brasil13939723337",
    "display" : "Ivermectina 6 mg comprimido"
  },
  {
    "code" : "@brasil18826645404",
    "display" : "Lacidipino 2 mg comprimido"
  },
  {
    "code" : "@brasil18785799803",
    "display" : "Lacidipino 4 mg comprimido"
  },
  {
    "code" : "@brasil19346959150",
    "display" : "Lacosamida 10 mg/mL solução oral"
  },
  {
    "code" : "@brasil10928994109",
    "display" : "Lacosamida 100 mg comprimido"
  },
  {
    "code" : "@brasil16457272465",
    "display" : "Lacosamida 100 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil15010459416",
    "display" : "Lacosamida 150 mg comprimido"
  },
  {
    "code" : "@brasil16295197386",
    "display" : "Lacosamida 200 mg comprimido"
  },
  {
    "code" : "@brasil15742965921",
    "display" : "Lacosamida 200 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10005979602",
    "display" : "Lacosamida 50 mg comprimido"
  },
  {
    "code" : "@brasil13122297927",
    "display" : "Lactase 3.000 unidades internacionais cápsula"
  },
  {
    "code" : "@brasil18132539248",
    "display" : "Lactato de Amônia 120 mg/g + Alantoína 1 mg/g loção"
  },
  {
    "code" : "@brasil10016100815",
    "display" : "Lactulose 667 mg/mL solução oral"
  },
  {
    "code" : "@brasil16855983589",
    "display" : "Lactulose 667 mg/mL xarope"
  },
  {
    "code" : "@brasil14872379296",
    "display" : "Lamivudina 10 mg/mL solução oral"
  },
  {
    "code" : "@brasil12026945641",
    "display" : "Lamivudina 150 mg + Zidovudina 300 mg comprimido"
  },
  {
    "code" : "@brasil17667327444",
    "display" : "Lamivudina 150 mg comprimido"
  },
  {
    "code" : "@brasil11531929280",
    "display" : "Lamotrigina 100 mg comprimido"
  },
  {
    "code" : "@brasil16442114379",
    "display" : "Lamotrigina 100 mg comprimido para suspensão"
  },
  {
    "code" : "@brasil10991162853",
    "display" : "Lamotrigina 200 mg comprimido"
  },
  {
    "code" : "@brasil18311056770",
    "display" : "Lamotrigina 200 mg comprimido para suspensão"
  },
  {
    "code" : "@brasil16401722072",
    "display" : "Lamotrigina 25 mg comprimido"
  },
  {
    "code" : "@brasil18371056594",
    "display" : "Lamotrigina 25 mg comprimido para suspensão"
  },
  {
    "code" : "@brasil11181408837",
    "display" : "Lamotrigina 5 mg comprimido para suspensão"
  },
  {
    "code" : "@brasil16804730114",
    "display" : "Lamotrigina 50 mg comprimido"
  },
  {
    "code" : "@brasil12511995966",
    "display" : "Lamotrigina 50 mg comprimido para suspensão"
  },
  {
    "code" : "@brasil12390529719",
    "display" : "Lanreotida 120 mg/ 0,5 mL solução para injeção de liberação prolongada; seringa preenchida"
  },
  {
    "code" : "@brasil13466391649",
    "display" : "Lanreotida 60 mg/ 0,3 mL solução para injeção de liberação prolongada; seringa preenchida"
  },
  {
    "code" : "@brasil11848283680",
    "display" : "Lanreotida 60 mg/ 0,5 mL solução para injeção de liberação prolongada; seringa preenchida"
  },
  {
    "code" : "@brasil13919867866",
    "display" : "Lanreotida 90 mg/ 0,3 mL solução para injeção de liberação prolongada; seringa preenchida"
  },
  {
    "code" : "@brasil17842939110",
    "display" : "Lanreotida 90 mg/ 0,5 mL solução para injeção de liberação prolongada; seringa preenchida"
  },
  {
    "code" : "@brasil17695993553",
    "display" : "Lansoprazol 15 mg cápsula"
  },
  {
    "code" : "@brasil19501267892",
    "display" : "Lansoprazol 15 mg cápsula gastrorresistente"
  },
  {
    "code" : "@brasil14855334445",
    "display" : "Lansoprazol 30 mg cápsula"
  },
  {
    "code" : "@brasil15114774735",
    "display" : "Lansoprazol 30 mg cápsula gastrorresistente"
  },
  {
    "code" : "@brasil16533603626",
    "display" : "Lansoprazol 30 mg cápsula gastrorresistente e Claritromicina 500 mg comprimido e Amoxicilina 500 mg cápsula"
  },
  {
    "code" : "@brasil17177216527",
    "display" : "Lansoprazol 30 mg cápsula gastrorresistente e Levofloxacino 500 mg comprimido e Amoxicilina 500 mg cápsula"
  },
  {
    "code" : "@brasil12596824952",
    "display" : "Lapatinibe 250 mg comprimido"
  },
  {
    "code" : "@brasil10916084786",
    "display" : "Laronidase 2,9 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15077944131",
    "display" : "Latanaprosta 50 microgramas/mL + Timolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil11607194580",
    "display" : "Latanoprosta 50 microgramas/mL solução oftálmica"
  },
  {
    "code" : "@brasil12461535736",
    "display" : "Leflunomida 100 mg comprimido"
  },
  {
    "code" : "@brasil18652505582",
    "display" : "Leflunomida 20 mg comprimido"
  },
  {
    "code" : "@brasil12257904793",
    "display" : "Lenalidomida 10 mg comprimido"
  },
  {
    "code" : "@brasil11772412034",
    "display" : "Lenalidomida 25 mg comprimido"
  },
  {
    "code" : "@brasil15972288171",
    "display" : "Lenalidomida 5 mg cápsula"
  },
  {
    "code" : "@brasil15983247444",
    "display" : "Lenvatinibe 10 mg cápsula"
  },
  {
    "code" : "@brasil15632528396",
    "display" : "Lenvatinibe 4 mg cápsula"
  },
  {
    "code" : "@brasil15738997845",
    "display" : "Lercanidipino 10 mg comprimido"
  },
  {
    "code" : "@brasil15502192921",
    "display" : "Lercanidipino 20 mg comprimido"
  },
  {
    "code" : "@brasil12473663176",
    "display" : "Letrozol 2,5 mg cápsula"
  },
  {
    "code" : "@brasil12012185864",
    "display" : "Letrozol 2,5 mg comprimido"
  },
  {
    "code" : "@brasil16840188899",
    "display" : "Leuprorrelina 11,25 mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16124707380",
    "display" : "Leuprorrelina 14 mg/2,8 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11864202023",
    "display" : "Leuprorrelina 22,5 mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15466050136",
    "display" : "Leuprorrelina 22,5 mg pó para suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil12293255283",
    "display" : "Leuprorrelina 3,75 mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14377401930",
    "display" : "Leuprorrelina 45 mg pó para suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil11132709477",
    "display" : "Leuprorrelina 7,5 mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19258581387",
    "display" : "Leuprorrelina 7,5 mg pó para suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil12711226028",
    "display" : "Levamisol 150 mg comprimido"
  },
  {
    "code" : "@brasil13403624540",
    "display" : "Levamisol 80 mg comprimido"
  },
  {
    "code" : "@brasil19588808321",
    "display" : "Levanlodipino 2,5 mg comprimido"
  },
  {
    "code" : "@brasil12449793965",
    "display" : "Levanlodipino 5 mg comprimido"
  },
  {
    "code" : "@brasil10212876805",
    "display" : "Levetiracetam 100 mg/mL solução oral"
  },
  {
    "code" : "@brasil10333729869",
    "display" : "Levetiracetam 250 mg comprimido"
  },
  {
    "code" : "@brasil12404697063",
    "display" : "Levetiracetam 500 mg comprimido"
  },
  {
    "code" : "@brasil14456242800",
    "display" : "Levetiracetam 750 mg comprimido"
  },
  {
    "code" : "@brasil11919893399",
    "display" : "Levobunolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil12016962357",
    "display" : "Levobupivacaína 0,25% solução para injeção 20 mL; ampola"
  },
  {
    "code" : "@brasil14443280001",
    "display" : "Levobupivacaína 0,75% solução para injeção 20 mL; ampola"
  },
  {
    "code" : "@brasil19830434301",
    "display" : "Levobupivacaína 100 mg/20 mL (0,5%) + Epinefrina 100 microgramas/20 mL (1:200.000) solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11189701557",
    "display" : "Levobupivacaína 100 mg/20 mL (0,5%) solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14032401705",
    "display" : "Levobupivacaína 150 mg/20 mL (0,75%) + Epinefrina 100 microgramas/20 mL (1:200.000) solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11585569707",
    "display" : "Levobupivacaína 150 mg/20 mL (0,75%) solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16756484783",
    "display" : "Levobupivacaína 50 mg/20 mL (0,25%) + Epinefrina 100 microgramas/20 mL (1:200.000) solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14817322681",
    "display" : "Levobupivacaína 50 mg/20 mL (0,25%) solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11859893287",
    "display" : "Levobupivacaína Isobárica 20 mg/4 mL (0,5%) solução para injeção; ampola"
  },
  {
    "code" : "@brasil12969445727",
    "display" : "Levocetirizina 5 mg comprimido"
  },
  {
    "code" : "@brasil10467115202",
    "display" : "Levocetirizina 5 mg/mL solução oral"
  },
  {
    "code" : "@brasil18022711655",
    "display" : "Levocloperastina 7,08 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil14550052474",
    "display" : "Levodopa 100 + Carbidopa 25 mg + Entacapona 200 mg comprimido"
  },
  {
    "code" : "@brasil15184460015",
    "display" : "Levodopa 100 mg + Benserazida 25 mg cápsula"
  },
  {
    "code" : "@brasil14144618644",
    "display" : "Levodopa 100 mg + Benserazida 25 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil12399851652",
    "display" : "Levodopa 100 mg + Benserazida 25 mg comprimido"
  },
  {
    "code" : "@brasil14128072348",
    "display" : "Levodopa 100 mg + Benserazida 25 mg comprimido para suspensão"
  },
  {
    "code" : "@brasil12926369115",
    "display" : "Levodopa 150 + Carbidopa 37,5 mg + Entacapona 200 mg comprimido"
  },
  {
    "code" : "@brasil16641768901",
    "display" : "Levodopa 200 mg + Benserazida 50 mg comprimido"
  },
  {
    "code" : "@brasil12382489797",
    "display" : "Levodopa 200 mg + Benserazida 50 mg comprimido de liberação modificada"
  },
  {
    "code" : "@brasil17787226779",
    "display" : "Levodopa 200 mg + Carbidopa 50 mg + Entacapona 200 mg comprimido"
  },
  {
    "code" : "@brasil17192632439",
    "display" : "Levodopa 200 mg + Carbidopa 50 mg comprimido"
  },
  {
    "code" : "@brasil18644007757",
    "display" : "Levodopa 250 mg + Carbidopa 25 mg comprimido"
  },
  {
    "code" : "@brasil10872235297",
    "display" : "Levodopa 50 + Carbidopa 12,5 mg + Entacapona 200 mg comprimido"
  },
  {
    "code" : "@brasil17377810306",
    "display" : "Levodropropizina 30 mg/mL solução oral"
  },
  {
    "code" : "@brasil18527604813",
    "display" : "Levodropropizina 6 mg/mL xarope"
  },
  {
    "code" : "@brasil12797773453",
    "display" : "Levofloxacino 250 mg comprimido"
  },
  {
    "code" : "@brasil19437004763",
    "display" : "Levofloxacino 500 mg comprimido"
  },
  {
    "code" : "@brasil12083885251",
    "display" : "Levofloxacino 500 mg/100 mL solução para injeção; bolsa"
  },
  {
    "code" : "@brasil19829996598",
    "display" : "Levofloxacino 500 mg/100 mL solução para injeção; frasco"
  },
  {
    "code" : "@brasil17903148667",
    "display" : "Levofloxacino 500 mg/20 mL solução para injeção; frasco"
  },
  {
    "code" : "@brasil11824986599",
    "display" : "Levofloxacino 750 mg comprimido"
  },
  {
    "code" : "@brasil14325664483",
    "display" : "Levomentol 28,2 mg/g + Cânfora 52,6 mg/g + Eucalipto 13,3 mg/g pomada"
  },
  {
    "code" : "@brasil18742007693",
    "display" : "Levomentol 415,4 mg/g + Cânfora 415,4 mg/g inalante"
  },
  {
    "code" : "@brasil15957835003",
    "display" : "Levomepromazina 100 mg comprimido"
  },
  {
    "code" : "@brasil12601062740",
    "display" : "Levomepromazina 25 mg comprimido"
  },
  {
    "code" : "@brasil17488708836",
    "display" : "Levomepromazina 25mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14561933887",
    "display" : "Levonorgestrel 0,05 mg + Etinilestradiol 0,03 mg comprimido e Levonorgestrel 0,075 mg + Etinilestradiol 0,04 mg comprimido e Levonorgestrel 0,125 mg + Etinilestradiol 0,03 mg comprimido"
  },
  {
    "code" : "@brasil19075716423",
    "display" : "Levonorgestrel 0,05 mg + Etinilestradiol 0,03 mg comprimido e Levonorgestrel 0,075 mg + Etinilestradiol 0,04 mg comprimido e Levonorgestrel 0,125 mg + Etinilestradiol 0,03 mg comprimido e Piridoxina 10 mg comprimido"
  },
  {
    "code" : "@brasil11445919573",
    "display" : "Levonorgestrel 0,1 mg + Etinilestradiol 0,02 mg comprimido"
  },
  {
    "code" : "@brasil16754349428",
    "display" : "Levonorgestrel 0,15 mg + Etinilestradiol 0,03 mg comprimido"
  },
  {
    "code" : "@brasil11804146087",
    "display" : "Levonorgestrel 0,15 mg + Etinilestradiol 0,03 mg comprimido e Etinilestradiol 0,01 mg comprimido"
  },
  {
    "code" : "@brasil17371218693",
    "display" : "Levonorgestrel 0,25 mg + Etinilestradiol 0,05 mg comprimido"
  },
  {
    "code" : "@brasil15469012552",
    "display" : "Levonorgestrel 0,25 mg + Etinilestradiol 0,05 mg comprimido vaginal"
  },
  {
    "code" : "@brasil11930120560",
    "display" : "Levonorgestrel 0,75 mg comprimido"
  },
  {
    "code" : "@brasil11183928772",
    "display" : "Levonorgestrel 1,5 mg comprimido"
  },
  {
    "code" : "@brasil17897249335",
    "display" : "Levonorgestrel 30 micrograma comprimido"
  },
  {
    "code" : "@brasil17827602155",
    "display" : "Levonorgestrel 52 mg (20 microgramas/24 horas) dispositivo intrauterino"
  },
  {
    "code" : "@brasil10724118938",
    "display" : "Levosimendana 12,5 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16916134306",
    "display" : "Levotiroxina Sódica 100 microgramas comprimido"
  },
  {
    "code" : "@brasil18661437571",
    "display" : "Levotiroxina Sódica 112 microgramas comprimido"
  },
  {
    "code" : "@brasil10375288081",
    "display" : "Levotiroxina Sódica 12,5 microgramas comprimido"
  },
  {
    "code" : "@brasil12626687578",
    "display" : "Levotiroxina Sódica 125 microgramas comprimido"
  },
  {
    "code" : "@brasil16276207849",
    "display" : "Levotiroxina Sódica 137 microgramas comprimido"
  },
  {
    "code" : "@brasil13743921157",
    "display" : "Levotiroxina Sódica 150 microgramas comprimido"
  },
  {
    "code" : "@brasil18546713810",
    "display" : "Levotiroxina Sódica 175 microgramas comprimido"
  },
  {
    "code" : "@brasil16396516090",
    "display" : "Levotiroxina Sódica 200 microgramas comprimido"
  },
  {
    "code" : "@brasil11326870378",
    "display" : "Levotiroxina Sódica 25 microgramas comprimido"
  },
  {
    "code" : "@brasil19051765303",
    "display" : "Levotiroxina Sódica 300 microgramas comprimido"
  },
  {
    "code" : "@brasil13509517313",
    "display" : "Levotiroxina Sódica 37,5 microgramas comprimido"
  },
  {
    "code" : "@brasil19714932513",
    "display" : "Levotiroxina Sódica 38 microgramas comprimido"
  },
  {
    "code" : "@brasil12524965471",
    "display" : "Levotiroxina Sódica 50 microgramas comprimido"
  },
  {
    "code" : "@brasil15148699128",
    "display" : "Levotiroxina Sódica 62,5 microgramas comprimido"
  },
  {
    "code" : "@brasil19253793393",
    "display" : "Levotiroxina Sódica 75 microgramas comprimido"
  },
  {
    "code" : "@brasil16971679669",
    "display" : "Levotiroxina Sódica 88 microgramas comprimido"
  },
  {
    "code" : "@brasil16445047058",
    "display" : "Lidocaína 100 mg/2 mL (5%) + Glicose 150 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14848228183",
    "display" : "Lidocaína 100 mg/5 mL (2%) solução para injeção; ampola"
  },
  {
    "code" : "@brasil11212690435",
    "display" : "Lidocaína 100 mg/mL (10%) solução spray"
  },
  {
    "code" : "@brasil17557734125",
    "display" : "Lidocaína 100 mg/mL solução"
  },
  {
    "code" : "@brasil16360951675",
    "display" : "Lidocaína 20 mg/g (2%) gel"
  },
  {
    "code" : "@brasil16493067634",
    "display" : "Lidocaína 20 mg/mL (2%) + Epinefrina 0,01 mg/mL (1:100.000) solução para injeção 1,8 mL; carpule"
  },
  {
    "code" : "@brasil17363764145",
    "display" : "Lidocaína 20 mg/mL (2%) + Epinefrina 0,02 mg/mL (1:50.000) solução para injeção 1,8 mL; carpule"
  },
  {
    "code" : "@brasil17129727662",
    "display" : "Lidocaína 20 mg/mL + Cloreto de Benzalcônio 1,3 mg/mL solução spray"
  },
  {
    "code" : "@brasil15163549262",
    "display" : "Lidocaína 200 mg/20 mL (1%) + Epinefrina 100 microgramas/20 mL (1:200.000) solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14662250534",
    "display" : "Lidocaína 200 mg/20 mL (1%) solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13076087843",
    "display" : "Lidocaína 21 mg/mL + Cloreto de Benzetônio 1,33 mg/mL solução spray"
  },
  {
    "code" : "@brasil17325446797",
    "display" : "Lidocaína 25 mg/g + Prilocaína 25 mg/g creme"
  },
  {
    "code" : "@brasil14359071462",
    "display" : "Lidocaína 36 mg/1,8 mL solução para injeção; frasco"
  },
  {
    "code" : "@brasil10025373966",
    "display" : "Lidocaína 40 mg/g creme"
  },
  {
    "code" : "@brasil13899898987",
    "display" : "Lidocaína 400 mg/20 mL (2%) + Epinefrina 100 microgramas/20 mL (1:200.000) solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11289355075",
    "display" : "Lidocaína 400 mg/20 mL (2%) solução para injeção; ampola"
  },
  {
    "code" : "@brasil19805702238",
    "display" : "Lidocaína 400 mg/20 mL (2%) solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13651311269",
    "display" : "Lidocaína 50 mg/5 mL (1%) solução para injeção; ampola"
  },
  {
    "code" : "@brasil10080074853",
    "display" : "Lidocaína 50 mg/g (5%) emplastro"
  },
  {
    "code" : "@brasil17368388963",
    "display" : "Lidocaína 50 mg/g + Acetato de Hidrocortisona 2,5 mg/g + Óxido de Zinco 180 mg/g + Subacetato de Alumínio 35 mg/g pomada retal"
  },
  {
    "code" : "@brasil15613688075",
    "display" : "Lidocaína 50 mg/g pomada"
  },
  {
    "code" : "@brasil17614397151",
    "display" : "Lidocaína 500 mg/50 mL solução para injeção; frasco"
  },
  {
    "code" : "@brasil13318372435",
    "display" : "Lidocaína 70 mg/g + Tetracaína 70 mg/g creme"
  },
  {
    "code" : "@brasil18881441845",
    "display" : "Limeciclina 150 mg cápsula"
  },
  {
    "code" : "@brasil19216007941",
    "display" : "Limeciclina 300 mg cápsula"
  },
  {
    "code" : "@brasil15192748292",
    "display" : "Linagliptina 2,5 mg + Metformina 1 g comprimido"
  },
  {
    "code" : "@brasil14844455908",
    "display" : "Linagliptina 2,5 mg + Metformina 500 mg comprimido"
  },
  {
    "code" : "@brasil19650212971",
    "display" : "Linagliptina 2,5 mg + Metformina 850 mg comprimido"
  },
  {
    "code" : "@brasil13415902771",
    "display" : "Linagliptina 5 mg comprimido"
  },
  {
    "code" : "@brasil12562431805",
    "display" : "Lincomicina 300 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10630901110",
    "display" : "Lincomicina 600 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10628622974",
    "display" : "Linestrenol 0,5 mg comprimido"
  },
  {
    "code" : "@brasil17620632514",
    "display" : "Linezolida 600 mg comprimido"
  },
  {
    "code" : "@brasil17983706906",
    "display" : "Linezolida 600 mg/300 mL solução para injeção; bolsa"
  },
  {
    "code" : "@brasil18897066718",
    "display" : "Linezolida 600 mg/300 mL solução para injeção; frasco"
  },
  {
    "code" : "@brasil15405100559",
    "display" : "Lipegfilgrastim 6 mg/ 0,6 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil17926146263",
    "display" : "Liraglutida 18 mg/3 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil11073005581",
    "display" : "Lisado bacteriano de Escherichia coli 6 mg cápsula"
  },
  {
    "code" : "@brasil14005220199",
    "display" : "Lisados bacterianos 1.100 microgramas/mL suspensão oral"
  },
  {
    "code" : "@brasil19101270313",
    "display" : "Lisados bacterianos 11 microgramas/mL suspensão oral"
  },
  {
    "code" : "@brasil16877156947",
    "display" : "Lisados bacterianos 110 microgramas/mL suspensão oral"
  },
  {
    "code" : "@brasil12698209165",
    "display" : "Lisados bacterianos 3 mg comprimido"
  },
  {
    "code" : "@brasil19666435138",
    "display" : "Lisados bacterianos 3,5 mg cápsula"
  },
  {
    "code" : "@brasil18754551966",
    "display" : "Lisados bacterianos 3,5 mg granulado"
  },
  {
    "code" : "@brasil14442077617",
    "display" : "Lisados bacterianos 7 mg cápsula"
  },
  {
    "code" : "@brasil14441574805",
    "display" : "Lisdexanfetamina 30 mg cápsula"
  },
  {
    "code" : "@brasil13214678086",
    "display" : "Lisdexanfetamina 50 mg cápsula"
  },
  {
    "code" : "@brasil11104713166",
    "display" : "Lisdexanfetamina 70 mg cápsula"
  },
  {
    "code" : "@brasil18563840115",
    "display" : "Lisina 500 mg cápsula"
  },
  {
    "code" : "@brasil19264013112",
    "display" : "Lisinopril 10 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil11173809701",
    "display" : "Lisinopril 10 mg comprimido"
  },
  {
    "code" : "@brasil17493464542",
    "display" : "Lisinopril 20 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil15479572595",
    "display" : "Lisinopril 20 mg comprimido"
  },
  {
    "code" : "@brasil17498283149",
    "display" : "Lisinopril 30 mg comprimido"
  },
  {
    "code" : "@brasil10129825406",
    "display" : "Lisinopril 5 mg comprimido"
  },
  {
    "code" : "@brasil14852710089",
    "display" : "Lixisenatida 0,15 mg/3 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil14210874133",
    "display" : "Lixisenatida 0,15 mg/3 mL solução para injeção; dispositivo para injeção e Lixisenatida 0,3 mg/3 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil15130125436",
    "display" : "Lixisenatida 0,3 mg/3 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil15171177064",
    "display" : "Lomustina 10 mg cápsula"
  },
  {
    "code" : "@brasil10164365283",
    "display" : "Lomustina 40 mg cápsula"
  },
  {
    "code" : "@brasil10874089793",
    "display" : "Loperamida 2 mg comprimido"
  },
  {
    "code" : "@brasil10454274713",
    "display" : "Lopinavir 100 mg + Ritonavir 25 mg comprimido"
  },
  {
    "code" : "@brasil10959988375",
    "display" : "Lopinavir 133,3 mg + Ritonavir 33,3 mg cápsula"
  },
  {
    "code" : "@brasil14018450446",
    "display" : "Lopinavir 200 mg + Ritonavir 50 mg comprimido"
  },
  {
    "code" : "@brasil11877243910",
    "display" : "Lopinavir 80 mg/mL + Ritonavir 20 mg/mL solução oral"
  },
  {
    "code" : "@brasil19815917916",
    "display" : "Loratadina 1 mg/mL + Pseudoefedrina 12 mg/mL xarope"
  },
  {
    "code" : "@brasil11990682744",
    "display" : "Loratadina 1 mg/mL xarope"
  },
  {
    "code" : "@brasil14170758009",
    "display" : "Loratadina 10 mg + Pseudoefedrina 240 mg comprimido"
  },
  {
    "code" : "@brasil13385608039",
    "display" : "Loratadina 10 mg comprimido"
  },
  {
    "code" : "@brasil19118257935",
    "display" : "Loratadina 5 mg + Pseudoefedrina 120 mg comprimido"
  },
  {
    "code" : "@brasil10085657889",
    "display" : "Lorazepam 1 mg comprimido"
  },
  {
    "code" : "@brasil10316813494",
    "display" : "Lorazepam 2 mg comprimido"
  },
  {
    "code" : "@brasil16515050702",
    "display" : "Lorcasserina 10 mg comprimido"
  },
  {
    "code" : "@brasil10368965546",
    "display" : "Lornoxicam 8 mg comprimido"
  },
  {
    "code" : "@brasil15100873833",
    "display" : "Losartana 100 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "@brasil11824115738",
    "display" : "Losartana 100 mg comprimido"
  },
  {
    "code" : "@brasil17154959137",
    "display" : "Losartana 25 mg comprimido"
  },
  {
    "code" : "@brasil10750551586",
    "display" : "Losartana 50 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil19326544354",
    "display" : "Losartana 50 mg comprimido"
  },
  {
    "code" : "@brasil17925196174",
    "display" : "Loteprednol 2 mg/mL suspensão oftálmica"
  },
  {
    "code" : "@brasil16005699191",
    "display" : "Loteprednol 5 mg/mL + Tobramicina 3 mg/mL suspensão oftálmica"
  },
  {
    "code" : "@brasil19490174779",
    "display" : "Loteprednol 5 mg/mL suspensão oftálmica"
  },
  {
    "code" : "@brasil19068983725",
    "display" : "Lovastatina 10 mg comprimido"
  },
  {
    "code" : "@brasil14032655593",
    "display" : "Lovastatina 20 mg comprimido"
  },
  {
    "code" : "@brasil18698607372",
    "display" : "Lovastatina 40 mg comprimido"
  },
  {
    "code" : "@brasil10847791554",
    "display" : "Loxoprofeno 60 mg comprimido"
  },
  {
    "code" : "@brasil12822337962",
    "display" : "Macitentana 10 mg comprimido"
  },
  {
    "code" : "@brasil16123847816",
    "display" : "Macrogol (4000) 10 g granulado"
  },
  {
    "code" : "@brasil15495916114",
    "display" : "Macrogol 13,12 g + Bicarbonato de Sódio 0,17 g + Cloreto de Sódio 0,35 g + Cloreto de Potássio 0,04 g pó para solução oral"
  },
  {
    "code" : "@brasil12218819224",
    "display" : "Magaldrato 80 mg/mL + Simeticona 10 mg/mL solução oral"
  },
  {
    "code" : "@brasil16180555684",
    "display" : "Magaldrato 80 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil12361561927",
    "display" : "Magaldrato 800 mg + Dimeticona 100 mg comprimido mastigável"
  },
  {
    "code" : "@brasil17520840694",
    "display" : "Maleato de Levomepromazina 40 mg/mL solução oral"
  },
  {
    "code" : "@brasil17407799582",
    "display" : "Maleato de Midazolam 15 mg/3 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15443349195",
    "display" : "Maleato de Midazolam 50 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17512489637",
    "display" : "Manitol 100 g/500 mL (20%) solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15608509801",
    "display" : "Manitol 3% solução para irrigação 3 L; bolsa"
  },
  {
    "code" : "@brasil19372074517",
    "display" : "Manitol 50 g/ 250 mL (20%) solução para injeção; bolsa"
  },
  {
    "code" : "@brasil14116042892",
    "display" : "Manitol 50 g/ 250 mL (20%) solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12143078335",
    "display" : "Maprotilina 25 mg comprimido"
  },
  {
    "code" : "@brasil10584737760",
    "display" : "Maprotilina 75 mg comprimido"
  },
  {
    "code" : "@brasil15278801856",
    "display" : "Maraviroque 150 mg comprimido"
  },
  {
    "code" : "@brasil14567922757",
    "display" : "Maraviroque 300 mg comprimido"
  },
  {
    "code" : "@brasil18352618418",
    "display" : "Mebendazol 100 mg + Tiabendazol 166 mg comprimido"
  },
  {
    "code" : "@brasil17762751873",
    "display" : "Mebendazol 100 mg comprimido"
  },
  {
    "code" : "@brasil10213103135",
    "display" : "Mebendazol 20 mg/mL + Tiabendazol 33,2 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil11078696912",
    "display" : "Mebendazol 20 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil15396043056",
    "display" : "Mebendazol 200 mg + Tiabendazol 332 mg comprimido"
  },
  {
    "code" : "@brasil13468667270",
    "display" : "Mebendazol 200 mg + Tiabendazol 332 mg comprimido mastigável"
  },
  {
    "code" : "@brasil17640298489",
    "display" : "Mebendazol 500 mg comprimido"
  },
  {
    "code" : "@brasil13123261175",
    "display" : "Mebeverina 200 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil16406308398",
    "display" : "Meclozina 25 mg comprimido"
  },
  {
    "code" : "@brasil11528483582",
    "display" : "Meclozina 50 mg comprimido"
  },
  {
    "code" : "@brasil10756434592",
    "display" : "Medroxiprogesterona 10 mg comprimido"
  },
  {
    "code" : "@brasil15273749496",
    "display" : "Medroxiprogesterona 150 mg/1 mL suspensão para injeção; ampola"
  },
  {
    "code" : "@brasil18698881544",
    "display" : "Medroxiprogesterona 150 mg/1 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12496675021",
    "display" : "Medroxiprogesterona 150 mg/1 mL suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil11310539497",
    "display" : "Medroxiprogesterona 2,5 mg comprimido"
  },
  {
    "code" : "@brasil17396534136",
    "display" : "Medroxiprogesterona 25 mg/0,5 mL + Estradiol 5 mg/0,5 mL suspensão para injeção; ampola"
  },
  {
    "code" : "@brasil12885681159",
    "display" : "Medroxiprogesterona 25 mg/1 mL + Estradiol 5 mg/1 mL suspensão para injeção; ampola"
  },
  {
    "code" : "@brasil13716905193",
    "display" : "Medroxiprogesterona 5 mg comprimido"
  },
  {
    "code" : "@brasil18586595809",
    "display" : "Medroxiprogesterona 50 mg/1 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11973166010",
    "display" : "Mefloquina 250 mg comprimido"
  },
  {
    "code" : "@brasil11220753323",
    "display" : "Megestrol 160 mg comprimido"
  },
  {
    "code" : "@brasil11746247252",
    "display" : "Melfalana 2 mg comprimido"
  },
  {
    "code" : "@brasil15886739049",
    "display" : "Melfalana 50 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14018504947",
    "display" : "Meloxicam 15 mg comprimido"
  },
  {
    "code" : "@brasil16198100265",
    "display" : "Meloxicam 15 mg/1,5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10585920866",
    "display" : "Meloxicam 7,5 mg comprimido"
  },
  {
    "code" : "@brasil10660026780",
    "display" : "Memantina 10 mg comprimido"
  },
  {
    "code" : "@brasil16685269451",
    "display" : "Memantina 20 mg comprimido"
  },
  {
    "code" : "@brasil19702468186",
    "display" : "Menotropina 1.200 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19146894269",
    "display" : "Menotropina 600 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19752320244",
    "display" : "Menotropina 75 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19048744195",
    "display" : "Menotropina 75 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17735029669",
    "display" : "Mentol 150 mg/g + Cânfora 100 mg/g  + Salicilato de Metila 80 mg/g + Óleo de Eucalipto 50 mg/g pomada"
  },
  {
    "code" : "@brasil14807924575",
    "display" : "Mentol 28,2 mg/g + Cânfora 52,6 mg/g + Óleo de Eucalipto 13,3 mg/g pomada"
  },
  {
    "code" : "@brasil10776652078",
    "display" : "Mepartricina 5.000 unidades internacionais/g + Tetraciclina 20 mg/g creme vaginal"
  },
  {
    "code" : "@brasil13739024281",
    "display" : "Mepiramina 15 mg + Hidróxido de Alumínio 150 mg + Ácido Acetilsalicílico 150 mg + Cafeína 50 mg comprimido"
  },
  {
    "code" : "@brasil14753141694",
    "display" : "Mepivacaína 36 mg/1,8 mL + Norepinefrina 18 microgramas/1,8 mL (1:100.000) solução para injeção; carpule"
  },
  {
    "code" : "@brasil15862758675",
    "display" : "Mepivacaína 54 mg/1,8 mL solução para injeção; carpule"
  },
  {
    "code" : "@brasil18205079069",
    "display" : "Mercaptamina 150 mg comprimido"
  },
  {
    "code" : "@brasil14486296347",
    "display" : "Mercaptamina 5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil18970562095",
    "display" : "Mercaptamina 50 mg comprimido"
  },
  {
    "code" : "@brasil16824286333",
    "display" : "Mercaptopurina 50 mg comprimido"
  },
  {
    "code" : "@brasil11320918724",
    "display" : "Meropeném 1 g pó e diluente para solução para injeção; frasco-ampola + bolsa"
  },
  {
    "code" : "@brasil17126190434",
    "display" : "Meropeném 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12775410098",
    "display" : "Meropeném 2 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14534570093",
    "display" : "Meropeném 500 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10316640175",
    "display" : "Meropeném 500 mg pó e diluente para solução para injeção; frasco-ampola + bolsa"
  },
  {
    "code" : "@brasil14372985505",
    "display" : "Meropeném 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18153018901",
    "display" : "Mesalazina 1 g comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil16582990451",
    "display" : "Mesalazina 1 g granulado de liberação prolongada"
  },
  {
    "code" : "@brasil14447154451",
    "display" : "Mesalazina 1 g supositório"
  },
  {
    "code" : "@brasil11944788471",
    "display" : "Mesalazina 1,2 g comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil19612662482",
    "display" : "Mesalazina 10 mg/mL suspensão retal"
  },
  {
    "code" : "@brasil10391643540",
    "display" : "Mesalazina 2 g granulado de liberação prolongada"
  },
  {
    "code" : "@brasil15349649073",
    "display" : "Mesalazina 250 mg supositório"
  },
  {
    "code" : "@brasil16686204303",
    "display" : "Mesalazina 30 mg/mL suspensão retal"
  },
  {
    "code" : "@brasil18686916731",
    "display" : "Mesalazina 400 mg comprimido"
  },
  {
    "code" : "@brasil10674244081",
    "display" : "Mesalazina 500 mg comprimido"
  },
  {
    "code" : "@brasil14180288587",
    "display" : "Mesalazina 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil16710940808",
    "display" : "Mesalazina 500 mg supositório"
  },
  {
    "code" : "@brasil10716691985",
    "display" : "Mesalazina 800 mg comprimido"
  },
  {
    "code" : "@brasil16163806211",
    "display" : "Mesilato de Codergocrina 0,3 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12057450153",
    "display" : "Mesilato de Codergocrina 1 mg cápsula"
  },
  {
    "code" : "@brasil16318312412",
    "display" : "Mesilato de Codergocrina 1 mg/mL solução oral"
  },
  {
    "code" : "@brasil18652716471",
    "display" : "Mesilato de Codergocrina 3 mg/1 mL solução oral"
  },
  {
    "code" : "@brasil13721202092",
    "display" : "Mesilato de Codergocrina 4,5 mg comprimido"
  },
  {
    "code" : "@brasil14508778455",
    "display" : "Mesilato de Codergocrina 6 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil10417635654",
    "display" : "Mesilato de Pralidoxima 200 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10867298105",
    "display" : "Mesna 400 mg comprimido"
  },
  {
    "code" : "@brasil11416441006",
    "display" : "Mesna 400 mg/4 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11079312041",
    "display" : "Mesna 600 mg comprimido"
  },
  {
    "code" : "@brasil10459640137",
    "display" : "Mesterolona 25 mg comprimido"
  },
  {
    "code" : "@brasil19284265532",
    "display" : "Metadona 10 mg comprimido"
  },
  {
    "code" : "@brasil13553289959",
    "display" : "Metadona 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12910229071",
    "display" : "Metadona 5 mg comprimido"
  },
  {
    "code" : "@brasil14197983101",
    "display" : "Metaraminol 10 mg/ 1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19461141459",
    "display" : "Metaraminol 100 mg/ 10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11777417958",
    "display" : "Metenamina 120 mg + Cloreto de Metiltionínio 20 mg comprimido"
  },
  {
    "code" : "@brasil19130784670",
    "display" : "Metformina 1 g comprimido"
  },
  {
    "code" : "@brasil10898224124",
    "display" : "Metformina 1 g comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil13533526837",
    "display" : "Metformina 500 mg comprimido"
  },
  {
    "code" : "@brasil16267847739",
    "display" : "Metformina 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil13092348213",
    "display" : "Metformina 750 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil14959950655",
    "display" : "Metformina 850 mg comprimido"
  },
  {
    "code" : "@brasil16191257112",
    "display" : "Metformina 850 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil17334212488",
    "display" : "Metilcelulose 2% solução oftálmica"
  },
  {
    "code" : "@brasil15277392541",
    "display" : "Metilcelulose 30 mg/1,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil16487635741",
    "display" : "Metildopa 250 mg comprimido"
  },
  {
    "code" : "@brasil13282176276",
    "display" : "Metildopa 500 mg comprimido"
  },
  {
    "code" : "@brasil19236507729",
    "display" : "Metilergometrina 0,125 mg comprimido"
  },
  {
    "code" : "@brasil17217885940",
    "display" : "Metilergometrina 0,2 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14738524177",
    "display" : "Metilfenidato 10 mg cápsula de liberação modificada"
  },
  {
    "code" : "@brasil14798486030",
    "display" : "Metilfenidato 10 mg comprimido"
  },
  {
    "code" : "@brasil12343989183",
    "display" : "Metilfenidato 18 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil10781617872",
    "display" : "Metilfenidato 20 mg cápsula de liberação modificada"
  },
  {
    "code" : "@brasil12430982460",
    "display" : "Metilfenidato 30 mg cápsula de liberação modificada"
  },
  {
    "code" : "@brasil17281338624",
    "display" : "Metilfenidato 36 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil10516016818",
    "display" : "Metilfenidato 40 mg cápsula de liberação modificada"
  },
  {
    "code" : "@brasil19619501612",
    "display" : "Metilfenidato 54 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil10304769975",
    "display" : "Metipranolol 3 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil10009615485",
    "display" : "Metoclopramida 1 mg/mL solução oral"
  },
  {
    "code" : "@brasil15017155970",
    "display" : "Metoclopramida 10 mg comprimido"
  },
  {
    "code" : "@brasil19372704250",
    "display" : "Metoclopramida 10 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11647178018",
    "display" : "Metoclopramida 4 mg/mL solução oral"
  },
  {
    "code" : "@brasil12783943313",
    "display" : "Metoclopramida 5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14476434199",
    "display" : "Metoclopramida 7 mg + Simeticona 40 mg + Pepsina 50 mg cápsula"
  },
  {
    "code" : "@brasil17238485808",
    "display" : "Metoprolol 100 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil19175888027",
    "display" : "Metoprolol 100 mg + Hidroclorotiazida 12,5 mg comprimido de liberação pronlongada"
  },
  {
    "code" : "@brasil15916774658",
    "display" : "Metoprolol 100 mg comprimido"
  },
  {
    "code" : "@brasil17533758949",
    "display" : "Metoprolol 100 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil18631941421",
    "display" : "Metoprolol 25 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil16272249328",
    "display" : "Metoprolol 5 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11814320562",
    "display" : "Metoprolol 5 mg/5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil16896328893",
    "display" : "Metoprolol 50 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil10844526132",
    "display" : "Metotrexato 1 g/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13972132990",
    "display" : "Metotrexato 2,5 mg comprimido"
  },
  {
    "code" : "@brasil11067308401",
    "display" : "Metotrexato 5 g/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12971913005",
    "display" : "Metotrexato 50 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19176010421",
    "display" : "Metotrexato 50 mg/2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14395723783",
    "display" : "Metotrexato 500 mg/20 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12678127215",
    "display" : "Metotrexato 500 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14785737090",
    "display" : "Metoxisaleno 1 mg/g (0,1%) creme"
  },
  {
    "code" : "@brasil19149137201",
    "display" : "Metoxisaleno 10 mg cápsula"
  },
  {
    "code" : "@brasil17665987411",
    "display" : "Metoxisaleno 2 mg/g (0,2%) creme"
  },
  {
    "code" : "@brasil15862605119",
    "display" : "Metronidazol 1,5 g/300 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10038598113",
    "display" : "Metronidazol 100 mg/g + Nistatina 20.000 unidades internacionais/g creme vaginal"
  },
  {
    "code" : "@brasil15831535648",
    "display" : "Metronidazol 100 mg/g creme vaginal"
  },
  {
    "code" : "@brasil19099400497",
    "display" : "Metronidazol 100 mg/g gel vaginal"
  },
  {
    "code" : "@brasil19100340611",
    "display" : "Metronidazol 125 mg/g creme vaginal"
  },
  {
    "code" : "@brasil17561717141",
    "display" : "Metronidazol 250 mg comprimido"
  },
  {
    "code" : "@brasil17595073995",
    "display" : "Metronidazol 250 mg/g + Nistatina 100.000 unidades internacionais/g + Cloreto de Benzalcônio 1,25 mg/g creme vaginal"
  },
  {
    "code" : "@brasil10074988295",
    "display" : "Metronidazol 400 mg comprimido"
  },
  {
    "code" : "@brasil12300452488",
    "display" : "Metronidazol 500 mg/100 mL solução para injeção; bolsa"
  },
  {
    "code" : "@brasil18246245799",
    "display" : "Metronidazol 500 mg/100 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16223043552",
    "display" : "Metronidazol 62,5 mg/g + Nistatina 25.000 unidades internacionais/g + Cloreto de Benzalcônio 1,25 mg/g + Lisozima 2,5 mg/g creme vaginal"
  },
  {
    "code" : "@brasil17846140596",
    "display" : "Metronidazol 7,5 mg/g (0,75%) gel"
  },
  {
    "code" : "@brasil11012721508",
    "display" : "Metronidazol 750 mg + Miconazol 200 mg óvulo"
  },
  {
    "code" : "@brasil11278644260",
    "display" : "Micafungina 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18805406248",
    "display" : "Micafungina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18901722363",
    "display" : "Micofenolato de Mofetila 500 mg comprimido"
  },
  {
    "code" : "@brasil13342778963",
    "display" : "Micofenolato de Sódio 180 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil11057596308",
    "display" : "Micofenolato de Sódio 360 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil18732750235",
    "display" : "Miconazol 20 mg/g (2%) loção"
  },
  {
    "code" : "@brasil16143021271",
    "display" : "Miconazol 20 mg/g creme"
  },
  {
    "code" : "@brasil12610232058",
    "display" : "Miconazol 20 mg/g creme vaginal"
  },
  {
    "code" : "@brasil18302138490",
    "display" : "Miconazol 20 mg/g gel"
  },
  {
    "code" : "@brasil15257178827",
    "display" : "Miconazol 20 mg/g pó"
  },
  {
    "code" : "@brasil14995701670",
    "display" : "Miconazol 20 mg/g solução aerossol"
  },
  {
    "code" : "@brasil10458022346",
    "display" : "Miconazol 20 mg/mL (2%) loção"
  },
  {
    "code" : "@brasil13956177767",
    "display" : "Miconazol 20 mg/mL (2%) solução"
  },
  {
    "code" : "@brasil12022661967",
    "display" : "Miconazol 20 mg/ml suspensão spray"
  },
  {
    "code" : "@brasil10915823606",
    "display" : "Midazolam 15 mg comprimido"
  },
  {
    "code" : "@brasil15725159239",
    "display" : "Midazolam 15 mg/3 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19274468614",
    "display" : "Midazolam 2 mg/mL solução oral"
  },
  {
    "code" : "@brasil16741793402",
    "display" : "Midazolam 25 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17596520479",
    "display" : "Midazolam 5 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15113173204",
    "display" : "Midazolam 50 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19786431219",
    "display" : "Midazolam 7,5 mg comprimido"
  },
  {
    "code" : "@brasil16419171704",
    "display" : "Midodrina 10 mg comprimido"
  },
  {
    "code" : "@brasil15970786655",
    "display" : "Midodrina 2,5 mg comprimido"
  },
  {
    "code" : "@brasil16716952710",
    "display" : "Midodrina 5 mg comprimido"
  },
  {
    "code" : "@brasil10467653301",
    "display" : "Mifamurtida 4 mg pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10509892226",
    "display" : "Miglustate 100 mg cápsula"
  },
  {
    "code" : "@brasil19717443564",
    "display" : "Milrinona 10 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18300628574",
    "display" : "Minociclina 100 mg cápsula"
  },
  {
    "code" : "@brasil13383530771",
    "display" : "Minociclina 100 mg comprimido"
  },
  {
    "code" : "@brasil14171586160",
    "display" : "Minoxidil 10 mg comprimido"
  },
  {
    "code" : "@brasil13399679662",
    "display" : "Minoxidil 50 mg/mL solução spray"
  },
  {
    "code" : "@brasil14445690552",
    "display" : "Mirabegrona 25 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil16916315439",
    "display" : "Mirabegrona 50 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil14458692141",
    "display" : "Mirtazapina 15 mg comprimido orodispersível"
  },
  {
    "code" : "@brasil15674424938",
    "display" : "Mirtazapina 15 mg comprimido para suspensão"
  },
  {
    "code" : "@brasil18808362881",
    "display" : "Mirtazapina 30 mg comprimido"
  },
  {
    "code" : "@brasil13419905129",
    "display" : "Mirtazapina 30 mg comprimido orodispersível"
  },
  {
    "code" : "@brasil19814622092",
    "display" : "Mirtazapina 45 mg comprimido"
  },
  {
    "code" : "@brasil13207738606",
    "display" : "Mirtazapina 45 mg comprimido orodispersível"
  },
  {
    "code" : "@brasil13419196858",
    "display" : "Mirtazapina 60 mg cápsula"
  },
  {
    "code" : "@brasil13070090656",
    "display" : "Misoprostol 100 microgramas comprimido"
  },
  {
    "code" : "@brasil16269551547",
    "display" : "Misoprostol 200 microgramas comprimido vaginal"
  },
  {
    "code" : "@brasil11837521149",
    "display" : "Misoprostol 25 microgramas comprimido"
  },
  {
    "code" : "@brasil12772409311",
    "display" : "Mitomicina 5 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10510108814",
    "display" : "Mitotano 500 mg comprimido"
  },
  {
    "code" : "@brasil14539275442",
    "display" : "Mitoxantrona 20 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13174907529",
    "display" : "Moclobemida 150 mg comprimido"
  },
  {
    "code" : "@brasil17822083948",
    "display" : "Moclobemida 300 mg comprimido"
  },
  {
    "code" : "@brasil13467701824",
    "display" : "Modafinila 100 mg comprimido"
  },
  {
    "code" : "@brasil11295358110",
    "display" : "Modafinila 200 mg comprimido"
  },
  {
    "code" : "@brasil13981528936",
    "display" : "Molgramostim 300 microgramas pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15813742125",
    "display" : "Mometasona 1 mg/g (0,1%) creme"
  },
  {
    "code" : "@brasil15415661403",
    "display" : "Mometasona 1 mg/g + Ácido Fusídico 20 mg/g creme"
  },
  {
    "code" : "@brasil16565070613",
    "display" : "Mometasona 1 mg/g pomada"
  },
  {
    "code" : "@brasil19312268902",
    "display" : "Mometasona 100 microgramas + Formoterol 50 microgramas pó para inalação oral"
  },
  {
    "code" : "@brasil11045916611",
    "display" : "Mometasona 200 microgramas cápsula para inalação"
  },
  {
    "code" : "@brasil11531316731",
    "display" : "Mometasona 200 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "@brasil17077261409",
    "display" : "Mometasona 200 microgramas/dose + Formoterol 5 microgramas/dose suspensão aerossol"
  },
  {
    "code" : "@brasil19791069782",
    "display" : "Mometasona 400 microgramas cápsula para inalação"
  },
  {
    "code" : "@brasil19681771171",
    "display" : "Mometasona 400 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "@brasil17569181710",
    "display" : "Mometasona 50 microgramas/dose suspensão spray"
  },
  {
    "code" : "@brasil18174882527",
    "display" : "Mononitrato de Isossorbida 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17769634943",
    "display" : "Mononitrato de Isossorbida 20 mg comprimido"
  },
  {
    "code" : "@brasil18375113370",
    "display" : "Mononitrato de Isossorbida 40 mg comprimido"
  },
  {
    "code" : "@brasil11445843046",
    "display" : "Mononitrato de Isossorbida 5 mg comprimido sublingual"
  },
  {
    "code" : "@brasil13012410925",
    "display" : "Mononitrato de Isossorbida 50 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil16702942293",
    "display" : "Monossialogangliosídeo 100 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19768048718",
    "display" : "Monossulfiram 250 mg/mL solução"
  },
  {
    "code" : "@brasil10126116582",
    "display" : "Montelucaste 10 mg + Levocetirizina 5 mg comprimido"
  },
  {
    "code" : "@brasil14592678372",
    "display" : "Montelucaste 10 mg comprimido"
  },
  {
    "code" : "@brasil10044228638",
    "display" : "Montelucaste 4 mg comprimido mastigável"
  },
  {
    "code" : "@brasil18980545761",
    "display" : "Montelucaste 4 mg granulado"
  },
  {
    "code" : "@brasil17386009986",
    "display" : "Montelucaste 5 mg comprimido mastigável"
  },
  {
    "code" : "@brasil11231727646",
    "display" : "Morfina 10 mg comprimido"
  },
  {
    "code" : "@brasil19218824661",
    "display" : "Morfina 100 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil14030657934",
    "display" : "Morfina 100 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil18045973029",
    "display" : "Morfina 30 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil13863787168",
    "display" : "Morfina 30 mg comprimido"
  },
  {
    "code" : "@brasil17720572544",
    "display" : "Morfina 30 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil19904068380",
    "display" : "Morfina 60 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil18715335407",
    "display" : "Morfina 60 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil15846343118",
    "display" : "Moxifloxacino 400 mg comprimido"
  },
  {
    "code" : "@brasil16386555540",
    "display" : "Moxifloxacino 400 mg/250 mL solução para injeção; bolsa"
  },
  {
    "code" : "@brasil18952747934",
    "display" : "Moxifloxacino 400 mg/250 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12771413038",
    "display" : "Moxifloxacino 5 mg/mL + Dexametasona 1 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil14341111912",
    "display" : "Moxifloxacino 5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil13574142271",
    "display" : "Mucopolissacaridase 0,625 mg + Alfamilase Bacteriana 31,25 mg + Alfaquimotripsina 0,375 mg comprimido"
  },
  {
    "code" : "@brasil16555166072",
    "display" : "Mucopolissacaridase 3,375 mg (135 TRU)/g creme"
  },
  {
    "code" : "@brasil18314821819",
    "display" : "Mupirocina 20 mg/g creme"
  },
  {
    "code" : "@brasil15534479174",
    "display" : "Mupirocina 20 mg/g pomada"
  },
  {
    "code" : "@brasil14649789997",
    "display" : "Nadroparina cálcica 2.850 unidades internacionais/0,3 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil15146107462",
    "display" : "Nadroparina cálcica 5.700 unidades internacionais/0,6 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil15013998088",
    "display" : "Nafazolina 0,12 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil17748261658",
    "display" : "Nafazolina 0,15 mg/mL + Sulfato de Zinco 0,3 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil13909841536",
    "display" : "Nafazolina 0,25 mg/mL + Feniramina 3 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil17928705444",
    "display" : "Nafazolina 0,5 mg/mL + Cloreto de Benzalcônio 0,1 mg/mL solução nasal"
  },
  {
    "code" : "@brasil11935047126",
    "display" : "Nafazolina 0,5 mg/mL + Mepiramina 0,2 mg/mL + Dexpantenol 5 mg/mL solução nasal"
  },
  {
    "code" : "@brasil15890208719",
    "display" : "Nafazolina 0,5 mg/mL + Sulfato de Zinco 4 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil17185537242",
    "display" : "Nafazolina 0,5 mg/mL + Zinco 1 mg/mL + Berberina 0,025 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil17826998677",
    "display" : "Nafazolina 0,5 mg/mL + Zinco 1 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil17595155235",
    "display" : "Nafazolina 0,5 mg/mL solução nasal"
  },
  {
    "code" : "@brasil15162292228",
    "display" : "Nafazolina 0,75 mg/mL + Dexametasona 0,5 mg/mL + Neomicina 5 mg/mL solução spray"
  },
  {
    "code" : "@brasil14757145832",
    "display" : "Nafazolina 1 mg/mL + Mepiramina 0,2 mg/mL + Dexpantenol 5 mg/mL solução nasal"
  },
  {
    "code" : "@brasil16324426191",
    "display" : "Nafazolina 1 mg/mL solução nasal"
  },
  {
    "code" : "@brasil11210590852",
    "display" : "Nalbufina 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19309307976",
    "display" : "Nalbufina 20 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16256082732",
    "display" : "Naloxona 0,4 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12251961166",
    "display" : "Naltrexona 50 mg comprimido"
  },
  {
    "code" : "@brasil13543645825",
    "display" : "Nandrolona 25 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15351175985",
    "display" : "Nandrolona 50 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15216694719",
    "display" : "Naproxeno 250 mg comprimido"
  },
  {
    "code" : "@brasil16960442806",
    "display" : "Naproxeno 500 mg + Esomeprazol 20 mg comprimido de liberação modificada"
  },
  {
    "code" : "@brasil11270818412",
    "display" : "Naproxeno 500 mg comprimido"
  },
  {
    "code" : "@brasil16683306158",
    "display" : "Naproxeno Sódico 275 mg comprimido"
  },
  {
    "code" : "@brasil16887771622",
    "display" : "Naproxeno Sódico 550 mg comprimido"
  },
  {
    "code" : "@brasil10695248646",
    "display" : "Naratriptana 2,5 mg comprimido"
  },
  {
    "code" : "@brasil11204855348",
    "display" : "Natalizumabe 300 mg/15 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12123081191",
    "display" : "Natalizumabe 300 mg/15 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14816956225",
    "display" : "Nateglinida 120 mg comprimido"
  },
  {
    "code" : "@brasil10863391635",
    "display" : "Nateglinida 120 mg comprimido e Metformina 500 mg comprimido"
  },
  {
    "code" : "@brasil12727869890",
    "display" : "Nateglinida 120 mg comprimido e Metformina 850 mg comprimido"
  },
  {
    "code" : "@brasil14830754849",
    "display" : "Nebivolol 5 mg comprimido"
  },
  {
    "code" : "@brasil10287260095",
    "display" : "Nelfinavir 250 mg comprimido"
  },
  {
    "code" : "@brasil17769264696",
    "display" : "Nelfinavir 50 mg/g pó para solução oral"
  },
  {
    "code" : "@brasil15123445124",
    "display" : "Neomicina 15 mg/mL + Tartarato de Bismuto e Sódio 25 mg/mL + Mentol 1 mg/mL + Cloridrato de Procaína 15 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil18434490940",
    "display" : "Neomicina 3,5 mg/g pomada"
  },
  {
    "code" : "@brasil10884830094",
    "display" : "Neomicina 5 mg/g + Bacitracina 250 unidades internacionais/g pomada"
  },
  {
    "code" : "@brasil10700768446",
    "display" : "Neomicina 5 mg/g pomada"
  },
  {
    "code" : "@brasil15351132400",
    "display" : "Neomicina 8.750 unidades internacionais/g + Polimixina B 8.750 unidades internacionais/g + Nistatina 25.000 unidades internacionais/g + Tinidazol 37,5 mg/g creme vaginal"
  },
  {
    "code" : "@brasil17398960595",
    "display" : "Neostigmina 0,5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16359125994",
    "display" : "Nepafenaco 1 mg/mL suspensão oftálmica"
  },
  {
    "code" : "@brasil15970047874",
    "display" : "Nepafenaco 3 mg/mL suspensão oftálmica"
  },
  {
    "code" : "@brasil18577315887",
    "display" : "Nevirapina 10 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil18431738891",
    "display" : "Nevirapina 200 mg comprimido"
  },
  {
    "code" : "@brasil16418362012",
    "display" : "Nicergolina 30 mg comprimido"
  },
  {
    "code" : "@brasil11068742796",
    "display" : "Nicotina 14 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "@brasil15230091347",
    "display" : "Nicotina 2 mg goma de mascar"
  },
  {
    "code" : "@brasil14281666029",
    "display" : "Nicotina 2 mg pastilha"
  },
  {
    "code" : "@brasil17958849702",
    "display" : "Nicotina 21 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "@brasil16986894351",
    "display" : "Nicotina 4 mg goma de mascar"
  },
  {
    "code" : "@brasil15924356090",
    "display" : "Nicotina 4 mg pastilha"
  },
  {
    "code" : "@brasil13827938504",
    "display" : "Nicotina 7 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "@brasil19205753334",
    "display" : "Nifedipino 10 mg + Atenolol 25 mg cápsula de liberação modificada"
  },
  {
    "code" : "@brasil15316558241",
    "display" : "Nifedipino 10 mg cápsula"
  },
  {
    "code" : "@brasil11913066153",
    "display" : "Nifedipino 10 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil10016574812",
    "display" : "Nifedipino 10 mg comprimido de liberação retardada"
  },
  {
    "code" : "@brasil15947419818",
    "display" : "Nifedipino 20 mg + Atenolol 50 mg cápsula de liberação modificada"
  },
  {
    "code" : "@brasil13028207813",
    "display" : "Nifedipino 20 mg + Atenolol 50 mg comprimido"
  },
  {
    "code" : "@brasil16038990099",
    "display" : "Nifedipino 20 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil10709404404",
    "display" : "Nifedipino 20 mg comprimido"
  },
  {
    "code" : "@brasil17321605119",
    "display" : "Nifedipino 20 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil10858505489",
    "display" : "Nifedipino 30 mg comprimido"
  },
  {
    "code" : "@brasil10149199319",
    "display" : "Nifedipino 30 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil15020636910",
    "display" : "Nifedipino 40 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil16920245043",
    "display" : "Nifedipino 60 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil10978928943",
    "display" : "Nilotinibe 150 mg cápsula"
  },
  {
    "code" : "@brasil18588643676",
    "display" : "Nilotinibe 200 mg cápsula"
  },
  {
    "code" : "@brasil13260732453",
    "display" : "Nimesulida 10 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil16038827341",
    "display" : "Nimesulida 100 mg comprimido"
  },
  {
    "code" : "@brasil19964295223",
    "display" : "Nimesulida 100 mg comprimido para suspensão"
  },
  {
    "code" : "@brasil16368686058",
    "display" : "Nimesulida 100 mg supositório"
  },
  {
    "code" : "@brasil15486927967",
    "display" : "Nimesulida 20 mg/g gel"
  },
  {
    "code" : "@brasil15585500806",
    "display" : "Nimesulida 200 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil12209625598",
    "display" : "Nimesulida 50 mg/mL solução oral"
  },
  {
    "code" : "@brasil17190535855",
    "display" : "Nimesulida 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil18129400309",
    "display" : "Nimesulida Betaciclodextrina 400 mg comprimido"
  },
  {
    "code" : "@brasil11666403357",
    "display" : "Nimodipino 30 mg comprimido"
  },
  {
    "code" : "@brasil15421585984",
    "display" : "Nimotuzumabe 50 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16997579937",
    "display" : "Nimotuzumabe 50 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11760064736",
    "display" : "Nintedanibe 100 mg cápsula"
  },
  {
    "code" : "@brasil18025825383",
    "display" : "Nintedanibe 150 mg cápsula"
  },
  {
    "code" : "@brasil19744303792",
    "display" : "Nistatina 100.000 unidades internacionais/g + Óxido de Zinco 200 mg/g creme"
  },
  {
    "code" : "@brasil13615320969",
    "display" : "Nistatina 100.000 unidades internacionais/g + Óxido de Zinco 200 mg/g pomada"
  },
  {
    "code" : "@brasil14758076391",
    "display" : "Nistatina 100.000 unidades internacionais/mL suspensão oral"
  },
  {
    "code" : "@brasil13127292051",
    "display" : "Nistatina 25.000 unidades internacionais/g creme vaginal"
  },
  {
    "code" : "@brasil10817086379",
    "display" : "Nistatina 500.000 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil10591002897",
    "display" : "Nitazoxanida 20 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil16387555063",
    "display" : "Nitazoxanida 500 mg comprimido"
  },
  {
    "code" : "@brasil11041730185",
    "display" : "Nitrato de Butoconazol 20 mg/g creme vaginal"
  },
  {
    "code" : "@brasil18903777000",
    "display" : "Nitrato de Butoconazol 5 mg/g creme vaginal"
  },
  {
    "code" : "@brasil17390469746",
    "display" : "Nitrato de Oxiconazol 10 mg/g creme"
  },
  {
    "code" : "@brasil14673270558",
    "display" : "Nitrato de Oxiconazol 10 mg/mL solução"
  },
  {
    "code" : "@brasil10499471024",
    "display" : "Nitrato de Prata 10 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil10159651300",
    "display" : "Nitrato de Prata 5g Bastão"
  },
  {
    "code" : "@brasil13070256618",
    "display" : "Nitrazepam 5 mg comprimido"
  },
  {
    "code" : "@brasil19813667459",
    "display" : "Nitrendipino 10 mg comprimido"
  },
  {
    "code" : "@brasil13101198749",
    "display" : "Nitrendipino 20 mg comprimido"
  },
  {
    "code" : "@brasil12228450952",
    "display" : "Nitrofural 2 mg/g pomada"
  },
  {
    "code" : "@brasil15188981484",
    "display" : "Nitrofural 2mg/mL solução"
  },
  {
    "code" : "@brasil18864544496",
    "display" : "Nitrofurantoína 100 mg cápsula"
  },
  {
    "code" : "@brasil13924240202",
    "display" : "Nitrofurantoína 100 mg comprimido"
  },
  {
    "code" : "@brasil13043484316",
    "display" : "Nitrofurantoína 5 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil15477127427",
    "display" : "Nitroglicerina 25 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17557117823",
    "display" : "Nitroglicerina 50 mg (10 mg/24 horas) adesivo transdérmico"
  },
  {
    "code" : "@brasil11310410164",
    "display" : "Nitroglicerina 50 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12844454014",
    "display" : "Nitroprusseto de Sódio 50 mg pó e diluente para solução para injeção; ampola"
  },
  {
    "code" : "@brasil10261460495",
    "display" : "Nitroprusseto de Sódio 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15742903057",
    "display" : "Nitroprusseto de Sódio 50 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18618656421",
    "display" : "Nivolumabe 100 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12100542607",
    "display" : "Nivolumabe 40 mg/4 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10197821333",
    "display" : "Nomegestrol 2,5 mg + Estradiol 1,5 mg comprimido"
  },
  {
    "code" : "@brasil16533039505",
    "display" : "Nomegestrol 5 mg comprimido"
  },
  {
    "code" : "@brasil16282061202",
    "display" : "Nonoxinol 20 mg/mL (2%) gel vaginal"
  },
  {
    "code" : "@brasil12956755274",
    "display" : "Norelgestromina 203 microgramas/24 horas + Etinilestradiol 33,9 microgramas/24 horas adesivo transdérmico"
  },
  {
    "code" : "@brasil14353362566",
    "display" : "Norepinefrina 4 mg/4 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13791564230",
    "display" : "Noretisterona 0,35 mg comprimido"
  },
  {
    "code" : "@brasil15441602323",
    "display" : "Norfloxacino 400 mg comprimido"
  },
  {
    "code" : "@brasil18012701483",
    "display" : "Norgestimato 0,18 mg + Etinilestradiol 0,025 mg comprimido e Norgestimato 0,215 mg + Etinilestradiol 0,025 mg comprimido e Norgestimato 0,25 mg + Etinilestradiol 0,025 mg comprimido"
  },
  {
    "code" : "@brasil12395365388",
    "display" : "Norgestimato 1 mg + Etinilestradiol 90 micrograma comprimido"
  },
  {
    "code" : "@brasil11128555135",
    "display" : "Nortriptilina 10 mg cápsula"
  },
  {
    "code" : "@brasil13219157375",
    "display" : "Nortriptilina 10 mg comprimido"
  },
  {
    "code" : "@brasil12283761204",
    "display" : "Nortriptilina 2 mg/mL solução oral"
  },
  {
    "code" : "@brasil12528999746",
    "display" : "Nortriptilina 25 mg cápsula"
  },
  {
    "code" : "@brasil17717033117",
    "display" : "Nortriptilina 50 mg cápsula"
  },
  {
    "code" : "@brasil13104931816",
    "display" : "Nortriptilina 50 mg comprimido"
  },
  {
    "code" : "@brasil13862634303",
    "display" : "Nortriptilina 75 mg cápsula"
  },
  {
    "code" : "@brasil14646744079",
    "display" : "Obinutuzumabe 1 g/ 40 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19567821712",
    "display" : "Ocitocina 40 unidades internacionais/mL solução spray"
  },
  {
    "code" : "@brasil14612257492",
    "display" : "Ocitocina 5 unidades internacionais/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15761883206",
    "display" : "Ocriplasmina 0,5 mg/0,2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10684622050",
    "display" : "Octreotida 0,05 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12851776463",
    "display" : "Octreotida 0,05 mg/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10792550621",
    "display" : "Octreotida 0,1 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18782094145",
    "display" : "Octreotida 0,1 mg/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15328918615",
    "display" : "Octreotida 0,5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18599605547",
    "display" : "Octreotida 10 mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13089252711",
    "display" : "Octreotida 10 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12850977230",
    "display" : "Octreotida 10 mg pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10903964237",
    "display" : "Octreotida 20 mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13860802606",
    "display" : "Octreotida 20 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16232149316",
    "display" : "Octreotida 20 mg pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18928651806",
    "display" : "Octreotida 30 mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10607565389",
    "display" : "Octreotida 30 mg pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10720232482",
    "display" : "Ofatumumabe 1 g/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12804884073",
    "display" : "Ofatumumabe 100 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18322121218",
    "display" : "Ofloxacino 200 mg comprimido"
  },
  {
    "code" : "@brasil14193002341",
    "display" : "Ofloxacino 3 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil12129258588",
    "display" : "Ofloxacino 400 mg comprimido"
  },
  {
    "code" : "@brasil17502416833",
    "display" : "Olanzapina 10 mg comprimido"
  },
  {
    "code" : "@brasil11941448972",
    "display" : "Olanzapina 10 mg comprimido orodispersível"
  },
  {
    "code" : "@brasil11931366632",
    "display" : "Olanzapina 10 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10787968821",
    "display" : "Olanzapina 2,5 mg comprimido"
  },
  {
    "code" : "@brasil19207640371",
    "display" : "Olanzapina 5 mg comprimido"
  },
  {
    "code" : "@brasil12640815341",
    "display" : "Olanzapina 5 mg comprimido orodispersível"
  },
  {
    "code" : "@brasil11311849523",
    "display" : "Olaparibe 50 mg cápsula"
  },
  {
    "code" : "@brasil15918814981",
    "display" : "Oleato de Etanolamina 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11467930935",
    "display" : "Óleo de Cade 3 mg/g + Alcatrão de Pinho 3 mg/g + Alcatrão Mineral 3 mg/g sabonete"
  },
  {
    "code" : "@brasil10004901922",
    "display" : "Óleo de Cade 3 mg/mL + Alcatrão de Pinho 3 mg/mL + Alcatrão Mineral 3 mg/mL xampu"
  },
  {
    "code" : "@brasil19218089503",
    "display" : "Óleo de Fígado de Bacalhau 58,8 mg/mL + Retinol 253 unidades internacionais/mL + Colecalciferol 25,2 unidades internacionais/mL emulsão oral"
  },
  {
    "code" : "@brasil13722801611",
    "display" : "Olmesartana Medoxomila 20 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "@brasil16381184649",
    "display" : "Olmesartana Medoxomila 20 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil18013025462",
    "display" : "Olmesartana Medoxomila 20 mg comprimido"
  },
  {
    "code" : "@brasil10770007576",
    "display" : "Olmesartana Medoxomila 40 mg + Anlodipino 10 mg comprimido"
  },
  {
    "code" : "@brasil17199484878",
    "display" : "Olmesartana Medoxomila 40 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "@brasil12547437419",
    "display" : "Olmesartana Medoxomila 40 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil10924332663",
    "display" : "Olmesartana Medoxomila 40 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "@brasil16617414676",
    "display" : "Olmesartana Medoxomila 40 mg comprimido"
  },
  {
    "code" : "@brasil17609088957",
    "display" : "Olodaterol 2,5 microgramas/dose solução para inalação; inalador"
  },
  {
    "code" : "@brasil19098640826",
    "display" : "Olopatadina 1 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil14680218988",
    "display" : "Olopatadina 2 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil12870878047",
    "display" : "Omalizumabe 150 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14686692164",
    "display" : "Ombitasvir 12,5 mg + Veruprevir 75 mg + Ritonavir 50 mg comprimido e Dasabuvir 250 mg comprimido"
  },
  {
    "code" : "@brasil15981759991",
    "display" : "Omeprazol 10 mg cápsula gastrorresistente"
  },
  {
    "code" : "@brasil13533651914",
    "display" : "Omeprazol 10 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil19375364247",
    "display" : "Omeprazol 20 mg cápsula gastrorresistente"
  },
  {
    "code" : "@brasil19361036491",
    "display" : "Omeprazol 20 mg cápsula gastrorresistente e Claritromicina 500 mg comprimido e Amoxicilina 500 mg cápsula"
  },
  {
    "code" : "@brasil16825357540",
    "display" : "Omeprazol 20 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil13487057501",
    "display" : "Omeprazol 40 mg cápsula gastrorresistente"
  },
  {
    "code" : "@brasil11567294225",
    "display" : "Omeprazol 40 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil11362802088",
    "display" : "Omeprazol 40 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil17900642497",
    "display" : "Omeprazol 40 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18705412239",
    "display" : "Ondansetrona 4 mg comprimido"
  },
  {
    "code" : "@brasil16637420686",
    "display" : "Ondansetrona 4 mg comprimido orodispersível"
  },
  {
    "code" : "@brasil12172498061",
    "display" : "Ondansetrona 4 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16830571503",
    "display" : "Ondansetrona 8 mg comprimido"
  },
  {
    "code" : "@brasil13861935168",
    "display" : "Ondansetrona 8 mg comprimido orodispersível"
  },
  {
    "code" : "@brasil13831521451",
    "display" : "Ondansetrona 8 mg/4 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10612840186",
    "display" : "Orfenadrina 35 mg + Dipirona 300 mg + Cafeína 50 mg comprimido"
  },
  {
    "code" : "@brasil12313817265",
    "display" : "Orfenadrina 35 mg + Paracetamol 450 mg + Cafeína 50 mg comprimido"
  },
  {
    "code" : "@brasil15183924160",
    "display" : "Orfenadrina 35 mg/mL + Dipirona 300 mg/mL + Cafeína 50 mg/mL solução oral"
  },
  {
    "code" : "@brasil11661649877",
    "display" : "Orlistate 120 mg cápsula"
  },
  {
    "code" : "@brasil19494372436",
    "display" : "Ornitina 3 g granulado"
  },
  {
    "code" : "@brasil16173309361",
    "display" : "Oseltamivir 12 mg cápsula"
  },
  {
    "code" : "@brasil19598829827",
    "display" : "Oseltamivir 12 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil15662450198",
    "display" : "Oseltamivir 15 mg/mL solução oral"
  },
  {
    "code" : "@brasil19792323212",
    "display" : "Oseltamivir 20 mg cápsula"
  },
  {
    "code" : "@brasil11974265780",
    "display" : "Oseltamivir 25 mg cápsula"
  },
  {
    "code" : "@brasil17232189323",
    "display" : "Oseltamivir 30 mg cápsula"
  },
  {
    "code" : "@brasil16909735831",
    "display" : "Oseltamivir 45 mg cápsula"
  },
  {
    "code" : "@brasil16347801121",
    "display" : "Oseltamivir 75 mg cápsula"
  },
  {
    "code" : "@brasil18369892115",
    "display" : "Osimertinibe 40 mg comprimido"
  },
  {
    "code" : "@brasil12480173987",
    "display" : "Osimertinibe 80 mg comprimido"
  },
  {
    "code" : "@brasil14188819418",
    "display" : "Oxacilina 500 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19689290241",
    "display" : "Oxacilina 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13749669298",
    "display" : "Oxaliplatina 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12958670455",
    "display" : "Oxaliplatina 100 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13544344689",
    "display" : "Oxaliplatina 140 mg/28 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13595528194",
    "display" : "Oxaliplatina 200 mg/40 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16415936271",
    "display" : "Oxaliplatina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19543038185",
    "display" : "Oxaliplatina 50 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11056862138",
    "display" : "Oxamniquina 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil10553953041",
    "display" : "Oxcarbazepina 300 mg comprimido"
  },
  {
    "code" : "@brasil17257695873",
    "display" : "Oxcarbazepina 60 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil15370706826",
    "display" : "Oxcarbazepina 600 mg comprimido"
  },
  {
    "code" : "@brasil12179613523",
    "display" : "Oxibuprocaína 4 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil19662427182",
    "display" : "Oxibutinina 1 mg/mL solução oral"
  },
  {
    "code" : "@brasil16283770105",
    "display" : "Oxibutinina 1 mg/mL xarope"
  },
  {
    "code" : "@brasil14704073279",
    "display" : "Oxibutinina 10 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil11079738950",
    "display" : "Oxibutinina 5 mg comprimido"
  },
  {
    "code" : "@brasil11594810588",
    "display" : "Oxicodona 10 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil14524735606",
    "display" : "Oxicodona 20 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil11616684003",
    "display" : "Oxicodona 40 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil14929288479",
    "display" : "Óxido de Zinco 100 mg/g + Colecalciferol  400 unidades internacionais/g + Retinol 1.000 unidades internacionais/g pomada"
  },
  {
    "code" : "@brasil15570712782",
    "display" : "Óxido de Zinco 200 mg/g (20%) + Cloreto de Benzalcônio 5 mg/g (0,5%) + Cânfora 50 mg/g (5%) pomada"
  },
  {
    "code" : "@brasil13200127335",
    "display" : "Óxido de Zinco 200 mg/g creme"
  },
  {
    "code" : "@brasil11169252647",
    "display" : "Oximetazolina 0,25 mg/mL solução nasal"
  },
  {
    "code" : "@brasil15295967342",
    "display" : "Oximetazolina 0,5 mg/mL solução nasal"
  },
  {
    "code" : "@brasil16566821173",
    "display" : "Oximetazolina 0,5 mg/mL solução spray"
  },
  {
    "code" : "@brasil11540621919",
    "display" : "Oximetolona 50 mg comprimido"
  },
  {
    "code" : "@brasil19547171990",
    "display" : "Oxitetraciclina 30 mg/g + Polimixina B 10.000 unidades/g pomada"
  },
  {
    "code" : "@brasil12555169659",
    "display" : "Oxitetraciclina 5 mg/g + Poliminixa B 10.000 unidades internacionais/g pomada oftálmica"
  },
  {
    "code" : "@brasil18080925416",
    "display" : "Oxomemazina 0,184 mg/mL + Guaifenesina 5 mg/mL + Paracetamol 2 mg/mL xarope"
  },
  {
    "code" : "@brasil17376511362",
    "display" : "Oxomemazina 0,332 mg/mL + Guaifenesina 6,66 mg/mL + Benzoato de Sódio 6,66 mg/mL + Paracetamol 6,66 mg/mL xarope"
  },
  {
    "code" : "@brasil15477757140",
    "display" : "Oxomemazina 0,367 mg/mL + Guaifenesina 6,66 mg/mL + Paracetamol 6,66 mg/mL xarope"
  },
  {
    "code" : "@brasil18446883835",
    "display" : "Oxomemazina 0,4 mg/mL + Iodeto de Potássio 20 mg/mL + Benzoato de Sódio 4 mg/mL + Guaifenesina 6 mg/mL xarope"
  },
  {
    "code" : "@brasil13574301863",
    "display" : "Paclitaxel 100 mg/16,7 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14549459957",
    "display" : "Paclitaxel 150 mg/25 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12024394507",
    "display" : "Paclitaxel 250 mg/41,7 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16294781644",
    "display" : "Paclitaxel 30 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13792988166",
    "display" : "Paclitaxel 300 mg/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12577745375",
    "display" : "Paliperidona 100 mg/1 mL suspensão para injeção de liberação prolongada; seringa preenchida"
  },
  {
    "code" : "@brasil15110035439",
    "display" : "Paliperidona 100 mg/1 mL suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil10773207200",
    "display" : "Paliperidona 150 mg/1,5 mL suspensão para injeção de liberação prolongada; seringa preenchida"
  },
  {
    "code" : "@brasil17509019929",
    "display" : "Paliperidona 150 mg/1,5 mL suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil11491231201",
    "display" : "Paliperidona 25 mg/0,25 mL suspensão para injeção de liberação prolongada; seringa preenchida"
  },
  {
    "code" : "@brasil19994378376",
    "display" : "Paliperidona 3 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil11374530801",
    "display" : "Paliperidona 50 mg/0,5 mL suspensão para injeção de liberação prolongada; seringa preenchida"
  },
  {
    "code" : "@brasil17344305809",
    "display" : "Paliperidona 50 mg/0,5 mL suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil15343035919",
    "display" : "Paliperidona 6 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil12695007195",
    "display" : "Paliperidona 75 mg/0,75 mL suspensão para injeção de liberação prolongada; seringa preenchida"
  },
  {
    "code" : "@brasil13697020217",
    "display" : "Paliperidona 75 mg/0,75 mL suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil11568279853",
    "display" : "Paliperidona 9 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil12053129617",
    "display" : "Palivizumabe 100 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11381303463",
    "display" : "Palivizumabe 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18306101790",
    "display" : "Palivizumabe 100 mg/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10747128771",
    "display" : "Palivizumabe 50 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17869574135",
    "display" : "Palivizumabe 50 mg/0,5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15717282867",
    "display" : "Palonosetrona 0,075 mg/1,5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11904218318",
    "display" : "Palonosetrona 0,25 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14724605021",
    "display" : "Pamidronato Dissódico 30 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12629533318",
    "display" : "Pamidronato dissódico 60 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17439690628",
    "display" : "Pamidronato Dissódico 60 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18001479288",
    "display" : "Pamidronato dissódico 90 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14437186776",
    "display" : "Pamidronato Dissódico 90 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10974719468",
    "display" : "Pamidronato Dissódico 90 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17161719291",
    "display" : "Pamoato de Pirvínio 10 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil17892853530",
    "display" : "Pancreatina 10.000 unidades cápsula"
  },
  {
    "code" : "@brasil15271823586",
    "display" : "Pancreatina 10.000 unidades cápsula gastrorresistente"
  },
  {
    "code" : "@brasil16195483332",
    "display" : "Pancreatina 170 mg + Dimeticona 80 mg comprimido"
  },
  {
    "code" : "@brasil13240734303",
    "display" : "Pancreatina 25.000 unidades cápsula"
  },
  {
    "code" : "@brasil17958440227",
    "display" : "Pancreatina 25.000 unidades cápsula gastrorresistente"
  },
  {
    "code" : "@brasil12705724482",
    "display" : "Pancreatina 400 mg cápsula gastrorresistente"
  },
  {
    "code" : "@brasil18178417325",
    "display" : "Pancrelipase 12.000 unidades internacionais cápsula"
  },
  {
    "code" : "@brasil16223323237",
    "display" : "Pancrelipase 18.000 unidades internacionais cápsula"
  },
  {
    "code" : "@brasil14637388366",
    "display" : "Pancrelipase 20.000 unidades internacionais cápsula"
  },
  {
    "code" : "@brasil12100472600",
    "display" : "Pancrelipase 4.500 unidades internacionais cápsula"
  },
  {
    "code" : "@brasil12293237932",
    "display" : "Panitumumabe 100 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14103311200",
    "display" : "Panitumumabe 400 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16454676356",
    "display" : "Pantoprazol 20 mg comprimido"
  },
  {
    "code" : "@brasil12075773832",
    "display" : "Pantoprazol 40 mg cápsula"
  },
  {
    "code" : "@brasil19554168700",
    "display" : "Pantoprazol 40 mg comprimido"
  },
  {
    "code" : "@brasil15874279266",
    "display" : "Pantoprazol 40 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16944595663",
    "display" : "Pantoprazol 40 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16019935956",
    "display" : "Pantoprazol Magnésico 40 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil10907007604",
    "display" : "Pantoprazol Sódico 20 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil17648306624",
    "display" : "Pantoprazol Sódico 40 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil17307213372",
    "display" : "Papaverina 10 mg/mL + Dipirona 333 mg/mL + Atropa belladonna 6 mg/mL + Hyoscyamus niger 6 mg/mL + Peumus boldus 12 mg/mL solução oral"
  },
  {
    "code" : "@brasil15704988943",
    "display" : "Papaverina 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11266993684",
    "display" : "Papaverina 30 mg + Dipirona 250 mg + Atropa belladonna 0,03 mL comprimido"
  },
  {
    "code" : "@brasil16476410613",
    "display" : "Paracetamol 100 mg/mL + Clorfeniramina 2 mg/mL + Fenilefrina 2 mg/mL solução oral"
  },
  {
    "code" : "@brasil17015431779",
    "display" : "Paracetamol 100 mg/mL solução oral"
  },
  {
    "code" : "@brasil18384465143",
    "display" : "Paracetamol 100 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil12093380001",
    "display" : "Paracetamol 120 mg/mL + Carbinoxamina 2 mg/mL solução oral"
  },
  {
    "code" : "@brasil11720644496",
    "display" : "Paracetamol 13,3 mg/mL + Fenilefrina 0,33 mg/mL + Carbinoxamina 0,13 mg/mL solução oral"
  },
  {
    "code" : "@brasil17997029503",
    "display" : "Paracetamol 160 mg comprimido mastigável"
  },
  {
    "code" : "@brasil12305023056",
    "display" : "Paracetamol 200 mg/mL solução oral"
  },
  {
    "code" : "@brasil13282967192",
    "display" : "Paracetamol 300 mg + Diclofenaco Sódico 50 mg + Carisoprodol 125 mg + Cafeína 30 mg comprimido"
  },
  {
    "code" : "@brasil13985577647",
    "display" : "Paracetamol 32 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil18701082297",
    "display" : "Paracetamol 350 mg + Carisoprodol 150 mg + Cafeína 50 mg comprimido"
  },
  {
    "code" : "@brasil14091464283",
    "display" : "Paracetamol 40 mg/mL + Clorfeniramina 0,6 mg/mL + Fenilefrina 0,6 mg/mL solução oral"
  },
  {
    "code" : "@brasil15921287242",
    "display" : "Paracetamol 40 mg/mL + Fenilefrina 1 mg/mL + Carbinoxamina 0,4 mg/mL solução oral"
  },
  {
    "code" : "@brasil13183368054",
    "display" : "Paracetamol 40 mg/mL + Fenilefrina 1 mg/mL + Carbinoxamina 0,4 mg/mL xarope"
  },
  {
    "code" : "@brasil15661053959",
    "display" : "Paracetamol 400 mg + Clorfeniramina 4 mg + Fenilefrina 4 mg cápsula"
  },
  {
    "code" : "@brasil15773861700",
    "display" : "Paracetamol 400 mg + Clorfeniramina 4 mg + Fenilefrina 4 mg comprimido"
  },
  {
    "code" : "@brasil11236407347",
    "display" : "Paracetamol 400 mg + Clorfeniramina 4 mg + Fenilefrina 4 mg granulado"
  },
  {
    "code" : "@brasil13233459817",
    "display" : "Paracetamol 400 mg + Clorfeniramina 4 mg + Fenilefrina 4 mg pó para solução oral"
  },
  {
    "code" : "@brasil10838494514",
    "display" : "Paracetamol 400 mg + Famotidina 20 mg + Tramadol 20 mg cápsula"
  },
  {
    "code" : "@brasil11393634416",
    "display" : "Paracetamol 400 mg + Fenilefrina 20 mg comprimido e Paracetamol 400 mg + Carbinoxamina 4 mg comprimido"
  },
  {
    "code" : "@brasil15556209929",
    "display" : "Paracetamol 400 mg + Fenilefrina 20 mg comprimido e Paracetamol 400 mg comprimido"
  },
  {
    "code" : "@brasil11704025846",
    "display" : "Paracetamol 400 mg + Pentoxiverina 10 mg + Fenilefrina 10 mg + Carbinoxamina 2 mg comprimido"
  },
  {
    "code" : "@brasil17154760216",
    "display" : "Paracetamol 400 mg comprimido e Paracetamol 400 mg + Fenilefrina 20 mg comprimido e Paracetamol 400 mg + Carbinoxamina 4 mg comprimido"
  },
  {
    "code" : "@brasil15644383862",
    "display" : "Paracetamol 500 mg + Amitriptilina 25 mg + Ciclobenzaprina 5 mg + Meloxicam 7,5 mg cápsula"
  },
  {
    "code" : "@brasil12494339990",
    "display" : "Paracetamol 500 mg + Amitriptilina 25 mg + Meloxicam 7,5 mg cápsula"
  },
  {
    "code" : "@brasil19231951075",
    "display" : "Paracetamol 500 mg + Cafeína 65 mg comprimido"
  },
  {
    "code" : "@brasil14288437937",
    "display" : "Paracetamol 500 mg + Cafeína 65 mg comprimido efervescente"
  },
  {
    "code" : "@brasil11599029116",
    "display" : "Paracetamol 500 mg + Carisoprodol 150 mg + Fenilbutazona 75 mg comprimido"
  },
  {
    "code" : "@brasil19582101225",
    "display" : "Paracetamol 500 mg + Codeína 15 mg cápsula"
  },
  {
    "code" : "@brasil14514301375",
    "display" : "Paracetamol 500 mg + Codeína 30 mg comprimido"
  },
  {
    "code" : "@brasil13229019168",
    "display" : "Paracetamol 500 mg + Codeína 7,5 mg comprimido"
  },
  {
    "code" : "@brasil17105687274",
    "display" : "Paracetamol 500 mg + Dimetindeno 0,5 mg + Fenilefrina 2 mg + Rutosídeo 15 mg + Ácido Ascórbico 40 mg comprimido"
  },
  {
    "code" : "@brasil17668664023",
    "display" : "Paracetamol 500 mg + Meloxicam 15 mg + Ciclobenzaprina 5 mg cápsula"
  },
  {
    "code" : "@brasil18302337160",
    "display" : "Paracetamol 500 mg + Pseudoefedrina 30 mg comprimido"
  },
  {
    "code" : "@brasil11419514399",
    "display" : "Paracetamol 500 mg comprimido"
  },
  {
    "code" : "@brasil10726405353",
    "display" : "Paracetamol 500 mg comprimido efervescente"
  },
  {
    "code" : "@brasil19232334780",
    "display" : "Paracetamol 500 mg pó para solução oral"
  },
  {
    "code" : "@brasil11274582995",
    "display" : "Paracetamol 750 mg comprimido"
  },
  {
    "code" : "@brasil18460869105",
    "display" : "Parecoxibe 40 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18024933194",
    "display" : "Parecoxibe 40 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18036936834",
    "display" : "Paricalcitol 10 microgramas/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11102917576",
    "display" : "Paricalcitol 5 microgramas/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14652570107",
    "display" : "Paroxetina 10 mg comprimido"
  },
  {
    "code" : "@brasil12386456114",
    "display" : "Paroxetina 12,5 mg comprimido de liberação modificada"
  },
  {
    "code" : "@brasil15863563338",
    "display" : "Paroxetina 15 mg comprimido"
  },
  {
    "code" : "@brasil15913218738",
    "display" : "Paroxetina 20 mg comprimido"
  },
  {
    "code" : "@brasil12192647718",
    "display" : "Paroxetina 25 mg comprimido"
  },
  {
    "code" : "@brasil19494238912",
    "display" : "Paroxetina 25 mg comprimido de liberação modificada"
  },
  {
    "code" : "@brasil10478027853",
    "display" : "Paroxetina 30 mg comprimido"
  },
  {
    "code" : "@brasil17105455533",
    "display" : "Paroxetina 40 mg comprimido"
  },
  {
    "code" : "@brasil10693913157",
    "display" : "Pasireotida 0,3 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16015470916",
    "display" : "Pasireotida 0,6 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16511681745",
    "display" : "Pasireotida 0,9 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12231587880",
    "display" : "Pazopanibe 200 mg comprimido"
  },
  {
    "code" : "@brasil11167862154",
    "display" : "Pazopanibe 400 mg comprimido"
  },
  {
    "code" : "@brasil16080142161",
    "display" : "Pegfilgrastim 6 mg/0,6 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil13389131475",
    "display" : "Pegvisomanto 10 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12301383885",
    "display" : "Pegvisomanto 10 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19672221352",
    "display" : "Pegvisomanto 15 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15531885711",
    "display" : "Pegvisomanto 15 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13270025217",
    "display" : "Pegvisomanto 20 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19665033619",
    "display" : "Pelargonium sidoides 825 mg/mL solução oral"
  },
  {
    "code" : "@brasil12596167057",
    "display" : "Pembrolizumabe 100 mg/4 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12978113015",
    "display" : "Pemetrexede 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16468109930",
    "display" : "Pemetrexede 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11062716059",
    "display" : "Penciclovir 10 mg/g creme"
  },
  {
    "code" : "@brasil15918114189",
    "display" : "Penfluridol 20 mg comprimido"
  },
  {
    "code" : "@brasil16178092075",
    "display" : "Penicilamina 250 mg cápsula"
  },
  {
    "code" : "@brasil15805713119",
    "display" : "Pentamidina 300 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11768333251",
    "display" : "Pentoxifilina 100 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12663372989",
    "display" : "Pentoxifilina 400 mg comprimido"
  },
  {
    "code" : "@brasil16466243113",
    "display" : "Pentoxifilina 400 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil14859332780",
    "display" : "Perampanel 10 mg comprimido"
  },
  {
    "code" : "@brasil18872340001",
    "display" : "Perampanel 12 mg comprimido"
  },
  {
    "code" : "@brasil14840467798",
    "display" : "Perampanel 2 mg comprimido"
  },
  {
    "code" : "@brasil11327846804",
    "display" : "Perampanel 4 mg comprimido"
  },
  {
    "code" : "@brasil12117830934",
    "display" : "Perampanel 6 mg comprimido"
  },
  {
    "code" : "@brasil16605614567",
    "display" : "Perampanel 8 mg comprimido"
  },
  {
    "code" : "@brasil19281318455",
    "display" : "Pergolida 0,25 mg comprimido"
  },
  {
    "code" : "@brasil12615540736",
    "display" : "Pergolida 1 mg comprimido"
  },
  {
    "code" : "@brasil11573098423",
    "display" : "Periciazina 10 mg comprimido"
  },
  {
    "code" : "@brasil13991207939",
    "display" : "Periciazina 10 mg/mL solução oral"
  },
  {
    "code" : "@brasil14882018820",
    "display" : "Periciazina 40 mg/mL solução oral"
  },
  {
    "code" : "@brasil10310884638",
    "display" : "Perindopril Arginina 10 mg comprimido"
  },
  {
    "code" : "@brasil11293298192",
    "display" : "Perindopril Arginina 14 mg + Anlodipino 10 mg comprimido"
  },
  {
    "code" : "@brasil13045648878",
    "display" : "Perindopril Arginina 3,5 mg + Anlodipino 2,5 mg comprimido"
  },
  {
    "code" : "@brasil11135678598",
    "display" : "Perindopril Arginina 5 mg comprimido"
  },
  {
    "code" : "@brasil16227647731",
    "display" : "Perindopril Arginina 7 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "@brasil13660111596",
    "display" : "Perindopril Erbumina 4 mg + Indapamida 1,25 mg comprimido"
  },
  {
    "code" : "@brasil12326455769",
    "display" : "Perindopril Erbumina 4 mg comprimido"
  },
  {
    "code" : "@brasil19011894349",
    "display" : "Perindopril Erbumina 8 mg comprimido"
  },
  {
    "code" : "@brasil19437970460",
    "display" : "Permanganato de Potássio 100 mg comprimido"
  },
  {
    "code" : "@brasil15266763701",
    "display" : "Permanganato de Potássio 100 mg pó"
  },
  {
    "code" : "@brasil19305621867",
    "display" : "Permetrina 10 mg/g loção"
  },
  {
    "code" : "@brasil16608306332",
    "display" : "Permetrina 10 mg/mL (1%) xampu"
  },
  {
    "code" : "@brasil16488135154",
    "display" : "Permetrina 10 mg/mL loção"
  },
  {
    "code" : "@brasil18994998612",
    "display" : "Permetrina 50 mg/mL loção"
  },
  {
    "code" : "@brasil14123552807",
    "display" : "Peróxido de Benzoíla 100 mg/g gel"
  },
  {
    "code" : "@brasil19289265104",
    "display" : "Peróxido de Benzoíla 25 mg/g gel"
  },
  {
    "code" : "@brasil19708657988",
    "display" : "Peróxido de Benzoíla 40 mg/g gel"
  },
  {
    "code" : "@brasil12820713363",
    "display" : "Peróxido de Benzoíla 50 mg/g + Enxofre 20 mg/g creme"
  },
  {
    "code" : "@brasil19474355715",
    "display" : "Peróxido de Benzoíla 50 mg/g gel"
  },
  {
    "code" : "@brasil11737185512",
    "display" : "Peróxido de Benzoíla 80 mg/g gel"
  },
  {
    "code" : "@brasil12230935768",
    "display" : "Peróxido de Hidrogênio 3% solução"
  },
  {
    "code" : "@brasil11225614994",
    "display" : "Peróxido de Uréia 100 mg/mL solução otológica"
  },
  {
    "code" : "@brasil16091074323",
    "display" : "Pertuzumabe 420 mg/14 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10170309142",
    "display" : "Pertuzumabe 420 mg/14 mL solução para injeção; frasco-ampola e Trastuzumabe 440 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14922779363",
    "display" : "Petidina 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15121146071",
    "display" : "Picossulfato de Sódio 0,334 mg/mL + Óleo Mineral 282,25 mg/mL + Ágar-Ágar 2,72 mg/mL emulsão oral"
  },
  {
    "code" : "@brasil17290865998",
    "display" : "Picossulfato de Sódio 10 mg + Óxido de Magnésio 3,5 g + Ácido Cítrico 12 g pó para solução oral"
  },
  {
    "code" : "@brasil11974381786",
    "display" : "Picossulfato de Sódio 2,5 mg cápsula"
  },
  {
    "code" : "@brasil13143078593",
    "display" : "Picossulfato de Sódio 7,5 mg/mL solução oral"
  },
  {
    "code" : "@brasil13972243212",
    "display" : "Pidolato de Magnésio 150 mg/mL solução oral"
  },
  {
    "code" : "@brasil17495257114",
    "display" : "Pimecrolimo 10 mg/g creme"
  },
  {
    "code" : "@brasil10169309367",
    "display" : "Pimetixeno 0,1 mg/mL xarope"
  },
  {
    "code" : "@brasil15347357628",
    "display" : "Pimozida 1 mg comprimido"
  },
  {
    "code" : "@brasil11256061000",
    "display" : "Pimozida 4 mg comprimido"
  },
  {
    "code" : "@brasil15476181026",
    "display" : "Pindolol 10 mg + Clopamida 5 mg comprimido"
  },
  {
    "code" : "@brasil11492162198",
    "display" : "Pindolol 10 mg comprimido"
  },
  {
    "code" : "@brasil15738943129",
    "display" : "Pindolol 5 mg comprimido"
  },
  {
    "code" : "@brasil11965640634",
    "display" : "Pinus pinaster 50 mg comprimido"
  },
  {
    "code" : "@brasil10456628351",
    "display" : "Pioglitazona 15 mg comprimido"
  },
  {
    "code" : "@brasil15246481675",
    "display" : "Pioglitazona 30 mg comprimido"
  },
  {
    "code" : "@brasil11079731052",
    "display" : "Pioglitazona 45 mg comprimido"
  },
  {
    "code" : "@brasil18011419387",
    "display" : "Piperacilina 2 g + Tazobactam 250 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19718879803",
    "display" : "Piperacilina 4 g + Tazobactam 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10646481206",
    "display" : "Piperazina 100 mg/mL solução oral"
  },
  {
    "code" : "@brasil13861933008",
    "display" : "Piperidolato 100 mg + Hesperidina 50 mg + Ácido Ascórbico 50 mg comprimido"
  },
  {
    "code" : "@brasil13253052934",
    "display" : "Pipotiazina 100 mg/4 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17329208008",
    "display" : "Pipotiazina 25 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11082558203",
    "display" : "Piracetam 1 g/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15763544751",
    "display" : "Piracetam 400 mg + Cinarizina 25 mg comprimido"
  },
  {
    "code" : "@brasil17727761972",
    "display" : "Piracetam 400 mg + Di-hidroergocristina 1 mg comprimido"
  },
  {
    "code" : "@brasil13162695515",
    "display" : "Piracetam 400 mg comprimido"
  },
  {
    "code" : "@brasil16177775826",
    "display" : "Piracetam 60 mg/mL solução oral"
  },
  {
    "code" : "@brasil18726878107",
    "display" : "Piracetam 800 mg comprimido"
  },
  {
    "code" : "@brasil10265791778",
    "display" : "Pirazinamida 30 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil17888732902",
    "display" : "Pirazinamida 500 mg comprimido"
  },
  {
    "code" : "@brasil10955202309",
    "display" : "Pirenoxina Sódica 0,85 mg comprimido e diluente para solução oftálmica"
  },
  {
    "code" : "@brasil10847375411",
    "display" : "Piretanida 6 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil14644628086",
    "display" : "Pirfenidona 267 mg cápsula"
  },
  {
    "code" : "@brasil14669267677",
    "display" : "Piribedil 50 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil14319446955",
    "display" : "Piridoxina 1 mg/mL + Raceometionina 10 mg/mL solução oral"
  },
  {
    "code" : "@brasil11220525084",
    "display" : "Piridoxina 100 mg comprimido"
  },
  {
    "code" : "@brasil11356902150",
    "display" : "Piridoxina 100 mg/2 mL + Tiamina 100 mg/2 mL solução para injeção; ampola e Cianocobalamina 5 mg/1 mL + Diclofenaco Sódico 75 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17293975013",
    "display" : "Piridoxina 300 mg comprimido"
  },
  {
    "code" : "@brasil17254829011",
    "display" : "Piridoxina 40 mg comprimido"
  },
  {
    "code" : "@brasil14136769829",
    "display" : "Piridoxina 50 mg comprimido"
  },
  {
    "code" : "@brasil11040216330",
    "display" : "Piridoxina 500 mg comprimido"
  },
  {
    "code" : "@brasil18917380428",
    "display" : "Pirimetamina 2 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil17476864117",
    "display" : "Pirimetamina 25 mg comprimido"
  },
  {
    "code" : "@brasil12177782161",
    "display" : "Pirimetamina 5 mg/mL solução oral"
  },
  {
    "code" : "@brasil13330724362",
    "display" : "Piroxicam 20 mg cápsula"
  },
  {
    "code" : "@brasil10766087025",
    "display" : "Piroxicam 20 mg comprimido"
  },
  {
    "code" : "@brasil18195684483",
    "display" : "Piroxicam 20 mg comprimido efervescente"
  },
  {
    "code" : "@brasil13395127134",
    "display" : "Piroxicam 20 mg comprimido orodispersível"
  },
  {
    "code" : "@brasil18827337498",
    "display" : "Piroxicam 20 mg comprimido para solução"
  },
  {
    "code" : "@brasil14909051967",
    "display" : "Piroxicam 20 mg supositório"
  },
  {
    "code" : "@brasil13448712119",
    "display" : "Piroxicam 40 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11102437293",
    "display" : "Piroxicam 5 mg/g gel"
  },
  {
    "code" : "@brasil16048930300",
    "display" : "Pitavastatina 2 mg comprimido"
  },
  {
    "code" : "@brasil14150502972",
    "display" : "Pitavastatina 2 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil12863395774",
    "display" : "Pitavastatina 4 mg comprimido"
  },
  {
    "code" : "@brasil19721709953",
    "display" : "Pizotifeno 0,5 g comprimido"
  },
  {
    "code" : "@brasil19158129642",
    "display" : "Plerixafor 24 mg/1,2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16993727111",
    "display" : "Plumeria lancifolia 0,625 mL/15 mL + Salicilato de Sódio 400 mg/15 mL + Passiflora alata 0,3 mL/15 mL + Citrus aurantium L. 0,013 mL/15 mL solução oral"
  },
  {
    "code" : "@brasil19259519807",
    "display" : "Podofilina 20% solução"
  },
  {
    "code" : "@brasil11270982297",
    "display" : "Podofilina 25% solução"
  },
  {
    "code" : "@brasil18576352369",
    "display" : "Podofilina 25% suspensão"
  },
  {
    "code" : "@brasil10087999607",
    "display" : "Podofilotoxina 1,5 mg/g creme"
  },
  {
    "code" : "@brasil19490555485",
    "display" : "Policarbofila 500 mg comprimido"
  },
  {
    "code" : "@brasil12656573319",
    "display" : "Policresuleno 100 mg + Cinchocaína 27 mg supositório"
  },
  {
    "code" : "@brasil12974734121",
    "display" : "Policresuleno 100 mg/g + Cinchocaína 10 mg/g pomada"
  },
  {
    "code" : "@brasil12642127462",
    "display" : "Policresuleno 18 mg/g gel"
  },
  {
    "code" : "@brasil10365504808",
    "display" : "Policresuleno 240 mg + Cinchocaína 24 mg supositório"
  },
  {
    "code" : "@brasil10912496680",
    "display" : "Policresuleno 360 mg/g solução"
  },
  {
    "code" : "@brasil15463499709",
    "display" : "Policresuleno 50 mg/g + Cinchocaína 10 mg/g pomada"
  },
  {
    "code" : "@brasil18247914199",
    "display" : "Policresuleno 90 mg óvulo"
  },
  {
    "code" : "@brasil13098888799",
    "display" : "Polidocanol 3,2 mg/g + Lidocaína 3,4 mg/g + Tintura Camomila 150 mg/g gel"
  },
  {
    "code" : "@brasil17992617186",
    "display" : "Polidocanol 3,2 mg/g + Lidocaína 3,4 mg/g + Tintura Camomila 150 mg/g solução"
  },
  {
    "code" : "@brasil12913325281",
    "display" : "Poliestirenossulfonato de Cálcio 30 g (900 mg/g) pó para suspensão"
  },
  {
    "code" : "@brasil14028601704",
    "display" : "Polietilenoglicol (400) 3 mg/mL + Propilenoglicol 4 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil10666419844",
    "display" : "Polimixina B 1.000.000 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19354247969",
    "display" : "Polimixina B 1.500.000 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18832018353",
    "display" : "Polimixina B 10.000 unidades internacionais + Prednisolona 4 mg/g + Benzocaína 5 mg/g + Clioquinol 30 mg/g pomada"
  },
  {
    "code" : "@brasil13354645205",
    "display" : "Polimixina B 10.000 unidades internacionais/mL + Neomicina 10 mg/mL + Fludrocortisona 1 mg/mL + Lidocaína 40 mg/mL solução otológica"
  },
  {
    "code" : "@brasil16627035592",
    "display" : "Polimixina B 10.000 unidades internacionais/mL + Neomicina 3,5 mg/mL + Fluocinolona 0,25 mg/mL + Lidocaína 20 mg/mL solução otológica"
  },
  {
    "code" : "@brasil15364602369",
    "display" : "Polimixina B 10.000 unidades internacionais/mL + Neomicina 5 mg/mL + Hidrocortisona 10 mg/mL suspensão otológica"
  },
  {
    "code" : "@brasil18919643542",
    "display" : "Polimixina B 10.000 unidades internacionais/mL + Prednisolona 5 mg/mL + Neomicina 5 mg/mL suspensão oftálmica"
  },
  {
    "code" : "@brasil19723316680",
    "display" : "Polimixina B 11.000 unidades internacionais/mL + Neomicina 3,85 mg/mL + Fluocinolona 0,275 mg/mL + Lidocaína 20 mg/mL solução otológica"
  },
  {
    "code" : "@brasil15957802230",
    "display" : "Polimixina B 12.000 unidades internacionais + Lidocaína 45,4 mg/mL solução otológica"
  },
  {
    "code" : "@brasil14466227826",
    "display" : "Polimixina B 5.000 unidades internacionais/g + Neomicina 5 mg/g + Bacitracina 500 unidades internacionais/g + Óxido de Zinco 635,3 mg/g + Peróxido de Zinco 200 mg/g pó"
  },
  {
    "code" : "@brasil10112739148",
    "display" : "Polimixina B 500.000 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11937323297",
    "display" : "Polimixina B 6.000 unidades internacionais/mL + Neomicina 5 mg/mL + Dexametasona 1 mg/mL suspensão oftálmica"
  },
  {
    "code" : "@brasil17554336856",
    "display" : "Polipeptídeo Dialisável de Extrato de Leucócito 2 mg/mL solução oral"
  },
  {
    "code" : "@brasil16435248697",
    "display" : "Polissulfato de Mucopolissacarídeo 3 mg/g gel"
  },
  {
    "code" : "@brasil12465787475",
    "display" : "Polissulfato de Mucopolissacarídeo 3 mg/g pomada"
  },
  {
    "code" : "@brasil17827197244",
    "display" : "Polissulfato de Mucopolissacarídeo 5 mg/g gel"
  },
  {
    "code" : "@brasil11485007992",
    "display" : "Polissulfato de Mucopolissacarídeo 5 mg/g pomada"
  },
  {
    "code" : "@brasil14956611388",
    "display" : "Polypodium leucotomos 250 mg comprimido"
  },
  {
    "code" : "@brasil11211888184",
    "display" : "Posaconazol 40 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil19816905388",
    "display" : "Povidona 50 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil13646268380",
    "display" : "Pramipexol 0,125 mg comprimido"
  },
  {
    "code" : "@brasil19917155045",
    "display" : "Pramipexol 0,25 mg comprimido"
  },
  {
    "code" : "@brasil18624560131",
    "display" : "Pramipexol 0,375 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil12099449840",
    "display" : "Pramipexol 0,75 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil12831067630",
    "display" : "Pramipexol 1 mg comprimido"
  },
  {
    "code" : "@brasil17326738764",
    "display" : "Pramipexol 1,5 mg comprimido"
  },
  {
    "code" : "@brasil18225694695",
    "display" : "Pramipexol 1,5 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil15180560437",
    "display" : "Pramipexol 3 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil12760218001",
    "display" : "Prasugrel 10 mg comprimido"
  },
  {
    "code" : "@brasil11340408679",
    "display" : "Prasugrel 5 mg comprimido"
  },
  {
    "code" : "@brasil16811442426",
    "display" : "Pravastatina 10 mg comprimido"
  },
  {
    "code" : "@brasil18670412075",
    "display" : "Pravastatina 20 mg comprimido"
  },
  {
    "code" : "@brasil19724036601",
    "display" : "Pravastatina 40 mg comprimido"
  },
  {
    "code" : "@brasil10380466691",
    "display" : "Praziquantel 150 mg comprimido"
  },
  {
    "code" : "@brasil12386907898",
    "display" : "Praziquantel 500 mg comprimido"
  },
  {
    "code" : "@brasil11927052634",
    "display" : "Praziquantel 600 mg comprimido"
  },
  {
    "code" : "@brasil14438068906",
    "display" : "Prednicarbato 2,5 mg/g creme"
  },
  {
    "code" : "@brasil13079733952",
    "display" : "Prednicarbato 2,5 mg/g pomada"
  },
  {
    "code" : "@brasil17652653898",
    "display" : "Prednisolona 1 mg/mL solução oral"
  },
  {
    "code" : "@brasil18400781253",
    "display" : "Prednisolona 1,2 mg/mL suspensão oftálmica"
  },
  {
    "code" : "@brasil15748340752",
    "display" : "Prednisolona 10 mg/mL (1%) solução oftálmica"
  },
  {
    "code" : "@brasil13040133669",
    "display" : "Prednisolona 10 mg/mL suspensão oftálmica"
  },
  {
    "code" : "@brasil15412380661",
    "display" : "Prednisolona 11 mg/mL solução oral"
  },
  {
    "code" : "@brasil11472564786",
    "display" : "Prednisolona 20 mg comprimido"
  },
  {
    "code" : "@brasil12297976911",
    "display" : "Prednisolona 3 mg/mL solução oral"
  },
  {
    "code" : "@brasil19626670151",
    "display" : "Prednisolona 40 mg comprimido"
  },
  {
    "code" : "@brasil19976445024",
    "display" : "Prednisolona 5 mg comprimido"
  },
  {
    "code" : "@brasil16299375178",
    "display" : "Prednisona 20 mg comprimido"
  },
  {
    "code" : "@brasil18221679363",
    "display" : "Prednisona 5 mg comprimido"
  },
  {
    "code" : "@brasil10413982737",
    "display" : "Pregabalina 100 mg cápsula"
  },
  {
    "code" : "@brasil17680936973",
    "display" : "Pregabalina 150 mg cápsula"
  },
  {
    "code" : "@brasil11357924323",
    "display" : "Pregabalina 150 mg comprimido"
  },
  {
    "code" : "@brasil16275943652",
    "display" : "Pregabalina 25 mg cápsula"
  },
  {
    "code" : "@brasil11970317653",
    "display" : "Pregabalina 50 mg cápsula"
  },
  {
    "code" : "@brasil12403972429",
    "display" : "Pregabalina 75 mg cápsula"
  },
  {
    "code" : "@brasil10616219434",
    "display" : "Pregabalina 75 mg comprimido"
  },
  {
    "code" : "@brasil13481484876",
    "display" : "Prilocaína 54 mg/1,8 mL + Felipressina 0,054 unidades internacionais/1,8 mL solução para injeção; carpule"
  },
  {
    "code" : "@brasil17651235345",
    "display" : "Primaquina 15 mg comprimido"
  },
  {
    "code" : "@brasil12375058569",
    "display" : "Primaquina 5 mg comprimido"
  },
  {
    "code" : "@brasil12463602042",
    "display" : "Primidona 100 mg comprimido"
  },
  {
    "code" : "@brasil16551143596",
    "display" : "Primidona 250 mg comprimido"
  },
  {
    "code" : "@brasil14932512094",
    "display" : "Progesterona 100 mg cápsula"
  },
  {
    "code" : "@brasil16493693026",
    "display" : "Progesterona 200 mg cápsula"
  },
  {
    "code" : "@brasil13428898893",
    "display" : "Progesterona 80 mg/g gel vaginal"
  },
  {
    "code" : "@brasil19508452524",
    "display" : "Promestrieno 10 mg cápsula vaginal"
  },
  {
    "code" : "@brasil11464164694",
    "display" : "Promestrieno 10 mg/g creme vaginal"
  },
  {
    "code" : "@brasil15000982855",
    "display" : "Prometazina 0,565 mg/mL + Sulfoguaiacol de Potássio 9 mg/mL xarope"
  },
  {
    "code" : "@brasil13994702084",
    "display" : "Prometazina 1,130 mg/mL + Sulfoguaiacol de Potássio 9 mg/mL xarope"
  },
  {
    "code" : "@brasil16766144023",
    "display" : "Prometazina 20 mg/g creme"
  },
  {
    "code" : "@brasil19858015438",
    "display" : "Prometazina 50 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17573882635",
    "display" : "Propafenona 150 mg comprimido"
  },
  {
    "code" : "@brasil10471762865",
    "display" : "Propafenona 300 mg comprimido"
  },
  {
    "code" : "@brasil17013920289",
    "display" : "Propatilnitrato 10 mg comprimido sublingual"
  },
  {
    "code" : "@brasil16372062791",
    "display" : "Propifenazona 150 mg + Paracetamol 250 mg + Cafeína 50 mg comprimido"
  },
  {
    "code" : "@brasil13246214074",
    "display" : "Propiltiouracila 100 mg comprimido"
  },
  {
    "code" : "@brasil18462939873",
    "display" : "Propionato de Fluticasona 0,05 mg/g pomada"
  },
  {
    "code" : "@brasil14749714418",
    "display" : "Propionato de Fluticasona 0,25 mg/mL suspensão para inalação 2 mL; ampola"
  },
  {
    "code" : "@brasil13728204753",
    "display" : "Propionato de Fluticasona 0,5 mg/g creme"
  },
  {
    "code" : "@brasil10920176161",
    "display" : "Propionato de Fluticasona 1 mg/mL suspensão para inalação 2 mL; ampola"
  },
  {
    "code" : "@brasil11250018151",
    "display" : "Propionato de Fluticasona 100 microgramas/dose + Salmeterol 50 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "@brasil11585684204",
    "display" : "Propionato de Fluticasona 125 microgramas/dose + Salmeterol 25 microgramas/dose suspensão aerossol; inalador"
  },
  {
    "code" : "@brasil10171804473",
    "display" : "Propionato de Fluticasona 250 microgramas cápsula para inalação"
  },
  {
    "code" : "@brasil15328752066",
    "display" : "Propionato de Fluticasona 250 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "@brasil13710015017",
    "display" : "Propionato de Fluticasona 250 microgramas/dose + Salmeterol 25 microgramas/dose suspensão aerossol; inalador"
  },
  {
    "code" : "@brasil16701330603",
    "display" : "Propionato de Fluticasona 250 microgramas/dose + Salmeterol 50 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "@brasil13662414878",
    "display" : "Propionato de Fluticasona 250 microgramas/dose + Salmeterol 50 microgramas/dose suspensão aerossol"
  },
  {
    "code" : "@brasil12702114816",
    "display" : "Propionato de Fluticasona 250 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "@brasil17288669771",
    "display" : "Propionato de Fluticasona 250 microgramas/dose suspensão aerossol; inalador"
  },
  {
    "code" : "@brasil13987743949",
    "display" : "Propionato de Fluticasona 50 microgramas/dose + Salmeterol 25 microgramas/dose suspensão aerossol; inalador"
  },
  {
    "code" : "@brasil15510655943",
    "display" : "Propionato de Fluticasona 50 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "@brasil14058407668",
    "display" : "Propionato de Fluticasona 50 microgramas/dose suspensão aerossol; inalador"
  },
  {
    "code" : "@brasil18659209661",
    "display" : "Propionato de Fluticasona 50 microgramas/dose suspensão spray"
  },
  {
    "code" : "@brasil16458720187",
    "display" : "Propionato de Fluticasona 500 microgramas/dose + Salmeterol 50 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "@brasil13388783859",
    "display" : "Propionato de Fluticasona 500 microgramas/dose + Salmeterol 50 microgramas/dose suspensão aerossol"
  },
  {
    "code" : "@brasil17651505075",
    "display" : "Propionato de Testosterona 30 mg/1 mL + Fempropionato de Testosterona 60 mg/1 mL + Isocaproato de Testosterona 60 mg/1 mL + Decanoato de Testosterona 100 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15217030582",
    "display" : "Propofol 1 g/100 mL emulsão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10783096272",
    "display" : "Propofol 1 g/50 mL emulsão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15884919068",
    "display" : "Propofol 1 g/50 mL emulsão para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil14930596494",
    "display" : "Propofol 100 mg/10 mL emulsão para injeção; ampola"
  },
  {
    "code" : "@brasil18264389919",
    "display" : "Propofol 100 mg/10 mL emulsão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16121542392",
    "display" : "Propofol 200 mg/20 mL emulsão para injeção; ampola"
  },
  {
    "code" : "@brasil18972661091",
    "display" : "Propofol 200 mg/20 mL emulsão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16612530224",
    "display" : "Propofol 500 mg/50 mL emulsão para injeção; ampola"
  },
  {
    "code" : "@brasil10070136011",
    "display" : "Propofol 500 mg/50 mL emulsão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16409128824",
    "display" : "Propofol 500 mg/50 mL emulsão para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil16674160598",
    "display" : "Propranolol 10 mg comprimido"
  },
  {
    "code" : "@brasil13044095627",
    "display" : "Propranolol 160 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil10318690221",
    "display" : "Propranolol 3,75 mg/mL solução oral"
  },
  {
    "code" : "@brasil10341895752",
    "display" : "Propranolol 40 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil16349413650",
    "display" : "Propranolol 40 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "@brasil19059031323",
    "display" : "Propranolol 40 mg comprimido"
  },
  {
    "code" : "@brasil18721922809",
    "display" : "Propranolol 80 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil15916011905",
    "display" : "Propranolol 80 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "@brasil13187593558",
    "display" : "Propranolol 80 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil10217808297",
    "display" : "Propranolol 80 mg comprimido"
  },
  {
    "code" : "@brasil16593405552",
    "display" : "Protamina 50 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18754232783",
    "display" : "Proximetacaína 5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil19486853114",
    "display" : "Prucaloprida 1 mg comprimido"
  },
  {
    "code" : "@brasil12909711256",
    "display" : "Prucaloprida 2 mg comprimido"
  },
  {
    "code" : "@brasil17273077150",
    "display" : "Quelato de Ferro 150 mg/mL (Ferro 21 mg/mL) + Ácido Fólico 0,25 mg/mL + Cianocobalamina 7,5 microgramas/mL solução oral"
  },
  {
    "code" : "@brasil13742623070",
    "display" : "Quelato de Ferro 20 mg/mL (Ferro 2,77 mg/mL) + Ácido Fólico 0,333 mg/mL + Cianocobalamina 1 micrograma/mL elixir"
  },
  {
    "code" : "@brasil10665997564",
    "display" : "Quelato de Ferro 300 mg (Ferro 41,66 mg) + Ácido Fólico 5 mg + Cianocobalamina 15 microgramas comprimido"
  },
  {
    "code" : "@brasil14584294560",
    "display" : "Queratina 20 mg + Cistina 20 mg + Ácido paraminobenzóico 20 mg + Levedura 100 mg + Tiamina 60 mg + Pantotenato de Cálcio 60 mg cápsula"
  },
  {
    "code" : "@brasil18667789880",
    "display" : "Quetiapina 100 mg comprimido"
  },
  {
    "code" : "@brasil17740097852",
    "display" : "Quetiapina 200 mg comprimido"
  },
  {
    "code" : "@brasil12322430006",
    "display" : "Quetiapina 200 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil18549768074",
    "display" : "Quetiapina 25 mg comprimido"
  },
  {
    "code" : "@brasil19051753046",
    "display" : "Quetiapina 300 mg comprimido"
  },
  {
    "code" : "@brasil12660395467",
    "display" : "Quetiapina 300 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil17947383826",
    "display" : "Quetiapina 50 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil14632959219",
    "display" : "Quetiapina 50 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil17150779483",
    "display" : "Rabeprazol 10 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil12934315308",
    "display" : "Rabeprazol 20 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil12445222289",
    "display" : "Racecadotrila 10 mg granulado"
  },
  {
    "code" : "@brasil13147707685",
    "display" : "Racecadotrila 100 mg cápsula"
  },
  {
    "code" : "@brasil10364841464",
    "display" : "Racecadotrila 100 mg comprimido"
  },
  {
    "code" : "@brasil11749652903",
    "display" : "Racecadotrila 30 mg granulado"
  },
  {
    "code" : "@brasil19115810922",
    "display" : "Raloxifeno 60 mg comprimido"
  },
  {
    "code" : "@brasil19645646594",
    "display" : "Raltegravir 100 mg comprimido"
  },
  {
    "code" : "@brasil16144498814",
    "display" : "Raltegravir 100 mg comprimido mastigável"
  },
  {
    "code" : "@brasil12657502620",
    "display" : "Raltegravir 25 mg comprimido mastigável"
  },
  {
    "code" : "@brasil16713429479",
    "display" : "Raltegravir 400 mg comprimido"
  },
  {
    "code" : "@brasil16622783052",
    "display" : "Ramipril 10 mg cápsula"
  },
  {
    "code" : "@brasil13275081517",
    "display" : "Ramipril 10 mg comprimido"
  },
  {
    "code" : "@brasil17503511612",
    "display" : "Ramipril 2,5 mg cápsula"
  },
  {
    "code" : "@brasil15333694856",
    "display" : "Ramipril 2,5 mg comprimido"
  },
  {
    "code" : "@brasil12822870194",
    "display" : "Ramipril 5 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil12315580985",
    "display" : "Ramipril 5 mg + Hidroclorotiazida 25 mg cápsula"
  },
  {
    "code" : "@brasil17837323654",
    "display" : "Ramipril 5 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "@brasil13094442097",
    "display" : "Ramipril 5 mg cápsula"
  },
  {
    "code" : "@brasil18416740648",
    "display" : "Ramipril 5 mg comprimido"
  },
  {
    "code" : "@brasil16953077712",
    "display" : "Ramucirumabe 100 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11477255216",
    "display" : "Ramucirumabe 500 mg/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18005385674",
    "display" : "Ranelato de Estrôncio 2 g granulado"
  },
  {
    "code" : "@brasil15490152466",
    "display" : "Ranibizumabe 1,65 mg/0,165 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil15497611960",
    "display" : "Ranibizumabe 2,3 mg/0,23 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13039138653",
    "display" : "Ranibizumabe 2,3 mg/2,3 mL suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil13914480667",
    "display" : "Ranitidina 15 mg/mL xarope"
  },
  {
    "code" : "@brasil11357183363",
    "display" : "Ranitidina 150 mg comprimido"
  },
  {
    "code" : "@brasil12447790187",
    "display" : "Ranitidina 300 mg comprimido"
  },
  {
    "code" : "@brasil12944137995",
    "display" : "Ranitidina 40 mg/mL solução oral"
  },
  {
    "code" : "@brasil12803794491",
    "display" : "Ranitidina 50 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11127221006",
    "display" : "Ranolazina 1 g comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil13639618598",
    "display" : "Ranolazina 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil12628721782",
    "display" : "Rasagilina 1 mg comprimido"
  },
  {
    "code" : "@brasil18595177975",
    "display" : "Rasburicase 1,5 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11105436086",
    "display" : "Reboxetina 4 mg comprimido"
  },
  {
    "code" : "@brasil11520799221",
    "display" : "Regorafenibe 40 mg comprimido"
  },
  {
    "code" : "@brasil16344554996",
    "display" : "Remifentanila 1 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19923082057",
    "display" : "Remifentanila 2 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16893884209",
    "display" : "Remifentanila 5 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19179280267",
    "display" : "Repaglinida 0,5 mg comprimido"
  },
  {
    "code" : "@brasil18252102403",
    "display" : "Repaglinida 1 mg comprimido"
  },
  {
    "code" : "@brasil13404540682",
    "display" : "Repaglinida 2 mg comprimido"
  },
  {
    "code" : "@brasil16740001370",
    "display" : "Retapamulina 10 mg/g pomada"
  },
  {
    "code" : "@brasil13443095322",
    "display" : "Retinol 10 mg/g gel oftálmico"
  },
  {
    "code" : "@brasil13904430831",
    "display" : "Retinol 10.000 unidades internacionais/g + Aminoácidos 25 mg/g + Metionina 5 mg/g + Cloranfenicol 5 mg/g pomada oftálmica"
  },
  {
    "code" : "@brasil10173663496",
    "display" : "Retinol 100.000 unidades internacionais cápsula"
  },
  {
    "code" : "@brasil10880891689",
    "display" : "Retinol 150.000 unidades internacionais/mL solução oral"
  },
  {
    "code" : "@brasil15526108400",
    "display" : "Retinol 20.000 unidades internacionais/mL + Colecalciferol 1.600 unidades internacionais/mL + Racealfatocoferol 30 mg/mL solução oral"
  },
  {
    "code" : "@brasil13563329635",
    "display" : "Retinol 200.000 unidades internacionals cápsula"
  },
  {
    "code" : "@brasil11847739881",
    "display" : "Retinol 3.000 unidades internacionais + Piridoxina 10 mg + Colecalciferol 200 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil13987915024",
    "display" : "Retinol 3.000 unidades internacionais/mL + Colecalciferol 800 unidades internacionais/mL solução oral"
  },
  {
    "code" : "@brasil11629740577",
    "display" : "Retinol 5.000 unidades internacionais + Piridoxina 100 mg + Racealfatocoferol 300 mg cápsula"
  },
  {
    "code" : "@brasil15326817355",
    "display" : "Retinol 5.000 unidades internacionais/g + Colecalciferol 1.000 unidades internacionais/g + Racealfatocoferol 20 unidades internacionais/g + Alantoína 2 mg/g creme"
  },
  {
    "code" : "@brasil13975269414",
    "display" : "Retinol 5.000 unidades internacionais/g + Colecalciferol 100 unidades internacionais/g + Óxido de Zinco 66 mg/g pomada"
  },
  {
    "code" : "@brasil10447259377",
    "display" : "Retinol 5.000 unidades internacionais/g + Colecalciferol 900 unidades internacionais/g + Óxido de Zinco 150 mg/g + Óleo de Fígado de Bacalhau 86,6 mg/g pomada"
  },
  {
    "code" : "@brasil10728649608",
    "display" : "Retinol 5.000 unidades internacionais/g + Colecalciferol 900 unidades internacionais/g + Óxido de Zinco 150 mg/g pomada"
  },
  {
    "code" : "@brasil10606219320",
    "display" : "Retinol 5.500 unidades internacionais/mL + Colecalciferol 2.200 unidades internacionais/mL solução oral"
  },
  {
    "code" : "@brasil16917666117",
    "display" : "Retinol 50.000 unidades internacionais comprimido"
  },
  {
    "code" : "@brasil12699808703",
    "display" : "Retinol 50.000 unidades internacionais/mL + Colecalciferol 10.000 unidades internacionais/mL solução oral"
  },
  {
    "code" : "@brasil13200172783",
    "display" : "Ribavirina 200 mg cápsula"
  },
  {
    "code" : "@brasil19919390601",
    "display" : "Ribavirina 250 mg cápsula"
  },
  {
    "code" : "@brasil19666869172",
    "display" : "Rifabutina 150 mg cápsula"
  },
  {
    "code" : "@brasil19998178563",
    "display" : "Rifamicina SV Sódica 10 mg/mL solução spray"
  },
  {
    "code" : "@brasil19065848995",
    "display" : "Rifampicina 150 mg + Isoniazida 100 mg cápsula"
  },
  {
    "code" : "@brasil18406344928",
    "display" : "Rifampicina 150 mg + Isoniazida 75 mg + Pirazinamida 400 mg + Etambutol 275 mg comprimido"
  },
  {
    "code" : "@brasil10301980962",
    "display" : "Rifampicina 150 mg + Isoniazida 75 mg comprimido"
  },
  {
    "code" : "@brasil15991921354",
    "display" : "Rifampicina 20 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil12884136225",
    "display" : "Rifampicina 300 mg + Isoniazida 200 mg cápsula"
  },
  {
    "code" : "@brasil17942043213",
    "display" : "Rifampicina 300 mg cápsula"
  },
  {
    "code" : "@brasil19434250320",
    "display" : "Rilmenidina 1 mg comprimido"
  },
  {
    "code" : "@brasil17782110717",
    "display" : "Riluzol 50 mg comprimido"
  },
  {
    "code" : "@brasil19436070767",
    "display" : "Ringer com Lactato solução para injeção 1 L; bolsa"
  },
  {
    "code" : "@brasil16704153562",
    "display" : "Ringer com Lactato solução para injeção 1 L; frasco-ampola"
  },
  {
    "code" : "@brasil12936178037",
    "display" : "Ringer com Lactato solução para injeção 250 mL; bolsa"
  },
  {
    "code" : "@brasil18820079422",
    "display" : "Ringer com Lactato solução para injeção 250 mL; frasco-ampola"
  },
  {
    "code" : "@brasil16126265678",
    "display" : "Ringer com Lactato solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "@brasil10952434250",
    "display" : "Ringer com Lactato solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "@brasil17165906387",
    "display" : "Ringer solução para injeção 1 L; bolsa"
  },
  {
    "code" : "@brasil11610016031",
    "display" : "Ringer solução para injeção 1 L; frasco-ampola"
  },
  {
    "code" : "@brasil19353637180",
    "display" : "Ringer solução para injeção 250 mL; bolsa"
  },
  {
    "code" : "@brasil18909684649",
    "display" : "Ringer solução para injeção 250 mL; frasco-ampola"
  },
  {
    "code" : "@brasil16737094423",
    "display" : "Ringer solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "@brasil12661020188",
    "display" : "Ringer solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "@brasil18707749197",
    "display" : "Riociguate 0,5 mg comprimido"
  },
  {
    "code" : "@brasil14312792562",
    "display" : "Riociguate 1 mg comprimido"
  },
  {
    "code" : "@brasil13573318684",
    "display" : "Riociguate 1,5 mg comprimido"
  },
  {
    "code" : "@brasil19077924720",
    "display" : "Riociguate 2 mg comprimido"
  },
  {
    "code" : "@brasil10320704308",
    "display" : "Riociguate 2,5 mg comprimido"
  },
  {
    "code" : "@brasil17920372221",
    "display" : "Risedronato Sódico 150 mg comprimido"
  },
  {
    "code" : "@brasil11196317542",
    "display" : "Risedronato Sódico 35 mg comprimido"
  },
  {
    "code" : "@brasil14747806194",
    "display" : "Risedronato Sódico 35 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil15192799757",
    "display" : "Risedronato Sódico 5 mg comprimido"
  },
  {
    "code" : "@brasil19679468849",
    "display" : "Risperidona 0,25 mg comprimido"
  },
  {
    "code" : "@brasil18046737058",
    "display" : "Risperidona 0,5 mg comprimido"
  },
  {
    "code" : "@brasil16916137659",
    "display" : "Risperidona 1 mg comprimido"
  },
  {
    "code" : "@brasil14950138147",
    "display" : "Risperidona 1 mg/mL solução oral"
  },
  {
    "code" : "@brasil16029128222",
    "display" : "Risperidona 2 mg comprimido"
  },
  {
    "code" : "@brasil18834362269",
    "display" : "Risperidona 25 mg pó e diluente para suspensão para injeção de liberação prolongada; frasco-ampola"
  },
  {
    "code" : "@brasil13711945370",
    "display" : "Risperidona 25 mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19192497122",
    "display" : "Risperidona 3 mg comprimido"
  },
  {
    "code" : "@brasil13597821148",
    "display" : "Risperidona 37,5 mg pó e diluente para suspensão para injeção de liberação prolongada; frasco-ampola"
  },
  {
    "code" : "@brasil11068663503",
    "display" : "Risperidona 37,5 mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19082921004",
    "display" : "Risperidona 50 mg pó e diluente para suspensão para injeção de liberação prolongada; frasco-ampola"
  },
  {
    "code" : "@brasil16241408385",
    "display" : "Risperidona 50 mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18740241394",
    "display" : "Ritonavir 100 mg cápsula"
  },
  {
    "code" : "@brasil17078809798",
    "display" : "Ritonavir 100 mg comprimido"
  },
  {
    "code" : "@brasil13370835373",
    "display" : "Ritonavir 80 mg/mL solução oral"
  },
  {
    "code" : "@brasil10815070550",
    "display" : "Rituximabe 1,4 g/11,7 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11976062358",
    "display" : "Rituximabe 100 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11247315472",
    "display" : "Rituximabe 500 mg/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18512285814",
    "display" : "Rivaroxabana 10 mg comprimido"
  },
  {
    "code" : "@brasil17132831230",
    "display" : "Rivaroxabana 15 mg comprimido"
  },
  {
    "code" : "@brasil13733638005",
    "display" : "Rivaroxabana 20 mg comprimido"
  },
  {
    "code" : "@brasil14358005470",
    "display" : "Rivastigmina 1,5 mg cápsula"
  },
  {
    "code" : "@brasil17069173292",
    "display" : "Rivastigmina 13,3 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "@brasil19494631539",
    "display" : "Rivastigmina 2 mg/mL solução oral"
  },
  {
    "code" : "@brasil13584018584",
    "display" : "Rivastigmina 3 mg cápsula"
  },
  {
    "code" : "@brasil17071836875",
    "display" : "Rivastigmina 4,5 mg cápsula"
  },
  {
    "code" : "@brasil15658876676",
    "display" : "Rivastigmina 4,6 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "@brasil13935923317",
    "display" : "Rivastigmina 6 mg cápsula"
  },
  {
    "code" : "@brasil17085501323",
    "display" : "Rivastigmina 9,5 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "@brasil17844114774",
    "display" : "Rizatriptana 10 mg comprimido"
  },
  {
    "code" : "@brasil18835691890",
    "display" : "Roflumilaste 500 microgramas comprimido"
  },
  {
    "code" : "@brasil13931276325",
    "display" : "Romiplostim 250 microgramas pó para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11746362587",
    "display" : "Ropivacaína 1,50 g/20 mL (7,5%) solução para injeção; frasco"
  },
  {
    "code" : "@brasil19095737605",
    "display" : "Ropivacaína 100 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15781671054",
    "display" : "Ropivacaína 150 mg/20 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16797432475",
    "display" : "Ropivacaína 150 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13293906349",
    "display" : "Ropivacaína 200 mg/20 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18412576770",
    "display" : "Ropivacaína 200 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17692645486",
    "display" : "Ropivacaína 40 mg/20 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15872366683",
    "display" : "Ropivacaína 40 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18313298929",
    "display" : "Ropivacaína 75 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13823032744",
    "display" : "Rosuvastatina 10 mg comprimido"
  },
  {
    "code" : "@brasil13056824721",
    "display" : "Rosuvastatina 20 mg comprimido"
  },
  {
    "code" : "@brasil10677016665",
    "display" : "Rosuvastatina 40 mg comprimido"
  },
  {
    "code" : "@brasil13815025680",
    "display" : "Rosuvastatina 5 mg comprimido"
  },
  {
    "code" : "@brasil11796121839",
    "display" : "Rotigotina 2 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "@brasil12412383101",
    "display" : "Rotigotina 4 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "@brasil16919744662",
    "display" : "Rotigotina 6 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "@brasil13380643708",
    "display" : "Rotigotina 8 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "@brasil17002927172",
    "display" : "Rupatadina 10 mg comprimido"
  },
  {
    "code" : "@brasil14918756385",
    "display" : "Ruxolitinibe 15 mg comprimido"
  },
  {
    "code" : "@brasil13872435365",
    "display" : "Ruxolitinibe 20 mg comprimido"
  },
  {
    "code" : "@brasil19307467245",
    "display" : "Ruxolitinibe 5 mg comprimido"
  },
  {
    "code" : "@brasil14205286924",
    "display" : "Saccharomyces boulardii 100 mg cápsula"
  },
  {
    "code" : "@brasil10983258699",
    "display" : "Saccharomyces boulardii 200 mg cápsula"
  },
  {
    "code" : "@brasil19666009943",
    "display" : "Saccharomyces boulardii 200 mg cápsula e Saccharomyces boulardii 250 mg cápsula"
  },
  {
    "code" : "@brasil10112207214",
    "display" : "Saccharomyces boulardii 200 mg pó para solução oral"
  },
  {
    "code" : "@brasil19484867292",
    "display" : "Saccharomyces boulardii 200 mg pó para solução oral e Saccharomyces boulardii 250 mg pó para solução oral"
  },
  {
    "code" : "@brasil12354127281",
    "display" : "Saccharomyces boulardii 250 mg cápsula"
  },
  {
    "code" : "@brasil15818648491",
    "display" : "Saccharomyces boulardii 250 mg pó para solução oral"
  },
  {
    "code" : "@brasil16511585688",
    "display" : "Saccharomyces cerevisiae 100 milhões/mL suspensão oral"
  },
  {
    "code" : "@brasil13918611186",
    "display" : "Saccharomyces cerevisiae 50 milhões/mL suspensão oral"
  },
  {
    "code" : "@brasil19923595364",
    "display" : "Salbutamol 0,4 mg/mL + Guaifenesina 20 mg/mL solução oral"
  },
  {
    "code" : "@brasil13175719149",
    "display" : "Salbutamol 0,4 mg/mL solução oral"
  },
  {
    "code" : "@brasil15312964835",
    "display" : "Salbutamol 0,4 mg/mL xarope"
  },
  {
    "code" : "@brasil15208471737",
    "display" : "Salbutamol 0,5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10100064518",
    "display" : "Salbutamol 1 mg/mL solução para inalação 2,5 mL; ampola"
  },
  {
    "code" : "@brasil17203121786",
    "display" : "Salbutamol 100 microgramas/dose suspensão aerossol; inalador"
  },
  {
    "code" : "@brasil11670508794",
    "display" : "Salbutamol 2 mg comprimido"
  },
  {
    "code" : "@brasil12403710913",
    "display" : "Salbutamol 200 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "@brasil11989962170",
    "display" : "Salbutamol 4 mg comprimido"
  },
  {
    "code" : "@brasil13861982712",
    "display" : "Salbutamol 5 mg/mL solução para inalação 10 mL; frasco"
  },
  {
    "code" : "@brasil17534080916",
    "display" : "Salbutamol 5 mg/mL solução para inalação 5 mL; frasco"
  },
  {
    "code" : "@brasil16777537628",
    "display" : "Salicilato de Bismuto 17,46 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil12946420723",
    "display" : "Salicilato de Bismuto 500 mg cápsula"
  },
  {
    "code" : "@brasil10849857777",
    "display" : "Salicilato de Etilenoglicol 175 mg + Levomentol 140 mg + Acetato de Racealfatocoferol 140 mg + Cânfora 42 mg emplastro"
  },
  {
    "code" : "@brasil13046583944",
    "display" : "Salicilato de Metila 0,02 mL/g + Terebenthina 0,05 mL/g + Cânfora 30mg/g  + Mentol 5 mg/g pomada"
  },
  {
    "code" : "@brasil10220595280",
    "display" : "Salicilato de Metila 0,03 mL/mL + Cânfora 33 mg/mL + Mentol 8,3 mg/mL solução aerossol"
  },
  {
    "code" : "@brasil11266912380",
    "display" : "Salicilato de Metila 0,04 mL/g + Terebintina 0,22 mL/g + Cânfora 44 mg/g + Mentol 98 mg/g gel"
  },
  {
    "code" : "@brasil12777648671",
    "display" : "Salicilato de Metila 105 mg + Levomentol 31,5 mg adesivo transdérmico"
  },
  {
    "code" : "@brasil13410898169",
    "display" : "Salicilato de Metila 144,14 mg + Salicilato de Etilenoglicol 21,84 mg + Levomentol 131,04 mg + Cânfora 28,4 mg + Timol 18,34 mg emplastro"
  },
  {
    "code" : "@brasil19252981252",
    "display" : "Salicilato de Metila 150 mg/g + Levomentol 70 mg/g gel"
  },
  {
    "code" : "@brasil19986143724",
    "display" : "Salicilato de Metila 150 mg/g + Mentol 100 mg/g creme"
  },
  {
    "code" : "@brasil15628605600",
    "display" : "Salicilato de Metila 150 mg/g + Mentol 100 mg/g gel"
  },
  {
    "code" : "@brasil16661465684",
    "display" : "Salicilato de Metila 250 mg/g + Mentol 250 mg/g pomada"
  },
  {
    "code" : "@brasil10710522401",
    "display" : "Salicilato de Metila 30 mg/mL + Levomentol 38,5 mg/mL + Cânfora 38,5 mg/mL + Salicilato de Etilenoglicol 19 mg/mL solução aerossol"
  },
  {
    "code" : "@brasil15395739566",
    "display" : "Salicilato de Metila 36,04 mg + Salicilato de Etilenoglicol 5,46 mg + Levomentol 32,76 mg + Cânfora 7,1 mg + Timol 4,59 mg emplastro"
  },
  {
    "code" : "@brasil17855898119",
    "display" : "Salicilato de Metila 44 mg/g + Cânfora 44 mg/g + Mentol 20 mg/g pomada"
  },
  {
    "code" : "@brasil18719721824",
    "display" : "Salicilato de Metila 50 mg/g + Mentol 10 mg/g solução aerossol"
  },
  {
    "code" : "@brasil15246423253",
    "display" : "Salicilato de Metila 52,5 mg/g + Cânfora 44,4 mg/g + Mentol 20 mg/g pomada"
  },
  {
    "code" : "@brasil16227957256",
    "display" : "Salicilato de Metila 75 mg/mL + Cânfora 57,6 mg/mL + Mentol 14,4 mg/mL linimento"
  },
  {
    "code" : "@brasil17542028451",
    "display" : "Salmeterol 50 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "@brasil17620821544",
    "display" : "Sapropterina 100 mg comprimido"
  },
  {
    "code" : "@brasil10834335749",
    "display" : "Saquinavir 200 mg cápsula"
  },
  {
    "code" : "@brasil15272061148",
    "display" : "Saxagliptina 2,5 mg + Metformina 1 g comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil14561685969",
    "display" : "Saxagliptina 2,5 mg comprimido"
  },
  {
    "code" : "@brasil16415325062",
    "display" : "Saxagliptina 5 mg + Metformina 1 g comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil18597699838",
    "display" : "Saxagliptina 5 mg + metformina 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil16827770541",
    "display" : "Saxagliptina 5 mg comprimido"
  },
  {
    "code" : "@brasil17439173111",
    "display" : "Schinus terebenthifolius 0,67 mL/g creme"
  },
  {
    "code" : "@brasil16897433796",
    "display" : "Schinus terebenthifolius 7% creme vaginal"
  },
  {
    "code" : "@brasil14153356694",
    "display" : "Secnidazol 1 g comprimido"
  },
  {
    "code" : "@brasil12071357556",
    "display" : "Secnidazol 1 g comprimido e Tioconazol 20 mg/g + Tinidazol 30 mg/g creme vaginal"
  },
  {
    "code" : "@brasil18566129549",
    "display" : "Secnidazol 30 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil14201459598",
    "display" : "Secnidazol 500 mg comprimido"
  },
  {
    "code" : "@brasil11148438435",
    "display" : "Secuquinumabe 150 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16418154057",
    "display" : "Secuquinumabe 150 mg/1 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil18590413347",
    "display" : "Secuquinumabe 150 mg/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil19659254613",
    "display" : "Selegilina 10 mg comprimido"
  },
  {
    "code" : "@brasil14198579157",
    "display" : "Selegilina 5 mg comprimido"
  },
  {
    "code" : "@brasil12725611302",
    "display" : "Sertralina 100 mg comprimido"
  },
  {
    "code" : "@brasil14754539880",
    "display" : "Sertralina 25 mg comprimido"
  },
  {
    "code" : "@brasil14657767455",
    "display" : "Sertralina 50 mg comprimido"
  },
  {
    "code" : "@brasil12289198945",
    "display" : "Sertralina 75 mg comprimido"
  },
  {
    "code" : "@brasil14829274120",
    "display" : "Sevoflurano líquido para inalação 100 mL"
  },
  {
    "code" : "@brasil19544819171",
    "display" : "Sevoflurano líquido para inalação 250 mL"
  },
  {
    "code" : "@brasil12664849293",
    "display" : "Sibutramina 10 mg cápsula"
  },
  {
    "code" : "@brasil14569890827",
    "display" : "Sibutramina 10 mg comprimido"
  },
  {
    "code" : "@brasil10679881432",
    "display" : "Sibutramina 15 mg cápsula"
  },
  {
    "code" : "@brasil10479302238",
    "display" : "Sibutramina 15 mg comprimido"
  },
  {
    "code" : "@brasil19760709337",
    "display" : "Sildenafila 100 mg comprimido"
  },
  {
    "code" : "@brasil18358291309",
    "display" : "Sildenafila 12,5 mg cápsula"
  },
  {
    "code" : "@brasil19544426498",
    "display" : "Sildenafila 20 mg comprimido"
  },
  {
    "code" : "@brasil11745764455",
    "display" : "Sildenafila 25 mg comprimido"
  },
  {
    "code" : "@brasil11961656986",
    "display" : "Sildenafila 50 mg comprimido"
  },
  {
    "code" : "@brasil10710693224",
    "display" : "Silimarina 70 mg + Metionina 100 mg comprimido"
  },
  {
    "code" : "@brasil11190425083",
    "display" : "Silodosina 4 mg cápsula"
  },
  {
    "code" : "@brasil18545405628",
    "display" : "Silodosina 8 mg cápsula"
  },
  {
    "code" : "@brasil12881910476",
    "display" : "Siltuximabe 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17442581696",
    "display" : "Siltuximabe 400 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12131873155",
    "display" : "Silybum marianum 100 mg comprimido"
  },
  {
    "code" : "@brasil17838122114",
    "display" : "Silybum marianum 200 mg cápsula"
  },
  {
    "code" : "@brasil17003053720",
    "display" : "Simeprevir 150 mg cápsula"
  },
  {
    "code" : "@brasil15549001725",
    "display" : "Simeticona 125 mg cápsula"
  },
  {
    "code" : "@brasil18889840428",
    "display" : "Simeticona 125 mg comprimido mastigável"
  },
  {
    "code" : "@brasil12528261738",
    "display" : "Simeticona 150 mg comprimido"
  },
  {
    "code" : "@brasil17229099586",
    "display" : "Simeticona 150 mg/mL emulsão oral"
  },
  {
    "code" : "@brasil12183955284",
    "display" : "Simeticona 40 mg comprimido"
  },
  {
    "code" : "@brasil17424708041",
    "display" : "Simeticona 75 mg/mL emulsão oral"
  },
  {
    "code" : "@brasil12842578833",
    "display" : "Simeticona 75 mg/mL solução oral"
  },
  {
    "code" : "@brasil12024983857",
    "display" : "Simeticona 75 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil18028411954",
    "display" : "Simeticona 80 mg comprimido"
  },
  {
    "code" : "@brasil14907084985",
    "display" : "Simeticona 80 mg/mL + Homatropina 2,5 mg/mL emulsão oral"
  },
  {
    "code" : "@brasil18249370303",
    "display" : "Simeticona 80 mg/mL + Homatropina 2,5 mg/mL solução oral"
  },
  {
    "code" : "@brasil18620698942",
    "display" : "Sinvastatina 10 mg comprimido"
  },
  {
    "code" : "@brasil11074613481",
    "display" : "Sinvastatina 20 mg comprimido"
  },
  {
    "code" : "@brasil14331014298",
    "display" : "Sinvastatina 40 mg comprimido"
  },
  {
    "code" : "@brasil13722288489",
    "display" : "Sinvastatina 5 mg comprimido"
  },
  {
    "code" : "@brasil10845709154",
    "display" : "Sinvastatina 80 mg comprimido"
  },
  {
    "code" : "@brasil11113595887",
    "display" : "Sirolimo 1 mg comprimido"
  },
  {
    "code" : "@brasil11809221832",
    "display" : "Sirolimo 1 mg/mL solução oral"
  },
  {
    "code" : "@brasil12811763753",
    "display" : "Sirolimo 2 mg comprimido"
  },
  {
    "code" : "@brasil19768930410",
    "display" : "Sitagliptina 100 mg + Metformina 1g comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil12017259095",
    "display" : "Sitagliptina 100 mg comprimido"
  },
  {
    "code" : "@brasil10892705144",
    "display" : "Sitagliptina 25 mg comprimido"
  },
  {
    "code" : "@brasil17130164611",
    "display" : "Sitagliptina 50 mg + Metformina 1 g comprimido"
  },
  {
    "code" : "@brasil14561548403",
    "display" : "Sitagliptina 50 mg + Metformina 1 g comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil13553695391",
    "display" : "Sitagliptina 50 mg + Metformina 500 mg comprimido"
  },
  {
    "code" : "@brasil13500951092",
    "display" : "Sitagliptina 50 mg + Metformina 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil14866760590",
    "display" : "Sitagliptina 50 mg + Metformina 850 mg comprimido"
  },
  {
    "code" : "@brasil19131803845",
    "display" : "Sitagliptina 50 mg comprimido"
  },
  {
    "code" : "@brasil19499978001",
    "display" : "Sofosbuvir 400 mg comprimido"
  },
  {
    "code" : "@brasil18767991528",
    "display" : "Solifenacina 10 mg comprimido"
  },
  {
    "code" : "@brasil14874027365",
    "display" : "Solifenacina 5 mg comprimido"
  },
  {
    "code" : "@brasil13426225736",
    "display" : "Solifenacina 6 mg + Tansulosina 0,4 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil18088301826",
    "display" : "Somatostatina 3 mg pó e diluente para injeção; ampola"
  },
  {
    "code" : "@brasil18391218861",
    "display" : "Somatostatina 3 mg pó para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14117537385",
    "display" : "Somatropina 10 mg/1,5 mL solução para injeção; carpule"
  },
  {
    "code" : "@brasil14851417348",
    "display" : "Somatropina 10 mg/1,5 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil12245667866",
    "display" : "Somatropina 12 mg/1,5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15559921100",
    "display" : "Somatropina 12 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15471860723",
    "display" : "Somatropina 12 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16982121258",
    "display" : "Somatropina 12 unidades internacionais/1,5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18501574496",
    "display" : "Somatropina 15 mg/1,5 mL solução para injeção; carpule"
  },
  {
    "code" : "@brasil16005803481",
    "display" : "Somatropina 15 mg/1,5 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil12871984729",
    "display" : "Somatropina 15 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17611205387",
    "display" : "Somatropina 16 unidades internacionais pó e diluente para solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil13413560178",
    "display" : "Somatropina 16 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18451847011",
    "display" : "Somatropina 20 mg/2,5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13164696275",
    "display" : "Somatropina 24 unidades internacionais"
  },
  {
    "code" : "@brasil17750711437",
    "display" : "Somatropina 36 unidades internacionais pó e diluente para solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil16638444722",
    "display" : "Somatropina 36 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14737233447",
    "display" : "Somatropina 4 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17630503043",
    "display" : "Somatropina 4 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16812567091",
    "display" : "Somatropina 4 unidades internacionais/0,5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18032433573",
    "display" : "Somatropina 5 mg/1,5 mL solução para injeção; carpule"
  },
  {
    "code" : "@brasil11158610461",
    "display" : "Somatropina 5 mg/1,5 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil12240390219",
    "display" : "Somatropina 6 mg/1,03 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10764250130",
    "display" : "Somatropina 8 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11984796487",
    "display" : "Somatropina 8 unidades internacionais"
  },
  {
    "code" : "@brasil15265521652",
    "display" : "Sorafenibe 200 mg comprimido"
  },
  {
    "code" : "@brasil19176592526",
    "display" : "Sorbitol 2,7% + Manitol 0,54% solução para irrigação 1 L; frasco-ampola"
  },
  {
    "code" : "@brasil16249674115",
    "display" : "Sorbitol 3% solução para irrigação 3 L; bolsa"
  },
  {
    "code" : "@brasil18371686326",
    "display" : "Sorbitol 714 mg/g + Laurilsulfato de Sódio 7,7 mg/g supositório"
  },
  {
    "code" : "@brasil13885899216",
    "display" : "Sotalol 120 mg comprimido"
  },
  {
    "code" : "@brasil14920164126",
    "display" : "Sotalol 160 mg comprimido"
  },
  {
    "code" : "@brasil14885609059",
    "display" : "Stryphnodendron barbatiman 60 mg/g (6%) pomada"
  },
  {
    "code" : "@brasil19785474275",
    "display" : "Subcitrato de Bismuto Coloidal 120 mg comprimido"
  },
  {
    "code" : "@brasil12286610380",
    "display" : "Subgalato de Bismuto 1,5 mg/g + Óxido de Zinco 45 mg/g gel"
  },
  {
    "code" : "@brasil12257659100",
    "display" : "Subgalato de Bismuto 3 mg/g + Iodeto de Timol 1,5 mg/g + Óxido de Zinco 93,3 mg/g pó"
  },
  {
    "code" : "@brasil10549183925",
    "display" : "Succinato Sódico de Hidrocortisona 100 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13207651434",
    "display" : "Succinato Sódico de Hidrocortisona 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14738016569",
    "display" : "Succinato Sódico de Hidrocortisona 500 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14067128852",
    "display" : "Succinato Sódico de Hidrocortisona 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16121594863",
    "display" : "Succinato Sódico de Metilprednisolona 1 g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13668156063",
    "display" : "Succinato Sódico de Metilprednisolona 125 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15178910608",
    "display" : "Succinato Sódico de Metilprednisolona 125 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14600614209",
    "display" : "Succinato Sódico de Metilprednisolona 40 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14398268193",
    "display" : "Succinato Sódico de Metilprednisolona 500 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18563508965",
    "display" : "Succinato Sódico de Metilprednisolona 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14645065183",
    "display" : "Succinilgelatina 4% solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "@brasil14604945790",
    "display" : "Sucralfato 1 g comprimido mastigável"
  },
  {
    "code" : "@brasil14659313264",
    "display" : "Sucralfato 1g comprimido"
  },
  {
    "code" : "@brasil14121721696",
    "display" : "Sucralfato 200 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil10104963322",
    "display" : "Sufentanila 10 microgramas/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13844696546",
    "display" : "Sufentanila 250 microgramas/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16969974874",
    "display" : "Sufentanila 50 microgramas/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14515684473",
    "display" : "Sugamadex 200 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18769036416",
    "display" : "Sugamadex 200 mg/2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11455725897",
    "display" : "Sugamadex 500 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14062279334",
    "display" : "Sulbutiamina 200 mg comprimido"
  },
  {
    "code" : "@brasil15559433609",
    "display" : "Sulfacetamida Sódica 74 mg/g + Trolamina 20 mg/g pomada"
  },
  {
    "code" : "@brasil10258793625",
    "display" : "Sulfadiazina 150 mg/mL solução oral"
  },
  {
    "code" : "@brasil13779804857",
    "display" : "Sulfadiazina 500 mg comprimido"
  },
  {
    "code" : "@brasil18421854969",
    "display" : "Sulfadiazina de Prata 1% pasta"
  },
  {
    "code" : "@brasil15074823129",
    "display" : "Sulfadiazina de Prata 10 mg/g (1%) + Nitrato de Cério 22 mg/g (2,2%) creme"
  },
  {
    "code" : "@brasil14072290614",
    "display" : "Sulfadiazina de Prata 10 mg/g (1%) + Nitrato de Cério 4 mg/g (0,4%) creme"
  },
  {
    "code" : "@brasil17638931214",
    "display" : "Sulfadiazina de Prata 10 mg/g (1%) + Nitrato de Cério 4 mg/g (0,4%) gel"
  },
  {
    "code" : "@brasil15432817837",
    "display" : "Sulfadiazina de Prata 10 mg/g creme"
  },
  {
    "code" : "@brasil10691478112",
    "display" : "Sulfadiazina de Prata 10 mg/g creme vaginal"
  },
  {
    "code" : "@brasil15063187641",
    "display" : "Sulfametoxazol 40 mg/mL + Trimetoprima 8 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil15789858833",
    "display" : "Sulfametoxazol 400 mg + Trimetoprima 80 mg + Fenazopiridina 50 mg comprimido"
  },
  {
    "code" : "@brasil11346508357",
    "display" : "Sulfametoxazol 400 mg + Trimetoprima 80 mg comprimido"
  },
  {
    "code" : "@brasil18815813639",
    "display" : "Sulfametoxazol 400 mg/5 mL + Trimetoprima 80 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10965197207",
    "display" : "Sulfametoxazol 80 mg/mL + Trimetoprima 16 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil12713330035",
    "display" : "Sulfametoxazol 800 mg + Trimetoprima 160 mg comprimido"
  },
  {
    "code" : "@brasil16251479745",
    "display" : "Sulfassalazina 500 mg comprimido"
  },
  {
    "code" : "@brasil17660213639",
    "display" : "Sulfato de Glicosamina 500 mg + Sulfato de Condroitina 400 mg cápsula"
  },
  {
    "code" : "@brasil13899807457",
    "display" : "Sulfato de Magnésio 10% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "@brasil16050545325",
    "display" : "Sulfato de Magnésio 12,3% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "@brasil14480478151",
    "display" : "Sulfato de Magnésio 176,5 mg/g pó efervescente"
  },
  {
    "code" : "@brasil12461954766",
    "display" : "Sulfato de Magnésio 50% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "@brasil18229476191",
    "display" : "Sulfato de Magnésio 882,5 mg pó efervescente"
  },
  {
    "code" : "@brasil10704462118",
    "display" : "Sulfato de Magnésio 990 mg/g pó para solução oral"
  },
  {
    "code" : "@brasil14112071378",
    "display" : "Sulfato de Morfina 0,1 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12471433003",
    "display" : "Sulfato de Morfina 0,2 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil18617813556",
    "display" : "Sulfato de Morfina 1 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15971766080",
    "display" : "Sulfato de Morfina 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil17175791920",
    "display" : "Sulfato de Morfina 10 mg/mL solução oral"
  },
  {
    "code" : "@brasil16454915911",
    "display" : "Sulfato de Morfina 2 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14759874225",
    "display" : "Sulfato de Quinina 500 mg comprimido"
  },
  {
    "code" : "@brasil18897510372",
    "display" : "Sulfato de Zinco 1 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12986444981",
    "display" : "Sulfato de Zinco 1 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15871410392",
    "display" : "Sulfato de Zinco 17,6 mg/mL solução oral"
  },
  {
    "code" : "@brasil15380310894",
    "display" : "Sulfato de Zinco 2,5mg"
  },
  {
    "code" : "@brasil13597130730",
    "display" : "Sulfato de Zinco 20 mg comprimido para suspensão"
  },
  {
    "code" : "@brasil17665949543",
    "display" : "Sulfato de Zinco 4mg"
  },
  {
    "code" : "@brasil14318094954",
    "display" : "Sulfato Ferroso 0,14 mg/mL + Ácido Fosfórico 4 mg/mL solução oral"
  },
  {
    "code" : "@brasil18226699956",
    "display" : "Sulfato Ferroso 0,83 mg/mL + Ácido Fosfórico 4,67 mg/mL solução oral"
  },
  {
    "code" : "@brasil12764988207",
    "display" : "Sulfato Ferroso 0,91 mg/mL (Ferro 0,18 mg/mL) solução oral"
  },
  {
    "code" : "@brasil16459203571",
    "display" : "Sulfato Ferroso 125 mg/mL (Ferro 25 mg/mL) solução oral"
  },
  {
    "code" : "@brasil11766672879",
    "display" : "Sulfato Ferroso 25 mg/mL (Ferro 5 mg/mL) xarope"
  },
  {
    "code" : "@brasil18499022290",
    "display" : "Sulfato Ferroso 40 mg comprimido"
  },
  {
    "code" : "@brasil18530402375",
    "display" : "Sulfato Ferroso 50 mg/mL (Ferro 10 mg/mL) xarope"
  },
  {
    "code" : "@brasil12267184398",
    "display" : "Sulfato Ferroso 60 mg comprimido"
  },
  {
    "code" : "@brasil12874680414",
    "display" : "Sulfato Ferroso 68 mg/mL (Ferro 13,7 mg/mL) solução oral"
  },
  {
    "code" : "@brasil18513333468",
    "display" : "Sulfeto de Selênio 25 mg/mL xampu"
  },
  {
    "code" : "@brasil10034479311",
    "display" : "Sulfiram 250 mg/g solução"
  },
  {
    "code" : "@brasil11960545043",
    "display" : "Sulfiram 4 g sabonete"
  },
  {
    "code" : "@brasil12919085138",
    "display" : "Sulpirida 20 mg/mL solução oral"
  },
  {
    "code" : "@brasil18587829290",
    "display" : "Sulpirida 200 mg comprimido"
  },
  {
    "code" : "@brasil10142549452",
    "display" : "Sulpirida 25 mg + Bromazepam 1 mg cápsula"
  },
  {
    "code" : "@brasil19262494982",
    "display" : "Sulpirida 50 mg cápsula"
  },
  {
    "code" : "@brasil14654104060",
    "display" : "Sulpirida 50 mg comprimido"
  },
  {
    "code" : "@brasil14526695108",
    "display" : "Sultamicilina 375 mg comprimido"
  },
  {
    "code" : "@brasil13167471524",
    "display" : "Sultamicilina 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil17060921308",
    "display" : "Sultiamo 50 mg comprimido"
  },
  {
    "code" : "@brasil17927819309",
    "display" : "Sumatriptana 100 mg comprimido"
  },
  {
    "code" : "@brasil15423595797",
    "display" : "Sumatriptana 100 mg/mL solução spray"
  },
  {
    "code" : "@brasil15028291999",
    "display" : "Sumatriptana 25 mg comprimido"
  },
  {
    "code" : "@brasil11013259459",
    "display" : "Sumatriptana 50 mg + Naproxeno Sódico 500 mg comprimido"
  },
  {
    "code" : "@brasil18106703624",
    "display" : "Sumatriptana 50 mg comprimido"
  },
  {
    "code" : "@brasil16781981377",
    "display" : "Sumatriptana 6 mg/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil13359821133",
    "display" : "Sumatriptana 85 mg + Naproxeno Sódico 500 mg comprimido"
  },
  {
    "code" : "@brasil12403552076",
    "display" : "Sunitinibe 12,5 mg cápsula"
  },
  {
    "code" : "@brasil15726476706",
    "display" : "Sunitinibe 25 mg cápsula"
  },
  {
    "code" : "@brasil17171091516",
    "display" : "Sunitinibe 50 mg cápsula"
  },
  {
    "code" : "@brasil18957702896",
    "display" : "Tacrolimo 0,3 mg/g pomada"
  },
  {
    "code" : "@brasil14712451242",
    "display" : "Tacrolimo 1 mg cápsula"
  },
  {
    "code" : "@brasil10370737630",
    "display" : "Tacrolimo 1 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil18514180375",
    "display" : "Tacrolimo 1 mg/g pomada"
  },
  {
    "code" : "@brasil12309376030",
    "display" : "Tacrolimo 3 mg/g (0,3%) creme"
  },
  {
    "code" : "@brasil14996752742",
    "display" : "Tacrolimo 5 mg cápsula"
  },
  {
    "code" : "@brasil15172114980",
    "display" : "Tacrolimo 5 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil19331570395",
    "display" : "Tacrolimo 5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil19796934665",
    "display" : "Tadalafila 20 mg comprimido"
  },
  {
    "code" : "@brasil16460121054",
    "display" : "Tadalafila 5 mg comprimido"
  },
  {
    "code" : "@brasil16300783925",
    "display" : "Tafamidis 20 mg cápsula"
  },
  {
    "code" : "@brasil16463048620",
    "display" : "Tafluprosta 15 microgramas/mL solução oftálmica"
  },
  {
    "code" : "@brasil14174295358",
    "display" : "Talidomida 100 mg comprimido"
  },
  {
    "code" : "@brasil13615767240",
    "display" : "Tamoxifeno 10 mg comprimido"
  },
  {
    "code" : "@brasil14716741939",
    "display" : "Tamoxifeno 20 mg comprimido"
  },
  {
    "code" : "@brasil10546040022",
    "display" : "Tansulosina 0,4 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil14573655308",
    "display" : "Tapentadol 100 mg comprimido"
  },
  {
    "code" : "@brasil14532035303",
    "display" : "Tapentadol 100 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil11360980300",
    "display" : "Tapentadol 150 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil18860426551",
    "display" : "Tapentadol 200 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil11286737257",
    "display" : "Tapentadol 250 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil14805312941",
    "display" : "Tapentadol 50 mg comprimido"
  },
  {
    "code" : "@brasil19854974502",
    "display" : "Tapentadol 50 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil13996701857",
    "display" : "Tapentadol 75 mg comprimido"
  },
  {
    "code" : "@brasil18845808363",
    "display" : "Teclozana 10 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil10966353742",
    "display" : "Teclozana 500 mg comprimido"
  },
  {
    "code" : "@brasil14168585671",
    "display" : "Tegaserode 6 mg comprimido"
  },
  {
    "code" : "@brasil13242825271",
    "display" : "Teicoplanina 200 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16487378333",
    "display" : "Teicoplanina 200 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17946228399",
    "display" : "Teicoplanina 200mg"
  },
  {
    "code" : "@brasil14009277794",
    "display" : "Teicoplanina 400 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11969323745",
    "display" : "Teicoplanina 400 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10505946864",
    "display" : "Telaprevir 375 mg comprimido"
  },
  {
    "code" : "@brasil10649997517",
    "display" : "Telmisartana 40 mg + Anlodipino 10 mg comprimido"
  },
  {
    "code" : "@brasil14484566322",
    "display" : "Telmisartana 40 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "@brasil12791392813",
    "display" : "Telmisartana 40 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil14310473625",
    "display" : "Telmisartana 40 mg comprimido"
  },
  {
    "code" : "@brasil10054811312",
    "display" : "Telmisartana 80 mg + Anlodipino 10 mg comprimido"
  },
  {
    "code" : "@brasil18380638720",
    "display" : "Telmisartana 80 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "@brasil13392808429",
    "display" : "Telmisartana 80 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil12109188456",
    "display" : "Telmisartana 80 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "@brasil13394589267",
    "display" : "Telmisartana 80 mg comprimido"
  },
  {
    "code" : "@brasil18121317807",
    "display" : "Temozolomida 100 mg cápsula"
  },
  {
    "code" : "@brasil13185957327",
    "display" : "Temozolomida 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10775338234",
    "display" : "Temozolomida 140 mg cápsula"
  },
  {
    "code" : "@brasil18913100107",
    "display" : "Temozolomida 180 mg cápsula"
  },
  {
    "code" : "@brasil14545486432",
    "display" : "Temozolomida 20 mg cápsula"
  },
  {
    "code" : "@brasil18800327234",
    "display" : "Temozolomida 250 mg cápsula"
  },
  {
    "code" : "@brasil16296842353",
    "display" : "Temozolomida 5 mg cápsula"
  },
  {
    "code" : "@brasil12473429991",
    "display" : "Tenecteplase 40 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12489058721",
    "display" : "Tenecteplase 40 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16626101764",
    "display" : "Tenecteplase 50 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19439123540",
    "display" : "Tenecteplase 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18950267161",
    "display" : "Teniposídeo 50 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15051838376",
    "display" : "Tenofovir 300 mg + Lamivudina 300 mg + Efavirenz 600 mg comprimido"
  },
  {
    "code" : "@brasil18065319486",
    "display" : "Tenofovir 300 mg + Lamivudina 300 mg comprimido"
  },
  {
    "code" : "@brasil15702936233",
    "display" : "Tenofovir 300 mg comprimido"
  },
  {
    "code" : "@brasil12612686679",
    "display" : "Tenoxicam 20 mg comprimido"
  },
  {
    "code" : "@brasil13635066386",
    "display" : "Tenoxicam 20 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15234617426",
    "display" : "Tenoxicam 20 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19431348235",
    "display" : "Tenoxicam 40 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13339992633",
    "display" : "Tenoxicam 40 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19033841171",
    "display" : "Tensirolimo 30 mg/1,2 mL solução e diluente para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14933548749",
    "display" : "Teofilina 100 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil19431123013",
    "display" : "Teofilina 100 mg comprimido"
  },
  {
    "code" : "@brasil13331575525",
    "display" : "Teofilina 120 mg + Efedrina 15 mg comprimido"
  },
  {
    "code" : "@brasil18566320321",
    "display" : "Teofilina 200 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil12188815344",
    "display" : "Teofilina 200mg"
  },
  {
    "code" : "@brasil19000440395",
    "display" : "Teofilina 300 mg cápsula"
  },
  {
    "code" : "@brasil12872163747",
    "display" : "Terbinafina 10 mg/g creme"
  },
  {
    "code" : "@brasil13570600433",
    "display" : "Terbinafina 10 mg/g solução"
  },
  {
    "code" : "@brasil18380923938",
    "display" : "Terbinafina 10 mg/mL solução spray"
  },
  {
    "code" : "@brasil12172644306",
    "display" : "Terbinafina 125 mg comprimido"
  },
  {
    "code" : "@brasil17804487818",
    "display" : "Terbinafina 250 mg comprimido"
  },
  {
    "code" : "@brasil19156652248",
    "display" : "Terbutalina 0,3 mg/mL + Guaifenesina 13,3 mg/mL xarope"
  },
  {
    "code" : "@brasil14910648654",
    "display" : "Terbutalina 0,3 mg/mL xarope"
  },
  {
    "code" : "@brasil10796423498",
    "display" : "Terbutalina 0,5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10824754247",
    "display" : "Terconazol 8 mg/g creme vaginal"
  },
  {
    "code" : "@brasil13452180905",
    "display" : "Teriflunomida 14 mg comprimido"
  },
  {
    "code" : "@brasil18776740289",
    "display" : "Teriparatida 600 microgramas/2,4 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "@brasil18787322274",
    "display" : "Terizidona 250 mg cápsula"
  },
  {
    "code" : "@brasil19682231776",
    "display" : "Terlipressina 0,85 mg/8,5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13223147980",
    "display" : "Terlipressina 1 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16820357902",
    "display" : "Testosterona 10 mg/g gel"
  },
  {
    "code" : "@brasil19225706036",
    "display" : "Testosterona 20 mg/mL solução"
  },
  {
    "code" : "@brasil18746546261",
    "display" : "Testosterona 40 mg cápsula"
  },
  {
    "code" : "@brasil12076654602",
    "display" : "Tetraciclina 20 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil11973325834",
    "display" : "Tetraciclina 25 mg/g + Anfotericina B 12,5 mg/g creme vaginal"
  },
  {
    "code" : "@brasil12409226727",
    "display" : "Tetraciclina 5 mg/g pomada oftálmica"
  },
  {
    "code" : "@brasil13516702262",
    "display" : "Tetraciclina 500 mg cápsula"
  },
  {
    "code" : "@brasil12412878788",
    "display" : "Tetraciclina 500 mg comprimido"
  },
  {
    "code" : "@brasil17348481356",
    "display" : "Tiabendazol 50 mg/g + Neomicina 5 mg/g pomada"
  },
  {
    "code" : "@brasil15611850259",
    "display" : "Tiabendazol 50 mg/g pomada"
  },
  {
    "code" : "@brasil10797820845",
    "display" : "Tiabendazol 50 mg/g sabonete"
  },
  {
    "code" : "@brasil16443695393",
    "display" : "Tiabendazol 50 mg/mL loção"
  },
  {
    "code" : "@brasil18836881552",
    "display" : "Tiabendazol 50 mg/mL suspensão oral"
  },
  {
    "code" : "@brasil18448397355",
    "display" : "Tiabendazol 500 mg comprimido"
  },
  {
    "code" : "@brasil12775074673",
    "display" : "Tiamazol 10 mg comprimido"
  },
  {
    "code" : "@brasil14181927920",
    "display" : "Tiamazol 5 mg comprimido"
  },
  {
    "code" : "@brasil14193718994",
    "display" : "Tiamina 100 mg cápsula"
  },
  {
    "code" : "@brasil11069010198",
    "display" : "Tiamina 100 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil16360385645",
    "display" : "Tiamina 300 mg comprimido"
  },
  {
    "code" : "@brasil12570841453",
    "display" : "Tianeptina 12,5 mg comprimido"
  },
  {
    "code" : "@brasil11503507001",
    "display" : "Tianfenicol 500 mg cápsula"
  },
  {
    "code" : "@brasil10145299219",
    "display" : "Tianfenicol 500 mg comprimido"
  },
  {
    "code" : "@brasil15089070287",
    "display" : "Tibolona 1,25 mg comprimido"
  },
  {
    "code" : "@brasil11716666194",
    "display" : "Tibolona 2,5 mg comprimido"
  },
  {
    "code" : "@brasil14946161185",
    "display" : "Ticagrelor 90 mg comprimido"
  },
  {
    "code" : "@brasil16480021788",
    "display" : "Ticarcilina 3 g + Clavulanato de Potássio 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16916784425",
    "display" : "Ticlopidina 250 mg comprimido"
  },
  {
    "code" : "@brasil13191591223",
    "display" : "Tigeciclina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16865668543",
    "display" : "Timolol 2,5 mg/mL (0,25%) solução oftálmica"
  },
  {
    "code" : "@brasil17714814428",
    "display" : "Timolol 5 mg/mL (0,5%) solução oftálmica"
  },
  {
    "code" : "@brasil18097459474",
    "display" : "Timomodulina 200 mg/mL xarope"
  },
  {
    "code" : "@brasil12588758777",
    "display" : "Timomodulina 80 mg cápsula"
  },
  {
    "code" : "@brasil12999748821",
    "display" : "Timostimulina 2 mg pó e diluente para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19426035301",
    "display" : "Tinidazol 30 mg/g + Miconazol 20 mg/g creme vaginal"
  },
  {
    "code" : "@brasil14564608971",
    "display" : "Tinidazol 500 mg comprimido"
  },
  {
    "code" : "@brasil17556055901",
    "display" : "Tiocolchicosídeo 4 mg comprimido"
  },
  {
    "code" : "@brasil19452770368",
    "display" : "Tiocolchicosídeo 4 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13233987709",
    "display" : "Tioconazol 10 mg/g (1%) creme"
  },
  {
    "code" : "@brasil12679908723",
    "display" : "Tioconazol 10 mg/g (1%) pó"
  },
  {
    "code" : "@brasil13000235894",
    "display" : "Tioconazol 10 mg/g loção"
  },
  {
    "code" : "@brasil12511760034",
    "display" : "Tioconazol 10 mg/mL loção"
  },
  {
    "code" : "@brasil11463344106",
    "display" : "Tioconazol 20 mg/g + Tinidazol 30 mg/g creme vaginal"
  },
  {
    "code" : "@brasil10310104469",
    "display" : "Tioconazol 280 mg/mL solução"
  },
  {
    "code" : "@brasil16899368842",
    "display" : "Tioconazol 65 mg/g creme vaginal"
  },
  {
    "code" : "@brasil10507885701",
    "display" : "Tioconazol 65 mg/g pomada vaginal"
  },
  {
    "code" : "@brasil13774694914",
    "display" : "Tioguanina 40 mg comprimido"
  },
  {
    "code" : "@brasil18803968417",
    "display" : "Tiopental 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18584404882",
    "display" : "Tiopental 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19059228363",
    "display" : "Tioridazina 10 mg comprimido"
  },
  {
    "code" : "@brasil17303603790",
    "display" : "Tioridazina 100 mg comprimido"
  },
  {
    "code" : "@brasil10975596885",
    "display" : "Tioridazina 200 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil16325089768",
    "display" : "Tioridazina 25 mg comprimido"
  },
  {
    "code" : "@brasil19101124803",
    "display" : "Tioridazina 30 mg/mL solução oral"
  },
  {
    "code" : "@brasil18643653100",
    "display" : "Tioridazina 50 mg comprimido"
  },
  {
    "code" : "@brasil17472603410",
    "display" : "Tipranavir 100 mg/mL solução oral"
  },
  {
    "code" : "@brasil17085974649",
    "display" : "Tipranavir 250 mg cápsula"
  },
  {
    "code" : "@brasil15282669704",
    "display" : "Tirofibana 12,5 mg/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13583694707",
    "display" : "Tirotricina 0,1 mg/mL + Hidroxiquinolina 1 mg/mL colutório"
  },
  {
    "code" : "@brasil12575622509",
    "display" : "Tirotricina 0,25 mg/g + Hidroxiquinolina 6,2 mg/g + Fluoreto de Sódio 2,2 mg/g gel"
  },
  {
    "code" : "@brasil10151558675",
    "display" : "Tirotricina 0,3 mg/mL + Hidroxiquinolina 10 mg/mL colutório"
  },
  {
    "code" : "@brasil11747466167",
    "display" : "Tirotricina 1 mg + Hidroxiquinolina 0,7 mg + Benzocaína 5 mg pastilha"
  },
  {
    "code" : "@brasil15402267876",
    "display" : "Tirotricina 1 mg/mL + Hidroxiquinolina 2 mg/mL + Lidocaína 4 mg/mL colutório spray"
  },
  {
    "code" : "@brasil17203027927",
    "display" : "Tirotricina 1,035 mg + Benzocaína 5 mg pastilha"
  },
  {
    "code" : "@brasil14035536556",
    "display" : "Tizanidina 2 mg comprimido"
  },
  {
    "code" : "@brasil16393005228",
    "display" : "Tizanidina 4 mg comprimido"
  },
  {
    "code" : "@brasil13335838058",
    "display" : "Tobramicina 28 mg cápsula para inalação; inalador"
  },
  {
    "code" : "@brasil12117052861",
    "display" : "Tobramicina 3 mg/g + Dexametasona 1 mg/g pomada oftálmica"
  },
  {
    "code" : "@brasil19717354800",
    "display" : "Tobramicina 3 mg/g pomada oftálmica"
  },
  {
    "code" : "@brasil12936937270",
    "display" : "Tobramicina 3 mg/mL (0,3%) + Dexametasona 1 mg/mL (0,1%) suspensão oftálmica"
  },
  {
    "code" : "@brasil14097656079",
    "display" : "Tobramicina 3 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil12232107120",
    "display" : "Tobramicina 60 mg/mL solução para inalação 5 mL; ampola"
  },
  {
    "code" : "@brasil10438364417",
    "display" : "Tobramicina 75 mg/1,5 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil14194434054",
    "display" : "Tobramicina 75 mg/mL solução para inalação 4 mL; flaconete"
  },
  {
    "code" : "@brasil17292899093",
    "display" : "Tocilizumabe 162 mg/0,9 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil16945435176",
    "display" : "Tocilizumabe 200 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16327179292",
    "display" : "Tocilizumabe 80 mg/4 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12325227904",
    "display" : "Tofacitinibe 5 mg comprimido"
  },
  {
    "code" : "@brasil15339946517",
    "display" : "Tolcapona 100 mg comprimido"
  },
  {
    "code" : "@brasil15000390236",
    "display" : "Tolcapona 200 mg comprimido"
  },
  {
    "code" : "@brasil12295766082",
    "display" : "Tolterodina 1 mg comprimido"
  },
  {
    "code" : "@brasil10928543479",
    "display" : "Tolterodina 2 mg comprimido"
  },
  {
    "code" : "@brasil12629686287",
    "display" : "Tolterodina 4 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil19740439632",
    "display" : "Topiramato 100 mg comprimido"
  },
  {
    "code" : "@brasil17878433117",
    "display" : "Topiramato 15 mg cápsula"
  },
  {
    "code" : "@brasil11297276644",
    "display" : "Topiramato 25 mg cápsula"
  },
  {
    "code" : "@brasil19713655698",
    "display" : "Topiramato 25 mg comprimido"
  },
  {
    "code" : "@brasil16966482824",
    "display" : "Topiramato 50 mg comprimido"
  },
  {
    "code" : "@brasil19713953908",
    "display" : "Topotecana 0,25 mg cápsula"
  },
  {
    "code" : "@brasil14406299733",
    "display" : "Topotecana 1 mg cápsula"
  },
  {
    "code" : "@brasil18524045875",
    "display" : "Topotecana 4 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11089845243",
    "display" : "Toxina Botulínica do Tipo A 100 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15227299503",
    "display" : "Toxina Botulínica do Tipo A 200 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16435240483",
    "display" : "Toxina Botulínica do Tipo A 300 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13645944252",
    "display" : "Toxina Botulínica do Tipo A 50 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13682168156",
    "display" : "Toxina Botulínica do Tipo A 500 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15648597948",
    "display" : "Tramadol 100 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil18567128019",
    "display" : "Tramadol 100 mg comprimido"
  },
  {
    "code" : "@brasil10149128994",
    "display" : "Tramadol 100 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil16674580345",
    "display" : "Tramadol 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13363714843",
    "display" : "Tramadol 100 mg/mL solução oral"
  },
  {
    "code" : "@brasil14729581757",
    "display" : "Tramadol 37,5 mg + Paracetamol 325 mg comprimido"
  },
  {
    "code" : "@brasil11460114745",
    "display" : "Tramadol 50 mg cápsula"
  },
  {
    "code" : "@brasil15574581785",
    "display" : "Tramadol 50 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil11807962619",
    "display" : "Tramadol 50 mg comprimido"
  },
  {
    "code" : "@brasil10552618307",
    "display" : "Tramadol 50 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11958018467",
    "display" : "Trametinibe 0,5 mg comprimido"
  },
  {
    "code" : "@brasil12994265697",
    "display" : "Trametinibe 2 mg comprimido"
  },
  {
    "code" : "@brasil19999917287",
    "display" : "Tranilcipromina 10 mg comprimido"
  },
  {
    "code" : "@brasil14316462830",
    "display" : "Trastuzumabe 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10564998546",
    "display" : "Trastuzumabe 100 mg pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12666779292",
    "display" : "Trastuzumabe 150 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10821975478",
    "display" : "Trastuzumabe 160 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10867970334",
    "display" : "Trastuzumabe 440 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14653706925",
    "display" : "Trastuzumabe 440 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19093659815",
    "display" : "Trastuzumabe 600 mg/5mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13141728184",
    "display" : "Travoprosta 0,04 mg/mL + Timolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil15476696513",
    "display" : "Travoprosta 0,04 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil15852679018",
    "display" : "Trazodona 100 mg comprimido"
  },
  {
    "code" : "@brasil13203801123",
    "display" : "Trazodona 150 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil15139157607",
    "display" : "Trazodona 50 mg comprimido"
  },
  {
    "code" : "@brasil15097487562",
    "display" : "Tretinoína 0,1 mg/g gel"
  },
  {
    "code" : "@brasil15479342344",
    "display" : "Tretinoína 0,25 mg/g + Clindamicina 12 mg/g gel"
  },
  {
    "code" : "@brasil15596295524",
    "display" : "Tretinoína 0,25 mg/g creme"
  },
  {
    "code" : "@brasil17147412137",
    "display" : "Tretinoína 0,25 mg/g gel"
  },
  {
    "code" : "@brasil10802522925",
    "display" : "Tretinoína 0,5 mg/g creme"
  },
  {
    "code" : "@brasil16556668863",
    "display" : "Tretinoína 0,5 mg/g gel"
  },
  {
    "code" : "@brasil12121929871",
    "display" : "Tretinoína 1 mg/g creme"
  },
  {
    "code" : "@brasil14126036970",
    "display" : "Tretinoína 1 mg/g gel"
  },
  {
    "code" : "@brasil19940057944",
    "display" : "Tretinoína 10 mg cápsula"
  },
  {
    "code" : "@brasil12243165784",
    "display" : "Triancinolona Acetonida 1 mg/g + Neomicina 2,5 mg/g + Gramicidina 0,25 mg/g + Nistatina 100.000 unidades internacionais/g creme"
  },
  {
    "code" : "@brasil17973177289",
    "display" : "Triancinolona Acetonida 1 mg/g + Neomicina 2,5 mg/g + Gramicidina 0,25 mg/g + Nistatina 100.000 unidades internacionais/g pomada"
  },
  {
    "code" : "@brasil18300336400",
    "display" : "Triancinolona Acetonida 1 mg/g pasta"
  },
  {
    "code" : "@brasil17171382536",
    "display" : "Triancinolona Acetonida 1 mg/g pomada"
  },
  {
    "code" : "@brasil17413231391",
    "display" : "Triancinolona Acetonida 100 mg/5 mL solução para injeção; frasco"
  },
  {
    "code" : "@brasil16604248485",
    "display" : "Triancinolona Acetonida 40 mg/1 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14783316397",
    "display" : "Triancinolona Acetonida 55 microgramas/dose suspensão spray"
  },
  {
    "code" : "@brasil14967806277",
    "display" : "Triancinolona Hexacetonida 100 mg/5 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15489760445",
    "display" : "Triancinolona Hexacetonida 20 mg/1 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil15202122278",
    "display" : "Tribenosídeo 200 mg comprimido"
  },
  {
    "code" : "@brasil13805339133",
    "display" : "Tribenosídeo 400 mg + Lidocaína 40 mg supositório"
  },
  {
    "code" : "@brasil17974536499",
    "display" : "Tribenosídeo 50 mg/g + Lidocaína 20 mg/g creme"
  },
  {
    "code" : "@brasil14560349707",
    "display" : "Triclosana 1% sabonete"
  },
  {
    "code" : "@brasil18536336325",
    "display" : "Triexifenidil 2 mg comprimido"
  },
  {
    "code" : "@brasil11905392371",
    "display" : "Triexifenidil 5 mg comprimido"
  },
  {
    "code" : "@brasil18040916077",
    "display" : "Trifluoperazina 2 mg comprimido"
  },
  {
    "code" : "@brasil15628876922",
    "display" : "Trifluoperazina 5 mg comprimido"
  },
  {
    "code" : "@brasil12517465996",
    "display" : "Triflusal 300 mg cápsula"
  },
  {
    "code" : "@brasil19129224547",
    "display" : "Trifolium pratense 100 mg comprimido"
  },
  {
    "code" : "@brasil17402448473",
    "display" : "Trimebutina 200 mg cápsula"
  },
  {
    "code" : "@brasil11666458491",
    "display" : "Trimetazidina 35 mg comprimido"
  },
  {
    "code" : "@brasil16791995973",
    "display" : "Trimetazidina 35 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil13506463619",
    "display" : "Trióxido de Arsênio 10 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil13667296396",
    "display" : "Trioxisaleno 10 mg cápsula"
  },
  {
    "code" : "@brasil10614390186",
    "display" : "Triprolidina 0,25 mg/mL + Pseudoefedrina 6 mg/mL xarope"
  },
  {
    "code" : "@brasil17282470162",
    "display" : "Triprolidina 2,5 mg + Pseudoefedrina 60 mg comprimido"
  },
  {
    "code" : "@brasil15293429134",
    "display" : "Trombina 2 unidades internacionais/cm² + Fibrinogênio 5,5 mg/cm² implante"
  },
  {
    "code" : "@brasil18557227632",
    "display" : "Trometamol Cetorolaco 10 mg comprimido sublingual"
  },
  {
    "code" : "@brasil17990739239",
    "display" : "Trometamol Cetorolaco 20 mg/mL solução oral"
  },
  {
    "code" : "@brasil11041351761",
    "display" : "Trometamol Cetorolaco 30 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil10871223769",
    "display" : "Trometamol Cetorolaco 4 mg/mL (0,4%) solução oftálmica"
  },
  {
    "code" : "@brasil14361144474",
    "display" : "Trometamol Cetorolaco 4,5 mg/mL (0,45%) solução oftálmica"
  },
  {
    "code" : "@brasil19192051372",
    "display" : "Trometamol Cetorolaco 5 mg/mL (0,5%) solução oftálmica"
  },
  {
    "code" : "@brasil16825385787",
    "display" : "Trometamol Cetorolaco 60 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12083438495",
    "display" : "Tropicamida 10 mg/mL solução oftálmica"
  },
  {
    "code" : "@brasil17969537951",
    "display" : "Ubidecarenona 20 mg/mL xarope"
  },
  {
    "code" : "@brasil16464833966",
    "display" : "Ubidecarenona 200 mg cápsula"
  },
  {
    "code" : "@brasil18415556285",
    "display" : "Ubidecarenona 300 mg cápsula"
  },
  {
    "code" : "@brasil11876902180",
    "display" : "Ubidecarenona 50 mg comprimido"
  },
  {
    "code" : "@brasil19510812049",
    "display" : "Udenafila 100 mg comprimido"
  },
  {
    "code" : "@brasil14604047101",
    "display" : "Ulipristal 30 mg comprimido"
  },
  {
    "code" : "@brasil16409375439",
    "display" : "Uncaria tomentosa 50 mg/g (5%) gel"
  },
  {
    "code" : "@brasil13364988995",
    "display" : "Undecanoato de Testosterona 1 g/4 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil12087716516",
    "display" : "Ureia 100 mg/g creme"
  },
  {
    "code" : "@brasil14676130379",
    "display" : "Ureia 100 mg/g loção"
  },
  {
    "code" : "@brasil19740476363",
    "display" : "Ureia 20% + Ácido Salicílico 3% creme"
  },
  {
    "code" : "@brasil17653651010",
    "display" : "Ureia 200 mg/g creme"
  },
  {
    "code" : "@brasil15101271638",
    "display" : "Ureia 50 mg/g (5%) creme"
  },
  {
    "code" : "@brasil16257637491",
    "display" : "Urofolitropina 150 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11582177114",
    "display" : "Urofolitropina 150 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19487271120",
    "display" : "Urofolitropina 75 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13939416643",
    "display" : "Urofolitropina 75 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14351352483",
    "display" : "Ustequinumabe 45 mg/0,5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12520407206",
    "display" : "Ustequinumabe 45 mg/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil11186880627",
    "display" : "Ustequinumabe 90 mg/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "@brasil15269495112",
    "display" : "Valaciclovir 500 mg comprimido"
  },
  {
    "code" : "@brasil13720497360",
    "display" : "Valerato de Betametasona 0,5 mg/g + Gentamicina 1 mg/g + Tolnaftato 10 mg/g + Clioquinol 10 mg/g creme"
  },
  {
    "code" : "@brasil12259941576",
    "display" : "Valerato de Betametasona 0,5 mg/g + Gentamicina 1 mg/g + Tolnaftato 10 mg/g + Clioquinol 10 mg/g pomada"
  },
  {
    "code" : "@brasil11301879230",
    "display" : "Valerato de Betametasona 1 mg/g + Neomicina 5 mg/g creme"
  },
  {
    "code" : "@brasil12977112551",
    "display" : "Valerato de Betametasona 1 mg/g + Neomicina 5 mg/g pomada"
  },
  {
    "code" : "@brasil16089576980",
    "display" : "Valerato de Betametasona 1 mg/g creme"
  },
  {
    "code" : "@brasil17722267364",
    "display" : "Valerato de Betametasona 1 mg/g loção"
  },
  {
    "code" : "@brasil16169478999",
    "display" : "Valerato de Betametasona 1 mg/g pomada"
  },
  {
    "code" : "@brasil18567505103",
    "display" : "Valerato de Betametasona 1 mg/g solução"
  },
  {
    "code" : "@brasil19154201780",
    "display" : "Valerato de Betametasona 1 mg/mL loção"
  },
  {
    "code" : "@brasil14413870501",
    "display" : "Valerato de Betametasona 2,5 mg/g + Hialuronidase 150 UTR/g pomada"
  },
  {
    "code" : "@brasil19443062699",
    "display" : "Valerato de Diflucortolona 1 mg/g + Clorquinaldol 10 mg/g creme"
  },
  {
    "code" : "@brasil10650896224",
    "display" : "Valerato de Diflucortolona 1 mg/g creme"
  },
  {
    "code" : "@brasil19609234954",
    "display" : "Valerato de Diflucortolona 1 mg/g pomada"
  },
  {
    "code" : "@brasil14724748687",
    "display" : "Valerato de Estradiol 2 mg + Ciproterona 1 mg comprimido"
  },
  {
    "code" : "@brasil11402377328",
    "display" : "Valerato de Estradiol 8 mg + Dienogeste 5 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil12293410013",
    "display" : "Valeriana officinalis 225,75 mg comprimido"
  },
  {
    "code" : "@brasil14274370421",
    "display" : "Valeriana officinalis 250 mg + Humulus lupulus 60 mg comprimido"
  },
  {
    "code" : "@brasil14580419606",
    "display" : "Valeriana officinalis 50 mg cápsula"
  },
  {
    "code" : "@brasil19769803302",
    "display" : "Valganciclovir 450 mg comprimido"
  },
  {
    "code" : "@brasil19410393412",
    "display" : "Valproato de Sódio 200 mg comprimido"
  },
  {
    "code" : "@brasil16657154117",
    "display" : "Valproato de Sódio 200 mg/mL solução oral"
  },
  {
    "code" : "@brasil14124123782",
    "display" : "Valproato de sódio 300 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil12682612623",
    "display" : "Valproato de sódio 300 mg comprimido gastrorresistente"
  },
  {
    "code" : "@brasil14640648777",
    "display" : "Valproato de sódio 500 mg comprimido"
  },
  {
    "code" : "@brasil18239647649",
    "display" : "Valproato de sódio 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil16528003676",
    "display" : "Valsartana 160 mg + Anlodipino 10 mg comprimido"
  },
  {
    "code" : "@brasil19302462727",
    "display" : "Valsartana 160 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "@brasil19473172842",
    "display" : "Valsartana 160 mg + Hidroclorotiazida 12,5 mg + Anlodipino 10 mg comprimido"
  },
  {
    "code" : "@brasil14823155983",
    "display" : "Valsartana 160 mg + Hidroclorotiazida 12,5 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "@brasil19681109942",
    "display" : "Valsartana 160 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil19944835545",
    "display" : "Valsartana 160 mg + Hidroclorotiazida 12,5 mg comprimido e Anlodipino 10 mg comprimido"
  },
  {
    "code" : "@brasil12754139948",
    "display" : "Valsartana 160 mg + Hidroclorotiazida 12,5 mg comprimido e Anlodipino 5 mg comprimido"
  },
  {
    "code" : "@brasil16499444772",
    "display" : "Valsartana 160 mg + Hidroclorotiazida 25 mg + Anlodipino 10 mg comprimido"
  },
  {
    "code" : "@brasil18027756219",
    "display" : "Valsartana 160 mg + Hidroclorotiazida 25 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "@brasil19676860885",
    "display" : "Valsartana 160 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "@brasil14669796678",
    "display" : "Valsartana 160 mg + Hidroclorotiazida 25 mg comprimido e Anlodipino 10 mg comprimido"
  },
  {
    "code" : "@brasil19577526466",
    "display" : "Valsartana 160 mg + Hidroclorotiazida 25 mg comprimido e Anlodipino 5 mg comprimido"
  },
  {
    "code" : "@brasil18915921809",
    "display" : "Valsartana 160 mg comprimido"
  },
  {
    "code" : "@brasil15551518056",
    "display" : "Valsartana 320 mg + Anlodipino 10 mg comprimido"
  },
  {
    "code" : "@brasil16005947733",
    "display" : "Valsartana 320 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "@brasil10348536585",
    "display" : "Valsartana 320 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil12451115018",
    "display" : "Valsartana 320 mg + Hidroclorotiazida 25 mg + Anlodipino 10 mg comprimido"
  },
  {
    "code" : "@brasil17674292200",
    "display" : "Valsartana 320 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "@brasil18237484848",
    "display" : "Valsartana 320 mg comprimido"
  },
  {
    "code" : "@brasil15447374837",
    "display" : "Valsartana 40 mg comprimido"
  },
  {
    "code" : "@brasil15993381668",
    "display" : "Valsartana 80 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "@brasil19340974909",
    "display" : "Valsartana 80 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "@brasil11911774585",
    "display" : "Valsartana 80 mg + Hidroclorotiazida 12,5 mg comprimido e Anlodipino 5 mg comprimido"
  },
  {
    "code" : "@brasil19440317561",
    "display" : "Valsartana 80 mg comprimido"
  },
  {
    "code" : "@brasil11010866109",
    "display" : "Vancomicina 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13545530412",
    "display" : "Vancomicina 500 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16683154967",
    "display" : "Vancomicina 500 mg pó e diluente para solução para injeção; frasco-ampola + bolsa"
  },
  {
    "code" : "@brasil14867034743",
    "display" : "Vancomicina 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16772079835",
    "display" : "Vandetanibe 100 mg comprimido"
  },
  {
    "code" : "@brasil18677690081",
    "display" : "Vandetanibe 300 mg comprimido"
  },
  {
    "code" : "@brasil18993836107",
    "display" : "Vardenafila 10 mg comprimido"
  },
  {
    "code" : "@brasil13198191283",
    "display" : "Vardenafila 10 mg comprimido orodispersível"
  },
  {
    "code" : "@brasil13161618189",
    "display" : "Vardenafila 20 mg comprimido"
  },
  {
    "code" : "@brasil15089540009",
    "display" : "Vardenafila 5 mg comprimido"
  },
  {
    "code" : "@brasil19752717863",
    "display" : "Vareniclina 0,5 mg comprimido"
  },
  {
    "code" : "@brasil13218019597",
    "display" : "Vareniclina 1 mg comprimido"
  },
  {
    "code" : "@brasil13226973732",
    "display" : "Vareniclina 1 mg comprimido e Vareniclina 0,5 mg comprimido"
  },
  {
    "code" : "@brasil12978480897",
    "display" : "Varfarina 1 mg comprimido"
  },
  {
    "code" : "@brasil12234633761",
    "display" : "Varfarina 2,5 mg comprimido"
  },
  {
    "code" : "@brasil13905196350",
    "display" : "Varfarina 5 mg comprimido"
  },
  {
    "code" : "@brasil17528739716",
    "display" : "Varfarina 7,5 mg comprimido"
  },
  {
    "code" : "@brasil16424432838",
    "display" : "Vasopressina 20 unidades/1 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil15070173454",
    "display" : "Vedolizumabe 300 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11929600146",
    "display" : "Vemurafenibe 240 mg comprimido"
  },
  {
    "code" : "@brasil19874568039",
    "display" : "Venlafaxina 150 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil14028339080",
    "display" : "Venlafaxina 150 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil19933330461",
    "display" : "Venlafaxina 37,5 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil19126223406",
    "display" : "Venlafaxina 37,5 mg comprimido"
  },
  {
    "code" : "@brasil17558136056",
    "display" : "Venlafaxina 37,5 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil11793984538",
    "display" : "Venlafaxina 50 mg comprimido"
  },
  {
    "code" : "@brasil19297225482",
    "display" : "Venlafaxina 75 mg cápsula de liberação prolongada"
  },
  {
    "code" : "@brasil14943683811",
    "display" : "Venlafaxina 75 mg comprimido"
  },
  {
    "code" : "@brasil18008397795",
    "display" : "Venlafaxina 75 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil15060869290",
    "display" : "Verapamil 120 mg comprimido"
  },
  {
    "code" : "@brasil19885303329",
    "display" : "Verapamil 120 mg comprimido de liberação retardada"
  },
  {
    "code" : "@brasil14731888205",
    "display" : "Verapamil 240 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil15056180938",
    "display" : "Verapamil 5 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "@brasil11010028235",
    "display" : "Verapamil 80 mg comprimido"
  },
  {
    "code" : "@brasil12279084754",
    "display" : "Verteporfina 15 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil11621628236",
    "display" : "Vigabatrina 500 mg comprimido"
  },
  {
    "code" : "@brasil14622940563",
    "display" : "Vildagliptina 50 mg + Metformina 1 g comprimido"
  },
  {
    "code" : "@brasil15248879635",
    "display" : "Vildagliptina 50 mg + Metformina 500 mg comprimido"
  },
  {
    "code" : "@brasil15641004782",
    "display" : "Vildagliptina 50 mg + Metformina 850 mg comprimido"
  },
  {
    "code" : "@brasil14120727770",
    "display" : "Vildagliptina 50 mg comprimido"
  },
  {
    "code" : "@brasil14087264614",
    "display" : "Vimblastina 10 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17146267672",
    "display" : "Vimblastina 10 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil17989329803",
    "display" : "Viminol 70 mg cápsula"
  },
  {
    "code" : "@brasil19920953742",
    "display" : "Vimpocetina 5 mg comprimido"
  },
  {
    "code" : "@brasil16600286676",
    "display" : "Vincristina 1 mg pó para solução para injeção; ampola"
  },
  {
    "code" : "@brasil18993707026",
    "display" : "Vincristina 1 mg/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18173909388",
    "display" : "Vincristina 2 mg/2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil16564027233",
    "display" : "Vinflunina 100 mg/4 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil13773156984",
    "display" : "Vinflunina 250 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil12613740368",
    "display" : "Vinflunina 50 mg/2 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14729909592",
    "display" : "Vinorelbina 10 mg/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil14956595314",
    "display" : "Vinorelbina 20 mg cápsula"
  },
  {
    "code" : "@brasil12663233346",
    "display" : "Vinorelbina 30 mg cápsula"
  },
  {
    "code" : "@brasil18019496291",
    "display" : "Vinorelbina 50 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil19994924373",
    "display" : "Vismodegibe 150 mg cápsula"
  },
  {
    "code" : "@brasil10295065575",
    "display" : "Vitelinato de Prata 100 mg/mL (10%) solução oftálmica"
  },
  {
    "code" : "@brasil13972630354",
    "display" : "Voriconazol 200 mg comprimido"
  },
  {
    "code" : "@brasil14928938954",
    "display" : "Voriconazol 200 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil18413934154",
    "display" : "Voriconazol 50 mg comprimido"
  },
  {
    "code" : "@brasil16407128064",
    "display" : "Vortioxetina 10 mg comprimido"
  },
  {
    "code" : "@brasil10151138993",
    "display" : "Vortioxetina 5 mg comprimido"
  },
  {
    "code" : "@brasil11517395312",
    "display" : "Xilazina 200 mg/10 mL solução para injeção; frasco"
  },
  {
    "code" : "@brasil10589227359",
    "display" : "Xilometazolina 1 mg/g gel"
  },
  {
    "code" : "@brasil10100108458",
    "display" : "Xilometazolina 1 mg/mL solução nasal"
  },
  {
    "code" : "@brasil18761570236",
    "display" : "Zafirlucaste 20 mg comprimido"
  },
  {
    "code" : "@brasil19392035703",
    "display" : "Zanamivir 5 mg/dose pó para inalação; inalador"
  },
  {
    "code" : "@brasil10734413172",
    "display" : "Zidovudina 10 mg/mL xarope"
  },
  {
    "code" : "@brasil19571326018",
    "display" : "Zidovudina 100 mg cápsula"
  },
  {
    "code" : "@brasil15436069009",
    "display" : "Zidovudina 200 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "@brasil10687996269",
    "display" : "Ziprasidona 40 mg cápsula"
  },
  {
    "code" : "@brasil16929997722",
    "display" : "Ziprasidona 80 mg cápsula"
  },
  {
    "code" : "@brasil11647850834",
    "display" : "Zolmitriptana 2,5 mg comprimido"
  },
  {
    "code" : "@brasil13128192854",
    "display" : "Zolmitriptana 2,5 mg comprimido orodispersível"
  },
  {
    "code" : "@brasil16668230234",
    "display" : "Zolpidem 10 mg comprimido"
  },
  {
    "code" : "@brasil12256271243",
    "display" : "Zolpidem 10 mg comprimido efervescente"
  },
  {
    "code" : "@brasil15468503370",
    "display" : "Zolpidem 12,5 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil12653340353",
    "display" : "Zolpidem 5 mg comprimido sublingual"
  },
  {
    "code" : "@brasil14332395887",
    "display" : "Zolpidem 6,25 mg comprimido de liberação prolongada"
  },
  {
    "code" : "@brasil11175188859",
    "display" : "Zopiclona 7,5 mg comprimido"
  },
  {
    "code" : "@brasil12780187634",
    "display" : "Zuclopentixol 10 mg comprimido"
  },
  {
    "code" : "@brasil12338421606",
    "display" : "Zuclopentixol 25 mg comprimido"
  }]
}

```
